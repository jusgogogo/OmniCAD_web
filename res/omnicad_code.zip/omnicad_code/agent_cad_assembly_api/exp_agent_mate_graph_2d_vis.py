#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Agent Experiment 3: baseline input + mate_graph.json + iterative 2D Vis tool."""
from __future__ import annotations

import json
import os
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional

from cad_assembly_agent_common import (
    main_for_agent_experiment,
    validation_feedback,
)

EXPERIMENT_MODE = "exp_agent_mate_graph_2d_vis"
EXPECT_EDGES = False
REQUIRE_VIEW_PARAMS_FOR_TOOL = True
TOOL_NAME = "2d_vis"

PROMPT_SPEC = {
    "name": EXPERIMENT_MODE,
    "agent_exp_label": "AgentExp3",
    "inputs": ['component_library', 'mate_graph.json', 'reference_views/color_by_component'],
    "baseline_input": True,
    "runtime_tool": "2D Vis rotate + zoom",
    "task": "Mate-graph-fixed pose reconstruction with optional clean rendered screenshot feedback.",
}


# ============================================================
# Mate Types（kept local in this experiment file）
# ============================================================

MATE_TYPE_DEFINITIONS: Dict[str, str] = {
    "MateCoincident": "Selected points, lines, planes, or faces on two components are constrained to be coincident or flush, depending on entity type and alignment.",
    "MateConcentric": "Selected cylindrical, circular, or axial entities on two components are constrained to share a common axis.",
    "MateDistanceDim": "Selected entities on two components are constrained to maintain a specified distance.",
    "MateAngleDim": "Selected entities on two components are constrained to maintain a specified angle.",
    "MateParallel": "Selected planar faces, linear edges, or axes on two components are constrained to remain parallel.",
    "MatePerpendicular": "Selected planar faces, linear edges, or axes on two components are constrained to remain perpendicular.",
    "MateTangent": "Selected curved or planar entities on two components are constrained to remain tangent.",
    "MateLock": "The relative position and orientation between two components are fixed.",
    "MateSymmetric": "Selected entities are constrained to remain symmetric about a specified plane or planar face.",
    "MateWidth": "A tab or component is constrained relative to two opposing width faces, often centered between them.",
    "MatePath": "A selected point, vertex, or feature on one component is constrained to follow a specified path.",
    "MateLinearCoupler": "The linear motions of two components are coupled according to a specified translation ratio.",
    "MateCamFollower": "A follower component is constrained to maintain contact with or follow a cam profile.",
    "MateGearDim": "The rotational motions of two components are coupled according to a specified gear ratio.",
    "MateRackPinionDim": "The rotation of one component and the linear translation of another are coupled according to a rack-and-pinion relationship.",
    "MateScrewDim": "Relative rotation and translation between two components are coupled according to a specified screw pitch.",
    "MateHinge": "Two components are constrained to rotate relative to each other about a shared hinge axis.",
    "MateSlot": "A point, axis, or cylindrical feature is constrained to move within a slot.",
    "MateLimitDistanceDim": "The distance between selected entities is constrained within specified minimum and maximum limits.",
    "MateLimitAngleDim": "The angle between selected entities is constrained within specified minimum and maximum limits.",
    "MateUniversalJoint": "Two rotational axes are coupled through a universal-joint relationship.",
}


# ============================================================
# JSON Schema（kept local in this experiment file）
# ============================================================

ASSEMBLY_PREDICTION_SCHEMA: Dict[str, Any] = {
    "type": "object",
    "properties": {
        "nodes": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "component_id": {"type": "string"},
                    "pose": {
                        "type": "object",
                        "properties": {
                            "position": {
                                "type": "object",
                                "properties": {
                                    "x": {"type": "number"},
                                    "y": {"type": "number"},
                                    "z": {"type": "number"},
                                },
                                "required": ["x", "y", "z"],
                                "additionalProperties": False,
                            },
                            "orientation": {
                                "type": "object",
                                "properties": {
                                    "rx": {"type": "number"},
                                    "ry": {"type": "number"},
                                    "rz": {"type": "number"},
                                },
                                "required": ["rx", "ry", "rz"],
                                "additionalProperties": False,
                            },
                        },
                        "required": ["position", "orientation"],
                        "additionalProperties": False,
                    },
                },
                "required": ["component_id", "pose"],
                "additionalProperties": False,
            },
        },
        "agent_action": {
            "type": "object",
            "properties": {
                "need_next_tool": {"type": "string", "enum": ["yes", "no"]},
                "view_rotation_deg": {
                    "type": ["object", "null"],
                    "properties": {
                        "rx": {"type": "number"},
                        "ry": {"type": "number"},
                        "rz": {"type": "number"},
                    },
                    "required": ["rx", "ry", "rz"],
                    "additionalProperties": False,
                },
                "view_scale": {"type": ["number", "null"]},
            },
            "required": ["need_next_tool", "view_rotation_deg", "view_scale"],
            "additionalProperties": False,
        },
    },
    "required": ["nodes", "agent_action"],
    "additionalProperties": False,
}

# ============================================================
# Response Format（OpenRouter/OpenAI JSON schema）
# ============================================================

response_format = {
    "type": "json_schema",
    "json_schema": {
        "name": f"{EXPERIMENT_MODE}_assembly_prediction_schema",
        "strict": True,
        "schema": ASSEMBLY_PREDICTION_SCHEMA,
    },
}


# ============================================================
# Local JSON / OBJ helpers
# ============================================================

def _json_block(obj: Any) -> str:
    return json.dumps(obj, ensure_ascii=False, indent=2)


def output_schema_example() -> Dict[str, Any]:
    return {
        "nodes": [{"component_id": "c00001", "pose": {"position": {"x": 0.0, "y": 0.0, "z": 0.0}, "orientation": {"rx": 0.0, "ry": 0.0, "rz": 0.0}}}, {"component_id": "c00002", "pose": {"position": {"x": 10.0, "y": 0.0, "z": 0.0}, "orientation": {"rx": 0.0, "ry": 0.0, "rz": 0.0}}}],
        "agent_action": {"need_next_tool": "yes", "view_rotation_deg": {"rx": 0.0, "ry": 0.0, "rz": 0.0}, "view_scale": 1.0},
    }


def obj_file_sections(library_json: Dict[str, Any]) -> str:
    sections: List[str] = []
    for item in library_json.get("library", []) or []:
        if not isinstance(item, dict):
            continue
        lib_id = str(item.get("library_id") or item.get("component_id") or "")
        obj_file = str(item.get("obj_file") or f"{lib_id}.mesh.obj")
        obj_name = obj_file.replace("\\\\", "/").replace("\\", "/").split("/")[-1]
        raw = item.get("raw_obj_text")
        header = f"OBJ_FILE: {obj_name}\nLIBRARY_ID: {lib_id}"
        if raw is None:
            sections.append(header + "\nOBJ_CONTENT: <not provided>")
        else:
            sections.append(header + "\nOBJ_CONTENT:\n```obj\n" + str(raw) + "\n```")
    return "\n\n".join(sections)


def prompt_mate_graph(mate_graph_json: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    data = dict(mate_graph_json or {})
    data.pop("assembly_id", None)
    return data


def used_mate_type_definitions(mate_graph_json: Optional[Dict[str, Any]]) -> Dict[str, str]:
    used: List[str] = []
    for edge in (mate_graph_json or {}).get("edges") or []:
        if not isinstance(edge, dict):
            continue
        mt = str(edge.get("mate_type") or "")
        if mt in MATE_TYPE_DEFINITIONS and mt not in used:
            used.append(mt)
    return {mt: MATE_TYPE_DEFINITIONS[mt] for mt in used}


# ============================================================
# System Prompt（CAD assembly decision agent）
# ============================================================

def build_assembly_decision_system_prompt() -> str:
    return f"""
You are a visual-geometric decision agent for CAD assembly pose reconstruction with a fixed mate graph.

--------------------------------------------------
TASK:

Estimate the absolute pose of each fixed component instance from these inputs:
- component_library: reusable component-template OBJ files referenced by mate_graph.nodes
- mate_graph.json: fixed component instances and known component-level mate constraints
- reference_views/color_by_component: 8 multi-view target assembly images where each component uses a different color and visible edges are highlighted

Return one output node for each component_id in mate_graph.nodes, plus an agent_action yes/no decision for the next runtime tool round.

--------------------------------------------------
OUTPUT FORMAT:

Return one JSON object strictly following this experiment's response_format schema.

--------------------------------------------------
POSE DEFINITION:

- pose is the absolute component pose in the prepared assembly coordinate frame
- position uses x, y, z in millimeters
- orientation uses rx, ry, rz Euler angles in degrees
- The runtime applies each predicted pose to the corresponding component-library OBJ mesh.

--------------------------------------------------
FIXED COMPONENT POLICY:

- mate_graph.nodes is the fixed component instance list for this experiment.
- Output exactly one node for every component_id in mate_graph.nodes.
- Do not add component instances.
- Do not delete component instances.
- Do not rename component_id values.
- Do not output library_id; the runtime attaches library_id from mate_graph.nodes after parsing.
- Do not output edges; mate_graph.edges is the known component-level graph.

--------------------------------------------------
REFERENCE VIEW DEFINITIONS:

- The reference views show the same target assembly from 8 camera directions.
- Use all views together to infer 3D placement from silhouette, occlusion, contact, repeated geometry, edge alignment, and multi-view consistency.
- Components use different visual colors and visible edges are highlighted, so color helps track visible component instances across views.
- If several nodes share one library_id, use component_id together with mate_graph connectivity to infer the correct pose.

--------------------------------------------------
MATE GRAPH DEFINITIONS:

- mate_graph.json is a component-level assembly graph.
- mate_graph.nodes defines the component instances already present in the assembly.
- mate_graph.edges defines known component-level mate constraints between those instances.
- mate_type values in mate_graph.edges are input constraint labels used for pose estimation.

--------------------------------------------------
AGENT ACTION DEFINITIONS:

- agent_action.need_next_tool must be the string "yes" or "no".
- The runtime tool is fixed by the current experiment, so agent_action does not include a tool-name field.
- If need_next_tool="no", no runtime tool will be called. Set view_rotation_deg=null and view_scale=null.
- If need_next_tool="yes", provide both view_rotation_deg and view_scale. The runtime enters the next round only when both are valid.
- view_rotation_deg controls only the camera/view rotation for the next clean render. It does not change component pose.
- view_scale controls only the zoom for the next clean render. It does not scale CAD geometry or assembly dimensions.
- Choose view_rotation_deg and view_scale to make the next render useful for checking the current prediction.
- The runtime evidence is generated from your current output JSON, not from ground truth.
- Set need_next_tool="yes" when the runtime evidence would provide useful additional evidence for checking or correcting the current prediction.
- Set need_next_tool="no" when the current prediction is already sufficiently supported by the component library and reference views.

--------------------------------------------------
ASSEMBLY CONSTRAINTS:

- Predicted poses should form a physically plausible assembly.
- Avoid large unintended interpenetration or physically conflicting placements.
- Known mate_graph.edges, visible contacts, alignments, and reference geometry should be reflected in the predicted poses.

--------------------------------------------------
IMPORTANT:

Output JSON only.
""".strip()


def build_system_prompt() -> str:
    return build_assembly_decision_system_prompt()


# ============================================================
# Prompt（experiment user prompt）
# ============================================================

def build_prompt(
    *,
    assembly_id: str,
    library_json: Dict[str, Any],
    reference_views: Optional[Dict[str, str]] = None,
    reference_view_style: str = "color_by_component",
    reference_assembly_obj: Optional[Dict[str, Any]] = None,
    mate_graph_json: Optional[Dict[str, Any]] = None,
    allowed_mate_types: Optional[List[str]] = None,
    node_policy: str = "predict_subset",
) -> str:
    component_library_text = obj_file_sections(library_json)
    reference_views_text = _json_block(reference_views or {})
    mate_graph_text = _json_block(prompt_mate_graph(mate_graph_json))
    used_mate_type_text = _json_block(used_mate_type_definitions(mate_graph_json))
    return f"""
You are shown one mate-graph-defined CAD assembly through baseline color-by-component reference views.

--------------------------------------------------
TASK:

For each component_id in mate_graph.nodes, predict its absolute pose and decide whether you need the 2D Vis rotate/zoom tool for another round.

--------------------------------------------------
INPUTS:

- component_library
- mate_graph.json
- reference_views/color_by_component

--------------------------------------------------
COMPONENT_LIBRARY:

component_library provides reusable geometry templates referenced by mate_graph.nodes.

{component_library_text}

--------------------------------------------------
MATE_GRAPH:

mate_graph.nodes defines the fixed component instances. In this experiment you must not add, delete, or rename component instances.
mate_graph.edges provides connectivity and pose constraints.

MATE TYPE DEFINITIONS FOR INPUT CONSTRAINTS:
Definitions for mate_type values already present in mate_graph.edges:
{used_mate_type_text}

{mate_graph_text}

--------------------------------------------------
REFERENCE_VIEWS:

The reference views show the same target assembly from 8 camera directions.
Use all views together to infer 3D placement from silhouette, occlusion, contact, repeated geometry, edge alignment, and multi-view consistency.
Components use different visual colors and visible edges are highlighted, so color helps distinguish component instances across views.
If several nodes share one library_id, use component_id together with mate_graph connectivity.

{reference_views_text}

--------------------------------------------------
AVAILABLE RUNTIME TOOL:

Tool name: 2D Vis rotate + zoom

When agent_action.need_next_tool="yes", provide both view_rotation_deg and view_scale. The runtime will apply the current JSON prediction, use the mate-graph component/library mapping, and render one clean ASM-area screenshot.
The screenshot is generated from the predicted assembly only, not from ground truth. 
The runtime enters the next round only when need_next_tool="yes" and both view_rotation_deg and view_scale are present.
Use the requested view rotation and zoom to make the next screenshot useful for checking the current prediction, such as component pose, contact, alignment, occlusion, repeated geometry, or hidden-side placement.

--------------------------------------------------
OUTPUT:

Return nodes and agent_action following the response schema. Do not return edges and do not return library_id.
""".strip()


# ============================================================
# Tool feedback prompt（experiment-specific）
# ============================================================

def build_tool_feedback_prompt(
    *,
    round_index: int,
    tool_mode: str,
    tool_meta: Optional[Dict[str, Any]],
    conflict_report: Optional[Dict[str, Any]],
    fatal: List[str],
    warnings: List[str],
    min_nodes: int,
    expect_edges: bool,
) -> str:
    sections: List[str] = [f"AGENT_TOOL_FEEDBACK_ROUND: {round_index}"]
    sections.append("The original baseline task, component library, mate_graph, and 8 target reference views remain in the conversation context. Use the reference views as the target and the mate_graph as the fixed structural constraint.")
    sections.append("The attached TOOL_IMAGE, if present, is a clean screenshot rendered from your previous node poses after library_id is attached from mate_graph.nodes. It is not ground truth and contains no interactive UI, axes, coordinate labels, or scale widgets.")
    if fatal:
        sections.append(validation_feedback(fatal, {}, min_nodes, expect_edges=expect_edges))
    if warnings:
        sections.append("VALIDATION_WARNINGS:\n" + _json_block(warnings))
    if tool_meta:
        compact = dict(tool_meta)
        if compact.get("png"):
            compact["png"] = Path(str(compact["png"])).name
        sections.append("2D_VIS_RESULT_METADATA:\n" + _json_block(compact))
    sections.append(
        "Compare the tool screenshot with the original 8 reference views and fixed mate_graph constraints. Correct only node poses as needed; keep exactly the fixed mate_graph component_ids."
    )
    sections.append(
        'Return a corrected COMPLETE JSON prediction. Do not output edges and do not output library_id. If another clean view would help, set agent_action.need_next_tool="yes" and provide view_rotation_deg plus view_scale. view_rotation_deg is only the next screenshot camera/view rotation; view_scale is only screenshot zoom. If final, set agent_action.need_next_tool="no".'
    )
    return "\n\n".join(sections)

def make_experiment_tool_feedback(
    *,
    round_index: int,
    tool_mode: str,
    tool_meta: Optional[Dict[str, Any]],
    conflict_report: Optional[Dict[str, Any]],
    fatal: List[str],
    warnings: List[str],
    min_nodes: int,
    expect_edges: bool,
) -> str:
    return build_tool_feedback_prompt(
        round_index=round_index,
        tool_mode=tool_mode,
        tool_meta=tool_meta,
        conflict_report=conflict_report,
        fatal=fatal,
        warnings=warnings,
        min_nodes=min_nodes,
        expect_edges=expect_edges,
    )



# ============================================================
# Experiment-local API call（kept inside each exp_*.py for debugging）
# ============================================================

def call_experiment_api(
    *,
    args: Any,
    messages: List[Dict[str, Any]],
    response_mode: str = "json_schema",
) -> str:
    """Call the model API for this experiment using this file's local schema.

    This mirrors the oneshot experiment style: each exp_*.py owns its prompt,
    response_format/schema, and API call. The common runner only prepares data
    and executes the agent loop.
    """
    if args.provider == "openrouter":
        from openai import OpenAI
        api_key = os.getenv(args.api_key_env) or os.getenv("openrouter")
        if not api_key:
            raise RuntimeError(f"Missing API key environment variable: {args.api_key_env} or openrouter")
        client = OpenAI(api_key=api_key, base_url="https://openrouter.ai/api/v1")
        kwargs: Dict[str, Any] = {
            "model": args.model,
            "messages": messages,
            "temperature": args.temperature,
        }
        if response_mode == "json_schema":
            kwargs["response_format"] = response_format
        elif response_mode == "json_object":
            kwargs["response_format"] = {"type": "json_object"}
        if getattr(args, "openrouter_response_healing", False):
            kwargs["extra_body"] = {"plugins": [{"id": "response-healing"}]}
        response = client.chat.completions.create(**kwargs)
        return response.choices[0].message.content or ""

    if args.provider == "openai":
        from openai import OpenAI
        api_key = os.getenv(args.api_key_env)
        if not api_key:
            raise RuntimeError(f"Missing API key environment variable: {args.api_key_env}")
        client = OpenAI(api_key=api_key)
        kwargs: Dict[str, Any] = {
            "model": args.model,
            "messages": messages,
            "temperature": args.temperature,
        }
        if response_mode == "json_schema":
            kwargs["response_format"] = response_format
        elif response_mode == "json_object":
            kwargs["response_format"] = {"type": "json_object"}
        response = client.chat.completions.create(**kwargs)
        return response.choices[0].message.content or ""

    if args.provider == "azure":
        from openai import AzureOpenAI
        api_key = os.getenv(args.api_key_env)
        endpoint_val = getattr(args, "azure_endpoint", None) or os.getenv(getattr(args, "azure_endpoint_env", "AZURE_OPENAI_ENDPOINT"))
        if not api_key:
            raise RuntimeError(f"Missing API key environment variable: {args.api_key_env}")
        if not endpoint_val:
            raise RuntimeError(f"Missing Azure endpoint. Use --azure-endpoint or {getattr(args, 'azure_endpoint_env', 'AZURE_OPENAI_ENDPOINT')}")
        client = AzureOpenAI(
            api_key=api_key,
            azure_endpoint=endpoint_val,
            api_version=getattr(args, "azure_api_version", None) or "2024-08-01-preview",
        )
        kwargs: Dict[str, Any] = {
            "model": args.model,
            "messages": messages,
            "temperature": args.temperature,
        }
        if response_mode == "json_schema":
            kwargs["response_format"] = response_format
        elif response_mode == "json_object":
            kwargs["response_format"] = {"type": "json_object"}
        response = client.chat.completions.create(**kwargs)
        return response.choices[0].message.content or ""

    raise ValueError(f"Unsupported provider for API call: {args.provider}")


# ============================================================
# Init conversation（kept for template compatibility）
# ============================================================

def init_conversation(
    *,
    assembly_id: str,
    library_json: Dict[str, Any],
    reference_views: Optional[Dict[str, str]] = None,
    reference_view_style: str = "color_by_component",
    reference_assembly_obj: Optional[Dict[str, Any]] = None,
    mate_graph_json: Optional[Dict[str, Any]] = None,
    allowed_mate_types: Optional[List[str]] = None,
    node_policy: str = "predict_subset",
) -> List[Dict[str, Any]]:
    messages: List[Dict[str, Any]] = []

    messages.append({
        "role": "system",
        "content": [{"type": "text", "text": build_system_prompt()}],
    })

    messages.append({
        "role": "user",
        "content": [{
            "type": "text",
            "text": build_prompt(
                assembly_id=assembly_id,
                library_json=library_json,
                reference_views=reference_views,
                reference_view_style=reference_view_style,
                reference_assembly_obj=reference_assembly_obj,
                mate_graph_json=mate_graph_json,
                allowed_mate_types=allowed_mate_types,
                node_policy=node_policy,
            ),
        }],
    })

    return messages


if __name__ == "__main__":
    main_for_agent_experiment(sys.modules[__name__])
