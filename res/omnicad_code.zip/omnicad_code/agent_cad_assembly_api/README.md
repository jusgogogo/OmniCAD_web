# Agent CAD Assembly API

This is the primary README for the current agent experiments.

## Active experiment set

The old five one-shot experiments are not used here. The active code contains four agent experiments, each as an independent `.py` script with its own prompt, schema, `response_format`, and API call logic:

| Label | Script | Input | Runtime tool |
|---|---|---|---|
| AgentExp1 | `exp_agent_2d_vis.py` | Baseline | 2D Vis rotate + zoom |
| AgentExp2 | `exp_agent_walkaround_video.py` | Baseline | Walk-around video / 20 dodecahedron frames |
| AgentExp3 | `exp_agent_mate_graph_2d_vis.py` | Baseline + `mate_graph.json` | 2D Vis rotate + zoom |
| AgentExp4 | `exp_agent_conflict_check_2d_vis.py` | Baseline | Conflict check + 2D Vis |

AgentExp2 remains available in the codebase, but the current reported agent runs use only AgentExp1, AgentExp3, and AgentExp4. Use the `--experiments` argument to explicitly select these three scripts and skip `exp_agent_walkaround_video.py`.

Baseline input means:

```text
component_library/
  <library_id>.mesh.obj
  ...
reference_views/color_by_component/
  front.png
  back.png
  left.png
  right.png
  top.png
  bottom.png
  iso_1.png
  iso_2.png
```

The baseline component library is a reusable OBJ template library. It is not the final instance list and does not tell the model how many times each component is used.

For AgentExp1, AgentExp2, and AgentExp4, the LLM can add or delete component instances during the agent loop if the reference views and tool feedback show the instance count is wrong. The output `component_id` values should remain sequential, for example `c00001`, `c00002`, `c00003`.

AgentExp3 is the exception. `mate_graph.json` directly defines the component instances and graph, so the LLM must not add, delete, or rename component instances. In that experiment it predicts poses only.

## OBJ input mode

The default raw OBJ mode is `full`. The runner sends the complete OBJ text in the initial baseline prompt unless you explicitly override it with `--raw-obj-mode none` or `--raw-obj-mode truncated`.

`--max-raw-obj-chars` is only used when `--raw-obj-mode truncated` is selected. It does not affect the default `full` mode.

## Agent context handling

The code keeps the initial system prompt, component library, and 8 target reference views in the message context for later rounds. This is intentional for OpenRouter/OpenAI Chat Completions style calls, because each API request is constructed from the `messages` list passed in that request. A later prompt that only says “refer to the first round” is not reliable unless the initial context is still included in the request.

To reduce repeated payload growth, later rounds keep all previous assistant JSON predictions, but only the latest tool feedback. Older tool feedback text and older tool images/frames are removed from the next API call, while complete round logs remain saved on disk.

## Agent iteration rule

The agent loop is capped at 10 rounds per sample. The CLI default is `--agent-iterations 10`, and the runtime clamps larger values to 10.

A next round happens only when the model outputs:

```json
"agent_action": {
  "need_next_tool": "yes"
}
```

If the model outputs `"need_next_tool": "no"`, the runtime stops and saves the current prediction.

## Validation retry rule

If a model response is valid JSON but fails semantic/runtime validation, the code retries inside the same agent round instead of immediately consuming another tool-feedback round. The default is `--max-validation-retries 3`, meaning one initial attempt plus up to three correction attempts in that same round.

The code no longer creates separate per-attempt files such as `validation_attempts/round_XX/attempt_YY_<response_mode>/raw_response.txt`. Parsed validation attempts are recorded directly inside the prediction JSON history instead:

```text
assembly_prediction.json
  assembly_id
  status
  rounds[]
    round
    status
    response_mode / started_at / elapsed_sec
    fatal_errors / warnings / agent_action
    prediction                  # validation-passing normalized prediction for this round
    api_attempts[]              # only for API / JSON-parse failures
    validation_attempts[]       # only failed validation/normalization retries
      attempt
      status / fatal_errors / warnings / agent_action
      prediction                # failed attempt JSON, normalized when possible
```

The final prediction is not duplicated at the top level. By convention, the effective prediction is the `prediction` field in the last successful round. API or JSON-parse failures do not count as validation attempts and do not advance the agent to the next round.

Each agent round is written once in `rounds[]`. Validation retries within the same round are kept under that round's `validation_attempts[]`; failed attempts keep their JSON, and the first valid attempt is promoted to the round-level `prediction` field and ends retrying for that round.

Only the validation-passing normalized `round.prediction` is appended to the persistent conversation history for the next agent round. Failed validation attempts and raw model JSON are recorded for debugging when applicable, but they are not given to later tool-feedback rounds. If all validation retries fail, the sample is marked `failed_validation`; to avoid polluting formal evaluation, the best invalid output and its validation-attempt history are saved in `assembly_prediction_best_effort.json`.

For tools that require a requested clean 2D view, the model must also output:

```json
"view_rotation_deg": {"rx": 0.0, "ry": 0.0, "rz": 0.0},
"view_scale": 1.0
```

`view_rotation_deg` controls only the camera/view rotation for the next tool screenshot. It does not change component pose. `view_scale` controls only screenshot zoom. It does not scale CAD geometry or assembly dimensions.

## Tool behavior

### 1. 2D Vis rotate + zoom

Used by AgentExp1 and AgentExp3.

This tool is now a clean automatic render+capture path. It does not rely on the old one-shot interactive HTML screenshot. The runtime applies the current predicted JSON poses to the component OBJ meshes, renders the ASM area, and returns a PNG containing only the predicted assembly.

The feedback image has:

```text
- different component colors
- highlighted visible edges
- no right-side information panel
- no axes
- no coordinate labels
- no scale widgets
- no interactive HTML UI chrome
```

For AgentExp1 and AgentExp3, `need_next_tool="yes"` requires both `view_rotation_deg` and `view_scale`. Without those parameters, the runtime does not enter the next visual feedback round.

### 2. Walk-around video / frames

Used by AgentExp2.

This uses a regular-dodecahedron camera route. The runtime writes one smooth MP4 walkthrough; because the current chat wrapper attaches images, API feedback frames are sampled from that same MP4 rather than rendered as a separate view set.

The frames are prediction renders only. They are generated from the model's current JSON, not from ground truth. The model should use them to inspect hidden-side errors, depth ordering, wrong component orientation, contact, and repeated-instance mistakes.

### 3. Conflict check + 2D Vis

Used by AgentExp4.

If the model sets `need_next_tool="yes"`, the next round receives:

```text
1. CONFLICT_CHECK_RESULT:
   a list of pairs of predicted component instances that physically conflict,
   interpenetrate, or have excessive mesh overlap.

2. TOOL_IMAGE:
   one clean ASM-area 2D Vis screenshot rendered from the same previous JSON.
```

The conflict check uses transformed predicted component meshes. It first computes AABB overlap and, when `trimesh` is available, strengthens the evidence with sampled vertex-containment checks. A valid flush/touching mate should not be treated as wrong by itself; the model should mainly correct meaningful penetration or physically impossible overlap while preserving visible contact and alignment.

For AgentExp4, `view_rotation_deg` and `view_scale` are optional. If supplied, they control only the clean 2D screenshot, not the conflict calculation or component geometry.

## JSON schema

AgentExp1, AgentExp2, and AgentExp4 return:

```json
{
  "nodes": [
    {
      "component_id": "c00001",
      "library_id": "lib00001",
      "pose": {
        "position": {"x": 0.0, "y": 0.0, "z": 0.0},
        "orientation": {"rx": 0.0, "ry": 0.0, "rz": 0.0}
      }
    }
  ],
  "edges": [
    {
      "source_component": "c00001",
      "target_component": "c00002",
      "mate_type": "MateCoincident"
    }
  ],
  "agent_action": {
    "need_next_tool": "yes",
    "view_rotation_deg": {"rx": 0.0, "ry": 0.0, "rz": 0.0},
    "view_scale": 1.0
  }
}
```

AgentExp3 returns `nodes` and `agent_action` only. The runtime restores `library_id` from `mate_graph.nodes`; it does not ask the model to output edges.

## Run the selected three experiments

The current evaluation run excludes AgentExp2 / `exp_agent_walkaround_video.py`. Run only AgentExp1, AgentExp3, and AgentExp4 with:

```powershell
python .\cad_assembly_run_agent_dataset.py "D:\prepared_dataset" ^
  --run-root "D:\agent_runs" ^
  --experiments exp_agent_2d_vis exp_agent_mate_graph_2d_vis exp_agent_conflict_check_2d_vis ^
  --provider openrouter ^
  --model openai/gpt-4.1 ^
  --api-key-env OPENROUTER_API_KEY ^
  --num-workers N ^
  --resume ^
  --openrouter-response-healing
```

## Run one experiment directly

Each experiment can be called independently, like the previous one-shot scripts:

```powershell
python .\exp_agent_2d_vis.py "D:\prepared_dataset" ^
  --out "D:\agent_raw\AgentExp1" ^
  --provider openrouter ^
  --model openai/gpt-4.1 ^
  --api-key-env OPENROUTER_API_KEY ^
  --num-workers N ^
  --resume ^
  --openrouter-response-healing
```

## Output layout

For the selected three-experiment run, the batch runner organizes results as:

```text
agent_runs/
  exp_agent_2d_vis/<sample>/
    component_library/
    reference_views/
    reference_views.json
    assembly_prediction.json
    assembly_prediction_best_effort.json      # only on failed validation / partial best effort
    log.json
    debug/                                    # only when --save-debug is set
  exp_agent_mate_graph_2d_vis/<sample>/
    component_library/
    reference_views/
    mate_graph.json
    assembly_prediction.json
    log.json
  exp_agent_conflict_check_2d_vis/<sample>/
    component_library/
    reference_views/
    assembly_prediction.json
    log.json
  RawApiRun/                                  # only when --resume or --keep-raw-api-run is used
```

Tool images/videos are generated in the runtime loop for the next API request but are not embedded as permanent output files. `assembly_prediction.html` and `mate_graph.html` are not collected by the batch runner. Debug-side raw responses are only written when `--save-debug` is set.
