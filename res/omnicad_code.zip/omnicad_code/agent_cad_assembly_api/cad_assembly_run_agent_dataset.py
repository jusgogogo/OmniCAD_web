#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Stage-B Agent CLI: run agentic API experiments on prepared CAD assembly samples.

This runner starts from the same flat Stage-A prepared samples used by the
baseline visual-input contract. It never opens SolidWorks and never regenerates
the reference views.
"""
from __future__ import annotations

import argparse
import json
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

ROOT = Path(__file__).resolve().parent

DEFAULT_EXPERIMENTS = [
    "exp_agent_2d_vis",
    "exp_agent_walkaround_video",
    "exp_agent_mate_graph_2d_vis",
    "exp_agent_conflict_check_2d_vis",
]

EXPERIMENT_SCRIPT_MAP = {
    "exp_agent_2d_vis": "exp_agent_2d_vis.py",
    "exp_agent_walkaround_video": "exp_agent_walkaround_video.py",
    "exp_agent_mate_graph_2d_vis": "exp_agent_mate_graph_2d_vis.py",
    "exp_agent_conflict_check_2d_vis": "exp_agent_conflict_check_2d_vis.py",
}

EXPERIMENT_LABELS = {
    "exp_agent_2d_vis": "AgentExp1",
    "exp_agent_walkaround_video": "AgentExp2",
    "exp_agent_mate_graph_2d_vis": "AgentExp3",
    "exp_agent_conflict_check_2d_vis": "AgentExp4",
}

INPUT_NAMES = {
    "component_library",
    "reference_views",
    "mate_graph.json",
    "reference_views.json",
}

OUTPUT_NAMES = {
    "assembly_prediction.json",
    "assembly_prediction_best_effort.json",
    "assembly_prediction_html_error.txt",
    "mate_graph_error.txt",
    "log.json",
}

MATE_GRAPH_INPUT_EXPERIMENTS = {"exp_agent_mate_graph_2d_vis"}
MATE_GRAPH_HTML_OUTPUTS = {"mate_graph.html", "mate_graph_error.txt"}


def write_json(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def run_cmd(cmd: List[str], cwd: Optional[Path] = None) -> Dict[str, Any]:
    start = time.time()
    proc = subprocess.run(cmd, cwd=str(cwd) if cwd else None, text=True, capture_output=True)
    return {
        "cmd": cmd,
        "cwd": str(cwd) if cwd else None,
        "returncode": proc.returncode,
        "stdout": proc.stdout,
        "stderr": proc.stderr,
        "elapsed_sec": round(time.time() - start, 3),
    }


def copytree_clean(src: Path, dst: Path) -> bool:
    if dst.exists():
        shutil.rmtree(dst)
    if src.exists():
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copytree(src, dst)
        return True
    return False


def copy_file_if_exists(src: Path, dst: Path) -> bool:
    if not src.exists():
        return False
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)
    return True


def copy_path(src: Path, dst: Path) -> bool:
    if not src.exists():
        return False
    if src.is_dir():
        return copytree_clean(src, dst)
    return copy_file_if_exists(src, dst)


def _replace_strings(obj: Any, replacements: Dict[str, str]) -> Any:
    if isinstance(obj, str):
        out = obj
        for src, dst in replacements.items():
            out = out.replace(src, dst).replace(src.replace("\\", "/"), dst.replace("\\", "/"))
        return out
    if isinstance(obj, list):
        return [_replace_strings(v, replacements) for v in obj]
    if isinstance(obj, dict):
        return {k: _replace_strings(v, replacements) for k, v in obj.items()}
    return obj


def rewrite_json_path_prefixes(root: Path, replacements: Dict[str, str]) -> None:
    if not root.exists() or not replacements:
        return
    paths = [root] if root.is_file() else list(root.rglob("*.json"))
    for path in paths:
        if path.suffix.lower() != ".json":
            continue
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except Exception:
            continue
        new_data = _replace_strings(data, replacements)
        if new_data != data:
            write_json(path, new_data)

def snapshot_code(code_dir: Path) -> None:
    code_dir.mkdir(parents=True, exist_ok=True)
    for pat in ["*.py", "*.md", "*.txt"]:
        for src in ROOT.glob(pat):
            shutil.copy2(src, code_dir / src.name)


def run_experiment(args: argparse.Namespace, exp: str, run_root: Path) -> Dict[str, Any]:
    label = EXPERIMENT_LABELS.get(exp, exp)
    use_persistent_raw = args.keep_raw_api_run or args.resume
    if use_persistent_raw:
        raw_root = run_root / "RawApiRun" / label
        if raw_root.exists() and not args.resume:
            shutil.rmtree(raw_root)
    else:
        raw_root = Path(tempfile.mkdtemp(prefix=f"cad_agent_{label}_"))
    script_name = EXPERIMENT_SCRIPT_MAP.get(exp)
    if not script_name:
        raise ValueError(f"Unsupported agent experiment: {exp}")

    cmd = [
        sys.executable,
        str(ROOT / script_name),
        str(args.prepared_root),
        "--out", str(raw_root),
        "--provider", args.provider,
        "--model", args.model,
        "--api-key-env", args.api_key_env,
        "--retry-sleep-sec", str(args.retry_sleep_sec),
        "--response-mode", args.response_mode,
        "--raw-obj-mode", args.raw_obj_mode,
        "--max-raw-obj-chars", str(args.max_raw_obj_chars),
        "--max-output-tokens", str(args.max_output_tokens),
        "--api-timeout-sec", str(args.api_timeout_sec),
        "--max-full-prompt-chars", str(args.max_full_prompt_chars),
        "--node-policy", args.node_policy,
        "--num-workers", str(args.num_workers),
        "--agent-iterations", str(args.agent_iterations),
        "--max-validation-retries", str(args.max_validation_retries),
        "--min-reference-views", str(args.min_reference_views),
        "--walkaround-frames", str(args.walkaround_frames),
        "--walkaround-fps", str(args.walkaround_fps),
        "--conflict-tolerance-mm", str(args.conflict_tolerance_mm),
        "--conflict-max-pairs", str(args.conflict_max_pairs),
    ]
    if args.recursive:
        cmd.append("--recursive")
    if args.resume:
        cmd.append("--resume")
    if args.max_samples > 0:
        cmd += ["--max-samples", str(args.max_samples)]
    if args.openrouter_response_healing:
        cmd.append("--openrouter-response-healing")
    if args.allow_missing_views:
        cmd.append("--allow-missing-views")
    if args.ignore_preflight:
        cmd.append("--ignore-preflight")
    if args.save_debug:
        cmd.append("--save-debug")
    if args.no_auto_visualize:
        cmd.append("--no-auto-visualize")
    if args.attach_mate_graph_edges_to_prediction:
        cmd.append("--attach-mate-graph-edges-to-prediction")

    result = run_cmd(cmd, cwd=ROOT)
    return {"experiment": exp, **result, "raw_root": str(raw_root)}


def sample_key_from_experiment_dir(exp_dir: Path) -> str:
    if "__" in exp_dir.name:
        return exp_dir.name.rsplit("__", 1)[0]
    return exp_dir.name


def collect_one_experiment_dir(run_root: Path, exp: str, exp_dir: Path) -> Dict[str, Any]:
    sample_key = sample_key_from_experiment_dir(exp_dir)
    output_dir = run_root / exp / sample_key
    if output_dir.exists():
        shutil.rmtree(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    copied_files: List[str] = []
    for src in sorted(exp_dir.iterdir()):
        if src.name in INPUT_NAMES or src.name in OUTPUT_NAMES:
            if exp in MATE_GRAPH_INPUT_EXPERIMENTS and src.name in MATE_GRAPH_HTML_OUTPUTS:
                continue
            copy_path(src, output_dir / src.name)
            copied_files.append(src.name)
        elif src.name == "debug" and src.is_dir():
            copy_path(src, output_dir / "debug")
            copied_files.append("debug")


    rewrite_json_path_prefixes(output_dir, {str(exp_dir): str(output_dir)})

    return {
        "experiment": exp,
        "sample": sample_key,
        "raw_experiment_dir": str(exp_dir),
        "output_dir": str(output_dir),
        "files": sorted(copied_files),
    }


def collect_experiment(run_root: Path, exp: str, raw_root: Path) -> Dict[str, Any]:
    exp_dirs = sorted([p for p in raw_root.iterdir() if p.is_dir()]) if raw_root.exists() else []
    sample_records = [collect_one_experiment_dir(run_root, exp, p) for p in exp_dirs]
    return {
        "experiment": exp,
        "raw_root": str(raw_root),
        "sample_count": len(sample_records),
        "samples": sample_records,
    }


def public_result_record(result: Dict[str, Any]) -> Dict[str, Any]:
    return {
        "experiment": result.get("experiment"),
        "returncode": result.get("returncode"),
        "elapsed_sec": result.get("elapsed_sec"),
    }


def public_collection_record(collection: Dict[str, Any]) -> Dict[str, Any]:
    samples = []
    for rec in collection.get("samples", []):
        samples.append({
            "experiment": rec.get("experiment"),
            "sample": rec.get("sample"),
            "output_dir": rec.get("output_dir"),
            "files": rec.get("files", []),
        })
    return {
        "experiment": collection.get("experiment"),
        "sample_count": collection.get("sample_count"),
        "samples": samples,
    }

def cleanup_path(path: Path) -> None:
    if path.exists():
        shutil.rmtree(path)


def main() -> None:
    ap = argparse.ArgumentParser(description="Run agentic CAD assembly API experiments from prepared samples.")
    ap.add_argument("prepared_root", type=Path, help="Stage-A flat prepared sample folder or prepared dataset root.")
    ap.add_argument("--run-root", "--output-folder", dest="run_root", type=Path, default=Path("cad_assembly_agent_api_runs"))
    ap.add_argument("--experiments", nargs="*", default=DEFAULT_EXPERIMENTS)
    ap.add_argument("--provider", choices=["openai", "openrouter", "azure", "dry-run"], default="openrouter")
    ap.add_argument("--model", default="openai/gpt-4.1")
    ap.add_argument("--api-key-env", default="OPENROUTER_API_KEY")
    ap.add_argument("--retry-sleep-sec", type=float, default=2.0)
    ap.add_argument("--response-mode", choices=["auto", "json_schema", "json_object", "none"], default="json_schema")
    ap.add_argument("--raw-obj-mode", choices=["none", "truncated", "full"], default="full")
    ap.add_argument("--max-raw-obj-chars", type=int, default=20000)
    ap.add_argument("--max-output-tokens", type=int, default=8192, help="Maximum completion tokens passed to each agent script. Use 0 to omit.")
    ap.add_argument("--api-timeout-sec", type=float, default=600.0, help="Per API request timeout in seconds. Use 0 to disable the client timeout.")
    ap.add_argument("--max-full-prompt-chars", type=int, default=0, help="Skip full-OBJ samples before API call when prompt exceeds this character count. 0 disables.")
    ap.add_argument("--node-policy", choices=["predict_subset", "all_library"], default="predict_subset")
    ap.add_argument("--recursive", action="store_true")
    ap.add_argument("--resume", action="store_true")
    ap.add_argument("--max-samples", type=int, default=0)
    ap.add_argument("--openrouter-response-healing", action="store_true")
    ap.add_argument("--allow-missing-views", action="store_true")
    ap.add_argument("--ignore-preflight", action="store_true")
    ap.add_argument("--save-debug", action="store_true")
    viz_group = ap.add_mutually_exclusive_group()
    viz_group.add_argument("--auto-visualize", dest="no_auto_visualize", action="store_false", help="Generate HTML visualizations for debugging.")
    viz_group.add_argument("--no-auto-visualize", dest="no_auto_visualize", action="store_true", help="Do not generate HTML visualizations. This is the default for batch runs.")
    ap.set_defaults(no_auto_visualize=True)
    ap.add_argument("--keep-raw-api-run", action="store_true")
    ap.add_argument("--num-workers", "--workers", dest="num_workers", type=int, default=1)
    ap.add_argument("--agent-iterations", type=int, default=10, help="Maximum agent rounds per sample. Hard-capped at 10.")
    ap.add_argument("--max-validation-retries", type=int, default=3, help="Validation repair attempts within the same agent round before failing the sample.")
    ap.add_argument("--min-reference-views", type=int, default=8)
    ap.add_argument("--walkaround-frames", type=int, default=20)
    ap.add_argument("--walkaround-fps", type=float, default=15.0)
    ap.add_argument("--conflict-tolerance-mm", type=float, default=0.01)
    ap.add_argument("--conflict-max-pairs", type=int, default=200)
    ap.add_argument("--attach-mate-graph-edges-to-prediction", action="store_true")
    args = ap.parse_args()
    args.agent_iterations = max(1, min(int(args.agent_iterations or 1), 10))
    args.walkaround_frames = max(1, int(args.walkaround_frames or 20))

    if args.provider == "openrouter" and args.api_key_env == "OPENAI_API_KEY":
        args.api_key_env = "OPENROUTER_API_KEY"
    if args.provider == "azure" and args.api_key_env == "OPENAI_API_KEY":
        args.api_key_env = "AZURE_OPENAI_API_KEY"

    run_root = args.run_root
    if not (args.keep_raw_api_run or args.resume):
        stale_raw = run_root / "RawApiRun"
        if stale_raw.exists():
            shutil.rmtree(stale_raw)
    run_root.mkdir(parents=True, exist_ok=True)
    print(f"[OUTPUT_FOLDER] {run_root}")
    print("[OUTPUT_LAYOUT] exp_agent_xxx/sample_name/files")
    print(f"[WORKERS] {max(1, int(args.num_workers or 1))}")

    start_ts = time.time()
    results: List[Dict[str, Any]] = []
    collections: List[Dict[str, Any]] = []
    for exp in args.experiments:
        result = run_experiment(args, exp, run_root)
        results.append(result)
        collections.append(collect_experiment(run_root, exp, Path(result["raw_root"])))
        if not (args.keep_raw_api_run or args.resume):
            cleanup_path(Path(result["raw_root"]))

    status = "ok" if all(r.get("returncode") == 0 for r in results) else "completed_with_errors"
    summary = {
        "run_root": str(run_root),
        "status": status,
        "experiments": args.experiments,
        "total_runtime_sec": round(time.time() - start_ts, 3),
        "results": [public_result_record(r) for r in results],
        "collections": [public_collection_record(c) for c in collections],
    }
    print(json.dumps({k: v for k, v in summary.items() if k not in {"results", "collections"}}, ensure_ascii=False, indent=2))
    if status != "ok":
        raise SystemExit(1)


if __name__ == "__main__":
    main()


