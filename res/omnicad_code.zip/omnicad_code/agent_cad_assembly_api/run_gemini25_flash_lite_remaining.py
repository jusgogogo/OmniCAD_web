#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Run remaining Gemini 2.5 Flash-lite agent samples from prepared subset folders."""
from __future__ import annotations

import subprocess
import sys
import time
from pathlib import Path


ROOT = Path(__file__).resolve().parent
RUN_ROOT = Path("<RUN_ROOT>")
SUBSET_ROOT = RUN_ROOT / "prepared_subsets"
MODEL = "google/gemini-2.5-flash-lite"

JOBS = [
    ("exp_agent_2d_vis", "exp_agent_2d_vis_remaining_402_only"),
    ("exp_agent_mate_graph_2d_vis", "exp_agent_mate_graph_2d_vis_remaining_402_and_notrun"),
    ("exp_agent_conflict_check_2d_vis", "exp_agent_conflict_check_2d_vis_all200"),
]


def main() -> int:
    log_dir = RUN_ROOT / "_process_logs"
    log_dir.mkdir(parents=True, exist_ok=True)
    rc = 0
    with (log_dir / "gemini_2_5_flash_lite_remaining.log").open("a", encoding="utf-8") as log:
        log.write(f"\n### START {time.strftime('%Y-%m-%d %H:%M:%S')} Gemini 2.5 Flash-lite remaining ###\n")
        log.flush()
        for exp, subset_name in JOBS:
            subset = SUBSET_ROOT / subset_name
            out = RUN_ROOT / "gemini_2_5_flash_lite" / exp
            cmd = [
                sys.executable,
                str(ROOT / "cad_assembly_run_agent_dataset.py"),
                str(subset),
                "--run-root",
                str(out),
                "--experiments",
                exp,
                "--provider",
                "openrouter",
                "--model",
                MODEL,
                "--api-key-env",
                "OPENROUTER_API_KEY",
                "--response-mode",
                "json_schema",
                "--raw-obj-mode",
                "full",
                "--max-full-prompt-chars",
                "0",
                "--max-output-tokens",
                "8192",
                "--api-timeout-sec",
                "600",
                "--agent-iterations",
                "10",
                "--max-validation-retries",
                "3",
                "--num-workers",
                "4",
                "--openrouter-response-healing",
                "--resume",
            ]
            log.write(f"\n===== {time.strftime('%Y-%m-%d %H:%M:%S')} {exp} =====\n")
            log.write(" ".join(f'"{x}"' if " " in x else x for x in cmd) + "\n")
            log.flush()
            proc = subprocess.run(cmd, cwd=str(ROOT), text=True, stdout=log, stderr=log)
            log.write(f"\n[RETURN_CODE] {proc.returncode}\n")
            log.flush()
            rc = max(rc, int(proc.returncode))
        log.write(f"\n### END {time.strftime('%Y-%m-%d %H:%M:%S')} rc={rc} ###\n")
        log.flush()
    return rc


if __name__ == "__main__":
    raise SystemExit(main())
