#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Shared runtime utilities for agentic CAD assembly experiments.

The active experiment layer is agent-only. The four runnable experiment entry
points are:
  exp_agent_2d_vis.py
  exp_agent_walkaround_video.py
  exp_agent_mate_graph_2d_vis.py
  exp_agent_conflict_check_2d_vis.py

All four start from the same baseline visual input contract: deduplicated
component OBJ library plus color-by-component reference views. AgentExp3 may
optionally consume mate_graph.json as an extra structural condition, matching the
"Baseline + Mate graph + 2D Vis" experiment design.
"""
from __future__ import annotations

import base64
import json
import mimetypes
import re
import shutil
import tempfile
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from cad_assembly_dataset import VIEW_NAMES


EXPERIMENT_MODES: Dict[str, str] = {
    "exp_agent_2d_vis": "baseline input + iterative 2D visualization tool",
    "exp_agent_walkaround_video": "baseline input + iterative walk-around video/frame tool",
    "exp_agent_mate_graph_2d_vis": "baseline input + mate_graph.json + iterative 2D visualization tool",
    "exp_agent_conflict_check_2d_vis": "baseline input + conflict check + iterative 2D visualization tool",
}


def read_json(path: Path) -> Any:
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def write_json(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


def write_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text or "", encoding="utf-8")


def image_to_data_url(path: Path) -> str:
    mime = mimetypes.guess_type(path.as_posix())[0] or "image/png"
    return f"data:{mime};base64," + base64.b64encode(path.read_bytes()).decode("ascii")


def extract_json_from_text(text: str) -> Dict[str, Any]:
    text = (text or "").strip()
    if text.startswith("```"):
        text = re.sub(r"^```(?:json)?\s*", "", text)
        text = re.sub(r"\s*```$", "", text)
    try:
        value = json.loads(text)
        if isinstance(value, dict):
            return value
    except Exception:
        pass
    starts = [m.start() for m in re.finditer(r"\{", text)]
    last_error: Optional[Exception] = None
    for start in starts:
        depth = 0
        in_str = False
        esc = False
        for i in range(start, len(text)):
            ch = text[i]
            if in_str:
                if esc:
                    esc = False
                elif ch == "\\":
                    esc = True
                elif ch == '"':
                    in_str = False
            else:
                if ch == '"':
                    in_str = True
                elif ch == "{":
                    depth += 1
                elif ch == "}":
                    depth -= 1
                    if depth == 0:
                        block = text[start:i + 1]
                        try:
                            val = json.loads(block)
                            if isinstance(val, dict):
                                return val
                        except Exception as exc:
                            last_error = exc
                        break
    if last_error:
        raise last_error
    raise ValueError("No JSON object found in response")


def edge_pair(edge: Dict[str, Any]) -> Tuple[Optional[str], Optional[str]]:
    comps = edge.get("components")
    if isinstance(comps, list) and len(comps) >= 2:
        return str(comps[0]), str(comps[1])
    a = edge.get("source_component") or edge.get("component_a") or edge.get("from") or edge.get("source")
    b = edge.get("target_components") or edge.get("target_component") or edge.get("component_b") or edge.get("to") or edge.get("target")
    return (str(a) if a else None, str(b) if b else None)


def mate_graph_node_map(mate_graph: Optional[Dict[str, Any]]) -> Dict[str, str]:
    out: Dict[str, str] = {}
    for node in (mate_graph or {}).get("nodes") or []:
        if not isinstance(node, dict):
            continue
        cid = str(node.get("component_id") or "")
        lib_id = str(node.get("library_id") or "")
        if cid and lib_id:
            out[cid] = lib_id
    return out


def normalize_prediction(pred: Dict[str, Any], assembly_id: str, expect_edges: bool = True, mate_graph: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """Normalize model JSON into the final prediction shape."""
    pred = dict(pred or {})
    raw_nodes = pred.get("nodes") or pred.get("node_parts") or []
    graph_library_by_component = mate_graph_node_map(mate_graph) if not expect_edges else {}
    nodes: List[Dict[str, Any]] = []
    for n in raw_nodes:
        if not isinstance(n, dict):
            continue
        cid = n.get("component_id") or n.get("id")
        if not cid:
            continue
        pose = n.get("pose") if isinstance(n.get("pose"), dict) else {}
        pos = pose.get("position") if isinstance(pose.get("position"), dict) else (n.get("position") or {})
        ori = pose.get("orientation") if isinstance(pose.get("orientation"), dict) else (n.get("orientation") or {})
        node_out = {
            "component_id": str(cid),
            "library_id": str(n.get("library_id") or graph_library_by_component.get(str(cid), "")),
            "pose": {
                "position": {
                    "x": float(pos.get("x", 0.0)),
                    "y": float(pos.get("y", 0.0)),
                    "z": float(pos.get("z", 0.0)),
                },
                "orientation": {
                    "rx": float(ori.get("rx", 0.0)),
                    "ry": float(ori.get("ry", 0.0)),
                    "rz": float(ori.get("rz", 0.0)),
                },
            },
        }
        nodes.append(node_out)

    out: Dict[str, Any] = {"assembly_id": str(assembly_id), "nodes": nodes}
    if expect_edges:
        edges: List[Dict[str, Any]] = []
        for e in pred.get("edges") or []:
            if not isinstance(e, dict):
                continue
            a, b = edge_pair(e)
            if not a or not b:
                continue
            mt = str(e.get("mate_type") or "").strip()
            if not mt:
                continue
            edges.append({
                "source_component": str(a),
                "target_component": str(b),
                "mate_type": mt,
            })
        out["edges"] = edges
    return out


def library_ids(library_json: Dict[str, Any]) -> List[str]:
    return [
        str(x.get("library_id") or x.get("component_id"))
        for x in library_json.get("library", [])
        if isinstance(x, dict) and (x.get("library_id") or x.get("component_id"))
    ]


def minimum_node_count(library_json: Dict[str, Any], mate_graph: Optional[Dict[str, Any]]) -> int:
    graph_nodes = mate_graph_node_map(mate_graph)
    if graph_nodes:
        return len(graph_nodes)
    return len(library_ids(library_json))


def response_modes(provider: str, requested: str) -> List[str]:
    """Return the response_format fallback order for one API attempt."""
    if requested != "auto":
        return [requested]
    if provider in {"openai", "openrouter", "azure"}:
        return ["json_schema", "json_object", "none"]
    return ["none"]


def validation_feedback(fatal: List[str], pred: Dict[str, Any], min_nodes: int, expect_edges: bool = True) -> str:
    node_count = len(pred.get("nodes") or [])
    edge_count = len(pred.get("edges") or [])
    if expect_edges:
        edge_instruction = "Infer and output mate edges between adjacent/connected component instances."
    else:
        edge_instruction = "Do not output edges. The input mate_graph.json already defines all component-level mates; only correct the node poses."
    return (
        "\n\nVALIDATION_FEEDBACK_FOR_RETRY:\n"
        f"The previous JSON was rejected. Fatal errors: {fatal}.\n"
        f"It contained {node_count} node(s) and {edge_count} edge(s). "
        f"Output at least {min_nodes} component nodes so every required component instance is represented. "
        "Do not collapse the whole assembly into one salient component. "
        "Infer repeated uses as separate component instances when the experiment requires open-set reconstruction. "
        f"{edge_instruction}\n"
    )


def validate_prediction(pred: Dict[str, Any], library_json: Dict[str, Any], mate_graph: Optional[Dict[str, Any]], exp_module) -> Tuple[List[str], List[str]]:
    fatal: List[str] = []
    warnings: List[str] = []
    valid_library_ids = set(library_ids(library_json))
    required_graph_nodes = mate_graph_node_map(mate_graph)
    expect_edges = bool(getattr(exp_module, "EXPECT_EDGES", True))
    allowed_mates = set(getattr(exp_module, "MATE_TYPE_DEFINITIONS", {}).keys())

    nodes = pred.get("nodes") if isinstance(pred.get("nodes"), list) else []
    node_ids = [str(n.get("component_id")) for n in nodes if isinstance(n, dict) and n.get("component_id")]
    node_id_set = set(node_ids)

    if len(node_ids) != len(node_id_set):
        fatal.append("duplicate_node_component_ids")

    min_nodes = minimum_node_count(library_json, mate_graph)
    if len(node_id_set) < min_nodes:
        fatal.append(f"too_few_nodes_for_assembly:min={min_nodes}:got={len(node_id_set)}")

    if required_graph_nodes:
        required_ids = list(required_graph_nodes.keys())
        missing_ids = [cid for cid in required_ids if cid not in node_id_set]
        extra_ids = [cid for cid in node_ids if cid not in required_graph_nodes]
        if missing_ids:
            fatal.append(f"missing_required_nodes={missing_ids}")
        if extra_ids:
            fatal.append(f"extra_nodes_beyond_mate_graph={extra_ids}")
    else:
        expected_ids = [f"c{i:05d}" for i in range(1, len(nodes) + 1)]
        if node_ids != expected_ids:
            fatal.append(f"component_ids_not_sequential:expected={expected_ids}:got={node_ids}")

    used_library_ids: List[str] = []
    pose_keys: List[tuple[float, float, float, float, float, float]] = []
    for n in nodes:
        if not isinstance(n, dict):
            fatal.append("non_object_node")
            continue
        cid = str(n.get("component_id") or "")
        lib_id = str(n.get("library_id") or "")
        if not lib_id:
            fatal.append(f"missing_library_id:{cid}")
        elif lib_id not in valid_library_ids:
            fatal.append(f"library_id_not_allowed:{cid}:{lib_id}")
        else:
            used_library_ids.append(lib_id)
        if required_graph_nodes and cid in required_graph_nodes and lib_id != required_graph_nodes[cid]:
            fatal.append(f"library_id_mismatch:{cid}:expected={required_graph_nodes[cid]}:got={lib_id}")
        pose = n.get("pose") or {}
        pos = pose.get("position") or {}
        ori = pose.get("orientation") or {}
        for k in ("x", "y", "z"):
            if not isinstance(pos.get(k), (int, float)):
                fatal.append(f"bad_position:{cid}:{k}")
        for k in ("rx", "ry", "rz"):
            if not isinstance(ori.get(k), (int, float)):
                fatal.append(f"bad_orientation:{cid}:{k}")
        if all(isinstance(pos.get(k), (int, float)) for k in ("x", "y", "z")) and all(isinstance(ori.get(k), (int, float)) for k in ("rx", "ry", "rz")):
            pose_keys.append(tuple(round(float((pos if i < 3 else ori).get(k)), 6) for i, k in enumerate(("x", "y", "z", "rx", "ry", "rz"))))

    if len(pose_keys) >= 3:
        counts: Dict[tuple[float, float, float, float, float, float], int] = {}
        for key in pose_keys:
            counts[key] = counts.get(key, 0) + 1
        max_same_pose = max(counts.values()) if counts else 0
        if max_same_pose == len(pose_keys):
            fatal.append("all_component_poses_identical")
        elif max_same_pose >= max(3, int(0.75 * len(pose_keys))):
            fatal.append(f"too_many_components_share_identical_pose:{max_same_pose}/{len(pose_keys)}")

    if not required_graph_nodes:
        missing_libraries = [lib_id for lib_id in library_ids(library_json) if lib_id not in set(used_library_ids)]
        if missing_libraries:
            fatal.append(f"unused_library_ids={missing_libraries}")

    if not expect_edges:
        if "edges" in pred:
            fatal.append("edges_not_allowed_for_mate_graph_experiment")
        return fatal, warnings

    seen = set()
    for e in pred.get("edges") or []:
        if not isinstance(e, dict):
            fatal.append("non_object_edge")
            continue
        a, b = edge_pair(e)
        mt = str(e.get("mate_type") or "")
        if not a or not b:
            fatal.append(f"bad_edge_components={e}")
            continue
        if a == b:
            fatal.append(f"self_edge={a}")
        if node_id_set and (a not in node_id_set or b not in node_id_set):
            fatal.append(f"edge_endpoint_not_allowed={a},{b}")
        if mt not in allowed_mates:
            fatal.append(f"mate_type_not_allowed={mt}")
        key = tuple(sorted([a, b]) + [mt])
        if key in seen:
            warnings.append(f"duplicate_edge={key}")
        seen.add(key)
    return fatal, warnings


def image_paths_from_views(sample_dir: Path, views: Dict[str, str]) -> List[Path]:
    out: List[Path] = []
    ordered_keys = list(VIEW_NAMES) + [k for k in sorted(views.keys()) if k not in set(VIEW_NAMES)]
    for view in ordered_keys:
        p = views.get(view)
        if not p:
            continue
        pp = Path(p)
        if not pp.is_absolute():
            pp = sample_dir / pp
        if pp.exists():
            out.append(pp)
    return out


def maybe_visualize_outputs(
    sample_dir: Path,
    prediction_json: Path,
    output_dir: Path,
    obj_kind: str,
    enabled: bool,
    generate_mate_graph_html: bool = True,
) -> None:
    if not enabled or not prediction_json.exists():
        return
    try:
        from cad_assembly_visualize_prediction import visualize
        with tempfile.TemporaryDirectory(prefix="cad_agent_vis_") as tmp:
            tmp_dir = Path(tmp)
            visualize(sample_dir, prediction_json, tmp_dir, obj_kind=obj_kind)
            html_path = tmp_dir / "assembly_prediction.html"
            if html_path.exists():
                shutil.copy2(html_path, output_dir / "assembly_prediction.html")
    except Exception as exc:
        write_text(output_dir / "assembly_prediction_html_error.txt", repr(exc))
    if not generate_mate_graph_html:
        for stale_name in ("mate_graph.html", "mate_graph_error.txt"):
            stale_path = output_dir / stale_name
            if stale_path.exists():
                stale_path.unlink()
        return
    try:
        from cad_assembly_visualize_graph import graph_html
        pred = read_json(prediction_json)
        html = graph_html(pred, sample_dir=sample_dir, obj_kind=obj_kind)
        write_text(output_dir / "mate_graph.html", html)
    except Exception as exc:
        write_text(output_dir / "mate_graph_error.txt", repr(exc))


def finalize_sample_status(status: Dict[str, Any], start_ts: float) -> Dict[str, Any]:
    end_ts = time.time()
    status = dict(status)
    status["end_time"] = time.strftime("%Y-%m-%d %H:%M:%S")
    status["runtime_sec"] = round(end_ts - start_ts, 3)
    status["sample_runtime_sec"] = status["runtime_sec"]
    status.setdefault("elapsed_sec", status["runtime_sec"])
    return status


def build_log_payload(statuses: List[Dict[str, Any]], start_time: Optional[str] = None, start_ts: Optional[float] = None, experiment_mode: Optional[str] = None) -> Dict[str, Any]:
    end_ts = time.time()
    success = sum(1 for s in statuses if str(s.get("status", "")).startswith("ok") or s.get("status") == "max_iterations_reached")
    run_times = [{
        "sample": Path(str(s.get("sample_dir") or "")).name,
        "sample_dir": s.get("sample_dir"),
        "experiment_dir": s.get("experiment_dir"),
        "runtime_sec": s.get("runtime_sec"),
        "status": s.get("status"),
    } for s in statuses]
    return {
        "experiment_mode": experiment_mode or (statuses[0].get("experiment_mode") if statuses else None),
        "start_time": start_time or (statuses[0].get("start_time") if statuses else time.strftime("%Y-%m-%d %H:%M:%S")),
        "end_time": time.strftime("%Y-%m-%d %H:%M:%S"),
        "total_success": success,
        "total_fail": len(statuses) - success,
        "total_run": len(statuses),
        "total_runtime_sec": round(end_ts - start_ts, 3) if start_ts is not None else None,
        "run_time_of_each_sample": run_times,
        "samples": statuses,
    }


def write_experiment_log(experiment_dir: Path, status: Dict[str, Any], start_time: str, start_ts: float) -> None:
    write_json(experiment_dir / "log.json", build_log_payload([status], start_time=start_time, start_ts=start_ts, experiment_mode=str(status.get("experiment_mode") or "")))


def finalize_and_write_sample_status(status: Dict[str, Any], start_ts: float, experiment_dir: Path, start_time: str) -> Dict[str, Any]:
    finalized = finalize_sample_status(status, start_ts)
    write_experiment_log(experiment_dir, finalized, start_time=start_time, start_ts=start_ts)
    return finalized
