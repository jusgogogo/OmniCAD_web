#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Shared runtime for agentic CAD assembly experiments."""
from __future__ import annotations

import argparse
import base64
import json
import mimetypes
import os
import re
import shutil
import sys
import time
import tempfile
import subprocess
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from cad_assembly_dataset import (
    VIEW_NAMES,
    discover_component_library,
    discover_dataset_samples,
    find_reference_views,
    load_exported_gt,
    load_or_build_mate_graph,
)
from cad_assembly_stage2_common import (
    extract_json_from_text,
    image_paths_from_views,
    library_ids,
    mate_graph_node_map,
    minimum_node_count,
    normalize_prediction,
    read_json,
    response_modes,
    validate_prediction,
    validation_feedback,
    write_json,
    write_text,
    maybe_visualize_outputs,
    finalize_and_write_sample_status,
    build_log_payload,
    write_experiment_log,
    finalize_sample_status,
)
from cad_assembly_agent_tools import (
    action_from_response,
    conflict_check,
    render_2d_vis_tool,
    render_walkaround_tool,
)


def remove_file_if_exists(path: Path) -> None:
    try:
        if path.exists():
            path.unlink()
    except OSError:
        pass


MATE_TYPE_DEFINITIONS: Dict[str, str] = {
    "MateCoincident": "Selected points, lines, planes, or faces on two components are constrained to be coincident or flush, depending on entity type and alignment.",
    "MateConcentric": "Selected cylindrical, circular, or axial entities on two components are constrained to share a common axis.",
    "MateDistanceDim": "Selected entities on two components are constrained to maintain a specified distance.",
    "MateAngleDim": "Selected entities on two components are constrained to maintain a specified angle.",
    "MateParallel": "Selected planar faces, linear edges, or axes on two components are constrained to remain parallel.",
    "MatePerpendicular": "Selected planar faces, linear edges, or axes on two components are constrained to remain perpendicular.",
    "MateTangent": "Selected curved or planar entities on two components are constrained to remain tangent.",
    "MateLock": "The relative position and orientation between two components are fixed.",
    "MateSymmetric": "Selected entities are constrained to remain symmetric about a specified plane or planar face.",
    "MateWidth": "A tab or component is constrained relative to two opposing width faces, often centered between them.",
    "MatePath": "A selected point, vertex, or feature on one component is constrained to follow a specified path.",
    "MateLinearCoupler": "The linear motions of two components are coupled according to a specified translation ratio.",
    "MateCamFollower": "A follower component is constrained to maintain contact with or follow a cam profile.",
    "MateGearDim": "The rotational motions of two components are coupled according to a specified gear ratio.",
    "MateRackPinionDim": "The rotation of one component and the linear translation of another are coupled according to a rack-and-pinion relationship.",
    "MateScrewDim": "Relative rotation and translation between two components are coupled according to a specified screw pitch.",
    "MateHinge": "Two components are constrained to rotate relative to each other about a shared hinge axis.",
    "MateSlot": "A point, axis, or cylindrical feature is constrained to move within a slot.",
    "MateLimitDistanceDim": "The distance between selected entities is constrained within specified minimum and maximum limits.",
    "MateLimitAngleDim": "The angle between selected entities is constrained within specified minimum and maximum limits.",
    "MateUniversalJoint": "Two rotational axes are coupled through a universal-joint relationship.",
}


def agent_prediction_schema(expect_edges: bool = True) -> Dict[str, Any]:
    node_item = {
        "type": "object",
        "properties": {
            "component_id": {"type": "string"},
            "library_id": {"type": "string"},
            "pose": {
                "type": "object",
                "properties": {
                    "position": {
                        "type": "object",
                        "properties": {"x": {"type": "number"}, "y": {"type": "number"}, "z": {"type": "number"}},
                        "required": ["x", "y", "z"],
                        "additionalProperties": False,
                    },
                    "orientation": {
                        "type": "object",
                        "properties": {"rx": {"type": "number"}, "ry": {"type": "number"}, "rz": {"type": "number"}},
                        "required": ["rx", "ry", "rz"],
                        "additionalProperties": False,
                    },
                },
                "required": ["position", "orientation"],
                "additionalProperties": False,
            },
        },
        "required": ["component_id", "library_id", "pose"],
        "additionalProperties": False,
    }
    action = {
        "type": "object",
        "properties": {
            "need_next_tool": {"type": "string", "enum": ["yes", "no"]},
            "view_rotation_deg": {
                "type": ["object", "null"],
                "properties": {"rx": {"type": "number"}, "ry": {"type": "number"}, "rz": {"type": "number"}},
                "required": ["rx", "ry", "rz"],
                "additionalProperties": False,
            },
            "view_scale": {"type": ["number", "null"]},
        },
        "required": ["need_next_tool", "view_rotation_deg", "view_scale"],
        "additionalProperties": False,
    }
    properties: Dict[str, Any] = {"nodes": {"type": "array", "items": node_item}, "agent_action": action}
    required = ["nodes", "agent_action"]
    if expect_edges:
        properties["edges"] = {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "source_component": {"type": "string"},
                    "target_component": {"type": "string"},
                    "mate_type": {"type": "string", "enum": list(MATE_TYPE_DEFINITIONS.keys())},
                },
                "required": ["source_component", "target_component", "mate_type"],
                "additionalProperties": False,
            },
        }
        required.append("edges")
    return {"type": "object", "properties": properties, "required": required, "additionalProperties": False}


def _json_block(obj: Any) -> str:
    return json.dumps(obj, ensure_ascii=False, indent=2)


def image_to_data_url(path: Path) -> str:
    mime = mimetypes.guess_type(path.as_posix())[0] or "image/png"
    return f"data:{mime};base64," + base64.b64encode(path.read_bytes()).decode("ascii")


def text_block(text: str) -> Dict[str, str]:
    return {"type": "text", "text": text}


def image_block(path: Path) -> Dict[str, Any]:
    return {"type": "image_url", "image_url": {"url": image_to_data_url(path)}}


def build_initial_messages(system_prompt: str, prompt: str, image_paths: List[Path]) -> List[Dict[str, Any]]:
    content: List[Dict[str, Any]] = [text_block(prompt)]
    for path in image_paths:
        content.append(text_block(f"REFERENCE_IMAGE: {path.name}"))
        content.append(image_block(path))
    return [
        {"role": "system", "content": [text_block(system_prompt)]},
        {"role": "user", "content": content},
    ]


def attach_reference_images_to_initial_messages(messages: List[Dict[str, Any]], image_paths: List[Path]) -> None:
    """Attach target reference-view images to the initial user message.

    The experiment file owns the system/user prompt layout through init_conversation(),
    and the common runner only injects the actual image payloads here. This mirrors
    the step-loop pattern used by the pin-agent code: initialize text/rules first,
    then append the current visual evidence as user content.
    """
    if not image_paths:
        return
    target = None
    for message in reversed(messages):
        if message.get("role") == "user":
            target = message
            break
    if target is None:
        target = {"role": "user", "content": []}
        messages.append(target)
    content = target.get("content")
    if isinstance(content, str):
        content = [text_block(content)]
    if not isinstance(content, list):
        content = []
    for path in image_paths:
        if path.exists():
            content.append(text_block(f"REFERENCE_IMAGE: {path.name}"))
            content.append(image_block(path))
    target["content"] = content


def _is_prior_tool_feedback_message(message: Dict[str, Any]) -> bool:
    if message.get("role") != "user":
        return False
    content = message.get("content") or []
    if not isinstance(content, list) or not content:
        return False
    first = content[0]
    if not isinstance(first, dict) or first.get("type") != "text":
        return False
    text = str(first.get("text") or "")
    return (
        text.startswith("AGENT_TOOL_FEEDBACK_ROUND")
        or text.startswith("AGENT FEEDBACK STEP")
        or text.startswith("VALIDATION_FEEDBACK_ROUND")
    )


def _strip_images_from_prior_tool_feedback(messages: List[Dict[str, Any]]) -> None:
    for message in messages:
        if not _is_prior_tool_feedback_message(message):
            continue
        content = message.get("content") or []
        if isinstance(content, list):
            text_only = [item for item in content if isinstance(item, dict) and item.get("type") == "text"]
            if text_only:
                message["content"] = text_only


def _compact_messages_for_next_agent_round(messages: List[Dict[str, Any]]) -> None:
    """Keep stable task context and prior assistant JSON, remove old tool feedback.

    Chat Completions/OpenRouter calls are stateless from the caller side: every
    round must include the context that the model needs. Therefore the initial
    system prompt, component library, target reference views, and previous
    assistant JSON predictions are kept. Older tool feedback text and tool
    images/frames are removed so they do not accumulate across rounds. Full logs
    are still saved on disk in agent_trace / agent_rounds.
    """
    compact: List[Dict[str, Any]] = []
    for message in messages:
        if _is_prior_tool_feedback_message(message):
            continue
        compact.append(message)
    messages[:] = compact


def append_tool_feedback(
    messages: List[Dict[str, Any]],
    previous_prediction: Dict[str, Any],
    feedback_text: str,
    image_paths: List[Path],
) -> None:
    # Keep stable task context and previous successful prediction JSON outputs,
    # but do not accumulate old tool feedback text or old tool images/frames.
    # Only the validation-passing normalized round prediction is appended as the
    # assistant history for the next API call; failed validation attempts and raw
    # model JSON are not carried into later agent rounds.
    _compact_messages_for_next_agent_round(messages)
    messages.append({"role": "assistant", "content": _json_block(previous_prediction)})
    content: List[Dict[str, Any]] = [text_block(feedback_text)]
    for path in image_paths:
        if path.exists():
            content.append(text_block(f"TOOL_IMAGE: {path.name}"))
            content.append(image_block(path))
    messages.append({"role": "user", "content": content})


def call_chat_provider(args: argparse.Namespace, experiment_mode: str, schema: Dict[str, Any], messages: List[Dict[str, Any]], response_mode: str) -> str:
    if args.provider == "openrouter":
        from openai import OpenAI
        api_key = os.getenv(args.api_key_env) or os.getenv("openrouter")
        if not api_key:
            raise RuntimeError(f"Missing API key environment variable: {args.api_key_env} or openrouter")
        client_kwargs: Dict[str, Any] = {"api_key": api_key, "base_url": "https://openrouter.ai/api/v1"}
        if getattr(args, "api_timeout_sec", 0) and float(args.api_timeout_sec) > 0:
            client_kwargs["timeout"] = float(args.api_timeout_sec)
        client = OpenAI(**client_kwargs)
        extra_body = {"plugins": [{"id": "response-healing"}]} if args.openrouter_response_healing else None
        kwargs: Dict[str, Any] = {"model": args.model, "messages": messages, "temperature": args.temperature}
        if getattr(args, "max_output_tokens", 0) and int(args.max_output_tokens) > 0:
            kwargs["max_tokens"] = int(args.max_output_tokens)
        if response_mode == "json_schema":
            kwargs["response_format"] = {"type": "json_schema", "json_schema": {"name": f"{experiment_mode}_assembly_prediction_schema", "strict": True, "schema": schema}}
        elif response_mode == "json_object":
            kwargs["response_format"] = {"type": "json_object"}
        if extra_body is not None:
            kwargs["extra_body"] = extra_body
        response = client.chat.completions.create(**kwargs)
        return response.choices[0].message.content or ""

    if args.provider == "openai":
        from openai import OpenAI
        api_key = os.getenv(args.api_key_env)
        if not api_key:
            raise RuntimeError(f"Missing API key environment variable: {args.api_key_env}")
        client_kwargs = {"api_key": api_key}
        if getattr(args, "api_timeout_sec", 0) and float(args.api_timeout_sec) > 0:
            client_kwargs["timeout"] = float(args.api_timeout_sec)
        client = OpenAI(**client_kwargs)
        kwargs = {"model": args.model, "messages": messages, "temperature": args.temperature}
        if getattr(args, "max_output_tokens", 0) and int(args.max_output_tokens) > 0:
            kwargs["max_tokens"] = int(args.max_output_tokens)
        if response_mode == "json_schema":
            kwargs["response_format"] = {"type": "json_schema", "json_schema": {"name": f"{experiment_mode}_assembly_prediction_schema", "strict": True, "schema": schema}}
        elif response_mode == "json_object":
            kwargs["response_format"] = {"type": "json_object"}
        response = client.chat.completions.create(**kwargs)
        return response.choices[0].message.content or ""

    if args.provider == "azure":
        from openai import AzureOpenAI
        api_key = os.getenv(args.api_key_env)
        endpoint_val = args.azure_endpoint or os.getenv(args.azure_endpoint_env)
        if not api_key:
            raise RuntimeError(f"Missing API key environment variable: {args.api_key_env}")
        if not endpoint_val:
            raise RuntimeError(f"Missing Azure endpoint. Use --azure-endpoint or {args.azure_endpoint_env}")
        client_kwargs = {"api_key": api_key, "azure_endpoint": endpoint_val, "api_version": args.azure_api_version or "2024-08-01-preview"}
        if getattr(args, "api_timeout_sec", 0) and float(args.api_timeout_sec) > 0:
            client_kwargs["timeout"] = float(args.api_timeout_sec)
        client = AzureOpenAI(**client_kwargs)
        kwargs = {"model": args.model, "messages": messages, "temperature": args.temperature}
        if getattr(args, "max_output_tokens", 0) and int(args.max_output_tokens) > 0:
            kwargs["max_tokens"] = int(args.max_output_tokens)
        if response_mode == "json_schema":
            kwargs["response_format"] = {"type": "json_schema", "json_schema": {"name": f"{experiment_mode}_assembly_prediction_schema", "strict": True, "schema": schema}}
        elif response_mode == "json_object":
            kwargs["response_format"] = {"type": "json_object"}
        response = client.chat.completions.create(**kwargs)
        return response.choices[0].message.content or ""

    raise ValueError(f"Unsupported provider: {args.provider}")


def obj_file_sections(library_json: Dict[str, Any]) -> str:
    sections: List[str] = []
    for item in library_json.get("library", []) or []:
        if not isinstance(item, dict):
            continue
        lib_id = str(item.get("library_id") or item.get("component_id") or "")
        obj_file = str(item.get("obj_file") or f"{lib_id}.mesh.obj")
        obj_name = obj_file.replace("\\", "/").split("/")[-1]
        raw = item.get("raw_obj_text")
        header = f"OBJ_FILE: {obj_name}\nLIBRARY_ID: {lib_id}"
        if raw is None:
            sections.append(header + "\nOBJ_CONTENT: <not provided>")
        else:
            sections.append(header + "\nOBJ_CONTENT:\n```obj\n" + str(raw) + "\n```")
    return "\n\n".join(sections)


def output_schema_example(expect_edges: bool = True) -> Dict[str, Any]:
    base: Dict[str, Any] = {
        "nodes": [
            {"component_id": "c00001", "library_id": "lib00001", "pose": {"position": {"x": 0.0, "y": 0.0, "z": 0.0}, "orientation": {"rx": 0.0, "ry": 0.0, "rz": 0.0}}},
            {"component_id": "c00002", "library_id": "lib00002", "pose": {"position": {"x": 10.0, "y": 0.0, "z": 0.0}, "orientation": {"rx": 0.0, "ry": 0.0, "rz": 0.0}}},
        ],
        "agent_action": {"need_next_tool": "yes", "view_rotation_deg": {"rx": 0.0, "ry": 0.0, "rz": 0.0}, "view_scale": 1.0},
    }
    if expect_edges:
        base["edges"] = [{"source_component": "c00001", "target_component": "c00002", "mate_type": "MateCoincident"}]
    return base


def build_base_system_prompt(expect_edges: bool, tool_mode: str, fixed_mate_graph: bool = False) -> str:
    edge_text = (
        "Return component-level mate edges between predicted component instances."
        if expect_edges else
        "Do not return edges. The input mate_graph.json already fixes the component instances and component-level mates."
    )
    fixed_text = (
        "For this mate-graph experiment, use exactly the component_id and library_id pairs in mate_graph.json; do not add, delete, or rename component nodes."
        if fixed_mate_graph else
        "The component_library is a reusable template library, not a final instance list. You may use a library_id more than once if the target assembly contains repeated instances. You may revise the number of component instances across agent rounds."
    )
    tool_text = {
        "2d_vis": 'You can request a 2D visualization tool result of your current 3D prediction. The runtime will render the predicted assembly with different component colors and black feature edges from your current JSON. Use need_next_tool="yes" only when a screenshot would help you correct pose, scale, rotation, missing parts, or collisions.',
        "walkaround_video": 'You can request a walk-around video tool result of your current 3D prediction. The runtime will render one smooth regular-dodecahedron MP4 from your current JSON; the current API wrapper receives sampled frames from that same video. Use need_next_tool="yes" only when multi-view inspection would help you correct the assembly.',
        "conflict_check": 'You can request a conflict-check tool result for your current 3D prediction. The runtime will compute likely component interpenetration pairs and render a clean 2D visualization from your current JSON. Use need_next_tool="yes" only when conflict evidence or another visualization round is needed to correct interpenetration.',
    }.get(tool_mode, "You can request a runtime tool result when useful.")
    return f"""
You are a visual-geometric CAD assembly reconstruction agent.

TASK:
Reconstruct one visible CAD assembly from:
- component_library: reusable component-template OBJ files in local component frames
- reference_views/color_by_component: target assembly reference images, each component rendered with a different color and highlighted edges

POSE:
- position is absolute x, y, z in millimeters in the prepared assembly coordinate frame
- orientation is absolute Euler rx, ry, rz in degrees
- component_id is an output component instance id, normally c00001, c00002, ... in order
- library_id must be one of the given component library ids

INSTANCE POLICY:
{fixed_text}

EDGES:
{edge_text}
Mate type definitions:
{_json_block(MATE_TYPE_DEFINITIONS)}

AGENT TOOL POLICY:
{tool_text}
- If the current prediction is final, set agent_action.need_next_tool="no".
- The runtime tool is fixed by the experiment; agent_action does not include a tool-name field.
- If you need a tool result, set agent_action.need_next_tool="yes". Some experiments require view_rotation_deg and view_scale; follow the current experiment prompt.
- Return one JSON object matching the response schema.

PHYSICAL PLAUSIBILITY:
Avoid unintended interpenetration. Contact, flush alignment, concentric axes, parallel faces, and visible adjacency should be reflected in poses and mate relations.

Return one strict JSON object matching the response schema.
""".strip()


def build_initial_prompt(
    experiment_name: str,
    library_json: Dict[str, Any],
    reference_views: Dict[str, str],
    mate_graph_json: Optional[Dict[str, Any]],
    expect_edges: bool,
    tool_mode: str,
    node_policy: str,
) -> str:
    parts = [
        f"EXPERIMENT: {experiment_name}",
        "INPUT_COMPONENT_LIBRARY_JSON:",
        _json_block(library_json),
        "COMPONENT_OBJ_CONTENTS:",
        obj_file_sections(library_json),
        "REFERENCE_VIEW_STYLE: color_by_component",
        "REFERENCE_VIEW_FILES:",
        _json_block(reference_views),
    ]
    if mate_graph_json is not None:
        parts += [
            "INPUT_MATE_GRAPH_JSON:",
            _json_block(mate_graph_json),
            "The mate_graph.json is an input contract. Predict poses for these nodes only. Keep component_id and library_id unchanged. Do not output edges.",
        ]
    if node_policy == "all_library" and mate_graph_json is None:
        parts.append("NODE_POLICY: every library template should appear at least once unless the target reference clearly excludes it.")
    parts += [
        "Round 1: produce your best assembly prediction. Request the runtime tool only if you need additional visual/check evidence for the next round.",
    ]
    return "\n\n".join(parts)


def resolve_assembly_id(args: argparse.Namespace, sample_dir: Path, library_json: Dict[str, Any], mate_graph: Optional[Dict[str, Any]]) -> str:
    if getattr(args, "assembly_id", None):
        return str(args.assembly_id)
    if isinstance(mate_graph, dict) and mate_graph.get("assembly_id"):
        return str(mate_graph["assembly_id"])
    try:
        gt = load_exported_gt(sample_dir)
        if isinstance(gt, dict) and gt.get("assembly_id"):
            return str(gt["assembly_id"])
    except Exception:
        pass
    if isinstance(library_json, dict) and library_json.get("assembly_id"):
        return str(library_json["assembly_id"])
    return sample_dir.name


def agent_mode_defaults(experiment_mode: str) -> Tuple[str, bool, str]:
    """Return reference view style, use_mate_graph, tool_mode."""
    if experiment_mode == "exp_agent_mate_graph_2d_vis":
        return "color_by_component", True, "2d_vis"
    if experiment_mode == "exp_agent_walkaround_video":
        return "color_by_component", False, "walkaround_video"
    if experiment_mode == "exp_agent_conflict_check_2d_vis":
        return "color_by_component", False, "conflict_check"
    return "color_by_component", False, "2d_vis"


def write_clean_inputs(input_dir: Path, sample_dir: Path, library_json: Dict[str, Any], reference_views: Dict[str, str], mate_graph: Optional[Dict[str, Any]], image_paths: List[Path]) -> None:
    comp_dir = input_dir / "component_library"
    comp_dir.mkdir(parents=True, exist_ok=True)
    for item in library_json.get("library", []) or []:
        if not isinstance(item, dict):
            continue
        rel = item.get("obj_file")
        if not rel:
            continue
        src = Path(str(rel))
        if not src.is_absolute():
            src = sample_dir / src
        if src.exists() and src.is_file():
            shutil.copy2(src, comp_dir / src.name)
    if image_paths:
        view_dir = input_dir / "reference_views" / "color_by_component"
        view_dir.mkdir(parents=True, exist_ok=True)
        for img in image_paths:
            if img.exists() and img.is_file():
                shutil.copy2(img, view_dir / img.name)
    if reference_views:
        write_json(input_dir / "reference_views.json", reference_views)
    if mate_graph is not None:
        write_json(input_dir / "mate_graph.json", mate_graph)


def build_tool_feedback_text(round_index: int, tool_mode: str, tool_meta: Optional[Dict[str, Any]], conflict_report: Optional[Dict[str, Any]], fatal: List[str], warnings: List[str], min_nodes: int, expect_edges: bool) -> str:
    sections = [f"AGENT_TOOL_FEEDBACK_ROUND: {round_index}"]
    if fatal:
        sections.append(validation_feedback(fatal, {}, min_nodes, expect_edges=expect_edges))
    if warnings:
        sections.append("VALIDATION_WARNINGS:\n" + _json_block(warnings))
    if tool_meta:
        compact = dict(tool_meta)
        # Keep the prompt concise: image files are attached separately.
        if "frames" in compact:
            compact["frames"] = [Path(p).name for p in compact.get("frames") or []]
        if "png" in compact and compact["png"]:
            compact["png"] = Path(str(compact["png"])).name
        if "video" in compact and compact["video"]:
            compact["video"] = Path(str(compact["video"])).name
        sections.append("TOOL_RESULT_METADATA:\n" + _json_block(compact))
    if conflict_report is not None:
        sections.append("CONFLICT_CHECK_RESULT:\n" + _json_block(conflict_report))
        if (conflict_report.get("conflict_pairs") or []):
            sections.append("Revise the assembly to remove likely physical interpenetration while preserving visible target geometry and mate plausibility.")
    sections.append('Now return a corrected COMPLETE JSON prediction, not a patch. If no further tool evidence is needed, set agent_action.need_next_tool="no".')
    return "\n\n".join(sections)


def make_experiment_tool_feedback(
    exp_module,
    round_index: int,
    tool_mode: str,
    tool_meta: Optional[Dict[str, Any]],
    conflict_report: Optional[Dict[str, Any]],
    fatal: List[str],
    warnings: List[str],
    min_nodes: int,
    expect_edges: bool,
) -> str:
    # Prefer a full per-experiment wrapper so each exp_*.py owns both
    # first-round prompt design and later-round feedback design.
    custom_full = getattr(exp_module, "make_experiment_tool_feedback", None)
    if callable(custom_full):
        return custom_full(
            round_index=round_index,
            tool_mode=tool_mode,
            tool_meta=tool_meta,
            conflict_report=conflict_report,
            fatal=fatal,
            warnings=warnings,
            min_nodes=min_nodes,
            expect_edges=expect_edges,
        )
    custom_prompt = getattr(exp_module, "build_tool_feedback_prompt", None)
    if callable(custom_prompt):
        return custom_prompt(
            round_index=round_index,
            tool_mode=tool_mode,
            tool_meta=tool_meta,
            conflict_report=conflict_report,
            fatal=fatal,
            warnings=warnings,
            min_nodes=min_nodes,
            expect_edges=expect_edges,
        )
    return build_tool_feedback_text(
        round_index,
        tool_mode,
        tool_meta,
        conflict_report,
        fatal,
        warnings,
        min_nodes,
        expect_edges=expect_edges,
    )


def build_validation_retry_feedback_text(
    round_index: int,
    validation_attempt: int,
    fatal: List[str],
    warnings: List[str],
    pred: Dict[str, Any],
    min_nodes: int,
    expect_edges: bool,
) -> str:
    sections = [
        f"VALIDATION_RETRY_FEEDBACK_ROUND: {round_index}",
        f"FAILED_VALIDATION_ATTEMPT: {validation_attempt}",
        "Your previous JSON was parsed and normalized, but it failed runtime semantic validation. Correct the JSON in this same agent round.",
        validation_feedback(fatal, pred, min_nodes, expect_edges=expect_edges),
    ]
    if warnings:
        sections.append("VALIDATION_WARNINGS:\n" + _json_block(warnings))
    sections.append("PREVIOUS_NORMALIZED_JSON:\n" + _json_block(pred))
    sections.append(
        "Return a corrected COMPLETE JSON prediction, not a patch. Keep the same response schema. "
        "Do not ask for a runtime tool only to fix schema or validation errors; first make the JSON valid."
    )
    return "\n\n".join(sections)


def append_validation_retry_feedback(
    validation_messages: List[Dict[str, Any]],
    previous_raw_response: str,
    feedback_text: str,
) -> None:
    validation_messages.append({"role": "assistant", "content": previous_raw_response})
    validation_messages.append({"role": "user", "content": [text_block(feedback_text)]})


def write_validation_attempt_files(
    out_dir: Path,
    round_index: int,
    validation_attempt: int,
    response_mode: str,
    raw: Optional[str],
    raw_json: Optional[Dict[str, Any]],
    normalized_prediction: Optional[Dict[str, Any]],
    status: Dict[str, Any],
) -> None:
    # Validation attempts are recorded inside assembly_prediction.json /
    # assembly_prediction_best_effort.json. Do not create per-attempt side files
    # such as validation_attempts/round_XX/attempt_YY_*.
    return


def compact_agent_action(action: Optional[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
    """Return the user/model-facing agent_action shape used in prediction logs."""
    if not isinstance(action, dict):
        return None
    raw_need = action.get("need_next_tool_raw")
    if raw_need is None:
        raw_need = "yes" if action.get("need_next_tool") else "no"
    need = "yes" if str(raw_need).strip().lower() == "yes" or bool(action.get("need_next_tool")) else "no"
    has_view = bool(action.get("has_view_params"))
    return {
        "need_next_tool": need,
        "view_rotation_deg": action.get("view_rotation_deg") if has_view else None,
        "view_scale": action.get("view_scale") if has_view else None,
    }


def clean_tool_meta(tool_meta: Optional[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
    if not isinstance(tool_meta, dict):
        return None
    out: Dict[str, Any] = {}
    for k, v in tool_meta.items():
        if isinstance(v, Path):
            out[k] = v.name
        elif isinstance(v, str) and k in {"png", "video"}:
            out[k] = Path(v).name
        elif isinstance(v, list) and k == "frames":
            out[k] = [Path(str(x)).name for x in v]
        else:
            out[k] = v
    return out


def make_api_attempt_record(
    attempt: int,
    response_mode: str,
    stage: str,
    started_at: str,
    elapsed_sec: float,
    exc: Exception,
) -> Dict[str, Any]:
    return {
        "attempt": attempt,
        "response_mode": response_mode,
        "stage": stage,
        "status": "error",
        "error_type": exc.__class__.__name__,
        "error": repr(exc),
        "started_at": started_at,
        "elapsed_sec": elapsed_sec,
    }


def make_validation_attempt_record(
    status: Dict[str, Any],
    raw_json: Optional[Dict[str, Any]],
    normalized_prediction: Optional[Dict[str, Any]],
) -> Dict[str, Any]:
    """Record failed validation/normalization attempts compactly.

    Valid attempts are promoted to the round-level ``prediction`` field. This
    per-attempt history is reserved for retry/debug entries, so parsed invalid
    JSON is kept without duplicating the final valid prediction.
    """
    record: Dict[str, Any] = {}
    for key in [
        "attempt",
        "response_mode",
        "started_at",
        "status",
        "fatal_errors",
        "warnings",
        "error_type",
        "error",
        "elapsed_sec",
    ]:
        if key in status:
            record[key] = status[key]
    if "agent_action" in status:
        record["agent_action"] = compact_agent_action(status.get("agent_action"))
    if normalized_prediction is not None:
        record["prediction"] = normalized_prediction
    elif raw_json is not None:
        # If normalization itself failed, the parsed model JSON is the only
        # prediction-shaped object available for this failed attempt.
        record["prediction"] = raw_json
    return record


def build_json_error_retry_feedback_text(
    round_index: int,
    validation_attempt: int,
    error: str,
    raw_json: Dict[str, Any],
) -> str:
    return "\n\n".join([
        f"VALIDATION_RETRY_FEEDBACK_ROUND: {round_index}",
        f"FAILED_VALIDATION_ATTEMPT: {validation_attempt}",
        "Your previous response was parseable JSON, but the runtime could not normalize or validate it.",
        f"RUNTIME_ERROR: {error}",
        "PREVIOUS_RAW_JSON:\n" + _json_block(raw_json),
        "Return a corrected COMPLETE JSON prediction, not a patch. Keep the same response schema.",
    ])


def final_prediction_with_mate_graph_edges(pred: Dict[str, Any], mate_graph: Optional[Dict[str, Any]], attach_edges: bool) -> Dict[str, Any]:
    out = dict(pred)
    if attach_edges and mate_graph is not None and "edges" not in out:
        out["edges"] = mate_graph.get("edges") or []
    return out


def clean_round_output(item: Dict[str, Any]) -> Dict[str, Any]:
    out: Dict[str, Any] = {
        "round": item.get("round"),
        "status": item.get("status"),
    }
    for key in [
        "response_mode",
        "started_at",
        "elapsed_sec",
        "fatal_errors",
        "warnings",
    ]:
        if key in item:
            out[key] = item[key]
    if "agent_action" in item:
        out["agent_action"] = compact_agent_action(item.get("agent_action"))
    if isinstance(item.get("prediction"), dict):
        out["prediction"] = item["prediction"]

    api_attempts = item.get("api_attempts") or []
    if api_attempts:
        out["api_attempts"] = api_attempts
    # Tool image/video paths are temporary runtime artifacts, so they are not
    # embedded in the prediction artifact. Exp4 conflict reports are retained
    # because they are textual JSON evidence.
    conflict_report = item.get("conflict_report")
    if conflict_report is not None:
        out["conflict_report"] = conflict_report
    attempts = item.get("validation_attempts") or []
    if attempts:
        out["validation_attempts"] = attempts
    return out


def prediction_with_round_history(pred: Dict[str, Any], rounds: List[Dict[str, Any]], status: str = "ok") -> Dict[str, Any]:
    """Build the readable agent prediction artifact.

    The final prediction is not duplicated at the top level. By convention, the
    effective prediction is the ``prediction`` field in the last successful
    round. Failed validation retries are retained under that round's
    ``validation_attempts``.
    """
    out: Dict[str, Any] = {}
    if pred.get("assembly_id"):
        out["assembly_id"] = pred.get("assembly_id")
    out["status"] = status
    out["rounds"] = [clean_round_output(item) for item in rounds if isinstance(item, dict)]
    if not out["rounds"] and pred:
        out["rounds"] = [{
            "round": 1,
            "status": "valid" if status in {"ok", "ok_with_warnings", "max_iterations_reached"} else status,
            "prediction": pred,
        }]
    return out




def append_round_output_once(round_outputs: List[Dict[str, Any]], item: Dict[str, Any]) -> None:
    """Append one trace record per agent round.

    A round should appear at most once in assembly_prediction*.json. During
    validation retries we may build temporary preview records for best-effort
    output, but the persistent round history should contain a single final
    record for that round. If a future branch tries to write the same round
    again, replace the last record instead of duplicating it.
    """
    if not isinstance(item, dict):
        return
    current_round = item.get("round")
    if round_outputs and round_outputs[-1].get("round") == current_round:
        round_outputs[-1] = item
    else:
        round_outputs.append(item)

def write_agent_round_files(out_dir: Path, rounds: List[Dict[str, Any]]) -> None:
    # Round-level details are written into the final sample log.json.
    # Keep this hook as a no-op so the loop can update its in-memory trace
    # without producing separate round_*.json files.
    return


def attach_round_log(status: Dict[str, Any], rounds: List[Dict[str, Any]]) -> Dict[str, Any]:
    if not rounds:
        return status
    cleaned_rounds: List[Dict[str, Any]] = []
    for item in rounds:
        out = {k: v for k, v in item.items() if k not in {"prediction", "validation_attempts"}}
        round_status = out.get("status")
        if isinstance(round_status, dict):
            out["status"] = {k: v for k, v in round_status.items() if k != "validation_attempts"}
        meta = out.get("tool_meta")
        if isinstance(meta, dict):
            out["tool_meta"] = {k: v for k, v in meta.items() if k not in {"png", "video", "frames"}}
        cleaned_rounds.append(out)
    return {**status, "rounds": cleaned_rounds}


def run_one_agent_sample(args: argparse.Namespace, sample_dir: Path, out_dir: Path, exp_module) -> Dict[str, Any]:
    sample_start_ts = time.time()
    sample_start_time = time.strftime("%Y-%m-%d %H:%M:%S")
    sample_dir = sample_dir.resolve()
    out_dir.mkdir(parents=True, exist_ok=True)
    debug_dir = out_dir / "debug"
    tool_tmp = tempfile.TemporaryDirectory(prefix="cad_agent_tool_")
    tool_dir = Path(tool_tmp.name)
    trace: List[Dict[str, Any]] = []
    round_outputs: List[Dict[str, Any]] = []

    def finish(status: Dict[str, Any]) -> Dict[str, Any]:
        try:
            shutil.rmtree(tool_dir, ignore_errors=True)
        finally:
            tool_tmp.cleanup()
        return finalize_and_write_sample_status(attach_round_log(status, round_outputs), sample_start_ts, out_dir, sample_start_time)

    default_style, default_mate, tool_mode = agent_mode_defaults(exp_module.EXPERIMENT_MODE)
    style = args.reference_view_style or default_style
    use_mate_graph = args.use_mate_graph_json or default_mate
    expect_edges = bool(getattr(exp_module, "EXPECT_EDGES", True))
    require_view_params_for_tool = bool(getattr(exp_module, "REQUIRE_VIEW_PARAMS_FOR_TOOL", tool_mode == "2d_vis"))

    library_json = discover_component_library(sample_dir, obj_kind=args.obj_kind, raw_obj_mode=args.raw_obj_mode, max_raw_obj_chars=args.max_raw_obj_chars)
    reference_views = find_reference_views(sample_dir, style=style)
    mate_graph = load_or_build_mate_graph(sample_dir, library_json=library_json) if use_mate_graph else None
    assembly_id = resolve_assembly_id(args, sample_dir, library_json, mate_graph)
    image_paths = image_paths_from_views(sample_dir, reference_views)
    write_clean_inputs(out_dir, sample_dir, library_json, reference_views, mate_graph, image_paths)

    missing: List[str] = []
    if not library_json.get("library"):
        missing.append("empty_component_library")
    if not args.allow_missing_views:
        min_views = max(1, int(getattr(args, "min_reference_views", 8) or 8))
        if len(reference_views) < min_views:
            missing.append(f"too_few_reference_views:min={min_views}:got={len(reference_views)}")
    if use_mate_graph and mate_graph is None:
        missing.append("missing_mate_graph_json")

    summary_base = {
        "assembly_id": assembly_id,
        "sample_dir": sample_dir.as_posix(),
        "experiment_dir": out_dir.as_posix(),
        "experiment_mode": exp_module.EXPERIMENT_MODE,
        "obj_kind": args.obj_kind,
        "reference_view_style": style,
        "library_count": len(library_json.get("library", [])),
        "reference_view_count": len(reference_views),
        "has_mate_graph": mate_graph is not None,
        "provider": args.provider,
        "model": args.model,
        "raw_obj_mode": args.raw_obj_mode,
        "max_raw_obj_chars": args.max_raw_obj_chars,
        "max_output_tokens": getattr(args, "max_output_tokens", 8192),
        "api_timeout_sec": getattr(args, "api_timeout_sec", 600.0),
        "max_full_prompt_chars": getattr(args, "max_full_prompt_chars", 0),
        "agent_iterations": args.agent_iterations,
        "max_validation_retries": max(0, int(getattr(args, "max_validation_retries", 3) or 0)),
        "require_view_params_for_tool": require_view_params_for_tool,
        "start_time": sample_start_time,
    }

    if missing and not args.ignore_preflight:
        return finish({**summary_base, "status": "preflight_failed", "missing": missing})
    if args.provider == "dry-run":
        return finish({**summary_base, "status": "dry_run", "missing": missing})

    system_prompt = exp_module.build_system_prompt()
    prompt = exp_module.build_prompt(
        assembly_id=assembly_id,
        library_json=library_json,
        reference_views=reference_views,
        mate_graph_json=mate_graph,
        allowed_mate_types=list(getattr(exp_module, "MATE_TYPE_DEFINITIONS", MATE_TYPE_DEFINITIONS).keys()),
        node_policy=args.node_policy,
    )
    schema = getattr(
        exp_module,
        "ASSEMBLY_PREDICTION_SCHEMA",
        getattr(exp_module, "ASSEMBLY_AGENT_PREDICTION_SCHEMA", agent_prediction_schema(expect_edges=expect_edges)),
    )

    init_fn = getattr(exp_module, "init_conversation", None)
    if callable(init_fn):
        messages = init_fn(
            assembly_id=assembly_id,
            library_json=library_json,
            reference_views=reference_views,
            mate_graph_json=mate_graph,
            allowed_mate_types=list(getattr(exp_module, "MATE_TYPE_DEFINITIONS", MATE_TYPE_DEFINITIONS).keys()),
            node_policy=args.node_policy,
        )
        attach_reference_images_to_initial_messages(messages, image_paths)
    else:
        messages = build_initial_messages(system_prompt, prompt, image_paths)

    max_full_prompt_chars = int(getattr(args, "max_full_prompt_chars", 0) or 0)
    uses_full_obj = str(getattr(args, "raw_obj_mode", "")).lower() == "full"
    prompt_chars = len(json.dumps(messages, ensure_ascii=False))
    if uses_full_obj and max_full_prompt_chars > 0 and prompt_chars > max_full_prompt_chars:
        return finish({
            **summary_base,
            "status": "skipped_context_limit",
            "elapsed_sec": round(time.time() - t0_total, 3),
            "prompt_chars": prompt_chars,
            "max_full_prompt_chars": max_full_prompt_chars,
            "last_error": f"local_prompt_size_skip:prompt_chars={prompt_chars}:limit={max_full_prompt_chars}",
        })

    best_pred: Optional[Dict[str, Any]] = None
    best_fatal: List[str] = ["not_run"]
    best_warnings: List[str] = []
    last_error: Optional[str] = None
    final_pred: Optional[Dict[str, Any]] = None
    final_warnings: List[str] = []
    final_action: Dict[str, Any] = {}
    t0_total = time.time()

    def _write_prediction_history(path: Path, status_value: str, fallback_pred: Optional[Dict[str, Any]] = None) -> None:
        base_pred = fallback_pred or final_pred or best_pred or {"assembly_id": assembly_id}
        write_json(path, prediction_with_round_history(base_pred, round_outputs, status=status_value))

    for round_index in range(1, max(1, int(args.agent_iterations or 1)) + 1):
        round_succeeded = False
        max_validation_retries = max(0, int(getattr(args, "max_validation_retries", 3) or 0))
        round_api_attempts: List[Dict[str, Any]] = []

        for rm in response_modes(args.provider, args.response_mode):
            validation_messages = list(messages)
            validation_attempt_records: List[Dict[str, Any]] = []

            for validation_attempt in range(1, max_validation_retries + 2):
                started_at = time.strftime("%Y-%m-%d %H:%M:%S")
                t0 = time.time()
                raw: Optional[str] = None
                raw_json: Optional[Dict[str, Any]] = None
                pred: Optional[Dict[str, Any]] = None

                try:
                    api_call = getattr(exp_module, "call_experiment_api", None)
                    if callable(api_call):
                        raw = api_call(args=args, messages=validation_messages, response_mode=rm)
                    else:
                        raw = call_chat_provider(args, exp_module.EXPERIMENT_MODE, schema, validation_messages, rm)
                except Exception as exc:
                    last_error = repr(exc)
                    round_api_attempts.append(make_api_attempt_record(
                        attempt=len(round_api_attempts) + 1,
                        response_mode=rm,
                        stage="api_call",
                        started_at=started_at,
                        elapsed_sec=round(time.time() - t0, 3),
                        exc=exc,
                    ))
                    print(f"[WARN] {sample_dir.name} round={round_index} mode={rm} api_call: {exc}", file=sys.stderr)
                    if args.retry_sleep_sec > 0:
                        time.sleep(args.retry_sleep_sec)
                    break

                try:
                    raw_json = extract_json_from_text(raw)
                except Exception as exc:
                    last_error = repr(exc)
                    round_api_attempts.append(make_api_attempt_record(
                        attempt=len(round_api_attempts) + 1,
                        response_mode=rm,
                        stage="parse_json",
                        started_at=started_at,
                        elapsed_sec=round(time.time() - t0, 3),
                        exc=exc,
                    ))
                    print(f"[WARN] {sample_dir.name} round={round_index} mode={rm} parse_json: {exc}", file=sys.stderr)
                    if args.retry_sleep_sec > 0:
                        time.sleep(args.retry_sleep_sec)
                    break

                try:
                    action = action_from_response(raw_json, tool_name=tool_mode)
                    pred = normalize_prediction(raw_json, assembly_id, expect_edges=expect_edges, mate_graph=mate_graph)
                    round_pred_to_save = final_prediction_with_mate_graph_edges(pred, mate_graph, attach_edges=args.attach_mate_graph_edges_to_prediction)
                    fatal, warnings = validate_prediction(pred, library_json, mate_graph, exp_module)
                except Exception as exc:
                    last_error = repr(exc)
                    meta = {
                        "attempt": validation_attempt,
                        "response_mode": rm,
                        "started_at": started_at,
                        "status": "error",
                        "error_type": exc.__class__.__name__,
                        "error": repr(exc),
                        "fatal_errors": [repr(exc)],
                        "warnings": [],
                        "elapsed_sec": round(time.time() - t0, 3),
                    }
                    validation_attempt_records.append(make_validation_attempt_record(meta, raw_json, None))
                    if args.save_debug:
                        adir = debug_dir / "rounds" / f"round_{round_index:02d}_{rm}_attempt_{validation_attempt:02d}"
                        adir.mkdir(parents=True, exist_ok=True)
                        write_text(adir / "raw_response.txt", raw)
                        write_json(adir / "raw_response.json", raw_json)
                        write_json(adir / "round_status.json", meta)
                    print(f"[WARN] {sample_dir.name} round={round_index} mode={rm} validation_attempt={validation_attempt}: {exc}", file=sys.stderr)
                    if validation_attempt <= max_validation_retries:
                        feedback = build_json_error_retry_feedback_text(
                            round_index=round_index,
                            validation_attempt=validation_attempt,
                            error=repr(exc),
                            raw_json=raw_json,
                        )
                        append_validation_retry_feedback(validation_messages, raw, feedback)
                        continue
                    append_round_output_once(round_outputs, {
                        "round": round_index,
                        "status": "validation_error",
                        "api_attempts": round_api_attempts,
                        "validation_attempts": validation_attempt_records,
                    })
                    write_agent_round_files(out_dir, round_outputs)
                    _write_prediction_history(out_dir / "assembly_prediction_best_effort.json", "validation_error")
                    status = {
                        **summary_base,
                        "status": "failed_validation",
                        "response_mode": rm,
                        "elapsed_sec": round(time.time() - t0_total, 3),
                        "rounds_run": round_index,
                        "fatal_errors": [repr(exc)],
                        "warnings": [],
                        "last_error": last_error,
                    }
                    return finish(status)

                meta = {
                    "attempt": validation_attempt,
                    "response_mode": rm,
                    "started_at": started_at,
                    "status": "valid" if not fatal else "invalid",
                    "fatal_errors": fatal,
                    "warnings": warnings,
                    "agent_action": action,
                    "elapsed_sec": round(time.time() - t0, 3),
                }
                if fatal:
                    validation_attempt_records.append(make_validation_attempt_record(meta, raw_json, round_pred_to_save))

                if args.save_debug:
                    adir = debug_dir / "rounds" / f"round_{round_index:02d}_{rm}_attempt_{validation_attempt:02d}"
                    adir.mkdir(parents=True, exist_ok=True)
                    write_text(adir / "raw_response.txt", raw)
                    write_json(adir / "raw_response.json", raw_json)
                    write_json(adir / "normalized_prediction.json", pred)
                    write_json(adir / "round_status.json", meta)

                if best_pred is None or len(fatal) < len(best_fatal):
                    best_pred, best_fatal, best_warnings = pred, fatal, warnings

                if fatal:
                    last_error = "; ".join(fatal)
                    preview_round = {
                        "round": round_index,
                        "status": "invalid",
                        "api_attempts": round_api_attempts,
                        "validation_attempts": validation_attempt_records,
                    }
                    write_json(
                        out_dir / "assembly_prediction_best_effort.json",
                        prediction_with_round_history(round_pred_to_save, [*round_outputs, preview_round], status="failed_validation"),
                    )
                    if validation_attempt <= max_validation_retries:
                        feedback = build_validation_retry_feedback_text(
                            round_index=round_index,
                            validation_attempt=validation_attempt,
                            fatal=fatal,
                            warnings=warnings,
                            pred=pred,
                            min_nodes=minimum_node_count(library_json, mate_graph),
                            expect_edges=expect_edges,
                        )
                        append_validation_retry_feedback(validation_messages, raw, feedback)
                        continue

                    append_round_output_once(round_outputs, preview_round)
                    write_agent_round_files(out_dir, round_outputs)
                    status = {
                        **summary_base,
                        "status": "failed_validation",
                        "response_mode": rm,
                        "elapsed_sec": round(time.time() - t0_total, 3),
                        "rounds_run": round_index,
                        "fatal_errors": fatal,
                        "warnings": warnings,
                        "last_error": last_error,
                        "final_agent_action": compact_agent_action(action),
                    }
                    return finish(status)

                tool_meta = None
                conflict_report = None
                next_images: List[Path] = []
                final_pred = pred
                final_warnings = warnings
                final_action = action
                tool_request_ready = bool(action.get("need_next_tool")) and (bool(action.get("has_view_params")) or not require_view_params_for_tool)
                if action.get("need_next_tool") and require_view_params_for_tool and not action.get("has_view_params"):
                    warnings = list(warnings) + ["agent_tool_request_missing_view_rotation_or_scale"]
                    meta["warnings"] = warnings

                if tool_mode == "conflict_check":
                    if tool_request_ready:
                        conflict_report = conflict_check(sample_dir, pred, obj_kind=args.obj_kind, tolerance_mm=args.conflict_tolerance_mm, max_pairs=args.conflict_max_pairs)
                        tool_meta = render_2d_vis_tool(sample_dir, pred, tool_dir, round_index, args.obj_kind, action)
                        if tool_meta.get("png"):
                            next_images.append(Path(tool_meta["png"]))
                elif tool_mode == "walkaround_video":
                    if tool_request_ready:
                        tool_meta = render_walkaround_tool(sample_dir, pred, tool_dir, round_index, args.obj_kind, frame_count=args.walkaround_frames, fps=args.walkaround_fps)
                        for fp in (tool_meta.get("frames") or [])[: args.walkaround_frames]:
                            next_images.append(Path(fp))
                else:
                    if tool_request_ready:
                        tool_meta = render_2d_vis_tool(sample_dir, pred, tool_dir, round_index, args.obj_kind, action)
                        if tool_meta.get("png"):
                            next_images.append(Path(tool_meta["png"]))

                append_round_output_once(round_outputs, {
                    "round": round_index,
                    "status": "valid",
                    "response_mode": rm,
                    "started_at": meta.get("started_at"),
                    "elapsed_sec": meta.get("elapsed_sec"),
                    "fatal_errors": [],
                    "warnings": warnings,
                    "agent_action": action,
                    "prediction": round_pred_to_save,
                    "api_attempts": round_api_attempts,
                    "tool_meta": clean_tool_meta(tool_meta),
                    "conflict_report": conflict_report,
                    "validation_attempts": validation_attempt_records,
                })
                write_agent_round_files(out_dir, round_outputs)

                should_continue = bool(tool_request_ready) and round_index < int(args.agent_iterations or 1)
                if should_continue:
                    feedback = make_experiment_tool_feedback(
                        exp_module,
                        round_index,
                        tool_mode,
                        tool_meta,
                        conflict_report,
                        [],
                        warnings,
                        minimum_node_count(library_json, mate_graph),
                        expect_edges=expect_edges,
                    )
                    append_tool_feedback(messages, round_pred_to_save, feedback, next_images)
                    round_succeeded = True
                    break

                pred_path = out_dir / "assembly_prediction.json"
                remove_file_if_exists(out_dir / "assembly_prediction_best_effort.json")
                write_json(pred_path, prediction_with_round_history(round_pred_to_save, round_outputs, status="ok" if not warnings else "ok_with_warnings"))
                maybe_visualize_outputs(sample_dir, pred_path, out_dir, args.obj_kind, not args.no_auto_visualize, generate_mate_graph_html=mate_graph is None or args.attach_mate_graph_edges_to_prediction)
                status = {
                    **summary_base,
                    "status": "ok" if not warnings else "ok_with_warnings",
                    "response_mode": rm,
                    "elapsed_sec": round(time.time() - t0_total, 3),
                    "rounds_run": round_index,
                    "stop_reason": "agent_action_no" if not tool_request_ready else "max_rounds_or_finalized",
                    "node_count": len(pred.get("nodes", [])),
                    "edge_count": len(round_pred_to_save.get("edges", [])),
                    "warnings": warnings,
                    "final_agent_action": compact_agent_action(action),
                }
                return finish(status)

            if round_succeeded:
                break

        if round_succeeded:
            continue

        # API or JSON-parsing errors never constitute a successful agent round.
        # Without a valid prediction there is no agent_action, so the sample must
        # fail here instead of advancing to the next agent round.
        if round_api_attempts:
            append_round_output_once(round_outputs, {
                "round": round_index,
                "status": "api_or_parse_error",
                "api_attempts": round_api_attempts,
                "validation_attempts": [],
            })
            write_agent_round_files(out_dir, round_outputs)
            if final_pred is not None or best_pred is not None:
                fallback = final_prediction_with_mate_graph_edges(
                    final_pred or best_pred or {"assembly_id": assembly_id},
                    mate_graph,
                    attach_edges=args.attach_mate_graph_edges_to_prediction,
                )
                write_json(out_dir / "assembly_prediction_best_effort.json", prediction_with_round_history(fallback, round_outputs, status="api_or_parse_error"))
            status = {
                **summary_base,
                "status": "error",
                "elapsed_sec": round(time.time() - t0_total, 3),
                "rounds_run": round_index,
                "fatal_errors": ["api_or_parse_error"],
                "warnings": [],
                "last_error": last_error,
            }
            return finish(status)

    if final_pred is not None:
        pred_path = out_dir / "assembly_prediction.json"
        pred_to_save = final_prediction_with_mate_graph_edges(final_pred, mate_graph, attach_edges=args.attach_mate_graph_edges_to_prediction)
        remove_file_if_exists(out_dir / "assembly_prediction_best_effort.json")
        write_json(pred_path, prediction_with_round_history(pred_to_save, round_outputs, status="max_iterations_reached"))
        maybe_visualize_outputs(sample_dir, pred_path, out_dir, args.obj_kind, not args.no_auto_visualize, generate_mate_graph_html=mate_graph is None or args.attach_mate_graph_edges_to_prediction)
        status = {
            **summary_base,
            "status": "max_iterations_reached",
            "elapsed_sec": round(time.time() - t0_total, 3),
            "rounds_run": int(args.agent_iterations or 1),
            "node_count": len(final_pred.get("nodes", [])),
            "edge_count": len((final_prediction_with_mate_graph_edges(final_pred, mate_graph, attach_edges=args.attach_mate_graph_edges_to_prediction)).get("edges", [])),
            "warnings": final_warnings,
            "final_agent_action": compact_agent_action(final_action),
        }
        return finish(status)

    if best_pred is not None:
        best_to_save = final_prediction_with_mate_graph_edges(best_pred, mate_graph, attach_edges=args.attach_mate_graph_edges_to_prediction)
        write_json(out_dir / "assembly_prediction_best_effort.json", prediction_with_round_history(best_to_save, round_outputs, status="failed_validation"))
    status = {**summary_base, "status": "failed_validation" if best_pred else "error", "elapsed_sec": round(time.time() - t0_total, 3), "fatal_errors": best_fatal, "warnings": best_warnings, "last_error": last_error}
    return finish(status)

def write_batch_summary(out_root: Path, statuses: List[Dict[str, Any]], start_time: Optional[str] = None, start_ts: Optional[float] = None, experiment_mode: Optional[str] = None) -> None:
    write_json(out_root / "log.json", build_log_payload(statuses, start_time=start_time, start_ts=start_ts, experiment_mode=experiment_mode))


EXPERIMENT_FOLDER_ALIASES = {
    "exp_agent_2d_vis": "agent_2d_vis",
    "exp_agent_walkaround_video": "agent_walkaround_video",
    "exp_agent_mate_graph_2d_vis": "agent_mate_graph_2d_vis",
    "exp_agent_conflict_check_2d_vis": "agent_conflict_check_2d_vis",
}


def clean_sample_label(sample: Path) -> str:
    name = sample.name
    for suffix in ["_mesh_only", "_v42", "_prepared", "_normalized"]:
        if name.endswith(suffix):
            name = name[: -len(suffix)]
    return name


def experiment_folder_name(sample: Path, experiment_mode: str) -> str:
    return f"{clean_sample_label(sample)}__{EXPERIMENT_FOLDER_ALIASES.get(experiment_mode, experiment_mode)}"


def main_for_agent_experiment(exp_module) -> None:
    p = argparse.ArgumentParser(description=f"Run CAD assembly agent experiment: {exp_module.EXPERIMENT_MODE}")
    p.add_argument("input", type=Path, help="Prepared sample folder or dataset root")
    p.add_argument("--out", "--output-folder", dest="out", type=Path, default=Path("cad_assembly_agent_runs"))
    p.add_argument("--obj-kind", choices=["mesh", "brep", "auto"], default="mesh")
    p.add_argument("--reference-view-style", choices=["color_by_component"], default=None)
    p.add_argument("--use-mate-graph-json", action="store_true")
    p.add_argument("--node-policy", choices=["predict_subset", "all_library"], default="predict_subset")
    p.add_argument("--raw-obj-mode", choices=["none", "truncated", "full"], default="full")
    p.add_argument("--max-raw-obj-chars", type=int, default=20000)
    p.add_argument("--provider", choices=["openai", "openrouter", "azure", "dry-run"], default="dry-run")
    p.add_argument("--model", default="openai/gpt-4.1")
    p.add_argument("--api-key-env", default="OPENAI_API_KEY")
    p.add_argument("--azure-endpoint", default=None)
    p.add_argument("--azure-endpoint-env", default="AZURE_OPENAI_ENDPOINT")
    p.add_argument("--azure-api-version", default=None)
    p.add_argument("--temperature", type=float, default=0.0)
    p.add_argument("--max-output-tokens", type=int, default=8192, help="Maximum completion tokens requested from OpenAI-compatible chat APIs. Use 0 to omit.")
    p.add_argument("--api-timeout-sec", type=float, default=600.0, help="Per API request timeout in seconds. Use 0 to disable the client timeout.")
    p.add_argument("--max-full-prompt-chars", type=int, default=0, help="Skip full-OBJ samples before API call when prompt exceeds this character count. 0 disables.")
    p.add_argument("--response-mode", choices=["auto", "json_schema", "json_object", "none"], default="json_schema")
    p.add_argument("--openrouter-response-healing", action="store_true")
    p.add_argument("--retry-sleep-sec", type=float, default=2.0)
    p.add_argument("--max-validation-retries", type=int, default=3, help="Validation repair attempts within the same agent round before failing the sample.")
    p.add_argument("--assembly-id", default=None)
    p.add_argument("--recursive", action="store_true")
    p.add_argument("--resume", action="store_true")
    p.add_argument("--max-samples", type=int, default=0)
    p.add_argument("--allow-missing-views", action="store_true")
    p.add_argument("--ignore-preflight", action="store_true")
    p.add_argument("--save-debug", action="store_true")
    p.add_argument("--no-auto-visualize", action="store_true")
    p.add_argument("--num-workers", "--workers", dest="num_workers", type=int, default=1)
    p.add_argument("--agent-iterations", type=int, default=10, help="Maximum agent rounds per sample. Hard-capped at 10.")
    p.add_argument("--min-reference-views", type=int, default=8, help="Minimum required baseline reference images when --allow-missing-views is not set.")
    p.add_argument("--walkaround-frames", type=int, default=20)
    p.add_argument("--walkaround-fps", type=float, default=15.0)
    p.add_argument("--conflict-tolerance-mm", type=float, default=0.01)
    p.add_argument("--conflict-max-pairs", type=int, default=200)
    p.add_argument("--attach-mate-graph-edges-to-prediction", action="store_true", help="For mate-graph agent runs, copy input mate_graph edges into final assembly_prediction.json for downstream visualization/eval.")
    args = p.parse_args()
    args.agent_iterations = max(1, min(int(args.agent_iterations or 1), 10))
    args.walkaround_frames = max(1, int(args.walkaround_frames or 20))
    args.experiment_mode = exp_module.EXPERIMENT_MODE

    if args.provider == "openrouter" and args.api_key_env == "OPENAI_API_KEY":
        args.api_key_env = "OPENROUTER_API_KEY"
    if args.provider == "azure" and args.api_key_env == "OPENAI_API_KEY":
        args.api_key_env = "AZURE_OPENAI_API_KEY"

    samples = discover_dataset_samples(args.input, recursive=args.recursive)
    if args.max_samples > 0:
        samples = samples[: args.max_samples]
    if not samples:
        raise SystemExit(f"No samples found under {args.input}")
    args.out.mkdir(parents=True, exist_ok=True)
    workers = max(1, int(args.num_workers or 1))
    print(f"[OUTPUT_FOLDER] {args.out}")
    print(f"[WORKERS] {workers}")

    batch_start_ts = time.time()
    batch_start_time = time.strftime("%Y-%m-%d %H:%M:%S")
    statuses: List[Dict[str, Any]] = []

    def process_sample(sample: Path) -> Dict[str, Any]:
        out_dir = args.out / experiment_folder_name(sample, args.experiment_mode)
        pred_path = out_dir / "assembly_prediction.json"
        if args.resume and pred_path.exists():
            resume_start_ts = time.time()
            resume_start_time = time.strftime("%Y-%m-%d %H:%M:%S")
            status = finalize_sample_status({"sample_dir": sample.as_posix(), "experiment_dir": out_dir.as_posix(), "experiment_mode": args.experiment_mode, "status": "skipped_resume", "start_time": resume_start_time}, resume_start_ts)
            write_experiment_log(out_dir, status, start_time=resume_start_time, start_ts=resume_start_ts)
            return status
        if out_dir.exists():
            shutil.rmtree(out_dir)
        print(f"[RUN] {sample} -> {out_dir}")
        try:
            return run_one_agent_sample(args, sample, out_dir, exp_module)
        except Exception as exc:
            error_start_ts = time.time()
            error_start_time = time.strftime("%Y-%m-%d %H:%M:%S")
            err = finalize_sample_status({"sample_dir": sample.as_posix(), "experiment_dir": out_dir.as_posix(), "experiment_mode": args.experiment_mode, "status": "error", "error": repr(exc), "start_time": error_start_time}, error_start_ts)
            out_dir.mkdir(parents=True, exist_ok=True)
            write_experiment_log(out_dir, err, start_time=error_start_time, start_ts=error_start_ts)
            print(f"[ERROR] {sample}: {exc}", file=sys.stderr)
            return err

    if workers == 1:
        for sample in samples:
            status = process_sample(sample)
            statuses.append(status)
            write_batch_summary(args.out, statuses, start_time=batch_start_time, start_ts=batch_start_ts, experiment_mode=args.experiment_mode)
            if status.get("status") == "error" and not args.recursive:
                raise SystemExit(1)
    else:
        with ThreadPoolExecutor(max_workers=workers) as executor:
            future_map = {executor.submit(process_sample, sample): sample for sample in samples}
            for fut in as_completed(future_map):
                status = fut.result()
                statuses.append(status)
                write_batch_summary(args.out, statuses, start_time=batch_start_time, start_ts=batch_start_ts, experiment_mode=args.experiment_mode)
    write_batch_summary(args.out, statuses, start_time=batch_start_time, start_ts=batch_start_ts, experiment_mode=args.experiment_mode)
    ok = sum(1 for s in statuses if str(s.get("status", "")).startswith("ok") or s.get("status") == "max_iterations_reached")
    print(f"Done. ok={ok}/{len(statuses)} out={args.out}")
    if any(s.get("status") == "error" for s in statuses):
        raise SystemExit(1)


