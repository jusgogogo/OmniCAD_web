#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Agent Experiment 2: baseline input + iterative walk-around video/frame tool."""
from __future__ import annotations

import json
import os
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional

from cad_assembly_agent_common import (
    main_for_agent_experiment,
    validation_feedback,
)

EXPERIMENT_MODE = "exp_agent_walkaround_video"
EXPECT_EDGES = True
REQUIRE_VIEW_PARAMS_FOR_TOOL = False
TOOL_NAME = "walkaround_video"

PROMPT_SPEC = {
    "name": EXPERIMENT_MODE,
    "agent_exp_label": "AgentExp2",
    "inputs": ['component_library', 'reference_views/color_by_component'],
    "baseline_input": True,
    "runtime_tool": "Walk-around video / frames",
    "task": "Baseline reconstruction with optional walk-around rendered frame feedback.",
}


# ============================================================
# Mate Types（kept local in this experiment file）
# ============================================================

MATE_TYPE_DEFINITIONS: Dict[str, str] = {
    "MateCoincident": "Selected points, lines, planes, or faces on two components are constrained to be coincident or flush, depending on entity type and alignment.",
    "MateConcentric": "Selected cylindrical, circular, or axial entities on two components are constrained to share a common axis.",
    "MateDistanceDim": "Selected entities on two components are constrained to maintain a specified distance.",
    "MateAngleDim": "Selected entities on two components are constrained to maintain a specified angle.",
    "MateParallel": "Selected planar faces, linear edges, or axes on two components are constrained to remain parallel.",
    "MatePerpendicular": "Selected planar faces, linear edges, or axes on two components are constrained to remain perpendicular.",
    "MateTangent": "Selected curved or planar entities on two components are constrained to remain tangent.",
    "MateLock": "The relative position and orientation between two components are fixed.",
    "MateSymmetric": "Selected entities are constrained to remain symmetric about a specified plane or planar face.",
    "MateWidth": "A tab or component is constrained relative to two opposing width faces, often centered between them.",
    "MatePath": "A selected point, vertex, or feature on one component is constrained to follow a specified path.",
    "MateLinearCoupler": "The linear motions of two components are coupled according to a specified translation ratio.",
    "MateCamFollower": "A follower component is constrained to maintain contact with or follow a cam profile.",
    "MateGearDim": "The rotational motions of two components are coupled according to a specified gear ratio.",
    "MateRackPinionDim": "The rotation of one component and the linear translation of another are coupled according to a rack-and-pinion relationship.",
    "MateScrewDim": "Relative rotation and translation between two components are coupled according to a specified screw pitch.",
    "MateHinge": "Two components are constrained to rotate relative to each other about a shared hinge axis.",
    "MateSlot": "A point, axis, or cylindrical feature is constrained to move within a slot.",
    "MateLimitDistanceDim": "The distance between selected entities is constrained within specified minimum and maximum limits.",
    "MateLimitAngleDim": "The angle between selected entities is constrained within specified minimum and maximum limits.",
    "MateUniversalJoint": "Two rotational axes are coupled through a universal-joint relationship.",
}


# ============================================================
# JSON Schema（kept local in this experiment file）
# ============================================================

ASSEMBLY_PREDICTION_SCHEMA: Dict[str, Any] = {
    "type": "object",
    "properties": {
        "nodes": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "component_id": {"type": "string"},
                    "library_id": {"type": "string"},
                    "pose": {
                        "type": "object",
                        "properties": {
                            "position": {
                                "type": "object",
                                "properties": {
                                    "x": {"type": "number"},
                                    "y": {"type": "number"},
                                    "z": {"type": "number"},
                                },
                                "required": ["x", "y", "z"],
                                "additionalProperties": False,
                            },
                            "orientation": {
                                "type": "object",
                                "properties": {
                                    "rx": {"type": "number"},
                                    "ry": {"type": "number"},
                                    "rz": {"type": "number"},
                                },
                                "required": ["rx", "ry", "rz"],
                                "additionalProperties": False,
                            },
                        },
                        "required": ["position", "orientation"],
                        "additionalProperties": False,
                    },
                },
                "required": ["component_id", "library_id", "pose"],
                "additionalProperties": False,
            },
        },
        "edges": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "source_component": {"type": "string"},
                    "target_component": {"type": "string"},
                    "mate_type": {"type": "string", "enum": list(MATE_TYPE_DEFINITIONS.keys())},
                },
                "required": ["source_component", "target_component", "mate_type"],
                "additionalProperties": False,
            },
        },
        "agent_action": {
            "type": "object",
            "properties": {
                "need_next_tool": {"type": "string", "enum": ["yes", "no"]},
            },
            "required": ["need_next_tool"],
            "additionalProperties": False,
        },
    },
    "required": ["nodes", "edges", "agent_action"],
    "additionalProperties": False,
}

# ============================================================
# Response Format（OpenRouter/OpenAI JSON schema）
# ============================================================

response_format = {
    "type": "json_schema",
    "json_schema": {
        "name": f"{EXPERIMENT_MODE}_assembly_prediction_schema",
        "strict": True,
        "schema": ASSEMBLY_PREDICTION_SCHEMA,
    },
}


# ============================================================
# Local JSON / OBJ helpers
# ============================================================

def _json_block(obj: Any) -> str:
    return json.dumps(obj, ensure_ascii=False, indent=2)


def output_schema_example() -> Dict[str, Any]:
    return {
        "nodes": [{"component_id": "c00001", "library_id": "lib00001", "pose": {"position": {"x": 0.0, "y": 0.0, "z": 0.0}, "orientation": {"rx": 0.0, "ry": 0.0, "rz": 0.0}}}, {"component_id": "c00002", "library_id": "lib00002", "pose": {"position": {"x": 10.0, "y": 0.0, "z": 0.0}, "orientation": {"rx": 0.0, "ry": 0.0, "rz": 0.0}}}],
        "edges": [{"source_component": "c00001", "target_component": "c00002", "mate_type": "MateCoincident"}],
        "agent_action": {"need_next_tool": "yes"},
    }


def obj_file_sections(library_json: Dict[str, Any]) -> str:
    sections: List[str] = []
    for item in library_json.get("library", []) or []:
        if not isinstance(item, dict):
            continue
        lib_id = str(item.get("library_id") or item.get("component_id") or "")
        obj_file = str(item.get("obj_file") or f"{lib_id}.mesh.obj")
        obj_name = obj_file.replace("\\\\", "/").replace("\\", "/").split("/")[-1]
        raw = item.get("raw_obj_text")
        header = f"OBJ_FILE: {obj_name}\nLIBRARY_ID: {lib_id}"
        if raw is None:
            sections.append(header + "\nOBJ_CONTENT: <not provided>")
        else:
            sections.append(header + "\nOBJ_CONTENT:\n```obj\n" + str(raw) + "\n```")
    return "\n\n".join(sections)



# ============================================================
# System Prompt（CAD assembly decision agent）
# ============================================================

def build_assembly_decision_system_prompt() -> str:
    return f"""
You are a visual-geometric decision agent for CAD assembly reconstruction.

--------------------------------------------------
TASK:

Reconstruct one visible CAD assembly from these baseline inputs:
- component_library: reusable component-template OBJ files
- reference_views/color_by_component: 8 multi-view target assembly images where each component uses a different color and visible edges are highlighted

Return component instance nodes, absolute poses, component-level mate edges, and an agent_action yes/no decision for the next runtime tool round.

--------------------------------------------------
OUTPUT FORMAT:

Return one JSON object strictly following this experiment's response_format schema.

--------------------------------------------------
POSE DEFINITION:

- pose is the absolute component pose in the prepared assembly coordinate frame
- position uses x, y, z in millimeters
- orientation uses rx, ry, rz Euler angles in degrees
- The runtime applies each predicted pose to the corresponding component-library OBJ mesh.

--------------------------------------------------
COMPONENT DEFINITIONS:

- A CAD assembly is a set of rigid component instances placed in one assembly coordinate frame.
- component_library is a reusable geometry-template library, not the final instance list.
- library_id identifies one reusable geometry template from component_library.
- component_id identifies one predicted component instance in the output.
- Repeated uses of the same library_id are separate component nodes with separate component_id values.
- You may add or delete component instances between agent rounds if the reference views and tool feedback show that the instance count is wrong.
- Across the agent loop, the LLM assembly is allowed to add or delete component instances; update component_id values accordingly and keep them sequential.
- component_id values must be sequential: c00001, c00002, c00003, ...
- Use every provided library_id at least once unless the input is visibly inconsistent.

--------------------------------------------------
REFERENCE VIEW DEFINITIONS:

- The reference views show the same target assembly from 8 camera directions.
- Use all views together to infer 3D placement from silhouette, occlusion, contact, repeated geometry, edge alignment, and multi-view consistency.
- Components use different visual colors and visible edges are highlighted, so color helps track visible component instances across views.
- Color is only a visual segmentation cue; final poses must still be geometrically plausible.

--------------------------------------------------
AGENT ACTION DEFINITIONS:

- agent_action.need_next_tool must be the string "yes" or "no".
- The available runtime tool is fixed by the current experiment, so agent_action does not include a tool-name field.
- If need_next_tool="no", no runtime tool will be called.
- If need_next_tool="yes", the runtime enters the next round and runs this experiment's fixed tool.
- view_rotation_deg and view_scale are optional unless the experiment prompt explicitly requires them.
- The runtime evidence is generated from your current output JSON, not from ground truth.
- Request another tool round only when it can materially improve the prediction.

--------------------------------------------------
ASSEMBLY CONSTRAINTS:

- Predicted components should form a physically plausible assembly.
- Avoid large unintended interpenetration or physically conflicting placements.
- Contacts, alignments, concentric axes, parallel faces, and other visible or geometric assembly relations should be reflected in poses and mate edges.

--------------------------------------------------
MATE TYPE DEFINITIONS FOR OUTPUT EDGES:

{_json_block(MATE_TYPE_DEFINITIONS)}

--------------------------------------------------
MATE EDGE DEFINITIONS:

- A mate edge is a component-level assembly relation between two output component instances.
- source_component and target_component refer to output component_id values.
- mate_type in each output edge must use one of the keys above.
- Mate edges are component-level relations only; do not output mesh face, vertex, or OBJ index relations.

--------------------------------------------------
IMPORTANT:

Output JSON only.
""".strip()


def build_system_prompt() -> str:
    return build_assembly_decision_system_prompt()


# ============================================================
# Prompt（experiment user prompt）
# ============================================================

def build_prompt(
    *,
    assembly_id: str,
    library_json: Dict[str, Any],
    reference_views: Optional[Dict[str, str]] = None,
    reference_view_style: str = "color_by_component",
    reference_assembly_obj: Optional[Dict[str, Any]] = None,
    mate_graph_json: Optional[Dict[str, Any]] = None,
    allowed_mate_types: Optional[List[str]] = None,
    node_policy: str = "predict_subset",
) -> str:
    component_library_text = obj_file_sections(library_json)
    reference_views_text = _json_block(reference_views or {})
    return f"""
You are shown one target CAD assembly through baseline color-by-component reference views.

--------------------------------------------------
TASK:

Predict visible component instances, their absolute poses, component-level mate edges, and whether you need walk-around visual evidence for another round.

--------------------------------------------------
INPUTS:

- component_library
- reference_views/color_by_component

--------------------------------------------------
COMPONENT_LIBRARY:

component_library provides reusable geometry templates.
It does not tell you how many times each part appears.
Use every library_id at least once. If a template appears multiple times in the reference assembly, output multiple component nodes with the same library_id. During later rounds you may add or delete component instances if the current instance count is wrong.

{component_library_text}

--------------------------------------------------
REFERENCE_VIEWS:

The reference views show the same target assembly from 8 camera directions.
Use all views together to infer 3D placement from silhouette, occlusion, contact, repeated geometry, edge alignment, and multi-view consistency.
Components use different visual colors and visible edges are highlighted, so color helps distinguish component instances across views.

{reference_views_text}

--------------------------------------------------
AVAILABLE RUNTIME TOOL:

Tool name: Walk-around video

The runtime tool is fixed for this experiment; the model does not output a tool name.

TOOL REQUEST:
If another agent round is needed, set agent_action.need_next_tool="yes".

VIDEO TOOL DEFINITION:
The runtime takes your current JSON prediction, loads the predicted component OBJ meshes, applies each predicted pose, auto-fits the assembly, and renders one smooth MP4 walk-around video along the regular-dodecahedron spherical route used by omnimech_prep_tools.

TOOL OUTPUT:
If need_next_tool="yes", the next round receives visual evidence sampled from the same walk-around MP4 generated from your current JSON only. It is not ground truth; it is a visual replay of your own predicted assembly. Use it to check hidden-side geometry, depth ordering, component orientation, contact, occlusion, repeated instances, and multi-view consistency.

If your prediction is final, set agent_action.need_next_tool="no".

--------------------------------------------------
OUTPUT:

Return nodes, edges, and agent_action following the response schema.
""".strip()


# ============================================================
# Tool feedback prompt（experiment-specific）
# ============================================================

def build_tool_feedback_prompt(
    *,
    round_index: int,
    tool_mode: str,
    tool_meta: Optional[Dict[str, Any]],
    conflict_report: Optional[Dict[str, Any]],
    fatal: List[str],
    warnings: List[str],
    min_nodes: int,
    expect_edges: bool,
) -> str:
    sections: List[str] = [f"AGENT_TOOL_FEEDBACK_ROUND: {round_index}"]
    sections.append("The original baseline task, component library, and 8 target reference views remain in the conversation context. Use those reference views as the target assembly.")
    sections.append("The attached TOOL_IMAGE frames, if present, are sampled from the same smooth walk-around MP4 generated from your previous predicted JSON only. They are not ground truth; they are visual evidence from the assembly you predicted in the previous round.")
    if fatal:
        sections.append(validation_feedback(fatal, {}, min_nodes, expect_edges=expect_edges))
    if warnings:
        sections.append("VALIDATION_WARNINGS:\n" + _json_block(warnings))
    if tool_meta:
        compact = dict(tool_meta)
        if compact.get("video"):
            compact["video"] = Path(str(compact["video"])).name
        if compact.get("frames"):
            compact["frames"] = [Path(str(x)).name for x in compact.get("frames") or []]
        sections.append("WALKAROUND_RESULT_METADATA:\n" + _json_block(compact))
    sections.append(
        "Use the walk-around video evidence to inspect hidden-side errors, depth ordering, component orientation, contact consistency, occlusion, repeated component instances, component count, library assignment, mate edges, and physical plausibility. You may add or delete component instances if the current instance count is wrong."
    )
    sections.append(
        'Return a corrected COMPLETE JSON prediction, not a patch. If another walk-around round would help, set agent_action.need_next_tool="yes". If final, set agent_action.need_next_tool="no".'
    )
    return "\n\n".join(sections)

def make_experiment_tool_feedback(
    *,
    round_index: int,
    tool_mode: str,
    tool_meta: Optional[Dict[str, Any]],
    conflict_report: Optional[Dict[str, Any]],
    fatal: List[str],
    warnings: List[str],
    min_nodes: int,
    expect_edges: bool,
) -> str:
    return build_tool_feedback_prompt(
        round_index=round_index,
        tool_mode=tool_mode,
        tool_meta=tool_meta,
        conflict_report=conflict_report,
        fatal=fatal,
        warnings=warnings,
        min_nodes=min_nodes,
        expect_edges=expect_edges,
    )



# ============================================================
# Experiment-local API call（kept inside each exp_*.py for debugging）
# ============================================================

def call_experiment_api(
    *,
    args: Any,
    messages: List[Dict[str, Any]],
    response_mode: str = "json_schema",
) -> str:
    """Call the model API for this experiment using this file's local schema.

    This mirrors the oneshot experiment style: each exp_*.py owns its prompt,
    response_format/schema, and API call. The common runner only prepares data
    and executes the agent loop.
    """
    if args.provider == "openrouter":
        from openai import OpenAI
        api_key = os.getenv(args.api_key_env) or os.getenv("openrouter")
        if not api_key:
            raise RuntimeError(f"Missing API key environment variable: {args.api_key_env} or openrouter")
        client = OpenAI(api_key=api_key, base_url="https://openrouter.ai/api/v1")
        kwargs: Dict[str, Any] = {
            "model": args.model,
            "messages": messages,
            "temperature": args.temperature,
        }
        if response_mode == "json_schema":
            kwargs["response_format"] = response_format
        elif response_mode == "json_object":
            kwargs["response_format"] = {"type": "json_object"}
        if getattr(args, "openrouter_response_healing", False):
            kwargs["extra_body"] = {"plugins": [{"id": "response-healing"}]}
        response = client.chat.completions.create(**kwargs)
        return response.choices[0].message.content or ""

    if args.provider == "openai":
        from openai import OpenAI
        api_key = os.getenv(args.api_key_env)
        if not api_key:
            raise RuntimeError(f"Missing API key environment variable: {args.api_key_env}")
        client = OpenAI(api_key=api_key)
        kwargs: Dict[str, Any] = {
            "model": args.model,
            "messages": messages,
            "temperature": args.temperature,
        }
        if response_mode == "json_schema":
            kwargs["response_format"] = response_format
        elif response_mode == "json_object":
            kwargs["response_format"] = {"type": "json_object"}
        response = client.chat.completions.create(**kwargs)
        return response.choices[0].message.content or ""

    if args.provider == "azure":
        from openai import AzureOpenAI
        api_key = os.getenv(args.api_key_env)
        endpoint_val = getattr(args, "azure_endpoint", None) or os.getenv(getattr(args, "azure_endpoint_env", "AZURE_OPENAI_ENDPOINT"))
        if not api_key:
            raise RuntimeError(f"Missing API key environment variable: {args.api_key_env}")
        if not endpoint_val:
            raise RuntimeError(f"Missing Azure endpoint. Use --azure-endpoint or {getattr(args, 'azure_endpoint_env', 'AZURE_OPENAI_ENDPOINT')}")
        client = AzureOpenAI(
            api_key=api_key,
            azure_endpoint=endpoint_val,
            api_version=getattr(args, "azure_api_version", None) or "2024-08-01-preview",
        )
        kwargs: Dict[str, Any] = {
            "model": args.model,
            "messages": messages,
            "temperature": args.temperature,
        }
        if response_mode == "json_schema":
            kwargs["response_format"] = response_format
        elif response_mode == "json_object":
            kwargs["response_format"] = {"type": "json_object"}
        response = client.chat.completions.create(**kwargs)
        return response.choices[0].message.content or ""

    raise ValueError(f"Unsupported provider for API call: {args.provider}")


# ============================================================
# Init conversation（kept for template compatibility）
# ============================================================

def init_conversation(
    *,
    assembly_id: str,
    library_json: Dict[str, Any],
    reference_views: Optional[Dict[str, str]] = None,
    reference_view_style: str = "color_by_component",
    reference_assembly_obj: Optional[Dict[str, Any]] = None,
    mate_graph_json: Optional[Dict[str, Any]] = None,
    allowed_mate_types: Optional[List[str]] = None,
    node_policy: str = "predict_subset",
) -> List[Dict[str, Any]]:
    messages: List[Dict[str, Any]] = []

    messages.append({
        "role": "system",
        "content": [{"type": "text", "text": build_system_prompt()}],
    })

    messages.append({
        "role": "user",
        "content": [{
            "type": "text",
            "text": build_prompt(
                assembly_id=assembly_id,
                library_json=library_json,
                reference_views=reference_views,
                reference_view_style=reference_view_style,
                reference_assembly_obj=reference_assembly_obj,
                mate_graph_json=mate_graph_json,
                allowed_mate_types=allowed_mate_types,
                node_policy=node_policy,
            ),
        }],
    })

    return messages


if __name__ == "__main__":
    main_for_agent_experiment(sys.modules[__name__])


