﻿#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Agent tools for CAD assembly reconstruction experiments.

Tools implemented here are runtime-owned. The model never executes code; it only
requests a tool result through the JSON action fields. The runner then renders or
checks the current prediction and feeds the produced evidence back in the next
LLM round.
"""
from __future__ import annotations

import json
import math
import os
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Tuple

os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
os.environ.setdefault("OMP_NUM_THREADS", "1")

import numpy as np

from cad_assembly_dataset import discover_component_library
from cad_assembly_stage2_common import write_text
from cad_assembly_visualize_prediction import (
    VIEW_EDGE_COLOR,
    color_for_key,
    euler_xyz_to_matrix,
    feature_edges_from_faces,
    library_color_map,
    library_obj_map,
    matrix_to_euler_xyz_deg,
    parse_obj,
    pose_to_rt,
    prediction_nodes,
    render_png,
    transform_vertices,
    visualize,
    _camera_frame_for_view,
    _hex_to_rgb,
    _shade_rgb,
)


def _as_float(value: Any, default: float = 0.0) -> float:
    try:
        if value is None:
            return default
        return float(value)
    except Exception:
        return default


def _is_yes(value: Any) -> bool:
    if isinstance(value, str):
        return value.strip().lower() in {"yes", "y", "true", "1"}
    return bool(value)


def action_from_response(raw_json: Dict[str, Any], tool_name: str = "2d_vis") -> Dict[str, Any]:
    """Extract normalized agent action from a model response.

    The preferred schema uses need_next_tool as the string "yes" or "no".
    Older boolean-style responses are accepted only as a fallback.
    """
    action = raw_json.get("agent_action") if isinstance(raw_json.get("agent_action"), dict) else {}
    need = action.get("need_next_tool")
    if need is None:
        need = action.get("need_tool")
    if need is None and tool_name == "walkaround_video":
        need = action.get("need_video")
    raw_rot = action.get("view_rotation_deg") if "view_rotation_deg" in action else action.get("rotation")
    raw_scale = action.get("view_scale") if "view_scale" in action else action.get("scale")
    rot = raw_rot
    if isinstance(rot, Sequence) and not isinstance(rot, (str, bytes, bytearray)):
        vals = list(rot) + [0.0, 0.0, 0.0]
        rot = {"rx": vals[0], "ry": vals[1], "rz": vals[2]}
    if not isinstance(rot, dict):
        rot = {}
    rotation_values = [
        rot.get("rx", rot.get("x")),
        rot.get("ry", rot.get("y")),
        rot.get("rz", rot.get("z")),
    ]
    has_rotation = isinstance(raw_rot, (dict, list, tuple)) and any(v is not None for v in rotation_values)
    try:
        scale_value = float(raw_scale)
        has_scale = math.isfinite(scale_value) and scale_value > 0.0
    except Exception:
        scale_value = 1.0
        has_scale = False
    scale = scale_value if has_scale else 1.0
    need_2d_vis = action.get("need_2d_vis")
    if need_2d_vis is None:
        need_2d_vis = action.get("need_visualization")
    return {
        "need_next_tool": _is_yes(need),
        "need_next_tool_raw": need,
        "need_2d_vis": _is_yes(need_2d_vis),
        "need_2d_vis_raw": need_2d_vis,
        "runtime_tool": tool_name,
        "has_view_params": bool(has_rotation and has_scale),
        "view_rotation_deg": {
            "rx": _as_float(rot.get("rx", rot.get("x", 0.0))),
            "ry": _as_float(rot.get("ry", rot.get("y", 0.0))),
            "rz": _as_float(rot.get("rz", rot.get("z", 0.0))),
        },
        "view_scale": max(0.05, min(_as_float(scale, 1.0), 50.0)),
    }


def _load_prediction_meshes(sample_dir: Path, pred: Dict[str, Any], obj_kind: str = "mesh") -> List[Dict[str, Any]]:
    obj_map = library_obj_map(sample_dir, obj_kind)
    lib_colors = library_color_map(sample_dir, obj_kind)
    meshes: List[Dict[str, Any]] = []
    for idx, node in enumerate(prediction_nodes(pred)):
        cid = str(node.get("component_id") or f"c{idx + 1:05d}")
        lib_id = str(node.get("library_id") or "")
        obj_path = obj_map.get(lib_id)
        if not obj_path:
            continue
        V, F = parse_obj(obj_path)
        if V.size == 0 or F.size == 0:
            continue
        R, t = pose_to_rt(node)
        Vt = transform_vertices(V, R, t)
        meshes.append({
            "component_id": cid,
            "library_id": lib_id,
            "vertices": Vt,
            "faces": F,
            "color": lib_colors.get(lib_id) or color_for_key(lib_id or cid),
            "pose": node.get("pose") or {},
        })
    return meshes


def _rotate_points_about_center(points: np.ndarray, R: np.ndarray, center: np.ndarray, scale: float = 1.0) -> np.ndarray:
    if points.size == 0:
        return points
    centered = points - center.reshape(1, 3)
    return (R @ (centered * float(scale)).T).T + center.reshape(1, 3)


def _project_for_direction(vertices: np.ndarray, direction: np.ndarray) -> Tuple[np.ndarray, np.ndarray, Tuple[np.ndarray, np.ndarray, np.ndarray]]:
    direction = np.asarray(direction, dtype=float)
    norm = float(np.linalg.norm(direction))
    if norm < 1e-12:
        direction = np.array([1.0, 1.0, 1.0], dtype=float)
        norm = float(np.linalg.norm(direction))
    direction = direction / norm
    forward = -direction
    up_hint = np.array([0.0, 0.0, 1.0], dtype=float)
    if abs(float(np.dot(up_hint, forward))) > 0.92:
        up_hint = np.array([0.0, 1.0, 0.0], dtype=float)
    right = np.cross(forward, up_hint)
    if float(np.linalg.norm(right)) < 1e-12:
        up_hint = np.array([1.0, 0.0, 0.0], dtype=float)
        right = np.cross(forward, up_hint)
    right = right / max(float(np.linalg.norm(right)), 1e-12)
    up = np.cross(right, forward)
    up = up / max(float(np.linalg.norm(up)), 1e-12)
    mins = vertices.min(axis=0)
    maxs = vertices.max(axis=0)
    center = (mins + maxs) / 2.0
    diag = float(np.linalg.norm(maxs - mins))
    cam_dist = max(diag * 2.4, 1.0)
    cam_pos = center - forward * cam_dist
    rel = vertices - cam_pos
    z = rel @ forward
    x = rel @ right
    y = rel @ up
    eps = max(diag * 1e-4, 1e-6)
    denom = np.maximum(z, eps)
    xy = np.column_stack([x / denom, y / denom])
    return xy, z, (forward, right, up)


def _rotated_camera_direction(direction: np.ndarray, rotation_deg: Optional[Dict[str, Any]]) -> np.ndarray:
    rd = rotation_deg or {}
    Rg = euler_xyz_to_matrix(
        _as_float(rd.get("rx", rd.get("x", 0.0))),
        _as_float(rd.get("ry", rd.get("y", 0.0))),
        _as_float(rd.get("rz", rd.get("z", 0.0))),
    )
    out = Rg @ np.asarray(direction, dtype=float)
    return out / max(float(np.linalg.norm(out)), 1e-12)


def _camera_basis_from_direction(direction: np.ndarray) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    direction = np.asarray(direction, dtype=float)
    n = float(np.linalg.norm(direction))
    if n < 1e-12:
        direction = np.array([1.55, 1.55, 1.25], dtype=float)
        n = float(np.linalg.norm(direction))
    direction = direction / n
    forward = -direction
    up_hint = np.array([0.0, 0.0, 1.0], dtype=float)
    if abs(float(np.dot(up_hint, forward))) > 0.92:
        up_hint = np.array([0.0, 1.0, 0.0], dtype=float)
    right = np.cross(forward, up_hint)
    if float(np.linalg.norm(right)) < 1e-12:
        up_hint = np.array([1.0, 0.0, 0.0], dtype=float)
        right = np.cross(forward, up_hint)
    right = right / max(float(np.linalg.norm(right)), 1e-12)
    up = np.cross(right, forward)
    up = up / max(float(np.linalg.norm(up)), 1e-12)
    return forward, right, up


def _render_agent_pyvista_png(
    meshes: List[Dict[str, Any]],
    out_path: Path,
    rotation_deg: Optional[Dict[str, Any]] = None,
    view_scale: float = 1.0,
    camera_direction: Optional[Sequence[float]] = None,
) -> bool:
    try:
        import pyvista as pv
    except Exception:
        return False
    plotter = None
    try:
        plotter = pv.Plotter(off_screen=True, window_size=(1280, 960))
        plotter.set_background("white")
        try:
            plotter.enable_anti_aliasing("ssaa")
        except Exception:
            pass
        all_points: List[np.ndarray] = []
        for mesh_idx, m in enumerate(meshes):
            V, F = m.get("vertices"), m.get("faces")
            if V is None or F is None or V.size == 0 or F.size == 0:
                continue
            faces = np.column_stack([np.full(len(F), 3, dtype=int), F.astype(int)]).ravel()
            poly = pv.PolyData(V, faces).clean().triangulate()
            if poly.n_points == 0 or poly.n_cells == 0:
                continue
            all_points.append(np.asarray(poly.points, dtype=float))
            plotter.add_mesh(
                poly,
                color=m.get("color") or color_for_key(m.get("library_id") or m.get("component_id") or mesh_idx),
                opacity=1.0,
                smooth_shading=False,
                show_edges=False,
                ambient=0.82,
                diffuse=0.24,
                specular=0.02,
            )
            try:
                feature = poly.extract_feature_edges(
                    feature_angle=35,
                    boundary_edges=True,
                    non_manifold_edges=True,
                    feature_edges=True,
                    manifold_edges=False,
                )
                if feature.n_points > 0:
                    plotter.add_mesh(feature, color=VIEW_EDGE_COLOR, line_width=1.0, render_lines_as_tubes=False)
            except Exception:
                pass
        if not all_points:
            return False
        points = np.vstack(all_points)
        mins = points.min(axis=0)
        maxs = points.max(axis=0)
        center = (mins + maxs) / 2.0
        diag = max(float(np.linalg.norm(maxs - mins)), 1.0)
        base_dir = np.asarray(camera_direction if camera_direction is not None else [1.55, 1.55, 1.25], dtype=float)
        direction = _rotated_camera_direction(base_dir, rotation_deg)
        forward, right, up = _camera_basis_from_direction(direction)
        camera_pos = center - forward * diag * 2.8
        plotter.camera_position = [tuple(camera_pos.tolist()), tuple(center.tolist()), tuple(up.tolist())]
        plotter.camera.parallel_projection = True
        centered = points - center
        half_width = max(float(np.max(np.abs(centered @ right))), 1e-6)
        half_height = max(float(np.max(np.abs(centered @ up))), 1e-6)
        aspect = 1280 / 960
        zoom = max(0.05, min(float(view_scale or 1.0), 50.0))
        plotter.camera.parallel_scale = max(half_height, half_width / aspect, 1e-6) / (0.90 * zoom)
        plotter.reset_camera_clipping_range()
        out_path.parent.mkdir(parents=True, exist_ok=True)
        plotter.screenshot(str(out_path), transparent_background=False)
        return out_path.exists() and out_path.stat().st_size > 0
    except Exception:
        return False
    finally:
        if plotter is not None:
            try:
                plotter.close()
            except Exception:
                pass

def render_agent_view_png(
    meshes: List[Dict[str, Any]],
    out_path: Path,
    rotation_deg: Optional[Dict[str, Any]] = None,
    view_scale: float = 1.0,
    camera_direction: Optional[Sequence[float]] = None,
    width_inches: float = 7.2,
    dpi: int = 180,
) -> None:
    """Render a CAD-style PNG from transformed component meshes.

    rotation_deg controls a global rotation applied around the current predicted
    assembly center. view_scale behaves like zoom: larger values make the object
    occupy more of the frame.
    """
    if not meshes:
        out_path.parent.mkdir(parents=True, exist_ok=True)
        write_text(out_path.with_suffix(".txt"), "No renderable meshes in prediction.")
        return

    if _render_agent_pyvista_png(meshes, out_path, rotation_deg=rotation_deg, view_scale=view_scale, camera_direction=camera_direction):
        return

    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib.collections import LineCollection, PolyCollection

    all_vertices = [m["vertices"] for m in meshes if m.get("vertices") is not None and m["vertices"].size > 0]
    P = np.vstack(all_vertices)
    center = (P.min(axis=0) + P.max(axis=0)) / 2.0
    rd = rotation_deg or {}
    Rg = euler_xyz_to_matrix(_as_float(rd.get("rx", rd.get("x", 0.0))), _as_float(rd.get("ry", rd.get("y", 0.0))), _as_float(rd.get("rz", rd.get("z", 0.0))))
    zoom = max(0.05, min(float(view_scale or 1.0), 50.0))
    direction = np.asarray(camera_direction if camera_direction is not None else [0.0, 1.0, 0.35], dtype=float)

    polygons: List[np.ndarray] = []
    colors: List[Any] = []
    depths: List[float] = []
    edge_segments: List[np.ndarray] = []
    edge_depths: List[float] = []
    all_xy: List[np.ndarray] = []
    remaining_faces = 80000

    for mesh_idx, m in enumerate(meshes):
        V0 = m["vertices"]
        F = m["faces"]
        if V0.size == 0 or F.size == 0 or remaining_faces <= 0:
            continue
        V = _rotate_points_about_center(V0, Rg, center, scale=1.0)
        xy, depth, basis = _project_for_direction(V, direction)
        forward, right, up = basis
        light_dir = -(forward - 0.35 * up + 0.20 * right)
        light_dir = light_dir / max(float(np.linalg.norm(light_dir)), 1e-12)
        base_rgb = _hex_to_rgb(m.get("color"))
        if len(F) > remaining_faces:
            step = max(1, len(F) // max(1, remaining_faces))
            F2 = F[::step][:remaining_faces]
        else:
            F2 = F
        remaining_faces -= len(F2)
        for a, b in feature_edges_from_faces(V, F, angle_deg=85.0, max_edges=1400):
            try:
                edge_segments.append(np.asarray([xy[a], xy[b]], dtype=float))
                edge_depths.append(float((depth[a] + depth[b]) * 0.5))
            except Exception:
                pass
        for tri in F2:
            try:
                if max(tri) >= len(V):
                    continue
                pts3 = V[tri]
                n = np.cross(pts3[1] - pts3[0], pts3[2] - pts3[0])
                n_norm = float(np.linalg.norm(n))
                shade = abs(float(np.dot(n / n_norm, light_dir))) if n_norm > 1e-12 else 0.55
                polygons.append(xy[tri])
                depths.append(float(depth[tri].mean()))
                colors.append(_shade_rgb(base_rgb, 0.45 + 0.55 * shade))
            except Exception:
                pass
        all_xy.append(xy)

    order = np.argsort(depths)[::-1] if depths else []
    polygons = [polygons[i] for i in order]
    colors = [colors[i] for i in order]

    fig, ax = plt.subplots(figsize=(width_inches, width_inches), dpi=dpi)
    ax.set_facecolor("white")
    if polygons:
        pc = PolyCollection(polygons, facecolors=colors, edgecolors="none", linewidths=0.0, alpha=1.0)
        ax.add_collection(pc)
        pts = np.vstack(all_xy)
        mins = pts.min(axis=0)
        maxs = pts.max(axis=0)
        span = max(float((maxs - mins).max()), 1.0) / zoom
        center2 = (mins + maxs) / 2
        pad = span * 0.06
        ax.set_xlim(center2[0] - span / 2 - pad, center2[0] + span / 2 + pad)
        ax.set_ylim(center2[1] - span / 2 - pad, center2[1] + span / 2 + pad)
        if edge_segments:
            edge_order = np.argsort(edge_depths)[::-1]
            ordered_edges = [edge_segments[i] for i in edge_order]
            ax.add_collection(LineCollection(ordered_edges, colors=VIEW_EDGE_COLOR, linewidths=0.45, alpha=0.88, antialiaseds=True))
    ax.set_aspect("equal")
    ax.axis("off")
    out_path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(out_path, bbox_inches="tight", pad_inches=0.0, facecolor="white", edgecolor="none")
    plt.close(fig)


def render_2d_vis_tool(
    sample_dir: Path,
    pred: Dict[str, Any],
    out_dir: Path,
    round_index: int,
    obj_kind: str,
    action: Dict[str, Any],
) -> Dict[str, Any]:
    """Generate the 2D visual tool evidence from the current prediction.

    This is intentionally a clean render+capture tool, not the older interactive
    HTML UI.  The returned PNG contains only the predicted assembly area: no
    right-side information panel, no axes, no coordinate labels, and no widget
    chrome.  The final pipeline may still create interactive HTML separately,
    but agent feedback uses this clean screenshot only.
    """
    out_dir.mkdir(parents=True, exist_ok=True)
    meshes = _load_prediction_meshes(sample_dir, pred, obj_kind=obj_kind)
    png_path = out_dir / f"round_{round_index:02d}_2d_vis.png"
    render_agent_view_png(
        meshes,
        png_path,
        rotation_deg=action.get("view_rotation_deg") or {},
        view_scale=float(action.get("view_scale") or 1.0),
    )
    meta = {
        "tool": "2d_vis_rotate_zoom",
        "round": round_index,
        "png": str(png_path),
        "render_type": "clean_prediction_screenshot",
        "contains_interactive_ui": False,
        "contains_axes_or_coordinate_labels": False,
        "view_rotation_deg": action.get("view_rotation_deg") or {},
        "view_scale": action.get("view_scale") or 1.0,
    }
    return meta


def _unit(v: np.ndarray) -> np.ndarray:
    n = float(np.linalg.norm(v))
    if n <= 1e-12:
        return v
    return v / n


def _dodecahedron_adjacency(directions: List[np.ndarray]) -> List[List[int]]:
    count = len(directions)
    distances = np.full((count, count), np.inf, dtype=float)
    for i in range(count):
        for j in range(i + 1, count):
            distance = float(np.linalg.norm(directions[i] - directions[j]))
            distances[i, j] = distances[j, i] = distance
    edge_length = float(np.min(distances))
    tolerance = edge_length * 1e-6
    return [
        sorted(
            j
            for j in range(count)
            if i != j and abs(float(distances[i, j]) - edge_length) <= tolerance
        )
        for i in range(count)
    ]


def _dodecahedron_vertex_route(directions: List[np.ndarray], closed: bool = False) -> List[int]:
    """Hamiltonian-style route over the 20 dodecahedron vertices.

    This uses neighboring regular-dodecahedron vertices where possible instead
    of jumping through raw vertex order. For agent feedback we normally return
    the 20 key vertex views, not every interpolated video frame, to keep API
    image payloads bounded.
    """
    adjacency = _dodecahedron_adjacency(directions)
    count = len(directions)
    start = 0
    route = [start]
    visited = {start}

    def search(current: int) -> bool:
        if len(route) == count:
            return (not closed) or (start in adjacency[current])
        candidates = sorted(
            (node for node in adjacency[current] if node not in visited),
            key=lambda node: sum(1 for nxt in adjacency[node] if nxt not in visited),
        )
        for node in candidates:
            visited.add(node)
            route.append(node)
            if search(node):
                return True
            route.pop()
            visited.remove(node)
        return False

    if search(start):
        return route

    remaining = set(range(count))
    route = [start]
    remaining.remove(start)
    while remaining:
        current = route[-1]
        next_node = min(remaining, key=lambda node: float(np.linalg.norm(directions[current] - directions[node])))
        route.append(next_node)
        remaining.remove(next_node)
    return route


def _dodecahedron_directions() -> List[np.ndarray]:
    """Return the same 20 unit directions as omnimech_prep_tools.

    Order matches render_cad_wireframe_all_angle.py: 8 cube-corner vertices
    followed by 12 golden-ratio vertices.
    """
    import itertools

    phi = (1.0 + math.sqrt(5.0)) * 0.5
    inverse_phi = 1.0 / phi
    vertices: List[Tuple[float, float, float]] = []
    vertices.extend(itertools.product((-1.0, 1.0), repeat=3))
    for first_sign, second_sign in itertools.product((-1.0, 1.0), repeat=2):
        vertices.extend(
            (
                (0.0, first_sign * inverse_phi, second_sign * phi),
                (first_sign * inverse_phi, second_sign * phi, 0.0),
                (first_sign * phi, 0.0, second_sign * inverse_phi),
            )
        )
    return [_unit(np.asarray(vertex, dtype=float)) for vertex in vertices]


def _slerp(start: np.ndarray, end: np.ndarray, t: float) -> np.ndarray:
    start = start / max(float(np.linalg.norm(start)), 1e-12)
    end = end / max(float(np.linalg.norm(end)), 1e-12)
    dot = float(np.clip(np.dot(start, end), -1.0, 1.0))
    if dot > 0.999999:
        blended = (1.0 - t) * start + t * end
        return blended / max(float(np.linalg.norm(blended)), 1e-12)
    angle = math.acos(dot)
    sin_angle = math.sin(angle)
    return (
        math.sin((1.0 - t) * angle) / sin_angle * start
        + math.sin(t * angle) / sin_angle * end
    )


def _smooth_dodecahedron_video_directions(rotation_step_deg: float = 1.0, closed: bool = True) -> List[Tuple[float, float, float]]:
    step = max(0.1, min(float(rotation_step_deg or 1.0), 360.0))
    directions = _dodecahedron_directions()
    route = _dodecahedron_vertex_route(directions, closed=closed)
    path = [directions[index] for index in route]
    if closed and path:
        path.append(path[0])
    frames: List[np.ndarray] = []
    for segment_index in range(max(0, len(path) - 1)):
        start = path[segment_index]
        end = path[segment_index + 1]
        angle = math.degrees(math.acos(float(np.clip(np.dot(start, end), -1.0, 1.0))))
        frame_count = max(1, int(math.ceil(angle / step)))
        for frame_index in range(frame_count):
            frames.append(_slerp(start, end, frame_index / frame_count))
    if not closed and path:
        frames.append(path[-1])
    return [tuple(float(x) for x in direction.tolist()) for direction in frames]

def _walkaround_directions(frame_count: int = 20) -> List[Tuple[float, float, float]]:
    base = _dodecahedron_directions()
    routed = [tuple(float(x) for x in direction.tolist()) for direction in base]
    if frame_count <= 0:
        frame_count = len(routed)
    if frame_count == len(routed):
        return routed
    if frame_count < len(routed):
        idxs = [round(i * (len(routed) - 1) / max(frame_count - 1, 1)) for i in range(frame_count)]
        return [routed[i] for i in idxs]
    return routed + [routed[i % len(routed)] for i in range(frame_count - len(routed))]

def render_walkaround_tool(
    sample_dir: Path,
    pred: Dict[str, Any],
    out_dir: Path,
    round_index: int,
    obj_kind: str,
    frame_count: int = 20,
    fps: float = 15.0,
) -> Dict[str, Any]:
    """Render one smooth walk-around MP4 and sample API-visible frames from it.

    The MP4 is the single tool artifact. Because the current chat wrapper only
    attaches image inputs, the returned frames are sampled from that MP4 instead
    of rendered through a separate 20-view path.
    """
    out_dir.mkdir(parents=True, exist_ok=True)
    meshes = _load_prediction_meshes(sample_dir, pred, obj_kind=obj_kind)
    frames_dir = out_dir / f"round_{round_index:02d}_walkaround_frames"
    frames_dir.mkdir(parents=True, exist_ok=True)
    for old in frames_dir.glob("*.png"):
        try:
            old.unlink()
        except Exception:
            pass

    video_path = out_dir / f"round_{round_index:02d}_walkaround.mp4"
    video_error = None
    video_frame_count = 0
    video_fps = float(fps or 15.0)
    video_duration_sec = None
    frame_paths: List[str] = []
    try:
        import cv2
        video_directions = _smooth_dodecahedron_video_directions(rotation_step_deg=1.0, closed=True)
        temp_frame = out_dir / f"round_{round_index:02d}_walkaround_video_frame.png"
        writer = None
        try:
            for video_index, direction in enumerate(video_directions, start=1):
                render_agent_view_png(meshes, temp_frame, rotation_deg={}, view_scale=1.0, camera_direction=direction)
                img = cv2.imread(str(temp_frame), cv2.IMREAD_COLOR)
                if img is None:
                    raise RuntimeError(f"could not read rendered video frame {video_index}")
                h, w = img.shape[:2]
                if writer is None:
                    writer = cv2.VideoWriter(str(video_path), cv2.VideoWriter_fourcc(*"mp4v"), video_fps, (w, h))
                    if not writer.isOpened():
                        raise RuntimeError("OpenCV could not initialize MP4 writer")
                writer.write(img)
                video_frame_count += 1
        finally:
            if writer is not None:
                writer.release()
            try:
                temp_frame.unlink(missing_ok=True)
            except Exception:
                pass
        if not video_path.exists() or video_path.stat().st_size == 0:
            raise RuntimeError("empty MP4 output")
        video_duration_sec = round(video_frame_count / video_fps, 3) if video_fps else None

        capture = cv2.VideoCapture(str(video_path))
        try:
            readable_count = int(capture.get(cv2.CAP_PROP_FRAME_COUNT)) or video_frame_count
            sample_count = max(1, min(int(frame_count or 20), readable_count))
            if sample_count == 1:
                sample_indices = [0]
            else:
                sample_indices = [round(i * (readable_count - 1) / (sample_count - 1)) for i in range(sample_count)]
            for out_index, source_index in enumerate(sample_indices, start=1):
                capture.set(cv2.CAP_PROP_POS_FRAMES, max(int(source_index), 0))
                ok, frame_img = capture.read()
                if not ok or frame_img is None:
                    continue
                frame_path = frames_dir / f"frame_{out_index:02d}.png"
                cv2.imwrite(str(frame_path), frame_img)
                if frame_path.exists():
                    frame_paths.append(str(frame_path))
        finally:
            capture.release()
    except Exception as exc:
        video_error = repr(exc)
        video_path = None  # type: ignore[assignment]

    meta = {
        "tool": "walkaround_video_smooth_dodecahedron",
        "round": round_index,
        "video": str(video_path) if video_path else None,
        "video_error": video_error,
        "video_path_mode": "dodecahedron",
        "video_rotation_step_deg": 1.0,
        "video_frame_count": video_frame_count,
        "video_fps": video_fps,
        "video_duration_sec": video_duration_sec,
        "api_frame_source": "sampled_from_same_video",
        "api_frame_count": len(frame_paths),
        "frames": frame_paths,
    }
    return meta

def _bbox(vertices: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
    return vertices.min(axis=0), vertices.max(axis=0)


def _bbox_intersection(a_min: np.ndarray, a_max: np.ndarray, b_min: np.ndarray, b_max: np.ndarray) -> Tuple[np.ndarray, float]:
    overlap = np.maximum(0.0, np.minimum(a_max, b_max) - np.maximum(a_min, b_min))
    return overlap, float(overlap[0] * overlap[1] * overlap[2])


def _bbox_volume(a_min: np.ndarray, a_max: np.ndarray) -> float:
    size = np.maximum(0.0, a_max - a_min)
    return float(size[0] * size[1] * size[2])


def conflict_check(
    sample_dir: Path,
    pred: Dict[str, Any],
    obj_kind: str = "mesh",
    tolerance_mm: float = 0.01,
    max_pairs: int = 200,
) -> Dict[str, Any]:
    """Approximate mesh interpenetration check for predicted component poses.

    The first pass uses transformed AABB intersection. If trimesh is available
    and meshes are usable, it also samples mutual vertex containment to estimate
    deep interpenetration. This is intentionally conservative: contact or flush
    mates are not marked as conflicts unless the overlap is non-trivial.
    """
    meshes = _load_prediction_meshes(sample_dir, pred, obj_kind=obj_kind)
    entries: List[Dict[str, Any]] = []
    for m in meshes:
        V = m["vertices"]
        if V.size == 0:
            continue
        bmin, bmax = _bbox(V)
        vol = _bbox_volume(bmin, bmax)
        entries.append({**m, "bbox_min": bmin, "bbox_max": bmax, "bbox_volume": max(vol, 1e-12)})

    conflicts: List[Dict[str, Any]] = []
    checked = 0
    trimesh = None
    try:
        import trimesh as _trimesh
        trimesh = _trimesh
    except Exception:
        trimesh = None

    for i in range(len(entries)):
        for j in range(i + 1, len(entries)):
            if checked >= max_pairs:
                break
            checked += 1
            a = entries[i]
            b = entries[j]
            overlap_size, overlap_volume = _bbox_intersection(a["bbox_min"], a["bbox_max"], b["bbox_min"], b["bbox_max"])
            if overlap_volume <= max(float(tolerance_mm) ** 3, 1e-12):
                continue
            ratio = overlap_volume / max(min(a["bbox_volume"], b["bbox_volume"]), 1e-12)
            evidence = {
                "bbox_overlap_size_mm": [round(float(x), 6) for x in overlap_size.tolist()],
                "bbox_intersection_volume": round(float(overlap_volume), 6),
                "bbox_overlap_ratio_of_smaller_bbox": round(float(ratio), 6),
            }
            method = "aabb_overlap"
            severity = "possible"
            vertex_inside_count = None
            if trimesh is not None:
                try:
                    ma = trimesh.Trimesh(vertices=a["vertices"], faces=a["faces"], process=False)
                    mb = trimesh.Trimesh(vertices=b["vertices"], faces=b["faces"], process=False)
                    # Sampling vertices is cheap and deterministic. Contains may
                    # fail if rtree is absent or mesh is not watertight.
                    ainb = mb.contains(a["vertices"][:: max(1, len(a["vertices"]) // 2000)])
                    bina = ma.contains(b["vertices"][:: max(1, len(b["vertices"]) // 2000)])
                    count = int(np.count_nonzero(ainb)) + int(np.count_nonzero(bina))
                    vertex_inside_count = count
                    evidence["sampled_vertex_inside_count"] = count
                    method = "trimesh_vertex_containment+aabb"
                    if count > 0:
                        severity = "likely"
                except Exception as exc:
                    evidence["trimesh_error"] = repr(exc)
            if severity == "possible" and ratio < 1e-4:
                # Very small AABB overlaps are often legitimate touching faces or
                # bbox artifacts, so suppress them unless we have stronger proof.
                continue
            conflicts.append({
                "component_a": a["component_id"],
                "component_b": b["component_id"],
                "library_a": a.get("library_id"),
                "library_b": b.get("library_id"),
                "severity": severity,
                "method": method,
                "evidence": evidence,
            })
        if checked >= max_pairs:
            break
    return {
        "checked_component_count": len(entries),
        "checked_pair_count": checked,
        "conflict_count": len(conflicts),
        "conflict_pairs": conflicts,
        "tolerance_mm": tolerance_mm,
        "note": "AABB overlap is conservative; treat severity=likely as stronger than severity=possible.",
    }








