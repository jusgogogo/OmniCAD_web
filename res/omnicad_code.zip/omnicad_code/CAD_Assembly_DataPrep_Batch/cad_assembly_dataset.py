#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Dataset discovery utilities for component-level CAD assembly experiments."""
from __future__ import annotations

import hashlib
import json
import math
import re
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

GOLDEN_RATIO = (1.0 + math.sqrt(5.0)) / 2.0
DODECAHEDRON_VIEW_NAMES = [f"v{i:02d}" for i in range(1, 21)]
CUBE_VERTEX_VIEW_NAMES = [f"v{i:02d}" for i in range(1, 9)]
VIEW_NAMES = CUBE_VERTEX_VIEW_NAMES
IMG_EXTS = [".png", ".jpg", ".jpeg", ".webp"]


def dodecahedron_vertex_positions() -> List[Tuple[float, float, float]]:
    """Return 20 regular-dodecahedron vertex directions in a fixed order.

    The reference-view pipeline uses these vertices as camera centers, matching
    the RotationNet case-(ii) setup conceptually: 20 views from the 20 vertices
    of a dodecahedron around the object.
    """
    phi = GOLDEN_RATIO
    inv = 1.0 / phi
    return [
        (0.0,  inv,  phi),
        (1.0,  1.0,  1.0),
        (phi,  0.0,  inv),
        (1.0, -1.0,  1.0),
        (0.0, -inv,  phi),
        (-1.0, -1.0,  1.0),
        (-phi,  0.0,  inv),
        (-1.0,  1.0,  1.0),
        (inv,  phi,  0.0),
        (inv, -phi,  0.0),
        (-inv, -phi,  0.0),
        (-inv,  phi,  0.0),
        (0.0,  inv, -phi),
        (1.0,  1.0, -1.0),
        (phi,  0.0, -inv),
        (1.0, -1.0, -1.0),
        (0.0, -inv, -phi),
        (-1.0, -1.0, -1.0),
        (-phi,  0.0, -inv),
        (-1.0,  1.0, -1.0),
    ]


def cube_vertex_positions() -> List[Tuple[float, float, float]]:
    """Return 8 cube-vertex camera directions in the omnimech static-view order."""
    return [
        (-1.0, -1.0, -1.0),
        (-1.0, -1.0,  1.0),
        (-1.0,  1.0, -1.0),
        (-1.0,  1.0,  1.0),
        ( 1.0, -1.0, -1.0),
        ( 1.0, -1.0,  1.0),
        ( 1.0,  1.0, -1.0),
        ( 1.0,  1.0,  1.0),
    ]


def view_direction(view: str) -> Tuple[float, float, float]:
    legacy = {
        "front": (0.0, -1.0, 0.0),
        "right": (1.0, 0.0, 0.0),
        "top": (0.0, 0.0, 1.0),
        "iso": (1.0, 1.0, 1.0),
    }
    if view in legacy:
        return legacy[view]
    m = re.fullmatch(r"v(\d{2})", str(view).lower())
    if not m:
        raise ValueError(f"Unsupported view name: {view}")
    idx = int(m.group(1)) - 1
    cube_verts = cube_vertex_positions()
    if 0 <= idx < len(cube_verts):
        return cube_verts[idx]
    verts = dodecahedron_vertex_positions()
    if idx < 0 or idx >= len(verts):
        raise ValueError(f"Unsupported dodecahedron view index: {view}")
    return verts[idx]


def read_json(path: Path) -> Any:
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def write_json(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


def safe_rel(path: Path, root: Path) -> str:
    try:
        return path.resolve().relative_to(root.resolve()).as_posix()
    except Exception:
        return path.as_posix()


def sanitize_token(text: str) -> str:
    return re.sub(r"[^A-Za-z0-9]+", "_", str(text or "")).strip("_")


def component_id_from_text(text: str) -> Optional[str]:
    m = re.search(r"(c\d{5})", str(text), flags=re.IGNORECASE)
    return m.group(1).lower() if m else None


def library_id_from_text(text: str) -> Optional[str]:
    m = re.search(r"(lib\d{5})", str(text), flags=re.IGNORECASE)
    return m.group(1).lower() if m else None


def part_id_from_text(text: str) -> Optional[str]:
    m = re.search(r"(p\d{5})", str(text), flags=re.IGNORECASE)
    return m.group(1).lower() if m else None


def find_first_existing(paths: Iterable[Path]) -> Optional[Path]:
    for p in paths:
        if p and p.exists():
            return p
    return None


_FALSE_STRINGS = {"false", "0", "hidden", "invisible", "suppressed", "no", "off", "none", "null"}
_TRUE_STRINGS = {"true", "1", "visible", "shown", "yes", "on"}


def _boolish(value: Any) -> Optional[bool]:
    if value is None:
        return None
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return bool(value)
    if isinstance(value, str):
        text = value.strip().lower()
        if text in _FALSE_STRINGS:
            return False
        if text in _TRUE_STRINGS:
            return True
    return None


def is_component_visible(record: Dict[str, Any]) -> bool:
    hidden_keys = [
        "hidden", "is_hidden", "component_hidden", "hidden_in_assembly",
        "suppressed", "is_suppressed", "component_suppressed",
        "exclude_from_reference_view", "exclude_from_dataset",
    ]
    for key in hidden_keys:
        if key in record and _boolish(record.get(key)) is True:
            return False
    visible_keys = ["visible", "is_visible", "component_visible", "visible_in_assembly", "shown", "is_shown"]
    for key in visible_keys:
        if key in record:
            parsed = _boolish(record.get(key))
            if parsed is not None:
                return parsed
    visibility = record.get("visibility") or record.get("display_state") or record.get("state")
    if isinstance(visibility, str) and visibility.strip().lower() in {"hidden", "invisible", "suppressed", "not_visible", "not shown", "not_shown"}:
        return False
    return True


def find_gt_json(sample_dir: Path) -> Optional[Path]:
    for p in [sample_dir / "assembly_graph_gt.json", sample_dir / "gt" / "assembly_graph_gt.json", sample_dir / "manifest.json"]:
        if p.exists():
            return p
    for p in sorted(sample_dir.glob("*.json")):
        if p.name in {"library.json", "mate_graph.json"}:
            continue
        try:
            data = read_json(p)
        except Exception:
            continue
        if isinstance(data, dict) and ("node_parts" in data or "dependency_graph" in data or ("nodes" in data and "edges" in data)):
            return p
    return None



def sw_transform_to_pose(transform: Dict[str, Any]) -> Tuple[Dict[str, float], Dict[str, float]]:
    arr = None
    if isinstance(transform, dict):
        arr = transform.get("array_data") or transform.get("ArrayData")
    if not isinstance(arr, list) or len(arr) < 12:
        return {}, {}
    vals = [float(v) for v in arr]
    R = [
        [vals[0], vals[3], vals[6]],
        [vals[1], vals[4], vals[7]],
        [vals[2], vals[5], vals[8]],
    ]
    position = {"x": vals[9] * 1000.0, "y": vals[10] * 1000.0, "z": vals[11] * 1000.0}
    sy = math.sqrt(R[0][0] * R[0][0] + R[1][0] * R[1][0])
    singular = sy < 1e-9
    if not singular:
        rx = math.atan2(R[2][1], R[2][2])
        ry = math.atan2(-R[2][0], sy)
        rz = math.atan2(R[1][0], R[0][0])
    else:
        rx = math.atan2(-R[1][2], R[1][1])
        ry = math.atan2(-R[2][0], sy)
        rz = 0.0
    orientation = {"rx": math.degrees(rx), "ry": math.degrees(ry), "rz": math.degrees(rz)}
    return position, orientation


def _mate_type(e: Dict[str, Any]) -> str:
    mts = e.get("mate_types")
    if isinstance(mts, list) and mts:
        return str(mts[0])
    return str(e.get("mate_type") or e.get("solidworks_type") or e.get("type") or e.get("mate_name") or "UnknownMate")

def _node_id(n: Dict[str, Any]) -> Optional[str]:
    return n.get("component_id") or n.get("id") or n.get("component")


def _edge_pair(e: Dict[str, Any]) -> Tuple[Optional[str], Optional[str]]:
    comps = e.get("components")
    if isinstance(comps, list) and len(comps) >= 2:
        return str(comps[0]), str(comps[1])
    a = e.get("source_component") or e.get("source_component_id") or e.get("component_a") or e.get("from") or e.get("source")
    b = e.get("target_component") or e.get("target_component_id") or e.get("target_components") or e.get("component_b") or e.get("to") or e.get("target")
    return (str(a) if a else None, str(b) if b else None)


def _is_mate_edge(e: Dict[str, Any]) -> bool:
    edge_id = str(e.get("edge_id") or e.get("id") or "")
    if e.get("mate_type") or e.get("solidworks_type") or e.get("mate_id"):
        return True
    if edge_id.lower().startswith("m"):
        return True
    if str(e.get("relation_type") or "").lower() == "mate":
        return True
    return False


def load_exported_gt(sample_dir: Path) -> Dict[str, Any]:
    gt_path = find_gt_json(sample_dir)
    if not gt_path:
        return {"assembly_id": sample_dir.name, "nodes": [], "edges": [], "node_parts": [], "_gt_path": None}
    data = read_json(gt_path)
    assembly_id = data.get("assembly_id") or data.get("assembly_name") or sample_dir.name

    raw_nodes = data.get("node_parts") if isinstance(data.get("node_parts"), list) else None
    raw_edges = data.get("edges") if isinstance(data.get("edges"), list) else None
    if raw_nodes is None:
        dep = data.get("dependency_graph") if isinstance(data.get("dependency_graph"), dict) else {}
        raw_nodes = dep.get("nodes") or data.get("nodes") or []
        raw_edges = dep.get("edges") or data.get("edges") or []

    nodes: List[Dict[str, Any]] = []
    for n in raw_nodes or []:
        if not isinstance(n, dict):
            continue
        cid = _node_id(n)
        if not cid:
            continue
        if n.get("node_type") not in (None, "component", "Node Part"):
            continue
        name = n.get("component_name_raw") or n.get("component_name") or n.get("name") or str(cid)
        transform = n.get("transform") or {}
        sw_pos, sw_ori = sw_transform_to_pose(transform)
        position = n.get("position") or (n.get("pose") or {}).get("position") or sw_pos
        orientation = n.get("orientation") or (n.get("pose") or {}).get("orientation") or sw_ori
        node_out = {
            "component_id": str(cid),
            "id": str(cid),
            "type": "Node Part",
            "component_name": str(name),
            "name": str(name),
            "assets": n.get("assets") or {},
            "position": position,
            "orientation": orientation,
            "pose": {"position": position, "orientation": orientation},
            "transform": transform,
        }
        for key in [
            "visible", "is_visible", "component_visible", "visible_in_assembly", "shown", "is_shown",
            "hidden", "is_hidden", "suppressed", "is_suppressed", "visibility", "display_state",
            "part_id", "document_id", "document_path", "referenced_document", "part_file", "model_path", "file_path", "path",
        ]:
            if key in n:
                node_out[key] = n.get(key)
        nodes.append(node_out)

    edges: List[Dict[str, Any]] = []
    for e in raw_edges or []:
        if not isinstance(e, dict) or not _is_mate_edge(e):
            continue
        a, b = _edge_pair(e)
        if not a or not b or not (str(a).startswith("c") and str(b).startswith("c")):
            continue
        edges.append({
            "source_component": str(a),
            "target_component": str(b),
            "from": str(a),
            "to": str(b),
            "mate_type": _mate_type(e),
        })
    return {"assembly_id": assembly_id, "nodes": nodes, "node_parts": nodes, "edges": edges, "_gt_path": str(gt_path)}


def parse_obj_basic(path: Path) -> Dict[str, Any]:
    verts: List[Tuple[float, float, float]] = []
    face_count = 0
    if not path.exists():
        return {"status": "missing", "vertex_count": 0, "face_count": 0, "bbox_size_mm": []}
    try:
        with path.open("r", encoding="utf-8", errors="ignore") as f:
            for line in f:
                if line.startswith("v "):
                    parts = line.split()
                    if len(parts) >= 4:
                        try:
                            verts.append((float(parts[1]), float(parts[2]), float(parts[3])))
                        except Exception:
                            pass
                elif line.startswith("f "):
                    face_count += 1
    except Exception as exc:
        return {"status": "read_error", "error": repr(exc), "vertex_count": 0, "face_count": 0, "bbox_size_mm": []}
    if verts:
        xs, ys, zs = zip(*verts)
        size = [round(max(xs) - min(xs), 6), round(max(ys) - min(ys), 6), round(max(zs) - min(zs), 6)]
    else:
        size = []
    return {"status": "ok", "vertex_count": len(verts), "face_count": face_count, "bbox_size_mm": size}


def read_obj_text(path: Path, mode: str = "none", max_chars: int = 60000) -> Optional[str]:
    if mode == "none" or not path.exists():
        return None
    text = path.read_text(encoding="utf-8", errors="ignore")
    if mode == "truncated" and len(text) > max_chars:
        return text[:max_chars] + "\n# [TRUNCATED]"
    return text


def _candidate_obj_files(sample_dir: Path, component_id: str, obj_kind: str) -> List[Path]:
    roots = [sample_dir / "component_library"]
    if obj_kind in ("mesh", "auto"):
        roots += [sample_dir / "obj" / "components", sample_dir / "obj"]
    if obj_kind in ("brep", "auto"):
        roots += [sample_dir / "brep_obj" / "components", sample_dir / "brep_obj"]
    patterns: List[str] = []
    if obj_kind == "mesh":
        patterns = [f"{component_id}.mesh.obj", f"{component_id}*.mesh.obj", f"{component_id}*.obj"]
    elif obj_kind == "brep":
        patterns = [f"{component_id}.brep.obj", f"{component_id}*.brep.obj", f"{component_id}*.obj"]
    else:
        patterns = [f"{component_id}.mesh.obj", f"{component_id}.brep.obj", f"{component_id}*.mesh.obj", f"{component_id}*.brep.obj", f"{component_id}*.obj"]
    hits: List[Path] = []
    for root in roots:
        if not root.exists():
            continue
        for pat in patterns:
            hits += sorted(root.glob(pat))
    return [h for h in hits if h.exists()]


def find_obj_by_assets(sample_dir: Path, node: Dict[str, Any], obj_kind: str) -> Optional[Path]:
    cid = str(node.get("component_id") or node.get("id") or "")
    assets = node.get("assets") or {}
    paths: List[Path] = []
    if obj_kind == "mesh":
        for key in ["mesh_obj", "obj", "component_obj"]:
            if assets.get(key):
                paths.append(sample_dir / str(assets[key]))
    elif obj_kind == "brep":
        for key in ["brep_obj", "brep_mesh_obj"]:
            if assets.get(key):
                paths.append(sample_dir / str(assets[key]))
    else:
        for key in ["mesh_obj", "obj", "component_obj", "brep_obj", "brep_mesh_obj"]:
            if assets.get(key):
                paths.append(sample_dir / str(assets[key]))
    paths += _candidate_obj_files(sample_dir, cid, obj_kind)
    existing = [p for p in paths if p.exists()]
    if not existing:
        return None
    if obj_kind == "auto":
        existing.sort(key=lambda p: p.stat().st_size)
    return existing[0]



def file_sha1(path: Path, chunk_size: int = 1024 * 1024) -> str:
    h = hashlib.sha1()
    with path.open("rb") as f:
        while True:
            chunk = f.read(chunk_size)
            if not chunk:
                break
            h.update(chunk)
    return h.hexdigest()


def _library_id_for_index(index: int) -> str:
    return f"lib{index:05d}"


def discover_component_library(sample_dir: Path, obj_kind: str = "auto", raw_obj_mode: str = "none", max_raw_obj_chars: int = 60000) -> Dict[str, Any]:
    gt = load_exported_gt(sample_dir)
    assembly_id = gt.get("assembly_id") or sample_dir.name
    library: List[Dict[str, Any]] = []
    lib_dir = sample_dir / "component_library"
    seen_keys: set[str] = set()
    next_lib_index = 1

    def add_library_file(path: Path, preferred_lib_id: Optional[str] = None) -> None:
        nonlocal next_lib_index
        try:
            key = file_sha1(path)
        except Exception:
            key = path.resolve().as_posix()
        if key in seen_keys:
            return
        lib_id = preferred_lib_id
        if not lib_id:
            lib_id = _library_id_for_index(next_lib_index)
            next_lib_index += 1
        item = {"library_id": lib_id, "obj_file": safe_rel(path, sample_dir), "mesh_summary": parse_obj_basic(path)}
        raw = read_obj_text(path, raw_obj_mode, max_raw_obj_chars)
        if raw is not None:
            item["raw_obj_text"] = raw
        library.append(item)
        seen_keys.add(key)

    if lib_dir.exists():
        all_objs = sorted(lib_dir.glob("*.obj"))
        if obj_kind == "mesh":
            all_objs = [p for p in all_objs if ".mesh.obj" in p.name or ".brep.obj" not in p.name]
        elif obj_kind == "brep":
            all_objs = [p for p in all_objs if ".brep.obj" in p.name]
        grouped: Dict[str, List[Path]] = {}
        for p in all_objs:
            explicit_id = library_id_from_text(p.name) or component_id_from_text(p.name) or p.stem
            grouped.setdefault(explicit_id, []).append(p)
        for explicit_id, paths in sorted(grouped.items()):
            paths.sort(key=lambda p: p.stat().st_size if obj_kind == "auto" else p.name)
            preferred = library_id_from_text(explicit_id)
            add_library_file(paths[0], preferred_lib_id=preferred)

    if not library:
        for n in gt.get("nodes") or []:
            cid = str(n.get("component_id") or n.get("id") or "")
            if not cid:
                continue
            p = find_obj_by_assets(sample_dir, n, obj_kind)
            if p:
                add_library_file(p, preferred_lib_id=None)
    return {"assembly_id": assembly_id, "library": library}


def find_reference_views(sample_dir: Path, style: str = "same_color") -> Dict[str, str]:
    roots = [
        sample_dir / "reference_views" / style,
        sample_dir / "reference_views" / ("color_by_component" if style == "color_by_component" else "same_color"),
        sample_dir / "views" / style,
        sample_dir / "views" / "assembly",
        sample_dir / "views",
        sample_dir,
    ]
    out: Dict[str, str] = {}
    for view in VIEW_NAMES:
        candidates: List[Path] = []
        for root in roots:
            if not root.exists():
                continue
            for ext in IMG_EXTS:
                candidates.extend(sorted(root.glob(f"assembly_{view}{ext}")))
                candidates.extend(sorted(root.glob(f"*_{view}{ext}")))
                candidates.extend(sorted(root.glob(f"*{view}*{ext}")))
        hit = find_first_existing(candidates)
        if hit:
            out[view] = safe_rel(hit, sample_dir)
    return out


def find_reference_assembly_obj(sample_dir: Path, obj_kind: str = "mesh", raw_obj_mode: str = "none", max_raw_obj_chars: int = 120000) -> Optional[Dict[str, Any]]:
    roots = [sample_dir / "reference_obj", sample_dir / "obj", sample_dir / "brep_obj", sample_dir]
    patterns = ["assembly.mesh.obj", "assembly.obj"] if obj_kind == "mesh" else ["assembly.brep.obj", "assembly.obj"]
    if obj_kind == "auto":
        patterns = ["assembly.mesh.obj", "assembly.brep.obj", "assembly.obj"]
    hits: List[Path] = []
    for root in roots:
        if not root.exists():
            continue
        for pat in patterns:
            hits += sorted(root.glob(pat))
    if not hits:
        return None
    if obj_kind == "auto":
        hits.sort(key=lambda p: p.stat().st_size)
    p = hits[0]
    out = {"obj_file": safe_rel(p, sample_dir), "mesh_summary": parse_obj_basic(p)}
    raw = read_obj_text(p, raw_obj_mode, max_raw_obj_chars)
    if raw is not None:
        out["raw_obj_text"] = raw
    return out


def find_mate_graph_json(sample_dir: Path) -> Optional[Path]:
    for p in [sample_dir / "graph" / "mate_graph.json", sample_dir / "mate_graph.json"]:
        if p.exists():
            return p
    return None


def find_component_instances_json(sample_dir: Path) -> Optional[Path]:
    for p in [sample_dir / "graph" / "component_instances.json", sample_dir / "component_instances.json"]:
        if p.exists():
            return p
    return None


def _library_entries_for_instances(library_json: Optional[Dict[str, Any]]) -> List[Dict[str, Any]]:
    library = (library_json or {}).get("library") or []
    out: List[Dict[str, Any]] = []
    for item in library:
        if not isinstance(item, dict):
            continue
        lib_id = str(item.get("library_id") or item.get("component_id") or "")
        if not lib_id:
            continue
        out.append({"library_id": lib_id, "obj_file": item.get("obj_file") or f"{lib_id}.mesh.obj"})
    return out


def _component_instances_from_nodes(assembly_id: str, nodes: List[Dict[str, Any]], library_json: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    instances: List[Dict[str, Any]] = []
    for node in nodes:
        if not isinstance(node, dict):
            continue
        cid = str(node.get("component_id") or node.get("id") or "")
        if not cid:
            continue
        row: Dict[str, Any] = {"component_id": cid}
        lib_id = node.get("library_id")
        if lib_id:
            row["library_id"] = str(lib_id)
        instances.append(row)
    return {"assembly_id": assembly_id, "library": _library_entries_for_instances(library_json), "component_instances": instances}


def load_or_build_component_instances(sample_dir: Path, library_json: Optional[Dict[str, Any]] = None) -> Optional[Dict[str, Any]]:
    """Load the closed-set component instances used by every experiment.

    The preferred source is graph/component_instances.json. When working with old
    prepared samples, fall back to mate_graph.nodes because those nodes already
    carry the same component_id -> library_id mapping. As a last resort, build a
    pose-free instance list from GT component nodes.
    """
    p = find_component_instances_json(sample_dir)
    if p:
        data = read_json(p)
        if isinstance(data, dict) and isinstance(data.get("component_instances"), list):
            return data
    mate_p = find_mate_graph_json(sample_dir)
    if mate_p:
        data = read_json(mate_p)
        nodes = data.get("nodes") or []
        if isinstance(nodes, list):
            out = _component_instances_from_nodes(str(data.get("assembly_id") or sample_dir.name), nodes, library_json=library_json or {"library": data.get("library") or []})
            if out.get("component_instances"):
                return out
    gt = load_exported_gt(sample_dir)
    gt_nodes = gt.get("nodes") or gt.get("node_parts") or []
    if gt_nodes:
        lib_ids = [str(x.get("library_id") or x.get("component_id")) for x in (library_json or {}).get("library", []) if isinstance(x, dict) and (x.get("library_id") or x.get("component_id"))]
        default_lib = lib_ids[0] if len(lib_ids) == 1 else None
        nodes: List[Dict[str, Any]] = []
        for n in gt_nodes:
            if not isinstance(n, dict):
                continue
            cid = str(n.get("component_id") or n.get("id") or "")
            if not cid:
                continue
            row: Dict[str, Any] = {"component_id": cid}
            if default_lib:
                row["library_id"] = default_lib
            nodes.append(row)
        return _component_instances_from_nodes(str(gt.get("assembly_id") or sample_dir.name), nodes, library_json=library_json)
    return None


def component_instance_ids(component_instances_json: Optional[Dict[str, Any]]) -> List[str]:
    if not component_instances_json:
        return []
    return [
        str(x.get("component_id"))
        for x in component_instances_json.get("component_instances", [])
        if isinstance(x, dict) and x.get("component_id")
    ]


def component_to_library_map(component_instances_json: Optional[Dict[str, Any]]) -> Dict[str, str]:
    out: Dict[str, str] = {}
    if not component_instances_json:
        return out
    for x in component_instances_json.get("component_instances", []) or []:
        if not isinstance(x, dict):
            continue
        cid = str(x.get("component_id") or "")
        lib_id = str(x.get("library_id") or "")
        if cid and lib_id:
            out[cid] = lib_id
    return out


def build_mate_graph_from_gt(sample_dir: Path, library_json: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    gt = load_exported_gt(sample_dir)
    assembly_id = gt.get("assembly_id") or sample_dir.name
    library = (library_json or {}).get("library") or []
    graph_library = []
    for item in library:
        if not isinstance(item, dict):
            continue
        lib_id = str(item.get("library_id") or item.get("component_id") or "")
        if not lib_id:
            continue
        graph_library.append({"library_id": lib_id, "obj_file": item.get("obj_file") or f"{lib_id}.mesh.obj"})

    # Prefer the closed-set component_instances mapping when it exists; otherwise
    # fall back to an existing prepared mate_graph mapping.
    prepared_nodes: Dict[str, str] = {}
    ci_path = find_component_instances_json(sample_dir)
    if ci_path:
        try:
            data = read_json(ci_path)
            for n in data.get("component_instances") or []:
                if isinstance(n, dict) and n.get("component_id") and n.get("library_id"):
                    prepared_nodes[str(n["component_id"])] = str(n["library_id"])
        except Exception:
            prepared_nodes = {}
    if not prepared_nodes:
        prepared = find_mate_graph_json(sample_dir)
        if prepared:
            try:
                data = read_json(prepared)
                for n in data.get("nodes") or []:
                    if isinstance(n, dict) and n.get("component_id") and n.get("library_id"):
                        prepared_nodes[str(n["component_id"])] = str(n["library_id"])
            except Exception:
                prepared_nodes = {}

    lib_ids = [str(x.get("library_id") or x.get("component_id")) for x in library if isinstance(x, dict)]
    default_lib = lib_ids[0] if lib_ids else None
    visible_ids = {
        str(n.get("component_id") or n.get("id") or "")
        for n in (gt.get("nodes") or [])
        if isinstance(n, dict) and is_component_visible(n) and str(n.get("component_id") or n.get("id") or "")
    }
    nodes = []
    for n in gt.get("nodes") or []:
        cid = str(n.get("component_id") or n.get("id") or "")
        if not cid or cid not in visible_ids:
            continue
        item = {"component_id": cid}
        lib_id = prepared_nodes.get(cid) or (cid if cid in lib_ids else default_lib)
        if lib_id:
            item["library_id"] = lib_id
        nodes.append(item)

    edges = []
    for e in gt.get("edges") or []:
        a, b = _edge_pair(e)
        if not a or not b or str(a) not in visible_ids or str(b) not in visible_ids:
            continue
        edges.append({
            "source_component": str(a),
            "target_component": str(b),
            "mate_type": str(e.get("mate_type") or "UnknownMate"),
        })
    return {"assembly_id": assembly_id, "library": graph_library or library, "nodes": nodes, "edges": edges}


def load_or_build_mate_graph(sample_dir: Path, library_json: Optional[Dict[str, Any]] = None) -> Optional[Dict[str, Any]]:
    p = find_mate_graph_json(sample_dir)
    if p:
        return read_json(p)
    gt = find_gt_json(sample_dir)
    if gt:
        return build_mate_graph_from_gt(sample_dir, library_json=library_json)
    return None


def discover_dataset_samples(root: Path, recursive: bool = False) -> List[Path]:
    if any((root / x).exists() for x in ["component_library", "assembly_graph_gt.json", "obj", "brep_obj", "reference_views"]):
        return [root]
    pattern = "**/assembly_graph_gt.json" if recursive else "*/assembly_graph_gt.json"
    samples = sorted({p.parent for p in root.glob(pattern)})
    samples += sorted({p.parent for p in root.glob("**/component_library")}) if recursive else []
    out: List[Path] = []
    seen: set[str] = set()
    for s in samples:
        key = s.resolve().as_posix()
        if key not in seen:
            seen.add(key)
            out.append(s)
    return out


def discover_components(sample_dir: Path, obj_prefer: str = "brep_obj") -> List[Dict[str, Any]]:
    obj_kind = "brep" if obj_prefer == "brep_obj" else "mesh"
    lib = discover_component_library(sample_dir, obj_kind=obj_kind)
    out = []
    for item in lib.get("library", []):
        p = sample_dir / item["obj_file"]
        stat = parse_obj_basic(p)
        cid = item.get("library_id") or item.get("component_id")
        out.append({
            "component_id": cid,
            "id": cid,
            "component_name": item.get("component_name") or cid,
            "name": item.get("component_name") or cid,
            "obj_file": p.as_posix(),
            "bbox_size_mm": stat.get("bbox_size_mm") or [],
            "obj_geometry": stat,
            "views": {},
            "component_views": {},
        })
    return out


def find_assembly_views(sample_dir: Path) -> Dict[str, str]:
    return {k: (sample_dir / v).as_posix() if not Path(v).is_absolute() else v for k, v in find_reference_views(sample_dir, "same_color").items()}
