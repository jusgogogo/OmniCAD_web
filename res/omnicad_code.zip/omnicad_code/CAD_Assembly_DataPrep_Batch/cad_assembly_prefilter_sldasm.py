#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Fast prefilter SolidWorks assemblies by estimated referenced part count.

This does not open SolidWorks. It scans SLDASM bytes for part-name references
and stops scanning one file as soon as the count is above the threshold. The
SolidWorks exporter still performs the accurate visible component gate later.
"""
from __future__ import annotations

import argparse
import csv
import re
from pathlib import Path


ASCII_RE = re.compile(rb'[^\\/:*?"<>\r\n\x00]{1,260}\.sldprt', re.IGNORECASE)
UTF16_DOT = b'.\x00s\x00l\x00d\x00p\x00r\x00t\x00'


def normalize_ref(raw: bytes, utf16: bool = False) -> str:
    try:
        text = raw.decode("utf-16le" if utf16 else "latin1", errors="ignore")
    except Exception:
        text = ""
    text = text.replace("\x00", "").strip()
    return Path(text).name.casefold()


def utf16_refs_from_chunk(chunk: bytes) -> set[str]:
    refs: set[str] = set()
    lower = chunk.lower()
    pos = 0
    while True:
        hit = lower.find(UTF16_DOT, pos)
        if hit < 0:
            break
        start = max(0, hit - 520)
        raw = chunk[start:hit + len(UTF16_DOT)]
        # Trim to the last UTF-16 separator-ish boundary before the filename.
        for sep in (b'\\\x00', b'/\x00', b'\x00\x00'):
            idx = raw.rfind(sep)
            if idx >= 0:
                raw = raw[idx + len(sep):]
        ref = normalize_ref(raw, utf16=True)
        if ref.endswith(".sldprt"):
            refs.add(ref)
        pos = hit + len(UTF16_DOT)
    return refs


def estimate_part_refs_stream(path: Path, max_parts: int, chunk_size: int = 4 * 1024 * 1024) -> tuple[int, bool]:
    refs: set[str] = set()
    overlap = b""
    with path.open("rb") as f:
        while True:
            data = f.read(chunk_size)
            if not data:
                break
            chunk = overlap + data
            for match in ASCII_RE.finditer(chunk):
                ref = normalize_ref(match.group(0), utf16=False)
                if ref.endswith(".sldprt"):
                    refs.add(ref)
                    if max_parts > 0 and len(refs) > max_parts:
                        return len(refs), True
            refs.update(utf16_refs_from_chunk(chunk))
            if max_parts > 0 and len(refs) > max_parts:
                return len(refs), True
            overlap = chunk[-2048:]
    return len(refs), False


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", type=Path, required=True)
    ap.add_argument("--out-dir", type=Path, required=True)
    ap.add_argument("--max-parts", type=int, default=30)
    ap.add_argument("--progress-every", type=int, default=100)
    args = ap.parse_args()

    args.out_dir.mkdir(parents=True, exist_ok=True)
    keep_csv = args.out_dir / f"sldasm_le_{args.max_parts}_parts.csv"
    skip_csv = args.out_dir / f"sldasm_skip_gt_{args.max_parts}_or_unknown.csv"
    keep_list = args.out_dir / f"sldasm_le_{args.max_parts}_parts.txt"

    asm_paths = sorted(args.root.rglob("*.sldasm"))
    fields = ["assembly", "estimated_unique_sldprt_refs", "status", "skip_reason", "error"]
    keep_count = 0
    skip_count = 0
    with keep_csv.open("w", encoding="utf-8-sig", newline="") as keep_f, \
            skip_csv.open("w", encoding="utf-8-sig", newline="") as skip_f, \
            keep_list.open("w", encoding="utf-8") as list_f:
        keep_writer = csv.DictWriter(keep_f, fieldnames=fields)
        skip_writer = csv.DictWriter(skip_f, fieldnames=fields)
        keep_writer.writeheader()
        skip_writer.writeheader()
        for idx, asm_path in enumerate(asm_paths, start=1):
            try:
                count, over_limit = estimate_part_refs_stream(asm_path, args.max_parts)
                row = {
                    "assembly": str(asm_path),
                    "estimated_unique_sldprt_refs": count,
                    "status": "keep" if 0 < count <= args.max_parts else "skip",
                    "skip_reason": "",
                    "error": "",
                }
                if row["status"] == "keep":
                    keep_writer.writerow(row)
                    list_f.write(str(asm_path) + "\n")
                    keep_count += 1
                else:
                    row["skip_reason"] = "gt_%d" % args.max_parts if over_limit or count > args.max_parts else "unknown_no_sldprt_refs"
                    skip_writer.writerow(row)
                    skip_count += 1
            except Exception as exc:
                skip_writer.writerow({
                    "assembly": str(asm_path),
                    "estimated_unique_sldprt_refs": "",
                    "status": "skip",
                    "skip_reason": "scan_error",
                    "error": repr(exc),
                })
                skip_count += 1
            if idx % max(1, args.progress_every) == 0:
                print(f"[scan] {idx}/{len(asm_paths)} keep={keep_count} skip={skip_count}", flush=True)
    print({
        "root": str(args.root),
        "total_assemblies": len(asm_paths),
        "keep_le_max_parts": keep_count,
        "skip_gt_or_unknown": skip_count,
        "keep_csv": str(keep_csv),
        "skip_csv": str(skip_csv),
        "keep_list": str(keep_list),
    })


if __name__ == "__main__":
    main()
