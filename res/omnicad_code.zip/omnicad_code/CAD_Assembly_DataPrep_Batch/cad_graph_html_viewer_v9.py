from __future__ import annotations

import json
from copy import deepcopy
from pathlib import Path
from typing import Any


DEFAULT_TEMPLATE_CANDIDATES = [
    Path(__file__).with_name("vis_graph_template.html"),
]

PALETTE = {
    "component": {"background": "#cdb4db", "border": "#333333"},
    "assembly_reference": {"background": "#ffd166", "border": "#333333"},
    "component_reference": {"background": "#ffd166", "border": "#333333"},
    "feature": {"background": "#a2d2ff", "border": "#333333"},
    "sketch": {"background": "#bde0fe", "border": "#333333"},
    "sketch_operation": {"background": "#caffbf", "border": "#333333"},
}


def _find_graph_data_span(html: str) -> tuple[int, int]:
    marker = "const GRAPH_DATA = "
    start_marker = html.find(marker)
    if start_marker < 0:
        raise ValueError("template does not contain const GRAPH_DATA")
    start = start_marker + len(marker)
    depth = 0
    in_string = False
    escape = False
    for i in range(start, len(html)):
        ch = html[i]
        if in_string:
            if escape:
                escape = False
            elif ch == "\\":
                escape = True
            elif ch == '"':
                in_string = False
            continue
        if ch == '"':
            in_string = True
        elif ch in "{[":
            depth += 1
        elif ch in "}]":
            depth -= 1
            if depth == 0:
                return start, i + 1
    raise ValueError("could not find GRAPH_DATA JSON end")


def _template_text() -> str:
    for path in DEFAULT_TEMPLATE_CANDIDATES:
        if path.exists():
            return path.read_text(encoding="utf-8", errors="replace")
    return _fallback_template()


def _fallback_template() -> str:
    return """<!doctype html>
<html lang="en"><head><meta charset="utf-8" /><meta name="viewport" content="width=device-width, initial-scale=1" />
<title>CAD graph - CAD graph</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/vis-network/9.1.2/dist/dist/vis-network.min.css" />
<script src="https://cdnjs.cloudflare.com/ajax/libs/vis-network/9.1.2/dist/vis-network.min.js"></script>
<style>
body{margin:0;font-family:Arial,Helvetica,sans-serif;background:#f8fafc;color:#111827}
#mynetwork{width:100vw;height:100vh;background:#fff}
#topbar{position:fixed;left:12px;top:12px;z-index:10;max-width:calc(100vw - 470px);background:rgba(255,255,255,.96);border:1px solid #d9dee3;border-radius:12px;padding:10px 12px;box-shadow:0 4px 18px rgba(15,23,42,.10)}
#infoPanel{position:fixed;right:12px;top:12px;width:430px;max-height:calc(100vh - 24px);overflow:auto;z-index:11;background:rgba(255,255,255,.96);border:1px solid #d9dee3;border-radius:12px;padding:12px;box-shadow:0 4px 18px rgba(15,23,42,.14)}
button,select,input{border:1px solid #cfd6dd;background:#fff;border-radius:8px;padding:6px 9px;font-size:12px}
button{cursor:pointer;font-weight:700}.mate-row,.selection-row{display:block;padding:4px 6px;margin:2px 0;border-radius:6px;background:#fff;border:1px solid #e5e7eb;font-size:12px}
#infoBody{white-space:pre-wrap;font-family:ui-monospace,SFMono-Regular,Menlo,Monaco,Consolas,'Liberation Mono',monospace;font-size:12px;line-height:1.45}
</style></head><body>
<div id="topbar"><div id="title" style="font-weight:800;margin-bottom:6px">CAD graph</div><div id="summary"></div><div id="toolbar">
<button onclick="fitGraph()">Fit</button><button onclick="resetGraph()">Reset</button><button onclick="setNodeFilter('all')">All nodes</button><button onclick="setNodeFilter('component')">Components</button><button onclick="setNodeFilter('assembly_reference')">Asm refs</button>
<select id="edgeFilter" onchange="applyFilters()"><option value="all">All edges</option><option value="dependency">Dependency</option><option value="mate">Mate</option></select>
<input id="searchBox" placeholder="Search node..." oninput="applyFilters()" /></div><div id="legend"></div></div>
<div id="infoPanel"><div style="display:flex;justify-content:space-between;gap:8px;align-items:center;margin-bottom:8px"><div id="infoTitle" style="font-weight:800">Graph info</div><button onclick="copyInfo()">Copy</button></div><div id="mateTree" style="display:none"></div><div id="infoBody">Click a node or edge to inspect its properties.</div></div>
<div id="mynetwork"></div>
<script>
const GRAPH_DATA = {"nodes":[],"edges":[],"summary":{}};
let currentFilter='all';let network;let allNodes;let allEdges;let lastInfo='';
function summarize(){const s=GRAPH_DATA.summary||{};document.getElementById('summary').textContent=`nodes ${GRAPH_DATA.nodes.length} / edges ${GRAPH_DATA.edges.length} / match ${(s.topology_matching_summary||{}).final_match??'-'}/${(s.topology_matching_summary||{}).mate_selection_count??'-'}`;}
function init(){allNodes=new vis.DataSet(GRAPH_DATA.nodes);allEdges=new vis.DataSet(GRAPH_DATA.edges);network=new vis.Network(document.getElementById('mynetwork'),{nodes:allNodes,edges:allEdges},{physics:{stabilization:true,barnesHut:{gravitationalConstant:-7000,springLength:170}},interaction:{hover:true,navigationButtons:true,keyboard:true},edges:{smooth:{type:'dynamic'}}});network.on('click',p=>{if(p.nodes.length)showNode(p.nodes[0]);else if(p.edges.length)showEdge(p.edges[0]);});summarize();}
function fitGraph(){network&&network.fit({animation:true});}function resetGraph(){applyFilters();fitGraph();}
function setNodeFilter(f){currentFilter=f;applyFilters();}
function applyFilters(){const q=(document.getElementById('searchBox')?.value||'').toLowerCase();const ef=document.getElementById('edgeFilter')?.value||'all';const ns=GRAPH_DATA.nodes.filter(n=>(currentFilter==='all'||n.node_type===currentFilter||n.command===currentFilter)&&(!q||JSON.stringify(n).toLowerCase().includes(q)));const ids=new Set(ns.map(n=>n.id));const es=GRAPH_DATA.edges.filter(e=>(ef==='all'||e.edge_type===ef||e.relation===ef)&&ids.has(e.from)&&ids.has(e.to)&&(!q||JSON.stringify(e).toLowerCase().includes(q)||JSON.stringify(ns.find(n=>n.id===e.from)||{}).toLowerCase().includes(q)||JSON.stringify(ns.find(n=>n.id===e.to)||{}).toLowerCase().includes(q)));allNodes.clear();allNodes.add(ns);allEdges.clear();allEdges.add(es);}
function showNode(id){const n=GRAPH_DATA.nodes.find(x=>x.id===id);if(!n)return;document.getElementById('infoTitle').textContent=n.label||id;document.getElementById('mateTree').style.display='none';lastInfo=JSON.stringify(n.raw||n,null,2);document.getElementById('infoBody').textContent=lastInfo;}
function mateRows(e){const ents=((e.raw||{}).selection||{}).entities||[];if(!ents.length)return '';return '<div style="font-weight:800;font-size:12px;margin-bottom:6px">Mate selections</div>'+ents.map((s,i)=>`<div class="selection-row">#${i+1} ${(s.component_id||'')} ${(s.entity_kind||s.entity_type||'')} ${(s.topology_selection_id||(s.selection_identity||{}).brep_topology_id||'')} ${(s.match_status||{}).match_method||''}</div>`).join('');}
function showEdge(id){const e=GRAPH_DATA.edges.find(x=>x.id===id);if(!e)return;document.getElementById('infoTitle').textContent=e.label||id;const mt=document.getElementById('mateTree');mt.innerHTML=mateRows(e);mt.style.display=mt.innerHTML?'block':'none';lastInfo=JSON.stringify(e.raw||e,null,2);document.getElementById('infoBody').textContent=lastInfo;}
function copyInfo(){navigator.clipboard&&navigator.clipboard.writeText(lastInfo);}
init();
</script></body></html>"""


def _label(node: dict[str, Any]) -> str:
    return str(
        node.get("component_name_raw")
        or node.get("reference_name_raw")
        or node.get("component_reference_name_raw")
        or node.get("label")
        or node.get("id")
        or ""
    )


def _strip(value: Any) -> Any:
    if isinstance(value, dict):
        out = {}
        for key, item in value.items():
            if key in {"value", "hex"} and isinstance(item, str) and len(item) > 160:
                continue
            if key == "brep_topology_references" and isinstance(item, list):
                counts: dict[str, int] = {}
                slim = []
                for ref in item:
                    if isinstance(ref, dict):
                        kind = str(ref.get("entity_kind") or "unknown")
                        counts[kind] = counts.get(kind, 0) + 1
                        if kind in {"body", "face", "edge", "vertex"} and len(slim) < 80:
                            slim.append(_strip(ref))
                out["brep_topology_reference_counts"] = counts
                out[key] = slim
                continue
            out[key] = _strip(item)
        return out
    if isinstance(value, list):
        return [_strip(item) for item in value]
    return value


def _node_title(node: dict[str, Any]) -> str:
    rows = []
    for key in ("id", "command", "node_type", "component_name_raw", "reference_name_raw", "assembly_history_path_text", "component_path"):
        if node.get(key) is not None:
            rows.append(f"{key}: {node.get(key)}")
    return "\n".join(rows) or str(node.get("id") or "")


def _convert_node(node: dict[str, Any]) -> dict[str, Any]:
    node_type = str(node.get("node_type") or node.get("command") or "")
    row = {
        "id": node.get("id"),
        "label": _label(node),
        "title": _node_title(node),
        "shape": "box",
        "color": PALETTE.get(node_type, {"background": "#e5e7eb", "border": "#333333"}),
        "font": {"size": 11, "multi": True, "vadjust": 6},
        "margin": 8,
        "command": node.get("command"),
        "node_type": node_type,
        "trainable": node.get("trainable", True),
        "sequence_index": node.get("sequence_index"),
        "raw": _strip(deepcopy(node)),
    }
    thumb = node.get("thumbnail_relative_path")
    if node_type == "component" and thumb:
        row["shape"] = "image"
        row["image"] = thumb
        row["brokenImage"] = ""
    return row


def _edge_label(edge: dict[str, Any]) -> str:
    if edge.get("assembly_relation") == "assembly:mate" or edge.get("relation") == "mate":
        return "assembly:mate"
    if edge.get("assembly_relation") == "assembly:parent_of" or edge.get("relation_detail") == "assembly:parent_of":
        return "assembly:parent_of"
    return str(edge.get("relation_detail") or edge.get("relation") or edge.get("id") or "")


def _convert_edge(edge: dict[str, Any]) -> dict[str, Any]:
    is_mate = edge.get("relation") == "mate" or edge.get("assembly_relation") == "assembly:mate"
    label = _edge_label(edge)
    return {
        "id": edge.get("id"),
        "from": edge.get("source"),
        "to": edge.get("target"),
        "label": label,
        "title": "\n".join(filter(None, [
            f"id: {edge.get('id')}",
            f"relation: {label}",
            f"mate_name_raw: {edge.get('mate_name_raw')}" if edge.get("mate_name_raw") else "",
            f"solidworks_tree_display: {edge.get('solidworks_tree_display')}" if edge.get("solidworks_tree_display") else "",
        ])),
        "arrows": "" if is_mate else "to",
        "dashes": bool(is_mate),
        "color": {"color": "#0f8b8d" if is_mate else "#4666d6"},
        "font": {"size": 11, "align": "middle", "strokeWidth": 4, "strokeColor": "#ffffff"},
        "width": 2,
        "relation": edge.get("relation"),
        "relation_detail": edge.get("relation_detail"),
        "assembly_relation": edge.get("assembly_relation"),
        "edge_type": "mate" if is_mate else ("dependency" if edge.get("relation") == "dependency" else edge.get("relation")),
        "raw": _strip(deepcopy(edge)),
    }


def _graph_data(record: dict[str, Any]) -> dict[str, Any]:
    graph = record.get("dependency_graph") or record
    return {
        "nodes": [_convert_node(node) for node in graph.get("nodes") or []],
        "edges": [_convert_edge(edge) for edge in graph.get("edges") or []],
        "summary": graph.get("summary") or {},
        "unresolved_mates": graph.get("unresolved_mates") or [],
        "schema": graph.get("schema"),
    }


def write_cad_graph_html(record: dict[str, Any], html_path: Path | str) -> None:
    template = _template_text()
    start, end = _find_graph_data_span(template)
    data = json.dumps(_graph_data(record), ensure_ascii=False)
    Path(html_path).write_text(template[:start] + data + template[end:], encoding="utf-8")
