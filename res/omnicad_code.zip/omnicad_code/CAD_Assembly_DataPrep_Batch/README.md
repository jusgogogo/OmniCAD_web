# CAD Assembly DataPrep Batch

This folder is the standalone Stage-1 data preparation pipeline. It does not call GPT/API.

Default input is one local dataset folder. The script recursively finds `.SLDASM` files under that folder; each `.SLDASM` is treated as one sample.

SolidWorks resolves each assembly's referenced `.SLDPRT` files using the paths stored in the assembly and the current SolidWorks search settings. The parts do not have to sit in the same folder as the assembly, but they must be resolvable when SolidWorks opens the `.SLDASM`.

Output is a prepared dataset sample that Stage2/API experiments can consume directly.

## What It Generates

For each assembly sample:

1. component-level `assembly_graph_gt.json`
2. component-level `mate_graph.json`
3. `assembly.mesh.obj`
4. `assembly.step` exported directly from SolidWorks as AP203
5. deduplicated mesh candidate library under `component_library/`
6. 8 STEP/B-rep style reference views under `reference_views/`

The topology, library deduplication, mate extraction, and reference-view rendering logic are unchanged.

## Install

```bat
cd /d <CODE_ROOT>\CAD_Assembly_DataPrep_Batch
python -m pip install -r requirements.txt
```

SolidWorks must be installed and available on Windows when processing `.SLDASM` directly.

## Overall Folder Logic

Default visible output uses one root:

```text
Dataset_Output/      final prepared samples + dataset_progress.json
```

`dataset_progress.json` is the only default run log file.

Example:

```bat
python cad_assembly_prepare_dataset.py ^
  --sldasm-root "<SOURCE_DATASET_ROOT>" ^
  --prepared-root "D:\path\Dataset_Output" ^
  --name-mode relative_hash ^
  --topology-mode mate_only ^
  --max-visible-components 30 ^
  --export-timeout-sec 900 ^
  --prepare-timeout-sec 900 ^
  --kill-solidworks-on-timeout ^
  --resume
```

`--sldasm-root` can point at a nested dataset folder. The script scans it recursively for `.SLDASM` files.

## Dataset Output Layout

The final `prepared-root` is kept clean. It contains sample folders plus one live progress file:

```text
Dataset_Output/
  dataset_progress.json
  sample_name/
    component_library/
      lib00001.mesh.obj
      lib00002.mesh.obj
    reference_views/
      same_color/
        assembly_v01.png ... assembly_v08.png
      color_by_component/
        assembly_v01.png ... assembly_v08.png
    assembly.mesh.obj
    assembly.step
    assembly_graph_gt.json
    mate_graph.json
```

The default run does not create these extra folders/files in `prepared-root`:

```text
_logs/
_tmp/
prepare_dataset_progress.json
.pipeline_work_*/
RawExport/
Stage1/
_debug/
component_instances.json
component_meshes/
_prepare_record.json
prepare_report.json
```

## Progress JSON

`Dataset_Output/dataset_progress.json` is the only default run log file. It is atomically refreshed during the run and contains:

```json
{
  "status": "running",
  "total_planned": 1000,
  "done": 123,
  "in_progress_or_pending": 877,
  "success_or_resume_skipped": 110,
  "success_without_resume_skipped": 105,
  "skipped": 8,
  "failed": 5,
  "status_counts": {
    "ok": 105,
    "skipped_exporter_policy": 8,
    "export_failed": 5
  },
  "skip_fail_summary": {
    "timeout_count": 2,
    "skip_reason_counts": {
      "visible_component_count_gt_limit": 6,
      "feature_tree_not_extractable": 2
    }
  },
  "failed_records": [
    {
      "sample_name": "sample_001",
      "source": "D:\\data\\sample_001\\assembly.SLDASM",
      "status": "stage1_validation_failed",
      "validation": {
        "missing": ["obj/assembly.mesh.obj"],
        "warnings": []
      }
    }
  ],
  "skipped_records": [],
  "current_item": {},
  "last_record": {},
  "elapsed_sec": 1234.5,
  "estimated_remaining_sec": 8800.0
}
```

## Regenerate Existing Samples To 8 Views

For an already prepared sample, regenerate `reference_views/` as 8 STEP/B-rep
views and keep `assembly.step` at the sample root:

```bat
python cad_assembly_regenerate_8views_from_sldasm.py ^
  --sample "D:\path\Dataset_Output\sample_name" ^
  --sldasm "D:\path\source_suite\assembly.SLDASM"
```

For batch use, provide a prepared-sample root and a source `.SLDASM` root:

```bat
python cad_assembly_regenerate_8views_from_sldasm.py ^
  --sample-root "D:\path\Dataset_Output" ^
  --sldasm-root "<SOURCE_DATASET_ROOT>"
```

The script overwrites only:

```text
sample/reference_views/same_color/assembly_v01.png ... assembly_v08.png
sample/reference_views/color_by_component/assembly_v01.png ... assembly_v08.png
sample/assembly.step
```

It removes old `assembly_v09.png ... assembly_v20.png` files from those two
reference-view folders and does not rebuild graph, mate, or library data.

Final status is `completed` when there are no failures, otherwise `completed_with_failures`.

`failed_records` and `skipped_records` are written directly inside `dataset_progress.json`; no separate `Logs/`, CSV, JSONL, or `prepare_dataset_log.json` file is generated.

## Temporary Files

By default, raw SolidWorks export, Stage1 intermediates, and atomic temp outputs are written to the system temp directory, not into `Dataset_Output`.

Only pass these debugging roots when you intentionally want retained intermediates:

```bat
--prepared-tmp-root "D:\debug\dataprep_tmp"
--raw-export-root "D:\debug\raw_export"
--stage1-output-root "D:\debug\stage1"
```

## Run Modes

Optional single assembly input:

```bat
python cad_assembly_prepare_dataset.py ^
  --sldasm "D:\path\assembly.SLDASM" ^
  --prepared-root "<PREPARED_DATASET_ROOT>" ^
  --name-mode stem ^
  --topology-mode mate_only ^
  --resume
```

Default folder input:

```bat
python cad_assembly_prepare_dataset.py ^
  --sldasm-root "D:\CAD_Dataset" ^
  --prepared-root "<PREPARED_DATASET_ROOT>" ^
  --name-mode relative_hash ^
  --topology-mode mate_only ^
  --resume
```

Optional explicit list input:

```bat
python cad_assembly_prepare_dataset.py ^
  --sldasm-list "D:\path\asm_list.txt" ^
  --prepared-root "<PREPARED_DATASET_ROOT>" ^
  --name-mode relative_hash ^
  --topology-mode mate_only ^
  --resume
```

## Unattended Batch Safety

For large `.SLDASM` batches, direct SolidWorks export is forced to one worker per process because one desktop SolidWorks COM session is not safe to drive concurrently.

Safety behavior:

```text
--max-visible-components 30       skip assemblies whose visible component count is above 30
feature_tree_not_extractable      skip assemblies whose feature tree cannot be read
--export-timeout-sec 900          timeout one SolidWorks export
--prepare-timeout-sec 900         timeout one dataset preparation step
--kill-solidworks-on-timeout      taskkill SLDWORKS.exe after export timeout
--resume                          skip already valid prepared samples
```

Policy skips and failures are summarized in:

```text
Dataset_Output/dataset_progress.json
```

## Useful Options

```text
--max-samples 5                  run only the first 5 discovered samples
--force                          rebuild even if outputs already exist
--dry-run                        discover and plan without opening SolidWorks
--export-timeout-sec 0           disable SolidWorks export timeout
--prepare-timeout-sec 0          disable preparation/reference-view timeout
--allow-missing-reference-obj
--allow-missing-views
--allow-missing-mate-graph
```

## Output JSON Shape

`assembly_graph_gt.json` uses component-level IDs and poses:

```json
{
  "component_id": "c00001",
  "library_id": "lib00001",
  "pose": {
    "position": {"x": 0.0, "y": 0.0, "z": 0.0},
    "orientation": {"rx": 0.0, "ry": 0.0, "rz": 0.0}
  }
}
```

Mate edges use component-level endpoints:

```json
{
  "source_component": "c00001",
  "target_component": "c00002",
  "mate_type": "MateCoincident"
}
```

`mate_graph.json` contains library candidates, component nodes, and mate edges. It does not include face/edge/vertex selections.


