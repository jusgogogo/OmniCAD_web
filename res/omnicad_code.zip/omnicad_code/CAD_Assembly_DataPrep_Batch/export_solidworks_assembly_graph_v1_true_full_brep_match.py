﻿"""
Export a clean SolidWorks assembly graph.

Assembly graph semantics:
- node: component instance
- edge: mate/joint relation between component instances
"""

from __future__ import annotations

import hashlib
import html as html_lib
import json
import base64
import math
import re
import shutil
import time
import copy
import ctypes
import ctypes.wintypes
import threading
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any

import pythoncom
import win32com.client

from export_solidworks_cad_graph_v9 import ascii_slug, call
from cad_graph_html_viewer_v9 import write_cad_graph_html


SW_DOC_ASSEMBLY = 2
SW_DOC_PART = 1
SW_OPEN_SILENT = 1
SW_OPEN_READONLY = 2
SW_SAVE_SILENT = 1


def _win_text(hwnd: int) -> str:
    try:
        user32 = ctypes.windll.user32
        length = user32.GetWindowTextLengthW(hwnd)
        buf = ctypes.create_unicode_buffer(length + 1)
        user32.GetWindowTextW(hwnd, buf, length + 1)
        return buf.value
    except Exception:
        return ""


def _win_class(hwnd: int) -> str:
    try:
        buf = ctypes.create_unicode_buffer(256)
        ctypes.windll.user32.GetClassNameW(hwnd, buf, len(buf))
        return buf.value
    except Exception:
        return ""


def _process_image_name(pid: int) -> str:
    PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
    try:
        kernel32 = ctypes.windll.kernel32
        handle = kernel32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, False, int(pid))
        if not handle:
            return ""
        try:
            size = ctypes.wintypes.DWORD(32768)
            buf = ctypes.create_unicode_buffer(size.value)
            if kernel32.QueryFullProcessImageNameW(handle, 0, buf, ctypes.byref(size)):
                return buf.value
        finally:
            kernel32.CloseHandle(handle)
    except Exception:
        return ""
    return ""


def _window_process_id(hwnd: int) -> int:
    try:
        pid = ctypes.wintypes.DWORD(0)
        ctypes.windll.user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
        return int(pid.value)
    except Exception:
        return 0


def _is_solidworks_dialog(hwnd: int) -> bool:
    try:
        user32 = ctypes.windll.user32
        if not user32.IsWindowVisible(hwnd):
            return False
    except Exception:
        return False
    cls = _win_class(hwnd)
    if cls != "#32770":
        return False
    title = _win_text(hwnd).strip()
    pid = _window_process_id(hwnd)
    image = _process_image_name(pid).lower()
    if "sldworks.exe" not in image:
        return False
    lowered = title.lower()
    # Keep this intentionally conservative: these are modal dialogs that block
    # unattended exports. The process filter keeps generic titles like "Open"
    # from affecting other applications.
    dialog_titles = {
        "open",
        "打开",
        "solidworks",
        "solidworks 2024",
        "save as",
        "另存为",
        "confirm save as",
        "确认另存为",
    }
    if lowered in dialog_titles:
        return True
    return "solidworks" in lowered or "打开" in title or "open" == lowered


class SolidWorksDialogWatchdog:
    """Cancel modal SolidWorks dialogs that can defeat SW_OPEN_SILENT."""

    def __init__(self, interval_sec: float = 0.5) -> None:
        self.interval_sec = interval_sec
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None
        self.events: list[dict[str, Any]] = []

    def start(self) -> "SolidWorksDialogWatchdog":
        self._thread = threading.Thread(target=self._run, name="sw-dialog-watchdog", daemon=True)
        self._thread.start()
        return self

    def stop(self) -> dict[str, Any]:
        self._stop.set()
        if self._thread is not None:
            self._thread.join(timeout=2.0)
        return self.summary()

    def summary(self) -> dict[str, Any]:
        return {
            "enabled": True,
            "closed_dialog_count": len(self.events),
            "events": self.events[-20:],
        }

    def _run(self) -> None:
        while not self._stop.is_set():
            self._scan_once()
            self._stop.wait(self.interval_sec)

    def _scan_once(self) -> None:
        user32 = ctypes.windll.user32
        WM_COMMAND = 0x0111
        WM_CLOSE = 0x0010
        IDCANCEL = 2

        @ctypes.WINFUNCTYPE(ctypes.c_bool, ctypes.c_void_p, ctypes.c_void_p)
        def enum_proc(hwnd: int, _lparam: int) -> bool:
            try:
                if _is_solidworks_dialog(hwnd):
                    title = _win_text(hwnd)
                    cls = _win_class(hwnd)
                    pid = _window_process_id(hwnd)
                    user32.PostMessageW(hwnd, WM_COMMAND, IDCANCEL, 0)
                    user32.PostMessageW(hwnd, WM_CLOSE, 0, 0)
                    self.events.append({
                        "time": time.strftime("%Y-%m-%d %H:%M:%S"),
                        "hwnd": int(hwnd),
                        "pid": pid,
                        "title": title,
                        "class": cls,
                        "action": "cancel_close",
                    })
            except Exception as exc:
                self.events.append({
                    "time": time.strftime("%Y-%m-%d %H:%M:%S"),
                    "error": repr(exc),
                })
            return True

        try:
            user32.EnumWindows(enum_proc, 0)
        except Exception:
            pass


def as_list(value: Any) -> list[Any]:
    if value is None:
        return []
    if isinstance(value, (list, tuple)):
        return list(value)
    try:
        return list(value)
    except Exception:
        return [value]


def stable_hash(text: str, length: int = 10) -> str:
    return hashlib.sha1(text.encode("utf-8", errors="ignore")).hexdigest()[:length]


def get_attr(obj: Any, name: str, default: Any = None) -> Any:
    try:
        value = getattr(obj, name)
        return value() if callable(value) else value
    except Exception:
        return default


def component_name(comp: Any) -> str:
    return str(call(comp, "Name2") or get_attr(comp, "Name2") or call(comp, "Name") or "component")


def component_path(comp: Any) -> str:
    return str(call(comp, "GetPathName") or get_attr(comp, "GetPathName") or "")


def transform_payload(comp: Any) -> dict[str, Any] | None:
    transform = call(comp, "Transform2") or get_attr(comp, "Transform2")
    if transform is None:
        return None
    data = call(transform, "ArrayData") or get_attr(transform, "ArrayData")
    values = as_list(data)
    if not values:
        return None
    try:
        values = [float(v) for v in values]
    except Exception:
        pass
    return {"array_data": values}


def transform_array(comp: Any) -> list[float] | None:
    payload = transform_payload(comp)
    values = (payload or {}).get("array_data")
    if not values or len(values) < 12:
        return None
    try:
        return [float(v) for v in values]
    except Exception:
        return None


def transform_point_mm(point_mm: list[float], transform: list[float] | None) -> list[float]:
    if transform is None or len(point_mm) < 3:
        return point_mm
    x, y, z = [float(v) / 1000.0 for v in point_mm[:3]]
    # SolidWorks MathTransform ArrayData stores rotation in 0..8 and translation in 9..11.
    x2 = x * transform[0] + y * transform[3] + z * transform[6] + transform[9]
    y2 = x * transform[1] + y * transform[4] + z * transform[7] + transform[10]
    z2 = x * transform[2] + y * transform[5] + z * transform[8] + transform[11]
    return [round(x2 * 1000.0, 6), round(y2 * 1000.0, 6), round(z2 * 1000.0, 6)]


def transform_dir(direction: list[float], transform: list[float] | None) -> list[float]:
    if transform is None or len(direction) < 3:
        return direction
    x, y, z = [float(v) for v in direction[:3]]
    x2 = x * transform[0] + y * transform[3] + z * transform[6]
    y2 = x * transform[1] + y * transform[4] + z * transform[7]
    z2 = x * transform[2] + y * transform[5] + z * transform[8]
    length = math.sqrt(x2 * x2 + y2 * y2 + z2 * z2)
    if length > 0:
        x2, y2, z2 = x2 / length, y2 / length, z2 / length
    return [round(x2, 6), round(y2, 6), round(z2, 6)]


def bytes_payload(value: Any) -> bytes:
    if value is None:
        return b""
    if isinstance(value, bytes):
        return value
    if isinstance(value, bytearray):
        return bytes(value)
    values = as_list(value)
    out = bytearray()
    for item in values:
        try:
            out.append(int(item) & 0xFF)
        except Exception:
            pass
    return bytes(out)


def persistent_reference(model: Any, entity: Any) -> dict[str, Any]:
    payload: dict[str, Any] = {"available": False}
    if model is None or entity is None:
        return payload
    ext = call(model, "Extension") or call(model, "GetExtension") or get_attr(model, "Extension")
    if ext is None:
        payload["error"] = "model_extension_unavailable"
        return payload
    try:
        raw = call(ext, "GetPersistReference3", entity)
        data = bytes_payload(raw)
        if data:
            payload.update({
                "available": True,
                "encoding": "base64",
                "value": base64.b64encode(data).decode("ascii"),
                "hex": data.hex(),
                "byte_count": len(data),
            })
        else:
            payload["error"] = "empty_reference"
    except Exception as exc:
        payload["error"] = repr(exc)
    return payload


def corresponding_entity(comp: Any, part_entity: Any) -> Any:
    if comp is None or part_entity is None:
        return None
    for method in ("GetCorrespondingEntity", "GetCorresponding"):
        try:
            value = call(comp, method, part_entity)
            if value is not None:
                return value
        except Exception:
            pass
    return None


def context_refs(asm_model: Any, part_model: Any, comp: Any, entity: Any, assembly_ref_mode: str = "off") -> dict[str, Any]:
    part_ref = persistent_reference(part_model, entity)
    asm_entity = None
    asm_ref = {"available": False, "error": "assembly_context_ref_disabled"}
    if assembly_ref_mode == "all":
        asm_entity = corresponding_entity(comp, entity)
        asm_ref = persistent_reference(asm_model, asm_entity) if asm_entity is not None else {"available": False, "error": "corresponding_entity_unavailable"}
    return {
        "part_context": {
            "persistent_ref": part_ref,
            "source": "part_doc.GetPersistReference3",
        },
        "assembly_context": {
            "persistent_ref": asm_ref,
            "source": "component.GetCorrespondingEntity/GetCorresponding + assembly_doc.GetPersistReference3",
            "corresponding_entity_available": asm_entity is not None,
        },
    }


def component_payload(comp: Any, node_id: str, parent_id: str | None, index: int, history_path: list[str] | None = None) -> dict[str, Any]:
    path = component_path(comp)
    name = component_name(comp)
    payload = {
        "id": node_id,
        "node_type": "component",
        "command": "component",
        "component_name": ascii_slug(Path(path).stem if path else name, f"component_{index:03d}"),
        "component_name_raw": name,
        "component_path": path,
        "referenced_configuration": str(call(comp, "ReferencedConfiguration") or get_attr(comp, "ReferencedConfiguration") or ""),
        "suppressed": bool(call(comp, "IsSuppressed") or False),
        "hidden": bool(call(comp, "IsHidden", False) or False),
        "fixed": bool(call(comp, "IsFixed") or False),
        "parent_component": parent_id,
        "assembly_history_path": history_path or [name],
        "assembly_history_path_text": " / ".join(history_path or [name]),
        "instance_index": index,
        "trainable": True,
    }
    transform = transform_payload(comp)
    if transform is not None:
        payload["transform"] = transform
    return payload


def component_signature(comp: Any) -> str:
    path = component_path(comp)
    name = component_name(comp)
    return f"{path}|{name}|{call(comp, 'ReferencedConfiguration') or ''}"


def normalize_part_lookup_name(text: str) -> str:
    text = str(text or "").strip().lower()
    text = re.sub(r"<\d+>", "", text)
    text = re.sub(r"[-_ ]+\d+$", "", text)
    text = re.sub(r"\.(sldprt|prt)$", "", text, flags=re.I)
    text = re.sub(r"[^0-9a-z\u4e00-\u9fff]+", "", text)
    return text


_PRT_INDEX_CACHE: dict[str, dict[str, Any]] = {}


def suite_prt_index(search_root: Path) -> dict[str, Any]:
    key = str(search_root.resolve()).lower() if search_root.exists() else str(search_root).lower()
    cached = _PRT_INDEX_CACHE.get(key)
    if cached is not None:
        return cached
    prts: list[Path] = []
    by_norm: dict[str, list[Path]] = defaultdict(list)
    try:
        for path in search_root.rglob("*"):
            if path.is_file() and path.suffix.lower() == ".sldprt":
                prts.append(path)
                by_norm[normalize_part_lookup_name(path.stem)].append(path)
                by_norm[normalize_part_lookup_name(path.name)].append(path)
    except Exception:
        pass
    payload = {"root": str(search_root), "prts": prts, "by_norm": by_norm, "prt_count": len(prts)}
    _PRT_INDEX_CACHE[key] = payload
    return payload


def component_lookup_names(node: dict[str, Any]) -> list[str]:
    names: list[str] = []
    for value in (
        node.get("component_path"),
        node.get("component_name_raw"),
        node.get("component_name"),
        node.get("name"),
        node.get("id"),
    ):
        if not value:
            continue
        text = str(value)
        names.append(Path(text).stem if ("\\" in text or "/" in text) else text)
        names.append(text)
    out: list[str] = []
    seen: set[str] = set()
    for name in names:
        norm = normalize_part_lookup_name(name)
        if norm and norm not in seen:
            seen.add(norm)
            out.append(norm)
    return out


def resolve_component_path_from_suite(node: dict[str, Any], search_root: Path) -> tuple[str, str | None]:
    original = str(node.get("component_path") or "")
    if original and Path(original).exists():
        return original, None
    index = suite_prt_index(search_root)
    by_norm: dict[str, list[Path]] = index.get("by_norm") or {}
    for name in component_lookup_names(node):
        hits = by_norm.get(name) or []
        if len(hits) == 1:
            return str(hits[0]), "suite_prt_name_exact"
        if len(hits) > 1:
            # Prefer the shortest path, usually the local part rather than a duplicate copy.
            hits = sorted(hits, key=lambda p: (len(p.parts), len(str(p))))
            return str(hits[0]), "suite_prt_name_duplicate_shortest_path"
    return original, None


def resolve_missing_component_paths(graph: dict[str, Any], assembly_path: Path) -> dict[str, Any]:
    search_root = assembly_path.parent
    resolved = 0
    unresolved = 0
    rows: list[dict[str, Any]] = []
    for node in graph.get("nodes", []) or []:
        if node.get("node_type") != "component":
            continue
        old_path = str(node.get("component_path") or "")
        new_path, method = resolve_component_path_from_suite(node, search_root)
        if method and new_path and Path(new_path).exists():
            node["component_path_original"] = old_path
            node["component_path"] = new_path
            node["component_path_resolved_by"] = method
            resolved += 1
            rows.append({"component_id": node.get("id"), "component_name_raw": node.get("component_name_raw"), "old_path": old_path, "new_path": new_path, "method": method})
        elif not new_path or not Path(new_path).exists():
            unresolved += 1
            rows.append({"component_id": node.get("id"), "component_name_raw": node.get("component_name_raw"), "old_path": old_path, "new_path": new_path, "method": "unresolved"})
    graph.setdefault("summary", {})["component_path_resolution"] = {
        "policy": "If SolidWorks component_path is missing, recursively search all .SLDPRT files under the input assembly suite folder and match by component/part name.",
        "assembly_path": str(assembly_path),
        "search_root": str(search_root),
        "suite_prt_count": suite_prt_index(search_root).get("prt_count"),
        "resolved_missing_count": resolved,
        "unresolved_missing_count": unresolved,
        "rows": rows,
    }
    return graph


def walk_components(root: Any) -> tuple[list[dict[str, Any]], dict[str, str], dict[str, str], dict[str, Any]]:
    nodes: list[dict[str, Any]] = []
    id_by_signature: dict[str, str] = {}
    id_by_name: dict[str, str] = {}
    comp_by_id: dict[str, Any] = {}

    def visit(comp: Any, parent_id: str | None, parent_history_path: list[str] | None = None) -> None:
        if comp is None:
            return
        sig = component_signature(comp)
        if sig in id_by_signature:
            return
        node_id = f"c{len(nodes) + 1:05d}"
        id_by_signature[sig] = node_id
        id_by_name[component_name(comp)] = node_id
        id_by_name[component_name(comp).split("/")[-1]] = node_id
        path = component_path(comp)
        if path:
            id_by_name[path.lower()] = node_id
            id_by_name[Path(path).stem.lower()] = node_id
        history_path = (parent_history_path or []) + [component_name(comp)]
        nodes.append(component_payload(comp, node_id, parent_id, len(nodes) + 1, history_path))
        comp_by_id[node_id] = comp
        for child in as_list(call(comp, "GetChildren")):
            visit(child, node_id, history_path)

    for child in as_list(call(root, "GetChildren")):
        visit(child, None, [])
    return nodes, id_by_signature, id_by_name, comp_by_id



def active_root_component(model: Any) -> Any:
    cfg_mgr = get_attr(model, "ConfigurationManager") or call(model, "ConfigurationManager")
    cfg_candidates: list[Any] = []
    if cfg_mgr is not None:
        for value in (
            get_attr(cfg_mgr, "ActiveConfiguration"),
            call(cfg_mgr, "ActiveConfiguration"),
            call(cfg_mgr, "GetActiveConfiguration"),
        ):
            if value is not None and value not in cfg_candidates:
                cfg_candidates.append(value)
    for value in (call(model, "GetActiveConfiguration"), get_attr(model, "ActiveConfiguration")):
        if value is not None and value not in cfg_candidates:
            cfg_candidates.append(value)
    for cfg in cfg_candidates:
        for args in ((True,), (False,), tuple()):
            root = call(cfg, "GetRootComponent3", *args) or call(cfg, "GetRootComponent", *args)
            if root is not None:
                return root
    return None

def collect_components_from_model(model: Any) -> tuple[list[dict[str, Any]], dict[str, str], dict[str, str], dict[str, Any]]:
    nodes: list[dict[str, Any]] = []
    id_by_signature: dict[str, str] = {}
    id_by_name: dict[str, str] = {}
    comp_by_id: dict[str, Any] = {}
    components = as_list(call(model, "GetComponents", False)) or as_list(call(model, "GetComponents", True))
    for comp in components:
        if comp is None:
            continue
        sig = component_signature(comp)
        if sig in id_by_signature:
            continue
        node_id = f"c{len(nodes) + 1:05d}"
        id_by_signature[sig] = node_id
        id_by_name[component_name(comp)] = node_id
        id_by_name[component_name(comp).split("/")[-1]] = node_id
        path = component_path(comp)
        if path:
            id_by_name[path.lower()] = node_id
            id_by_name[Path(path).stem.lower()] = node_id
        nodes.append(component_payload(comp, node_id, None, len(nodes) + 1, [component_name(comp)]))
        comp_by_id[node_id] = comp
    return nodes, id_by_signature, id_by_name, comp_by_id


def assembly_reference_nodes() -> tuple[list[dict[str, Any]], dict[str, str]]:
    refs = [
        ("a_ref_front", "assembly_front_plane", [0.0, 0.0, 0.0], [0.0, 0.0, 1.0]),
        ("a_ref_right", "assembly_right_plane", [0.0, 0.0, 0.0], [1.0, 0.0, 0.0]),
        ("a_ref_top", "assembly_top_plane", [0.0, 0.0, 0.0], [0.0, 1.0, 0.0]),
        ("a_ref_origin", "assembly_origin", [0.0, 0.0, 0.0], None),
    ]
    nodes = []
    by_name = {}
    for node_id, name, origin, normal in refs:
        node = {
            "id": node_id,
            "node_type": "assembly_reference",
            "command": "assembly_reference",
            "reference_name": name,
            "reference_scope": "assembly",
            "owner_scope": "assembly",
            "owner_assembly_id": "assembly_root",
            "owner_component_id": None,
            "belongs_to": {"type": "assembly", "id": "assembly_root"},
            "related_component_ids": [],
            "mate_edge_ids": [],
            "trainable": False,
            "origin_mm": origin,
        }
        if normal is not None:
            node["normal"] = normal
        nodes.append(node)
        by_name[name] = node_id
    return nodes, by_name


def nearest_assembly_reference(selection_entities: list[dict[str, Any]], reference_ids: dict[str, str]) -> str | None:
    for entity in selection_entities:
        if entity.get("component_id") is not None:
            continue
        plane = ((entity.get("surface") or {}).get("plane") or {})
        normal = [round(float(v), 3) for v in plane.get("normal", [])]
        origin = [round(float(v), 3) for v in plane.get("origin_mm", [])]
        if normal == [0.0, 0.0, 1.0] or normal == [0.0, 0.0, -1.0]:
            return reference_ids.get("assembly_front_plane")
        if normal == [1.0, 0.0, 0.0] or normal == [-1.0, 0.0, 0.0]:
            return reference_ids.get("assembly_right_plane")
        if normal == [0.0, 1.0, 0.0] or normal == [0.0, -1.0, 0.0]:
            return reference_ids.get("assembly_top_plane")
        if origin == [0.0, 0.0, 0.0]:
            return reference_ids.get("assembly_origin")
    return None


def iter_features_with_history(model: Any) -> list[tuple[Any, list[str]]]:
    features: list[tuple[Any, list[str]]] = []

    def visit(feat: Any, parent_path: list[str]) -> None:
        while feat is not None:
            name = str(call(feat, "Name") or get_attr(feat, "Name") or "")
            type_name = str(call(feat, "GetTypeName2") or call(feat, "GetTypeName") or "")
            label = name or type_name or "feature"
            path = parent_path + [label]
            features.append((feat, path))
            sub = call(feat, "GetFirstSubFeature")
            if sub is not None:
                visit(sub, path)
            feat = call(feat, "GetNextFeature")

    visit(call(model, "FirstFeature") or call(model, "IFirstFeature"), [])
    return features


def iter_mategroup_features_with_history(model: Any) -> list[tuple[Any, list[str]]]:
    """Return mate features from MateGroup branches without walking every subfeature."""
    features: list[tuple[Any, list[str]]] = []

    def visit_mate_branch(feat: Any, parent_path: list[str]) -> None:
        while feat is not None:
            name = str(call(feat, "Name") or get_attr(feat, "Name") or "")
            type_name = str(call(feat, "GetTypeName2") or call(feat, "GetTypeName") or "")
            label = name or type_name or "feature"
            path = parent_path + [label]
            features.append((feat, path))
            sub = call(feat, "GetFirstSubFeature")
            if sub is not None:
                visit_mate_branch(sub, path)
            feat = call(feat, "GetNextFeature")

    feat = call(model, "FirstFeature") or call(model, "IFirstFeature")
    while feat is not None:
        name = str(call(feat, "Name") or get_attr(feat, "Name") or "")
        type_name = str(call(feat, "GetTypeName2") or call(feat, "GetTypeName") or "")
        label = name or type_name or "feature"
        if type_name == "MateGroup" or "mate" in type_name.lower():
            visit_mate_branch(feat, [label])
        feat = call(feat, "GetNextFeature")
    return features


def iter_features(model: Any) -> list[Any]:
    return [feat for feat, _path in iter_features_with_history(model)]


def mate_type_name(feat: Any) -> str:
    return str(call(feat, "GetTypeName2") or call(feat, "GetTypeName") or "")


def iter_mate_features(model: Any, component_only: bool = False) -> list[tuple[Any, list[str], str]]:
    mates: list[tuple[Any, list[str], str]] = []
    seen: set[str] = set()

    def add_mate(feat: Any, source: str, history_path: list[str]) -> None:
        if feat is None:
            return
        type_name = mate_type_name(feat)
        name = str(call(feat, "Name") or get_attr(feat, "Name") or "")
        if type_name == "MateGroup" or "mate" not in type_name.lower():
            return
        key = f"{name}|{type_name}|{source}"
        if key in seen:
            return
        seen.add(key)
        mates.append((feat, history_path, source))

    if component_only:
        sw_export_phase("mate_features.model_getmates_start")
        direct_mates = as_list(call(model, "GetMates"))
        sw_export_phase(f"mate_features.model_getmates_collected {len(direct_mates)}")
        for feat in direct_mates:
            name = str(call(feat, "Name") or get_attr(feat, "Name") or mate_type_name(feat) or "mate")
            add_mate(feat, "assembly_getmates", ["Mates", name])
        if mates:
            sw_export_phase(f"mate_features.model_getmates_mates {len(mates)}")
            return mates

    sw_export_phase("mate_features.feature_tree_start")
    feature_rows = iter_mategroup_features_with_history(model) if component_only else iter_features_with_history(model)
    sw_export_phase(f"mate_features.feature_tree_collected {len(feature_rows)}")
    for feat, history_path in feature_rows:
        add_mate(feat, "assembly_feature_tree", history_path)
    sw_export_phase(f"mate_features.feature_tree_mates {len(mates)}")

    if not component_only:
        sw_export_phase("mate_features.component_getmates_start")
        for comp in as_list(call(model, "GetComponents", False)):
            for feat in as_list(call(comp, "GetMates")):
                name = str(call(feat, "Name") or get_attr(feat, "Name") or mate_type_name(feat) or "mate")
                add_mate(feat, f"component_getmates:{component_name(comp)}", [component_name(comp), "Mates", name])
        sw_export_phase(f"mate_features.component_getmates_done {len(mates)}")

    return mates


def mate_entity_component(entity: Any) -> Any:
    for name in (
        "ReferenceComponent",
        "Component",
        "Component2",
        "GetComponent",
        "GetComponent2",
        "GetReferenceComponent",
        "GetReferenceComponent2",
    ):
        value = call(entity, name) or get_attr(entity, name)
        if value is not None:
            return value
    ref = (
        call(entity, "Reference")
        or get_attr(entity, "Reference")
        or call(entity, "Entity")
        or get_attr(entity, "Entity")
        or call(entity, "GetEntity")
    )
    if ref is not None:
        for name in ("GetComponent", "GetComponent2", "Component", "Component2"):
            value = call(ref, name) or get_attr(ref, name)
            if value is not None:
                return value
    return None


def float_list(value: Any) -> list[float]:
    values = as_list(value)
    out: list[float] = []
    for item in values:
        try:
            out.append(float(item))
        except Exception:
            pass
    return out


def vector_norm(values: list[float]) -> float:
    return math.sqrt(sum(float(v) * float(v) for v in values))


def close_vec(a: Any, b: Any, tol: float = 1e-4) -> bool:
    av = float_list(a)
    bv = float_list(b)
    return len(av) == len(bv) and all(abs(x - y) <= tol for x, y in zip(av, bv))


def close_float(a: Any, b: Any, tol: float = 1e-4) -> bool:
    try:
        return abs(float(a) - float(b)) <= tol
    except Exception:
        return False


def plane_offset(point: Any, normal: Any) -> float | None:
    p = float_list(point)
    n = float_list(normal)
    if len(p) != 3 or len(n) != 3 or vector_norm(n) <= 1e-9:
        return None
    norm = vector_norm(n)
    n = [v / norm for v in n]
    return sum(pv * nv for pv, nv in zip(p, n))


def parallel_or_antiparallel(a: Any, b: Any, tol: float = 1e-5) -> bool:
    av = float_list(a)
    bv = float_list(b)
    if len(av) != 3 or len(bv) != 3:
        return False
    an = vector_norm(av)
    bn = vector_norm(bv)
    if an <= 1e-9 or bn <= 1e-9:
        return False
    dot = sum((x / an) * (y / bn) for x, y in zip(av, bv))
    return abs(abs(dot) - 1.0) <= tol


def vertex_descriptor(vertex: Any) -> dict[str, Any]:
    point = call(vertex, "GetPoint") or get_attr(vertex, "GetPoint")
    values = float_list(point)
    payload: dict[str, Any] = {"entity_type": "vertex"}
    if len(values) >= 3:
        payload["point_mm"] = [round(v * 1000.0, 6) for v in values[:3]]
    return payload


def curve_descriptor(curve: Any) -> dict[str, Any]:
    payload: dict[str, Any] = {}
    if curve is None:
        return payload
    for method, key in (
        ("IsLine", "is_line"),
        ("IsCircle", "is_circle"),
        ("IsEllipse", "is_ellipse"),
        ("IsParabola", "is_parabola"),
    ):
        value = call(curve, method)
        if value is not None:
            payload[key] = bool(value)
    params = float_list(call(curve, "CircleParams"))
    if len(params) >= 7:
        payload["circle"] = {
            "center_mm": [round(v * 1000.0, 6) for v in params[:3]],
            "axis": [round(v, 6) for v in params[3:6]],
            "radius_mm": round(params[6] * 1000.0, 6),
        }
    return payload


def edge_descriptor(edge: Any) -> dict[str, Any]:
    payload: dict[str, Any] = {"entity_type": "edge"}
    start = call(edge, "GetStartVertex")
    end = call(edge, "GetEndVertex")
    if start is not None:
        payload["start"] = vertex_descriptor(start)
    if end is not None:
        payload["end"] = vertex_descriptor(end)
    curve = call(edge, "GetCurve")
    curve_payload = curve_descriptor(curve)
    if curve_payload:
        payload["curve"] = curve_payload
    try:
        length = call(edge, "GetLength")
        if length is not None:
            payload["length_mm"] = round(float(length) * 1000.0, 6)
    except Exception:
        pass
    return payload


def surface_descriptor(surface: Any) -> dict[str, Any]:
    payload: dict[str, Any] = {}
    if surface is None:
        return payload
    is_plane = bool(call(surface, "IsPlane") or False)
    is_cylinder = bool(call(surface, "IsCylinder") or False)
    payload["is_plane"] = is_plane
    payload["is_cylinder"] = is_cylinder
    for method, key in (("IsCone", "is_cone"), ("IsSphere", "is_sphere"), ("IsTorus", "is_torus")):
        value = call(surface, method)
        if value is not None:
            payload[key] = bool(value)
    if is_plane:
        plane = float_list(call(surface, "PlaneParams"))
        # SolidWorks ISurface.PlaneParams returns 6 doubles:
        #   normal.x, normal.y, normal.z, rootPoint.x, rootPoint.y, rootPoint.z
        # rootPoint is in meters. The previous exporter treated the first 3
        # values as origin and the last 3 as normal, which corrupted planar
        # face geometry and made mate-to-B-Rep matching look worse than it was.
        if len(plane) < 6:
            payload["surface_type"] = "unknown"
            payload["parse_status"] = "plane_params_failed"
            payload["plane_params_raw"] = plane
            return payload
        normal = plane[:3]
        origin = plane[3:6]
        nlen = vector_norm(normal)
        if nlen > 1e-12:
            normal = [v / nlen for v in normal]
        payload["plane"] = {
            "origin_mm": [round(v * 1000.0, 6) for v in origin],
            "normal": [round(v, 6) for v in normal],
        }
        payload["surface_type"] = "plane"
        payload["parse_status"] = "ok"
        return payload
    if is_cylinder:
        cyl = float_list(call(surface, "CylinderParams"))
        axis = cyl[3:6] if len(cyl) >= 6 else []
        radius = cyl[6] if len(cyl) >= 7 else 0.0
        if len(cyl) < 7 or vector_norm(axis) <= 1e-9 or abs(radius) <= 1e-12:
            payload["surface_type"] = "unknown"
            payload["parse_status"] = "cylinder_params_failed"
            return payload
        payload["cylinder"] = {
            "origin_mm": [round(v * 1000.0, 6) for v in cyl[:3]],
            "axis": [round(v, 6) for v in cyl[3:6]],
            "radius_mm": round(cyl[6] * 1000.0, 6),
        }
        payload["surface_type"] = "cylinder"
        payload["parse_status"] = "ok"
        return payload
    payload["surface_type"] = "unknown"
    payload["parse_status"] = "unsupported_surface_type"
    return payload


def face_descriptor(face: Any) -> dict[str, Any]:
    payload: dict[str, Any] = {"entity_type": "face"}
    surface = call(face, "GetSurface")
    surface_payload = surface_descriptor(surface)
    if surface_payload:
        payload["surface"] = surface_payload
    try:
        area = call(face, "GetArea")
        if area is not None:
            payload["area_mm2"] = round(float(area) * 1_000_000.0, 6)
    except Exception:
        pass
    try:
        box = float_list(call(face, "GetBox"))
        if len(box) >= 6:
            payload["bbox_mm"] = [round(v * 1000.0, 6) for v in box[:6]]
    except Exception:
        pass
    return payload


def face_descriptor_with_assembly(face: Any, transform: list[float] | None) -> dict[str, Any]:
    payload = face_descriptor(face)
    surface = payload.get("surface") or {}
    payload["surface_type"] = surface.get("surface_type", "unknown")
    payload["parse_status"] = surface.get("parse_status")
    cylinder = surface.get("cylinder")
    if cylinder:
        payload["axis_point_assembly"] = transform_point_mm(cylinder.get("origin_mm", []), transform)
        payload["axis_dir_assembly"] = transform_dir(cylinder.get("axis", []), transform)
        payload["radius_mm"] = cylinder.get("radius_mm")
    plane = surface.get("plane")
    if plane:
        payload["plane_origin_assembly"] = transform_point_mm(plane.get("origin_mm", []), transform)
        payload["plane_normal_assembly"] = transform_dir(plane.get("normal", []), transform)
    if payload.get("bbox_mm"):
        box = payload["bbox_mm"]
        payload["bbox_corners_assembly_sample"] = [
            transform_point_mm([box[0], box[1], box[2]], transform),
            transform_point_mm([box[3], box[4], box[5]], transform),
        ]
    return payload


def compact_persistent_references_for_output(value: Any) -> Any:
    """Drop raw persistent-reference bytes from final dataset JSON.

    The exporter still keeps raw hex/base64 in memory while matching topology,
    but the saved dataset only needs stable hashes and metadata.
    """
    if isinstance(value, list):
        return [compact_persistent_references_for_output(item) for item in value]
    if not isinstance(value, dict):
        return value
    out: dict[str, Any] = {}
    looks_like_persistent_ref = (
        ("encoding" in value or "byte_count" in value)
        and ("hex" in value or "value" in value)
    )
    looks_like_selection_candidate = (
        "source" in value
        and "value" in value
        and "text" not in value
        and not looks_like_persistent_ref
    )
    ref_hex = str(value.get("hex") or "") if looks_like_persistent_ref else ""
    for key, item in value.items():
        if looks_like_persistent_ref and key in {"value", "hex"}:
            continue
        if looks_like_selection_candidate and key == "value":
            out["text"] = compact_persistent_references_for_output(item)
            continue
        out[key] = compact_persistent_references_for_output(item)
    if looks_like_persistent_ref and ref_hex and not out.get("persistent_ref_hash"):
        out["persistent_ref_hash"] = stable_hash(ref_hex, 12)
    return out


def _face_tessellation_candidate(values: list[float], stride: int, coord_offsets: tuple[int, int, int], bbox_m: list[float]) -> dict[str, Any] | None:
    if stride <= 0 or len(values) < stride * 3:
        return None
    vertex_map: dict[tuple[float, float, float], int] = {}
    vertices_m: list[list[float]] = []
    triangles: list[list[int]] = []
    triangle_count = len(values) // (stride * 3)
    for tri_index in range(triangle_count):
        tri: list[int] = []
        base = tri_index * stride * 3
        for corner in range(3):
            start = base + corner * stride
            try:
                point = (
                    round(float(values[start + coord_offsets[0]]), 9),
                    round(float(values[start + coord_offsets[1]]), 9),
                    round(float(values[start + coord_offsets[2]]), 9),
                )
            except Exception:
                return None
            if point not in vertex_map:
                vertex_map[point] = len(vertices_m)
                vertices_m.append([point[0], point[1], point[2]])
            tri.append(vertex_map[point])
        triangles.append(tri)
    if not vertices_m or not triangles:
        return None
    score = 0.0
    if len(bbox_m) >= 6:
        mins = [min(float(bbox_m[i]), float(bbox_m[i + 3])) for i in range(3)]
        maxs = [max(float(bbox_m[i]), float(bbox_m[i + 3])) for i in range(3)]
        tol = max(1e-6, math.sqrt(sum((maxs[i] - mins[i]) ** 2 for i in range(3))) * 0.02)
        for point in vertices_m[: min(200, len(vertices_m))]:
            for axis in range(3):
                if point[axis] < mins[axis] - tol:
                    score += (mins[axis] - point[axis])
                elif point[axis] > maxs[axis] + tol:
                    score += (point[axis] - maxs[axis])
    return {
        "vertices_m": vertices_m,
        "triangles": triangles,
        "score": score,
        "stride": stride,
        "coord_offsets": list(coord_offsets),
    }


def face_tessellation(face: Any, transform: list[float] | None) -> dict[str, Any]:
    """Export triangles directly from the SolidWorks Face2 object.

    These triangles are the only reliable way for the HTML inspector to make an
    on-surface click resolve to the exact face_id without reverse matching OBJ
    triangles later.
    """
    raw = None
    source_method = None
    errors: list[str] = []
    for method, args in (
        ("GetTessTriangles", (True,)),
        ("GetTessTriangles", (False,)),
        ("GetTessTriangles", ()),
        ("IGetTessTriangles", (True,)),
        ("IGetTessTriangles", (False,)),
        ("IGetTessTriangles", ()),
    ):
        try:
            raw = call(face, method, *args)
            values = float_list(raw)
            if values:
                source_method = f"{method}{args}"
                raw = values
                break
        except Exception as exc:
            errors.append(f"{method}{args}: {exc!r}")
    values = raw if isinstance(raw, list) else []
    if not values:
        return {"available": False, "status": "no_face_tessellation", "source": "SolidWorks.Face2", "errors": errors[:6]}
    bbox_m = float_list(call(face, "GetBox"))
    candidates: list[dict[str, Any]] = []
    if len(values) % 18 == 0:
        # SolidWorks Face2 tessellation is not perfectly consistent across entity
        # types/API bindings: some returns are xyz+normal, while others are
        # normal+xyz. Try both coordinate windows and choose the one that fits
        # the face bbox best. This is especially important for curved faces.
        for offsets in ((0, 1, 2), (3, 4, 5)):
            candidate = _face_tessellation_candidate(values, 6, offsets, bbox_m)
            if candidate:
                candidates.append(candidate)
    if len(values) % 9 == 0:
        candidate = _face_tessellation_candidate(values, 3, (0, 1, 2), bbox_m)
        if candidate:
            candidates.append(candidate)
    if not candidates:
        return {
            "available": False,
            "status": "unsupported_tessellation_layout",
            "source": "SolidWorks.Face2",
            "source_method": source_method,
            "raw_value_count": len(values),
        }
    chosen = min(candidates, key=lambda item: (float(item.get("score") or 0.0), -len(item.get("triangles") or [])))
    vertices_mm = [[round(float(coord) * 1000.0, 6) for coord in point] for point in chosen["vertices_m"]]
    vertices_assembly_mm = [transform_point_mm(point, transform) for point in vertices_mm] if transform is not None else None
    payload = {
        "available": True,
        "status": "ok",
        "source": "SolidWorks.Face2.GetTessTriangles",
        "source_method": source_method,
        "coordinate_frame": "part_local",
        "unit": "mm",
        "vertices_mm": vertices_mm,
        "triangles": chosen["triangles"],
        "vertex_count": len(vertices_mm),
        "triangle_count": len(chosen["triangles"]),
        "parse_stride": chosen.get("stride"),
        "bbox_score_m": round(float(chosen.get("score") or 0.0), 9),
    }
    if vertices_assembly_mm is not None:
        payload["vertices_assembly_mm"] = vertices_assembly_mm
        payload["assembly_coordinate_frame"] = "root_assembly"
    return payload


def edge_descriptor_with_assembly(edge: Any, transform: list[float] | None) -> dict[str, Any]:
    payload = edge_descriptor(edge)
    curve = payload.get("curve") or {}
    circle = curve.get("circle")
    if circle:
        payload["curve_type"] = "circle"
        payload["center_assembly"] = transform_point_mm(circle.get("center_mm", []), transform)
        payload["axis_dir_assembly"] = transform_dir(circle.get("axis", []), transform)
        payload["radius_mm"] = circle.get("radius_mm")
    for key in ("start", "end"):
        point = ((payload.get(key) or {}).get("point_mm") or [])
        if point:
            payload[f"{key}_point_assembly"] = transform_point_mm(point, transform)
    return payload


def entity_kind(ref: Any) -> str:
    if ref is None:
        return "unknown"
    for method, kind in (("GetSurface", "face"), ("GetCurve", "edge"), ("GetPoint", "vertex")):
        try:
            getattr(ref, method)
            return kind
        except Exception:
            pass
    return "unknown"


def local_topology_id(kind: str, index: int) -> str:
    prefix = {"body": "body", "face": "face", "loop": "loop", "edge": "edge", "vertex": "vertex"}.get(kind, "entity")
    return f"{prefix}_{index:05d}"


def topology_entity_id(kind: str, index: int, pref: dict[str, Any] | None) -> str:
    prefix = {"body": "body", "face": "face", "loop": "loop", "edge": "edge", "vertex": "vertex"}.get(kind, "entity")
    ref_hex = str((pref or {}).get("hex") or "")
    if ref_hex:
        return f"{prefix}_{stable_hash(ref_hex, 12)}"
    return f"{prefix}_{stable_hash(f'{prefix}:{index}', 12)}"


def persistent_ref_hash(pref: dict[str, Any] | None) -> str | None:
    ref_hex = str((pref or {}).get("hex") or "")
    return stable_hash(ref_hex, 12) if ref_hex else None


def collect_component_topology(model: Any, component_id: str, comp: Any, max_entities: int = 0, assembly_ref_mode: str = "off") -> tuple[list[dict[str, Any]], dict[str, dict[str, Any]]]:
    refs: list[dict[str, Any]] = []
    by_persist_hex: dict[str, dict[str, Any]] = {}
    comp_model = call(comp, "GetModelDoc2") or get_attr(comp, "GetModelDoc2")
    transform = transform_array(comp)
    body_values: list[Any] = []
    for body_type in (0, 1):
        for args in ((body_type, False), (body_type, True), (body_type,)):
            body_values = as_list(call(comp_model, "GetBodies2", *args)) if comp_model is not None else []
            if body_values:
                break
        if body_values:
            break
    if not body_values:
        body_values = as_list(call(comp, "GetBodies2", 0)) or as_list(call(comp, "GetBodies3", 0, None))
    counters = Counter()

    seen_entity_keys: set[str] = set()
    edge_id_by_key: dict[str, str] = {}
    vertex_id_by_key: dict[str, str] = {}

    def hit_limit() -> bool:
        return max_entities > 0 and len(refs) >= max_entities

    def add_to_map(row: dict[str, Any]) -> None:
        pref = row.get("persistent_ref") or {}
        if pref.get("hex"):
            by_persist_hex[f"part:{pref['hex']}"] = row
            by_persist_hex[str(pref["hex"])] = row
        part_ref = (((row.get("part_context") or {}).get("persistent_ref")) or {})
        if part_ref.get("hex"):
            by_persist_hex[f"part:{part_ref['hex']}"] = row
        asm_ref = (((row.get("assembly_context") or {}).get("persistent_ref")) or {})
        if asm_ref.get("hex"):
            by_persist_hex[f"assembly:{asm_ref['hex']}"] = row

    def entity_key(entity: Any, pref: dict[str, Any]) -> str:
        return str(pref.get("hex") or repr(entity))

    for body_index, body in enumerate(body_values, start=1):
        if body is None:
            continue
        body_pref = persistent_reference(comp_model or model, body)
        body_id = topology_entity_id("body", body_index, body_pref)
        body_sequence_id = local_topology_id("body", body_index)
        body_context = context_refs(model, comp_model or model, comp, body, assembly_ref_mode=assembly_ref_mode)
        body_row = {
            "component_id": component_id,
            "entity_kind": "body",
            "body_id": body_id,
            "local_topology_id": body_id,
            "debug_sequence_id": body_sequence_id,
            "persistent_ref_hash": persistent_ref_hash(body_pref),
            "persistent_ref": body_pref,
            **body_context,
            "descriptor": {"body_type": str(call(body, "GetType") or "")},
        }
        refs.append(body_row)
        add_to_map(body_row)
        if hit_limit():
            break
        faces = as_list(call(body, "GetFaces"))
        for face in faces:
            if hit_limit():
                break
            pref = persistent_reference(comp_model or model, face)
            face_context = context_refs(model, comp_model or model, comp, face, assembly_ref_mode=assembly_ref_mode)
            key = entity_key(face, pref)
            if key in seen_entity_keys:
                continue
            seen_entity_keys.add(key)
            counters["face"] += 1
            face_sequence_id = local_topology_id("face", counters["face"])
            face_id = topology_entity_id("face", counters["face"], pref)
            row = {
                "component_id": component_id,
                "entity_kind": "face",
                "body_id": body_id,
                "face_id": face_id,
                "local_topology_id": face_id,
                "debug_sequence_id": face_sequence_id,
                "persistent_ref_hash": persistent_ref_hash(pref),
                "persistent_ref": pref,
                **face_context,
                "descriptor": face_descriptor_with_assembly(face, transform),
                "tessellation": face_tessellation(face, transform),
                "loop_ids": [],
            }
            refs.append(row)
            add_to_map(row)

            loops = as_list(call(face, "GetLoops"))
            if not loops:
                loop = call(face, "GetFirstLoop")
                while loop is not None:
                    loops.append(loop)
                    loop = call(loop, "GetNext")
            for loop in loops:
                if loop is None or hit_limit():
                    continue
                counters["loop"] += 1
                loop_pref = persistent_reference(comp_model or model, loop)
                loop_sequence_id = local_topology_id("loop", counters["loop"])
                loop_id = topology_entity_id("loop", counters["loop"], loop_pref)
                loop_context = context_refs(model, comp_model or model, comp, loop, assembly_ref_mode=assembly_ref_mode)
                loop_edges = as_list(call(loop, "GetEdges"))
                loop_row = {
                    "component_id": component_id,
                    "entity_kind": "loop",
                    "body_id": body_id,
                    "face_id": face_id,
                    "loop_id": loop_id,
                    "local_topology_id": loop_id,
                    "debug_sequence_id": loop_sequence_id,
                    "persistent_ref_hash": persistent_ref_hash(loop_pref),
                    "persistent_ref": loop_pref,
                    **loop_context,
                    "descriptor": {
                        "is_outer": bool(call(loop, "IsOuter") or False),
                        "edge_count": len(loop_edges),
                    },
                    "edge_ids": [],
                }
                refs.append(loop_row)
                add_to_map(loop_row)
                row["loop_ids"].append(loop_id)
                if hit_limit():
                    break
                if not loop_edges:
                    loop_edges = as_list(call(face, "GetEdges"))
                for edge in loop_edges:
                    if edge is None or hit_limit():
                        continue
                    epref = persistent_reference(comp_model or model, edge)
                    edge_context = context_refs(model, comp_model or model, comp, edge, assembly_ref_mode=assembly_ref_mode)
                    ekey = entity_key(edge, epref)
                    edge_id = edge_id_by_key.get(ekey)
                    if not edge_id:
                        counters["edge"] += 1
                        edge_sequence_id = local_topology_id("edge", counters["edge"])
                        edge_id = topology_entity_id("edge", counters["edge"], epref)
                        edge_id_by_key[ekey] = edge_id
                        erow = {
                            "component_id": component_id,
                            "entity_kind": "edge",
                            "body_id": body_id,
                            "face_ids": [face_id],
                            "loop_ids": [loop_id],
                            "edge_id": edge_id,
                            "local_topology_id": edge_id,
                            "debug_sequence_id": edge_sequence_id,
                            "persistent_ref_hash": persistent_ref_hash(epref),
                            "persistent_ref": epref,
                            **edge_context,
                            "descriptor": edge_descriptor_with_assembly(edge, transform),
                            "vertex_ids": [],
                        }
                        refs.append(erow)
                        add_to_map(erow)
                    else:
                        erow = next((r for r in refs if r.get("entity_kind") == "edge" and r.get("edge_id") == edge_id), None)
                        if erow is not None:
                            if face_id not in erow.setdefault("face_ids", []):
                                erow["face_ids"].append(face_id)
                            if loop_id not in erow.setdefault("loop_ids", []):
                                erow["loop_ids"].append(loop_id)
                    if edge_id not in loop_row["edge_ids"]:
                        loop_row["edge_ids"].append(edge_id)
                    if hit_limit():
                        break
                    for vertex in (call(edge, "GetStartVertex"), call(edge, "GetEndVertex")):
                        if vertex is None or hit_limit():
                            continue
                        vpref = persistent_reference(comp_model or model, vertex)
                        vertex_context = context_refs(model, comp_model or model, comp, vertex, assembly_ref_mode=assembly_ref_mode)
                        vkey = entity_key(vertex, vpref)
                        vertex_id = vertex_id_by_key.get(vkey)
                        if not vertex_id:
                            counters["vertex"] += 1
                            vertex_sequence_id = local_topology_id("vertex", counters["vertex"])
                            vertex_id = topology_entity_id("vertex", counters["vertex"], vpref)
                            vertex_id_by_key[vkey] = vertex_id
                            vrow = {
                                "component_id": component_id,
                                "entity_kind": "vertex",
                                "body_id": body_id,
                                "edge_ids": [edge_id],
                                "vertex_id": vertex_id,
                                "local_topology_id": vertex_id,
                                "debug_sequence_id": vertex_sequence_id,
                                "persistent_ref_hash": persistent_ref_hash(vpref),
                                "persistent_ref": vpref,
                                **vertex_context,
                                "descriptor": vertex_descriptor(vertex),
                            }
                            point = (vrow["descriptor"] or {}).get("point_mm")
                            if point:
                                vrow["descriptor"]["point_assembly"] = transform_point_mm(point, transform)
                            refs.append(vrow)
                            add_to_map(vrow)
                        else:
                            vrow = next((r for r in refs if r.get("entity_kind") == "vertex" and r.get("vertex_id") == vertex_id), None)
                            if vrow is not None and edge_id not in vrow.setdefault("edge_ids", []):
                                vrow["edge_ids"].append(edge_id)
                        erow = next((r for r in refs if r.get("entity_kind") == "edge" and r.get("edge_id") == edge_id), None)
                        if erow is not None and vertex_id not in erow.setdefault("vertex_ids", []):
                            erow["vertex_ids"].append(vertex_id)
            if not row["loop_ids"]:
                for edge in as_list(call(face, "GetEdges")):
                    if edge is None or hit_limit():
                        continue
                epref = persistent_reference(comp_model or model, edge)
                edge_context = context_refs(model, comp_model or model, comp, edge, assembly_ref_mode=assembly_ref_mode)
                ekey = entity_key(edge, epref)
                if ekey in seen_entity_keys:
                    continue
                seen_entity_keys.add(ekey)
                counters["edge"] += 1
                edge_sequence_id = local_topology_id("edge", counters["edge"])
                edge_id = topology_entity_id("edge", counters["edge"], epref)
                erow = {
                    "component_id": component_id,
                    "entity_kind": "edge",
                    "body_id": body_id,
                    "face_ids": [face_id],
                    "edge_id": edge_id,
                    "local_topology_id": edge_id,
                    "debug_sequence_id": edge_sequence_id,
                    "persistent_ref_hash": persistent_ref_hash(epref),
                    "persistent_ref": epref,
                    **edge_context,
                    "descriptor": edge_descriptor_with_assembly(edge, transform),
                    "vertex_ids": [],
                }
                refs.append(erow)
                add_to_map(erow)
                for vertex in (call(edge, "GetStartVertex"), call(edge, "GetEndVertex")):
                    if hit_limit():
                        break
                    if vertex is None:
                        continue
                    vpref = persistent_reference(comp_model or model, vertex)
                    vertex_context = context_refs(model, comp_model or model, comp, vertex, assembly_ref_mode=assembly_ref_mode)
                    vkey = entity_key(vertex, vpref)
                    if vkey in seen_entity_keys:
                        continue
                    seen_entity_keys.add(vkey)
                    counters["vertex"] += 1
                    vertex_sequence_id = local_topology_id("vertex", counters["vertex"])
                    vertex_id = topology_entity_id("vertex", counters["vertex"], vpref)
                    vrow = {
                        "component_id": component_id,
                        "entity_kind": "vertex",
                        "body_id": body_id,
                        "edge_ids": [edge_id],
                        "vertex_id": vertex_id,
                        "local_topology_id": vertex_id,
                        "debug_sequence_id": vertex_sequence_id,
                        "persistent_ref_hash": persistent_ref_hash(vpref),
                        "persistent_ref": vpref,
                        **vertex_context,
                        "descriptor": vertex_descriptor(vertex),
                    }
                    point = (vrow["descriptor"] or {}).get("point_mm")
                    if point:
                        vrow["descriptor"]["point_assembly"] = transform_point_mm(point, transform)
                    refs.append(vrow)
                    add_to_map(vrow)
                    erow["vertex_ids"].append(vertex_id)
        if hit_limit():
            break
    by_persist_hex["__all__"] = refs  # fallback geometry matching when mate refs use assembly-context IDs.
    return refs, by_persist_hex


def geometry_reference_descriptor(ref: Any) -> dict[str, Any]:
    if ref is None:
        return {"entity_type": "unknown"}
    type_name = str(type(ref))
    for method, builder in (
        ("GetSurface", face_descriptor),
        ("GetCurve", edge_descriptor),
        ("GetPoint", vertex_descriptor),
    ):
        try:
            getattr(ref, method)
            payload = builder(ref)
            payload["api_type"] = type_name
            return payload
        except Exception:
            pass
    return {"entity_type": "unknown", "api_type": type_name}


def mate_entity_reference(entity: Any) -> Any:
    return (
        call(entity, "Reference")
        or get_attr(entity, "Reference")
        or call(entity, "Entity")
        or get_attr(entity, "Entity")
        or call(entity, "GetEntity")
    )


REFERENCE_PLANE_RAW_NAMES = {
    "front_plane": "Front Plane",
    "right_plane": "Right Plane",
    "top_plane": "Top Plane",
}


def normalize_reference_plane_name(text: Any) -> str | None:
    if text is None:
        return None
    raw = str(text).strip()
    if not raw:
        return None
    lowered = raw.lower().replace("_", " ").replace("-", " ")
    # Match exact SolidWorks reference names in selection strings such as
    # "Right Plane@Part-1@Asm". Include common French UI names seen in these files.
    checks = (
        ("front_plane", ("front plane", "plan de face", "face plane")),
        ("right_plane", ("right plane", "plan de droite", "droite plane")),
        ("top_plane", ("top plane", "plan de dessus", "dessus plane")),
    )
    for normalized, aliases in checks:
        if any(alias in lowered for alias in aliases):
            return normalized
    return None


def safe_object_name_candidates(obj: Any) -> list[str]:
    names: list[str] = []
    if obj is None:
        return names
    for attr in ("Name", "Name2", "GetName", "GetName2", "GetNameForSelection"):
        value = call(obj, attr) or get_attr(obj, attr)
        if value is not None:
            text = str(value)
            if text and text not in names:
                names.append(text)
    for feature_method in ("GetFeature", "IGetFeature", "GetOwnerFeature", "GetReferenceFeature"):
        feature = call(obj, feature_method) or get_attr(obj, feature_method)
        if feature is None:
            continue
        for attr in ("Name", "Name2", "GetName", "GetName2"):
            value = call(feature, attr) or get_attr(feature, attr)
            if value is not None:
                text = str(value)
                if text and text not in names:
                    names.append(text)
    return names


def select_by_id_string(model: Any, obj: Any) -> str | None:
    if model is None or obj is None:
        return None
    ext = call(model, "Extension") or call(model, "GetExtension") or get_attr(model, "Extension")
    if ext is None:
        return None
    value = call(ext, "GetSelectByIDString", obj)
    if value is None:
        return None
    text = str(value)
    return text if text else None


def solidworks_selection_candidates(model: Any, comp: Any | None, entity: Any, ref: Any) -> list[dict[str, str]]:
    candidates: list[dict[str, str]] = []
    seen: set[str] = set()

    def add(source: str, value: Any) -> None:
        if value is None:
            return
        text = str(value).strip()
        if not text or text in seen:
            return
        seen.add(text)
        candidates.append({"source": source, "value": text})

    add("assembly_doc.Extension.GetSelectByIDString(reference)", select_by_id_string(model, ref))
    add("assembly_doc.Extension.GetSelectByIDString(mate_entity)", select_by_id_string(model, entity))
    part_model = call(comp, "GetModelDoc2") or get_attr(comp, "GetModelDoc2") if comp is not None else None
    if part_model is not None:
        add("part_doc.Extension.GetSelectByIDString(reference)", select_by_id_string(part_model, ref))
    for value in safe_object_name_candidates(ref):
        add("reference_object_name_or_feature", value)
    for value in safe_object_name_candidates(entity):
        add("mate_entity_name_or_feature", value)
    return candidates


def exact_component_reference_plane_from_candidates(candidates: list[dict[str, str]]) -> dict[str, Any] | None:
    for candidate in candidates:
        plane_name = normalize_reference_plane_name(candidate.get("value"))
        if plane_name:
            return {
                "reference_name": plane_name,
                "reference_name_raw": REFERENCE_PLANE_RAW_NAMES.get(plane_name, plane_name),
                "solidworks_selection_string": candidate.get("value"),
                "solidworks_selection_source": candidate.get("source"),
                "candidate_strings": candidates,
                "reference_detection_method": "solidworks_selection_name_exact",
            }
    return None


def exact_component_reference_plane_from_selection(model: Any, comp: Any | None, entity: Any, ref: Any) -> dict[str, Any] | None:
    if comp is None:
        return None
    return exact_component_reference_plane_from_candidates(solidworks_selection_candidates(model, comp, entity, ref))




def is_noisy_selection_display(text: Any) -> bool:
    if text is None:
        return True
    value = str(text).strip()
    if not value:
        return True
    lowered = value.lower()
    noisy_tokens = (
        "chambrage",
        "t?te cylindrique",
        "tête cylindrique",
        "vis chc",
        "counterbore",
        "socket head cap screw",
    )
    if any(token in lowered for token in noisy_tokens):
        return True
    # A long owner feature description is less useful than the explicit topology id.
    if len(value) > 64 and "@" not in value and "<" not in value:
        return True
    return False


def selection_display_fallback(payload: dict[str, Any]) -> str:
    return str(
        payload.get("face_id")
        or payload.get("edge_id")
        or payload.get("vertex_id")
        or payload.get("selection_topology_id")
        or payload.get("local_topology_id")
        or payload.get("entity_type")
        or "selection"
    )


def primary_topology_selection_id(payload: dict[str, Any]) -> str | None:
    return (
        payload.get("local_topology_id")
        or payload.get("face_id")
        or payload.get("edge_id")
        or payload.get("vertex_id")
        or payload.get("selection_topology_id")
    )


def local_selection_geometry(payload: dict[str, Any]) -> dict[str, Any] | None:
    entity_type = payload.get("entity_type")
    if entity_type == "face":
        surface = payload.get("surface") or {}
        if surface.get("plane"):
            plane = surface.get("plane") or {}
            return {
                "geometry_type": "plane",
                "origin_mm": plane.get("origin_mm"),
                "normal": plane.get("normal"),
                "source": "part_brep_face",
            }
        if surface.get("cylinder"):
            cylinder = surface.get("cylinder") or {}
            return {
                "geometry_type": "cylinder",
                "axis_point_mm": cylinder.get("origin_mm"),
                "axis_dir": cylinder.get("axis"),
                "radius_mm": cylinder.get("radius_mm"),
                "source": "part_brep_face",
            }
    if entity_type == "edge":
        curve = payload.get("curve") or {}
        if curve.get("circle"):
            circle = curve.get("circle") or {}
            return {
                "geometry_type": "circle_edge",
                "center_mm": circle.get("center_mm"),
                "axis_dir": circle.get("axis"),
                "radius_mm": circle.get("radius_mm"),
                "source": "part_brep_edge",
            }
        start = ((payload.get("start") or {}).get("point_mm") or None)
        end = ((payload.get("end") or {}).get("point_mm") or None)
        if start or end:
            return {
                "geometry_type": "edge",
                "start_point_mm": start,
                "end_point_mm": end,
                "length_mm": payload.get("length_mm"),
                "source": "part_brep_edge",
            }
    if entity_type == "vertex" and payload.get("point_mm"):
        return {
            "geometry_type": "vertex",
            "point_mm": payload.get("point_mm"),
            "source": "part_brep_vertex",
        }
    return None


def assembly_selection_geometry(payload: dict[str, Any]) -> dict[str, Any] | None:
    if payload.get("axis_point_assembly") or payload.get("axis_dir_assembly"):
        return {
            "geometry_type": "axis_or_cylinder",
            "axis_point_mm": payload.get("axis_point_assembly") or payload.get("center_assembly"),
            "axis_dir": payload.get("axis_dir_assembly"),
            "radius_mm": payload.get("radius_mm"),
            "source": "IComponent2.Transform2",
        }
    if payload.get("plane_origin_assembly") or payload.get("plane_normal_assembly"):
        return {
            "geometry_type": "plane",
            "origin_mm": payload.get("plane_origin_assembly"),
            "normal": payload.get("plane_normal_assembly"),
            "source": "IComponent2.Transform2",
        }
    if payload.get("center_assembly"):
        return {
            "geometry_type": "circle_edge",
            "center_mm": payload.get("center_assembly"),
            "axis_dir": payload.get("axis_dir_assembly"),
            "radius_mm": payload.get("radius_mm"),
            "source": "IComponent2.Transform2",
        }
    if payload.get("point_assembly"):
        return {
            "geometry_type": "vertex",
            "point_mm": payload.get("point_assembly"),
            "source": "IComponent2.Transform2",
        }
    if payload.get("start_point_assembly") or payload.get("end_point_assembly"):
        return {
            "geometry_type": "edge",
            "start_point_mm": payload.get("start_point_assembly"),
            "end_point_mm": payload.get("end_point_assembly"),
            "source": "IComponent2.Transform2",
        }
    return None


def finalize_selection_identity(payload: dict[str, Any], component_id: str | None, comp: Any | None) -> None:
    selected_ref = payload.get("selected_reference") or {}
    pref_hex = str(((payload.get("persistent_ref") or {}).get("hex")) or "")
    persistent_hash = stable_hash(pref_hex, 12) if pref_hex else None
    if payload.get("assembly_reference_id") or payload.get("entity_kind") == "assembly_reference_plane":
        identity = {
            "selection_object_type": "assembly_reference_plane",
            "selection_id": payload.get("assembly_reference_id"),
            "selection_id_source": "assembly_reference_id",
            "display_id": payload.get("assembly_reference_id"),
            "display_id_source": "assembly_reference_id",
            "selection_surface_id": payload.get("assembly_reference_id"),
            "selection_surface_kind": "assembly_datum_plane",
            "is_geometric_selection_surface": True,
            "is_brep_topology": False,
            "brep_mapping_status": "not_applicable_reference_plane",
            "component_id": component_id,
            "reference_kind": "assembly_reference_plane",
            "reference_name": payload.get("assembly_reference_name"),
            "reference_name_raw": payload.get("assembly_reference_name_raw"),
            "persistent_ref_hash": persistent_hash,
            "persistent_ref_context": "assembly_mate_selection",
            "local_geometry": None,
            "assembly_geometry": assembly_selection_geometry(payload),
            "coordinate_mapping": {
                "local_frame": "assembly_reference",
                "assembly_frame": "root_assembly",
                "transform_source": "assembly_reference_geometry",
            },
        }
        payload["selection_identity"] = {k: v for k, v in identity.items() if v is not None}
        return
    if selected_ref.get("reference_kind") == "component_reference_plane":
        ref_name = str(selected_ref.get("reference_name") or payload.get("component_reference_name") or "")
        display_id = selected_ref.get("component_reference_node_id") or payload.get("component_reference_node_id")
        if not display_id and component_id and ref_name:
            display_id = component_reference_node_id(component_id, ref_name)
        identity = {
            "selection_object_type": "component_reference_plane",
            "selection_id": display_id,
            "selection_id_source": "component_reference_node_id",
            "display_id": display_id,
            "display_id_source": "component_reference_node_id",
            "selection_surface_id": display_id,
            "selection_surface_kind": "component_datum_plane",
            "is_geometric_selection_surface": True,
            "is_brep_topology": False,
            "brep_mapping_status": "not_applicable_reference_plane",
            "component_id": component_id,
            "component_name_raw": component_name(comp) if comp is not None else payload.get("component_name_raw"),
            "reference_kind": "component_reference_plane",
            "reference_name": ref_name,
            "reference_name_raw": selected_ref.get("reference_name_raw"),
            "persistent_ref_hash": persistent_hash,
            "persistent_ref_context": "assembly_mate_selection",
            "local_geometry": {
                "geometry_type": "plane",
                "origin_mm": selected_ref.get("local_plane_origin_mm"),
                "normal": selected_ref.get("local_plane_normal"),
                "source": "component_reference_plane",
            },
            "assembly_geometry": {
                "geometry_type": "plane",
                "origin_mm": selected_ref.get("assembly_plane_origin_mm"),
                "normal": selected_ref.get("assembly_plane_normal"),
                "source": "IComponent2.Transform2",
            },
            "coordinate_mapping": {
                "local_frame": "component_reference",
                "assembly_frame": "root_assembly",
                "transform_source": "IComponent2.Transform2",
            },
        }
        payload["selection_identity"] = {k: v for k, v in identity.items() if v is not None}
        return

    topology_id = primary_topology_selection_id(payload)
    if topology_id:
        payload["selection_topology_id"] = topology_id
        internal = payload.get("component_internal_selection") or {}
        if internal:
            internal["topology_selection_id"] = topology_id
            internal["history_path"] = [component_name(comp) if comp is not None else internal.get("owner_component_name_raw"), internal.get("selection_name_raw") or topology_id]
            payload["component_internal_selection"] = internal
    local_geometry = local_selection_geometry(payload)
    assembly_geometry = assembly_selection_geometry(payload)
    identity = {
        "selection_object_type": "brep_topology" if topology_id else "unresolved_selection",
        "selection_id": topology_id,
        "selection_id_source": "brep_topology_id" if topology_id else None,
        "display_id": topology_id or payload.get("raw_selection_id") or selection_display_fallback(payload),
        "display_id_source": "topology_selection_id" if topology_id else "raw_selection_id",
        "selection_surface_id": topology_id,
        "selection_surface_kind": f"brep_{payload.get('entity_type')}" if topology_id else "unresolved_selection",
        "is_geometric_selection_surface": payload.get("entity_type") in {"face", "edge", "vertex"},
        "is_brep_topology": bool(topology_id),
        "brep_topology_id": topology_id,
        "brep_mapping_status": (payload.get("match_status") or {}).get("match_method") or ("matched_or_generated_topology_id" if topology_id else "unmatched"),
        "raw_selection_id": payload.get("raw_selection_id"),
        "solidworks_selection_id_original": payload.get("raw_selection_id") if not topology_id else payload.get("solidworks_selection_id_original"),
        "component_id": component_id,
        "component_name_raw": component_name(comp) if comp is not None else payload.get("component_name_raw"),
        "entity_type": payload.get("entity_type"),
        "entity_kind": payload.get("entity_kind") or payload.get("entity_type"),
        "reference_kind": payload.get("reference_kind"),
        "topology_selection_id": topology_id,
        "persistent_ref_hash": persistent_hash,
        "persistent_ref_context": "assembly_mate_selection",
        "local_geometry": local_geometry,
        "assembly_geometry": assembly_geometry,
        "coordinate_mapping": {
            "local_frame": "part_brep",
            "assembly_frame": "root_assembly",
            "transform_source": "IComponent2.Transform2",
        } if local_geometry or assembly_geometry else None,
    }
    payload["selection_identity"] = {k: v for k, v in identity.items() if v is not None}


def component_internal_selection_payload(component_id: str | None, comp: Any | None, payload: dict[str, Any], candidates: list[dict[str, str]]) -> dict[str, Any] | None:
    if component_id is None or comp is None:
        return None
    raw_component_name = component_name(comp)
    display = None
    source = None
    for candidate in candidates or []:
        value = str(candidate.get("value") or "").strip()
        if not value:
            continue
        # Prefer SolidWorks selection paths such as Face<1>@Part<1> or ?<1>@Pi?ce2<1>.
        if "@" in value or "<" in value:
            display = value
            source = candidate.get("source")
            break
    if is_noisy_selection_display(display):
        display = None
        source = None
    entity_name = str(display).split("@")[0].strip() if display else None
    owner_feature = None
    for candidate in candidates or []:
        value = str(candidate.get("value") or "").strip()
        if not value or "@" in value or "<" in value or is_noisy_selection_display(value):
            continue
        owner_feature = value
        break
    owner_feature_source = f"{payload.get('entity_type')}.GetFeature" if owner_feature and payload.get("entity_type") else None
    topology_selection_id = selection_display_fallback(payload)
    return {
        "reference_scope": "component",
        "reference_kind": "component_internal_selection",
        "owner_component_id": component_id,
        "owner_component_name_raw": raw_component_name,
        "owner_component_path": component_path(comp),
        "selection_name_raw": entity_name,
        "selection_display_name": display,
        "selection_source": source,
        "component_internal_selection_name_source": "solidworks_selection_box" if display else "unavailable",
        "solidworks_owner_feature_name": owner_feature,
        "solidworks_owner_feature_source": owner_feature_source,
        "topology_selection_id": topology_selection_id,
        "history_path": [raw_component_name, entity_name or topology_selection_id],
        "entity_type": payload.get("entity_type"),
        "entity_kind": payload.get("entity_kind") or payload.get("entity_type"),
        "surface_type": payload.get("surface_type"),
        "local_topology_id": payload.get("local_topology_id"),
        "selection_topology_id": payload.get("selection_topology_id"),
        "face_id": payload.get("face_id"),
        "edge_id": payload.get("edge_id"),
        "vertex_id": payload.get("vertex_id"),
    }


def standard_reference_plane_name(origin_mm: Any, normal: Any, tol: float = 1e-4) -> str | None:
    n = float_list(normal)
    if len(n) != 3:
        return None
    axis = max(range(3), key=lambda i: abs(n[i]))
    if abs(abs(n[axis]) - 1.0) > 1e-3:
        return None
    if any(abs(n[i]) > 1e-3 for i in range(3) if i != axis):
        return None
    return {0: "right_plane", 1: "top_plane", 2: "front_plane"}.get(axis)


def component_reference_selection_payload(
    component_id: str | None,
    comp: Any | None,
    payload: dict[str, Any],
    mate_type: str = "",
    exact_reference: dict[str, Any] | None = None,
) -> dict[str, Any] | None:
    if component_id is None or comp is None or payload.get("entity_type") != "face":
        return None
    if not exact_reference:
        return None
    plane_name = normalize_reference_plane_name(exact_reference.get("reference_name_raw") or exact_reference.get("reference_name"))
    if not plane_name:
        return None
    surface = payload.get("surface") or {}
    plane = surface.get("plane") or {}
    raw_component_name = component_name(comp)
    comp_path = component_path(comp)
    raw_plane_name = REFERENCE_PLANE_RAW_NAMES.get(plane_name, plane_name)
    return {
        "reference_scope": "component",
        "reference_kind": "component_reference_plane",
        "reference_name": plane_name,
        "reference_name_raw": raw_plane_name,
        "owner_component_id": component_id,
        "owner_component_name_raw": raw_component_name,
        "owner_component_path": comp_path,
        "history_path": [raw_component_name, raw_plane_name],
        "solidworks_selection_string": exact_reference.get("solidworks_selection_string"),
        "solidworks_selection_source": exact_reference.get("solidworks_selection_source"),
        "reference_detection_method": exact_reference.get("reference_detection_method") or "solidworks_selection_name_exact",
        "local_plane_origin_mm": plane.get("origin_mm", []),
        "local_plane_normal": plane.get("normal", []),
        "assembly_plane_origin_mm": payload.get("plane_origin_assembly"),
        "assembly_plane_normal": payload.get("plane_normal_assembly"),
    }


def mark_reference_selection_not_topology(payload: dict[str, Any], reference_match_method: str) -> None:
    payload["topology_applicability"] = "not_applicable_reference_selection"
    payload["topology_match"] = False
    payload["reference_match"] = True
    payload["reference_match_method"] = reference_match_method
    for key in ("local_topology_id", "face_id", "edge_id", "vertex_id", "selection_topology_id"):
        payload.pop(key, None)


def mate_entity_descriptor(
    entity: Any,
    component_id: str | None,
    model: Any,
    comp: Any | None,
    topology_by_component: dict[str, dict[str, dict[str, Any]]] | None = None,
    mate_type: str = "",
) -> dict[str, Any]:
    ref = mate_entity_reference(entity)
    sw_selection_candidates = solidworks_selection_candidates(model, comp, entity, ref) if comp is not None else solidworks_selection_candidates(model, None, entity, ref)
    exact_component_reference = exact_component_reference_plane_from_candidates(sw_selection_candidates) if comp is not None else None
    payload = geometry_reference_descriptor(ref)
    if sw_selection_candidates:
        payload["solidworks_selection_candidates"] = sw_selection_candidates
        payload["solidworks_selection_display"] = sw_selection_candidates[0].get("value")
        payload["solidworks_selection_source"] = sw_selection_candidates[0].get("source")
    if exact_component_reference:
        payload["solidworks_selection_reference"] = exact_component_reference
    payload["component_id"] = component_id
    payload["mate_entity_type_raw"] = str(call(entity, "ReferenceType") or call(entity, "Type") or "")
    ref_model = (call(comp, "GetModelDoc2") or get_attr(comp, "GetModelDoc2")) if comp is not None else model
    assembly_pref = persistent_reference(model, ref)
    part_pref = persistent_reference(ref_model or model, ref) if comp is not None else {"available": False, "error": "not_component_entity"}
    pref = assembly_pref
    payload["persistent_ref"] = assembly_pref
    payload["mate_selection_context"] = {
        "persistent_ref": assembly_pref,
        "source": "mate selection entity + assembly_doc.GetPersistReference3",
    }
    payload["part_context_attempt"] = {
        "persistent_ref": part_pref,
        "source": "mate selection entity + part_doc.GetPersistReference3",
    }
    topo_match = None
    match_method = "unmatched"
    if component_id and topology_by_component and assembly_pref.get("hex"):
        topo_match = topology_by_component.get(component_id, {}).get(f"assembly:{assembly_pref['hex']}")
        if topo_match:
            match_method = "assembly_persistent_ref"
    if topo_match is None and component_id and topology_by_component and part_pref.get("hex"):
        topo_match = topology_by_component.get(component_id, {}).get(f"part:{part_pref['hex']}") or topology_by_component.get(component_id, {}).get(str(part_pref["hex"]))
        if topo_match:
            match_method = "part_persistent_ref"
    if topo_match:
        apply_topology_match(payload, topo_match)
    else:
        payload["topology_match"] = False
    params = float_list(call(entity, "EntityParams") or call(entity, "GetEntityParams"))
    if params:
        payload["entity_params_raw"] = params
        if payload.get("entity_type") == "unknown" and len(params) >= 6:
            payload["entity_type"] = "face"
            payload["surface"] = {
                "is_plane": True,
                "plane": {
                    "origin_mm": [round(v * 1000.0, 6) for v in params[:3]],
                    "normal": [round(v, 6) for v in params[3:6]],
                },
                "source": "MateEntity.EntityParams",
            }
        if len(params) >= 8:
            payload["mate_entity_extra_params"] = [round(v, 9) for v in params[6:]]
        surface = payload.get("surface") or {}
        if payload.get("entity_type") == "face" and len(params) >= 6 and not surface.get("plane"):
            payload["surface"] = {
                "is_plane": True,
                "plane": {
                    "origin_mm": [round(v * 1000.0, 6) for v in params[:3]],
                    "normal": [round(v, 6) for v in params[3:6]],
                },
                "source": "MateEntity.EntityParams",
            }
    if component_id is None:
        payload["reference_scope"] = "assembly_or_unresolved_component"
    else:
        payload["reference_scope"] = "component"
    payload["reference_available"] = ref is not None
    payload["entity_kind"] = payload.get("entity_type", "unknown")
    internal_selection = component_internal_selection_payload(component_id, comp, payload, sw_selection_candidates)
    if internal_selection:
        payload["component_internal_selection"] = internal_selection
    transform = transform_array(comp) if comp is not None else None
    if payload.get("entity_type") == "face":
        surface = payload.get("surface") or {}
        cylinder = surface.get("cylinder")
        if cylinder:
            payload["surface_type"] = "cylinder"
            payload["axis_point_assembly"] = transform_point_mm(cylinder.get("origin_mm", []), transform)
            payload["axis_dir_assembly"] = transform_dir(cylinder.get("axis", []), transform)
            payload["radius_mm"] = cylinder.get("radius_mm")
        plane = surface.get("plane")
        if plane:
            payload["surface_type"] = "plane"
            payload["plane_origin_assembly"] = transform_point_mm(plane.get("origin_mm", []), transform)
            payload["plane_normal_assembly"] = transform_dir(plane.get("normal", []), transform)
            selected_reference = component_reference_selection_payload(component_id, comp, payload, mate_type=mate_type, exact_reference=exact_component_reference)
            if selected_reference:
                payload["selected_reference"] = selected_reference
                payload["reference_kind"] = selected_reference["reference_kind"]
                payload["component_reference_name"] = selected_reference["reference_name"]
                payload["component_reference_name_raw"] = selected_reference["reference_name_raw"]
                payload["entity_kind"] = "component_reference_plane"
                mark_reference_selection_not_topology(payload, "component_reference_plane")
            else:
                nearest_plane = standard_reference_plane_name(plane.get("origin_mm", []), plane.get("normal", []))
                if nearest_plane:
                    payload["reference_kind"] = "geometric_planar_face"
                    payload["nearest_component_reference_plane"] = nearest_plane
    if payload.get("entity_type") == "edge":
        curve = payload.get("curve") or {}
        circle = curve.get("circle")
        if circle:
            payload["curve_type"] = "circle"
            payload["center_assembly"] = transform_point_mm(circle.get("center_mm", []), transform)
            payload["axis_dir_assembly"] = transform_dir(circle.get("axis", []), transform)
            payload["radius_mm"] = circle.get("radius_mm")
        for key in ("start", "end"):
            point = ((payload.get(key) or {}).get("point_mm") or [])
            if point:
                payload[f"{key}_point_assembly"] = transform_point_mm(point, transform)
    if payload.get("entity_type") == "vertex":
        point = payload.get("point_mm") or []
        if point:
            payload["point_assembly"] = transform_point_mm(point, transform)
    if component_id and topology_by_component and not payload.get("topology_match") and payload.get("topology_applicability") != "not_applicable_reference_selection":
        topo_match = topology_match_by_geometry(payload, topology_by_component.get(component_id))
        apply_topology_match(payload, topo_match)
        if topo_match:
            match_method = "geometry_signature"
    stable_suffix = stable_hash(str(pref.get("hex") or json.dumps(payload, ensure_ascii=True, sort_keys=True)), 12)
    if payload.get("topology_applicability") != "not_applicable_reference_selection" and not payload.get("local_topology_id"):
        payload["raw_selection_id"] = f"{payload.get('entity_type', 'entity')}_{stable_suffix}"
        payload["raw_selection_id_source"] = "solidworks_selection_persistent_ref_hash"
    if payload.get("topology_applicability") == "not_applicable_reference_selection":
        payload["match_status"] = {
            "assembly_ref_match": False,
            "part_ref_match": False,
            "geometry_fallback_match": False,
            "final_match": False,
            "match_method": "not_applicable_reference_selection",
            "match_confidence": 1.0,
            "topology_applicability": "not_applicable",
            "reference_match": True,
            "reference_match_method": payload.get("reference_match_method"),
        }
    else:
        payload["match_status"] = {
            "assembly_ref_match": match_method == "assembly_persistent_ref",
            "part_ref_match": match_method == "part_persistent_ref",
            "geometry_fallback_match": match_method == "geometry_signature",
            "final_match": bool(payload.get("topology_match")),
            "match_method": match_method if payload.get("topology_match") else "unmatched",
            "match_confidence": 1.0 if match_method in {"assembly_persistent_ref", "part_persistent_ref"} else (float(payload.get("geometry_fallback_confidence") or 0.0) if match_method == "geometry_signature" else 0.0),
            "topology_applicability": "applicable",
            "geometry_fallback_evaluation": payload.get("geometry_fallback_evaluation"),
        }
    finalize_selection_identity(payload, component_id, comp)
    payload["entity_hash"] = stable_hash(json.dumps(payload, ensure_ascii=True, sort_keys=True), 12)
    return payload


def mate_entities(specific: Any) -> list[Any]:
    entities: list[Any] = []
    count = call(specific, "GetMateEntityCount") or call(specific, "MateEntityCount") or 0
    try:
        count = int(count)
    except Exception:
        count = 0
    for idx in range(count):
        ent = call(specific, "MateEntity", idx) or call(specific, "GetMateEntity", idx)
        if ent is not None:
            entities.append(ent)
    for name in ("GetMateEntities", "MateEntities", "GetEntitiesToMate", "EntitiesToMate"):
        for ent in as_list(call(specific, name) or get_attr(specific, name)):
            if ent is not None and ent not in entities:
                entities.append(ent)
    if not entities:
        for idx in range(4):
            ent = call(specific, "EntityToMate", idx) or call(specific, "GetEntityToMate", idx)
            if ent is not None and ent not in entities:
                entities.append(ent)
    return entities


def topology_match_by_geometry(payload: dict[str, Any], topology_map: dict[str, Any] | None) -> dict[str, Any] | None:
    if not topology_map:
        return None
    candidates = topology_map.get("__all__", [])
    entity_type = payload.get("entity_type")
    scored: list[dict[str, Any]] = []

    def add_candidate(row: dict[str, Any], score: float, reason: str, metrics: dict[str, Any]) -> None:
        scored.append({
            "row": row,
            "score": round(float(score), 6),
            "reason": reason,
            "topology_id": row.get("local_topology_id") or row.get("face_id") or row.get("edge_id") or row.get("vertex_id"),
            "metrics": metrics,
        })

    for row in candidates:
        if row.get("entity_kind") != entity_type:
            continue
        desc = row.get("descriptor") or {}
        if entity_type == "face":
            if payload.get("surface_type") != desc.get("surface_type"):
                continue
            if payload.get("surface_type") == "plane":
                payload_normal = payload.get("plane_normal_assembly")
                desc_normal = desc.get("plane_normal_assembly")
                payload_origin = payload.get("plane_origin_assembly")
                desc_origin = desc.get("plane_origin_assembly")
                pn = _vec_unit(_as_xyz(payload_normal) or [])
                dn = _vec_unit(_as_xyz(desc_normal) or [])
                po = _as_xyz(payload_origin)
                do = _as_xyz(desc_origin)
                if not pn or not dn or not po or not do:
                    continue
                dot_value = _vec_dot(pn, dn)
                normal_delta = 1.0 - abs(dot_value)
                if normal_delta > 0.05:
                    continue
                oriented_dn = dn if dot_value >= 0 else [-dn[0], -dn[1], -dn[2]]
                # Signed plane distance after orienting the candidate normal.
                plane_distance = abs(_vec_dot(_vec_sub(po, do), oriented_dn))
                centroid_distance = _vec_norm(_vec_sub(po, do))
                area_ratio = None
                if payload.get("area_mm2") and desc.get("area_mm2"):
                    try:
                        area_ratio = float(payload.get("area_mm2")) / float(desc.get("area_mm2"))
                    except Exception:
                        area_ratio = None
                if area_ratio is not None and not (0.95 <= area_ratio <= 1.05):
                    continue
                score = 1.0 - min(1.0, normal_delta * 20.0 + plane_distance / 5.0 + centroid_distance / 5000.0)
                add_candidate(row, score, "plane_geometry_candidate", {
                    "normal_delta": round(normal_delta, 9),
                    "signed_plane_distance_mm": round(plane_distance, 6),
                    "centroid_distance_mm": round(centroid_distance, 6),
                    "area_ratio": round(area_ratio, 6) if area_ratio is not None else None,
                })
            if payload.get("surface_type") == "cylinder":
                pr = payload.get("radius_mm")
                dr = desc.get("radius_mm")
                pa = _vec_unit(_as_xyz(payload.get("axis_dir_assembly")) or [])
                da = _vec_unit(_as_xyz(desc.get("axis_dir_assembly")) or [])
                pp = _as_xyz(payload.get("axis_point_assembly") or payload.get("center_assembly"))
                dp = _as_xyz(desc.get("axis_point_assembly") or desc.get("center_assembly"))
                if pr is None or dr is None or not pa or not da or not pp or not dp:
                    continue
                radius_delta = abs(float(pr) - float(dr))
                axis_delta = 1.0 - abs(_vec_dot(pa, da))
                if radius_delta > 0.01 or axis_delta > 0.01:
                    continue
                cross_vec = _vec_cross(_vec_sub(pp, dp), da)
                axis_distance = _vec_norm(cross_vec)
                score = 1.0 - min(1.0, radius_delta / 0.05 + axis_delta * 10.0 + axis_distance / 5.0)
                add_candidate(row, score, "cylinder_geometry_candidate", {
                    "radius_delta_mm": round(radius_delta, 6),
                    "axis_delta": round(axis_delta, 9),
                    "axis_distance_mm": round(axis_distance, 6),
                })
        elif entity_type == "edge":
            if payload.get("curve_type") == desc.get("curve_type") == "circle":
                radius_delta = abs(float(payload.get("radius_mm") or 0) - float(desc.get("radius_mm") or 0))
                center_distance = _vec_norm(_vec_sub(_as_xyz(payload.get("center_assembly")) or [0, 0, 0], _as_xyz(desc.get("center_assembly")) or [0, 0, 0]))
                if radius_delta <= 0.01 and center_distance <= 0.2:
                    score = 1.0 - min(1.0, radius_delta / 0.05 + center_distance / 1.0)
                    add_candidate(row, score, "circle_edge_geometry_candidate", {"radius_delta_mm": round(radius_delta, 6), "center_distance_mm": round(center_distance, 6)})
            ps = _as_xyz(payload.get("start_point_assembly"))
            pe = _as_xyz(payload.get("end_point_assembly"))
            ds = _as_xyz(desc.get("start_point_assembly"))
            de = _as_xyz(desc.get("end_point_assembly"))
            if ps and pe and ds and de:
                direct = _vec_norm(_vec_sub(ps, ds)) + _vec_norm(_vec_sub(pe, de))
                reverse = _vec_norm(_vec_sub(ps, de)) + _vec_norm(_vec_sub(pe, ds))
                endpoint_distance = min(direct, reverse)
                if endpoint_distance <= 0.2:
                    score = 1.0 - min(1.0, endpoint_distance / 1.0)
                    add_candidate(row, score, "edge_endpoint_geometry_candidate", {"endpoint_distance_mm": round(endpoint_distance, 6)})
        elif entity_type == "vertex":
            pp = _as_xyz(payload.get("point_assembly"))
            dp = _as_xyz(desc.get("point_assembly"))
            if pp and dp:
                point_distance = _vec_norm(_vec_sub(pp, dp))
                if point_distance <= 0.1:
                    score = 1.0 - min(1.0, point_distance / 0.5)
                    add_candidate(row, score, "vertex_geometry_candidate", {"point_distance_mm": round(point_distance, 6)})
    scored.sort(key=lambda item: item["score"], reverse=True)
    payload["geometry_fallback_evaluation"] = {
        "candidate_count": len(scored),
        "accepted": False,
        "reason": "no_candidates",
        "candidates": [
            {k: v for k, v in item.items() if k != "row"}
            for item in scored[:8]
        ],
    }
    if not scored:
        return None
    best = scored[0]
    second_score = scored[1]["score"] if len(scored) > 1 else None
    unique_margin = best["score"] - second_score if second_score is not None else 1.0
    metrics = best.get("metrics") or {}
    accepted = (
        best["score"] >= 0.90
        and unique_margin >= 0.15
        and (
            entity_type != "face"
            or payload.get("surface_type") != "plane"
            or (
                (metrics.get("normal_delta") is not None and metrics.get("normal_delta") <= 0.01)
                and (metrics.get("signed_plane_distance_mm") is not None and metrics.get("signed_plane_distance_mm") <= 0.2)
            )
        )
    )
    payload["geometry_fallback_evaluation"].update({
        "accepted": bool(accepted),
        "reason": "accepted_unique_high_confidence" if accepted else "ambiguous_or_low_confidence",
        "best_topology_id": best.get("topology_id"),
        "best_score": best.get("score"),
        "second_score": second_score,
        "unique_margin": round(unique_margin, 6),
    })
    if accepted:
        payload["geometry_fallback_confidence"] = best.get("score")
        return best["row"]
    return None


def apply_topology_match(payload: dict[str, Any], topo_match: dict[str, Any] | None) -> None:
    if not topo_match:
        return
    payload["local_topology_id"] = topo_match.get("local_topology_id")
    payload["face_id"] = topo_match.get("face_id")
    payload["edge_id"] = topo_match.get("edge_id")
    payload["vertex_id"] = topo_match.get("vertex_id")
    payload["selection_topology_id"] = topo_match.get("local_topology_id") or topo_match.get("face_id") or topo_match.get("edge_id") or topo_match.get("vertex_id")
    payload["topology_match"] = True


def component_id_for(comp: Any, id_by_signature: dict[str, str], id_by_name: dict[str, str]) -> str | None:
    if comp is None:
        return None
    comp_id = id_by_signature.get(component_signature(comp)) or id_by_name.get(component_name(comp))
    if comp_id:
        return comp_id
    path = component_path(comp)
    if path:
        return id_by_name.get(path.lower()) or id_by_name.get(Path(path).stem.lower())
    short_name = component_name(comp).split("/")[-1].split("-")[0].lower()
    return id_by_name.get(short_name)


def mate_category(type_name: str) -> str:
    text = type_name.lower()
    mechanical = ("gear", "cam", "rack", "pinion", "screw", "universal", "hinge")
    advanced = ("symmetric", "width", "path", "linear", "coupler", "profile")
    standard = ("coincident", "parallel", "perpendicular", "tangent", "concentric", "distance", "angle", "lock")
    if any(k in text for k in mechanical):
        return "mechanical"
    if any(k in text for k in advanced):
        return "advanced"
    if any(k in text for k in standard):
        return "standard"
    return "unknown"


def mate_classification_payload(type_name: str) -> dict[str, Any]:
    category = mate_category(type_name)
    return {
        "category": category,
        "standard": category == "standard",
        "mechanical": category == "mechanical",
        "advanced": category == "advanced",
    }


def mate_definition_payload(specific: Any) -> dict[str, Any]:
    payload: dict[str, Any] = {}
    if specific is None:
        return payload
    for method, key in (
        ("Type", "type_code"),
        ("GetMateType", "type_code"),
        ("Alignment", "alignment_code"),
        ("GetAlignment", "alignment_code"),
        ("CanBeFlipped", "can_be_flipped"),
        ("Flipped", "flipped"),
        ("ForPositioningOnly", "for_positioning_only"),
    ):
        value = call(specific, method) or get_attr(specific, method)
        if value is not None:
            payload[key] = value
    for method, key, scale in (
        ("Distance", "distance_mm", 1000.0),
        ("DistanceValue", "distance_mm", 1000.0),
        ("Angle", "angle_rad", 1.0),
        ("AngleValue", "angle_rad", 1.0),
    ):
        value = call(specific, method) or get_attr(specific, method)
        if value is not None:
            try:
                payload[key] = round(float(value) * scale, 9)
                if key == "angle_rad":
                    payload["angle_deg"] = round(float(value) * 180.0 / math.pi, 6)
            except Exception:
                payload[key] = value
    return payload


def mate_payload(
    feat: Any,
    edge_id: str,
    source: str,
    target: str,
    component_ids: list[str],
    selection_entities: list[dict[str, Any]],
    history_path: list[str] | None = None,
    source_api_name: str = "FeatureTreeMate",
) -> dict[str, Any]:
    type_name = mate_type_name(feat)
    raw_name = str(call(feat, "Name") or get_attr(feat, "Name") or type_name or "mate")
    target_is_reference = target.startswith("a_ref_")
    specific = call(feat, "GetSpecificFeature2") or call(feat, "GetDefinition")
    classification = mate_classification_payload(type_name)
    quality_flags: list[str] = []
    if "concentric" in type_name.lower() or "coax" in type_name.lower():
        for entity in selection_entities:
            if entity.get("entity_type") == "face" and (entity.get("surface_type") == "plane" or entity.get("reference_kind") == "component_reference_plane"):
                quality_flags.append("suspicious_concentric_selection_plane")
                break
    if target_is_reference:
        for entity in selection_entities:
            if entity.get("component_id") is None:
                entity["entity_kind"] = "assembly_reference_plane"
                entity["entity_type"] = "assembly_reference"
                entity["assembly_reference_id"] = target
                entity["reference_scope"] = "assembly"
                mark_reference_selection_not_topology(entity, "assembly_reference_plane")
                entity["match_status"] = {
                    "assembly_ref_match": False,
                    "part_ref_match": False,
                    "geometry_fallback_match": False,
                    "final_match": False,
                    "match_method": "not_applicable_reference_selection",
                    "match_confidence": 1.0,
                    "topology_applicability": "not_applicable",
                    "reference_match": True,
                    "reference_match_method": "assembly_reference_plane",
                }
    selection_summary = summarize_mate_selection_entities(selection_entities)
    return {
        "id": edge_id,
        "source": source,
        "target": target,
        "relation": "mate",
        "relation_detail": "assembly:mate",
        "assembly_relation": "assembly:mate",
        "mate_name": ascii_slug(raw_name, "mate"),
        "mate_name_raw": raw_name,
        "feature_history_path": history_path or [],
        "feature_history_path_text": " / ".join(history_path or []),
        "solidworks_type": type_name,
        "mate_category": classification["category"],
        "mate_classification": classification,
        "mate_definition": mate_definition_payload(specific),
        "quality_flags": quality_flags,
        "component_ids": component_ids,
        "component_level_source": source,
        "component_level_target": target,
        "source_component_id": source if source.startswith("c") else None,
        "target_component_id": target if target.startswith("c") else None,
        "target_assembly_reference_id": target if target_is_reference else None,
        "target_reference_scope": "assembly" if target_is_reference else None,
        "selection": {
            "entities": selection_entities,
            "resolved": len(selection_entities) >= 2,
        },
        "selection_summary": selection_summary,
        "source_api": [source_api_name, "MateEntity"],
    }


def component_only_mate_payload(
    feat: Any,
    edge_id: str,
    source: str,
    target: str,
    component_ids: list[str],
    history_path: list[str] | None = None,
    source_api_name: str = "FeatureTreeMate",
) -> dict[str, Any]:
    type_name = mate_type_name(feat)
    raw_name = str(call(feat, "Name") or get_attr(feat, "Name") or type_name or "mate")
    classification = mate_classification_payload(type_name)
    return {
        "id": edge_id,
        "source": source,
        "target": target,
        "relation": "mate",
        "relation_detail": "assembly:mate",
        "assembly_relation": "assembly:mate",
        "mate_name": ascii_slug(raw_name, "mate"),
        "mate_name_raw": raw_name,
        "feature_history_path": history_path or [],
        "feature_history_path_text": " / ".join(history_path or []),
        "solidworks_type": type_name,
        "mate_category": classification["category"],
        "mate_classification": classification,
        "mate_definition": {"status": "skipped_component_only_mate_graph"},
        "quality_flags": [],
        "component_ids": component_ids,
        "component_level_source": source,
        "component_level_target": target,
        "source_component_id": source if source.startswith("c") else None,
        "target_component_id": target if target.startswith("c") else None,
        "selection": {"entities": [], "resolved": False},
        "selection_summary": [],
        "source_api": [source_api_name, "MateEntityComponentOnly"],
    }


def summarize_mate_selection_entities(selection_entities: list[dict[str, Any]]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for index, entity in enumerate(selection_entities or [], 1):
        selected_ref = entity.get("selected_reference") or {}
        identity = entity.get("selection_identity") or {}
        row = {
            "selection_index": index,
            "component_id": entity.get("component_id"),
            "component_name_raw": entity.get("component_name_raw") or selected_ref.get("owner_component_name_raw"),
            "entity_type": entity.get("entity_type"),
            "entity_kind": entity.get("entity_kind"),
            "reference_scope": entity.get("reference_scope"),
            "reference_kind": entity.get("reference_kind"),
            "selection_object_type": identity.get("selection_object_type"),
            "selection_id": identity.get("selection_id"),
            "display_id": identity.get("display_id"),
            "selection_id_source": identity.get("selection_id_source"),
            "topology_selection_id": identity.get("topology_selection_id") or entity.get("topology_selection_id"),
            "selection_topology_id": identity.get("selection_topology_id") or entity.get("selection_topology_id"),
            "brep_topology_id": identity.get("brep_topology_id") or entity.get("brep_topology_id"),
            "face_id": identity.get("face_id") or entity.get("face_id"),
            "edge_id": identity.get("edge_id") or entity.get("edge_id"),
            "vertex_id": identity.get("vertex_id") or entity.get("vertex_id"),
            "solidworks_selection_id_original": identity.get("solidworks_selection_id_original") or entity.get("solidworks_selection_id_original"),
            "solidworks_selection_persistent_ref_hash": identity.get("solidworks_selection_persistent_ref_hash") or entity.get("solidworks_selection_persistent_ref_hash"),
            "raw_selection_id": identity.get("raw_selection_id") or entity.get("raw_selection_id"),
            "raw_selection_id_source": entity.get("raw_selection_id_source"),
            "canonicalization": identity.get("canonicalization") or entity.get("canonicalization"),
            "selection_surface_kind": identity.get("selection_surface_kind"),
            "is_geometric_selection_surface": identity.get("is_geometric_selection_surface"),
            "is_brep_topology": identity.get("is_brep_topology"),
            "brep_mapping_status": identity.get("brep_mapping_status"),
            "component_reference_node_id": entity.get("component_reference_node_id"),
            "component_reference_name_raw": entity.get("component_reference_name_raw") or selected_ref.get("reference_name_raw"),
            "component_internal_selection_name_raw": (entity.get("component_internal_selection") or {}).get("selection_name_raw"),
            "component_internal_selection_display": (entity.get("component_internal_selection") or {}).get("selection_display_name"),
            "component_internal_selection_name_source": (entity.get("component_internal_selection") or {}).get("component_internal_selection_name_source"),
            "solidworks_owner_feature_name": (entity.get("component_internal_selection") or {}).get("solidworks_owner_feature_name"),
            "solidworks_owner_feature_source": (entity.get("component_internal_selection") or {}).get("solidworks_owner_feature_source"),
            "persistent_ref_hash": identity.get("persistent_ref_hash"),
            "local_geometry": identity.get("local_geometry"),
            "assembly_geometry": identity.get("assembly_geometry"),
            "coordinate_mapping": identity.get("coordinate_mapping"),
            "solidworks_selection_display": entity.get("solidworks_selection_display"),
            "assembly_reference_id": entity.get("assembly_reference_id"),
            "surface_type": entity.get("surface_type"),
            "match_status": entity.get("match_status"),
        }
        for key in (
            "plane_origin_assembly",
            "plane_normal_assembly",
            "axis_point_assembly",
            "axis_dir_assembly",
            "center_assembly",
            "point_assembly",
            "radius_mm",
        ):
            if entity.get(key) is not None:
                row[key] = entity.get(key)
        rows.append({k: v for k, v in row.items() if v is not None})
    return rows


def extract_mate_edges(
    model: Any,
    id_by_signature: dict[str, str],
    id_by_name: dict[str, str],
    reference_ids: dict[str, str] | None = None,
    topology_by_component: dict[str, dict[str, dict[str, Any]]] | None = None,
    component_only: bool = False,
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    edges: list[dict[str, Any]] = []
    unresolved: list[dict[str, Any]] = []
    seen: set[tuple[str, str, str]] = set()
    for feat, history_path, mate_source_api in iter_mate_features(model, component_only=component_only):
        type_name = mate_type_name(feat)
        specific = call(feat, "GetSpecificFeature2") or call(feat, "GetDefinition")
        entities = mate_entities(specific) if specific is not None else []
        component_ids: list[str] = []
        selection_entities: list[dict[str, Any]] = []
        for entity in entities:
            comp = mate_entity_component(entity)
            comp_id = component_id_for(comp, id_by_signature, id_by_name)
            if comp_id and comp_id not in component_ids:
                component_ids.append(comp_id)
            if not component_only:
                selection_entities.append(mate_entity_descriptor(entity, comp_id, model, comp, topology_by_component, mate_type=type_name))
        if len(component_ids) == 1 and reference_ids and not component_only:
            ref_id = nearest_assembly_reference(selection_entities, reference_ids)
            if ref_id:
                key = (component_ids[0], ref_id, str(call(feat, "Name") or type_name))
                if key not in seen:
                    seen.add(key)
                    edges.append(mate_payload(feat, f"m{len(edges) + 1:05d}", component_ids[0], ref_id, component_ids, selection_entities, history_path, mate_source_api))
                continue
        if len(component_ids) < 2:
            unresolved.append({
                "mate_name_raw": str(call(feat, "Name") or ""),
                "solidworks_type": type_name,
                "resolved_component_ids": component_ids,
                "entity_count": len(entities),
                "selection_entities": selection_entities,
                "specific_available": specific is not None,
                "component_only": component_only,
            })
            continue
        for i, source in enumerate(component_ids):
            for target in component_ids[i + 1:]:
                key = (source, target, str(call(feat, "Name") or type_name))
                if key in seen:
                    continue
                seen.add(key)
                if component_only:
                    edges.append(component_only_mate_payload(feat, f"m{len(edges) + 1:05d}", source, target, component_ids, history_path, mate_source_api))
                else:
                    edges.append(mate_payload(feat, f"m{len(edges) + 1:05d}", source, target, component_ids, selection_entities, history_path, mate_source_api))
    return edges, unresolved


def dependency_edges_from_mates(mate_edges: list[dict[str, Any]]) -> list[dict[str, Any]]:
    grouped: dict[tuple[str, str], dict[str, Any]] = {}
    for edge in mate_edges:
        source = str(edge.get("component_level_source") or edge.get("source") or "")
        target = str(edge.get("component_level_target") or edge.get("target") or "")
        if not source or not target:
            continue
        key = (source, target)
        row = grouped.setdefault(
            key,
            {
                "id": f"d{len(grouped) + 1:05d}",
                "source": source,
                "target": target,
                "relation": "dependency",
                "relation_detail": "assembly:parent_of",
                "assembly_relation": "assembly:parent_of",
                "dependency_source": "mate",
                "mate_edge_ids": [],
                "mate_types": [],
                "component_ids": sorted(set(edge.get("component_ids") or [])),
            },
        )
        if edge.get("id") not in row["mate_edge_ids"]:
            row["mate_edge_ids"].append(edge.get("id"))
        if edge.get("solidworks_type") and edge.get("solidworks_type") not in row["mate_types"]:
            row["mate_types"].append(edge.get("solidworks_type"))
        for comp_id in edge.get("component_ids") or []:
            if comp_id not in row["component_ids"]:
                row["component_ids"].append(comp_id)
    return list(grouped.values())


def component_reference_node_id(component_id: str, reference_name: str) -> str:
    return f"{component_id}_ref_{reference_name.replace('_plane', '')}"


def promote_component_reference_nodes(nodes: list[dict[str, Any]], mate_edges: list[dict[str, Any]]) -> list[dict[str, Any]]:
    node_ids = {str(node.get("id")) for node in nodes}
    created: dict[tuple[str, str], dict[str, Any]] = {}
    for edge in mate_edges:
        reference_node_ids: list[str] = []
        for entity in (edge.get("selection") or {}).get("entities") or []:
            selected = entity.get("selected_reference") or {}
            if selected.get("reference_kind") != "component_reference_plane":
                continue
            comp_id = str(selected.get("owner_component_id") or entity.get("component_id") or "")
            ref_name = str(selected.get("reference_name") or "")
            if not comp_id or not ref_name:
                continue
            node_id = component_reference_node_id(comp_id, ref_name)
            entity["component_reference_node_id"] = node_id
            selected["component_reference_node_id"] = node_id
            identity = entity.setdefault("selection_identity", {})
            identity.update({
                "selection_object_type": "component_reference_plane",
                "selection_id": node_id,
                "selection_id_source": "component_reference_node_id",
                "display_id": node_id,
                "display_id_source": "component_reference_node_id",
                "component_id": comp_id,
                "reference_kind": "component_reference_plane",
                "reference_name": ref_name,
                "reference_name_raw": selected.get("reference_name_raw"),
            })
            reference_node_ids.append(node_id)
            key = (comp_id, ref_name)
            if key in created or node_id in node_ids:
                continue
            node = {
                "id": node_id,
                "node_type": "component_reference",
                "command": "component_reference_plane",
                "reference_kind": "component_reference_plane",
                "reference_name": ref_name,
                "reference_name_raw": selected.get("reference_name_raw"),
                "owner_component_id": comp_id,
                "owner_component_name_raw": selected.get("owner_component_name_raw"),
                "owner_component_path": selected.get("owner_component_path"),
                "reference_scope": "component",
                "belongs_to": {"type": "component", "id": comp_id},
                "history_path": selected.get("history_path"),
                "local_plane_origin_mm": selected.get("local_plane_origin_mm"),
                "local_plane_normal": selected.get("local_plane_normal"),
                "assembly_plane_origin_mm": selected.get("assembly_plane_origin_mm"),
                "assembly_plane_normal": selected.get("assembly_plane_normal"),
                "trainable": False,
            }
            created[key] = node
            node_ids.add(node_id)
        if len(reference_node_ids) >= 2:
            edge["source_reference_node_id"] = reference_node_ids[0]
            edge["target_reference_node_id"] = reference_node_ids[1]
            edge["source"] = reference_node_ids[0]
            edge["target"] = reference_node_ids[1]
    nodes.extend(created.values())
    return list(created.values())


def attach_reference_usage(nodes: list[dict[str, Any]], edges: list[dict[str, Any]]) -> None:
    node_by_id = {node["id"]: node for node in nodes}
    for edge in edges:
        ref_id = edge.get("target_assembly_reference_id")
        if not ref_id:
            continue
        ref_node = node_by_id.get(ref_id)
        if not ref_node:
            continue
        comp_ids = list(edge.get("component_ids") or [])
        for comp_id in comp_ids:
            if comp_id not in ref_node["related_component_ids"]:
                ref_node["related_component_ids"].append(comp_id)
        if edge["id"] not in ref_node["mate_edge_ids"]:
            ref_node["mate_edge_ids"].append(edge["id"])



def attach_component_mates(nodes: list[dict[str, Any]], mate_edges: list[dict[str, Any]]) -> None:
    node_by_id = {str(node.get("id")): node for node in nodes if node.get("node_type") == "component"}

    def sw_tree_component_name(node: dict[str, Any] | None) -> str:
        raw = str((node or {}).get("component_name_raw") or (node or {}).get("id") or "")
        match = re.match(r"^(.*)-(\d+)$", raw)
        return f"{match.group(1)}<{match.group(2)}>" if match else raw

    for node in node_by_id.values():
        node["component_mates"] = []
    for edge in mate_edges:
        connected_ids = [str(v) for v in (edge.get("component_ids") or [])]
        connected_names = [str((node_by_id.get(cid) or {}).get("component_name_raw") or cid) for cid in connected_ids]
        connected_tree_names = [sw_tree_component_name(node_by_id.get(cid)) for cid in connected_ids]
        sw_display = f"{edge.get('mate_name_raw') or edge.get('id')} ({','.join(connected_tree_names)})" if connected_tree_names else str(edge.get("mate_name_raw") or edge.get("id"))
        edge["connected_component_names_raw"] = connected_names
        edge["solidworks_tree_display"] = sw_display
        edge["selection_summary"] = summarize_mate_selection_entities((edge.get("selection") or {}).get("entities") or [])
        for row in edge.get("selection_summary") or []:
            comp_node = node_by_id.get(str(row.get("component_id")))
            if comp_node and not row.get("component_name_raw"):
                row["component_name_raw"] = comp_node.get("component_name_raw")
        mate_row = {
            "mate_id": edge.get("id"),
            "mate_name_raw": edge.get("mate_name_raw"),
            "solidworks_mate_name_raw": edge.get("mate_name_raw"),
            "solidworks_tree_display": sw_display,
            "mate_name": edge.get("mate_name"),
            "solidworks_type": edge.get("solidworks_type"),
            "mate_category": edge.get("mate_category"),
            "feature_history_path": edge.get("feature_history_path"),
            "feature_history_path_text": edge.get("feature_history_path_text"),
            "connected_component_ids": connected_ids,
            "connected_component_names_raw": connected_names,
            "connected_component_tree_names": connected_tree_names,
            "selection_summary": edge.get("selection_summary"),
            "source": edge.get("source"),
            "target": edge.get("target"),
        }
        for comp_id in edge.get("component_ids") or []:
            node = node_by_id.get(str(comp_id))
            if node is None:
                continue
            if not any(row.get("mate_id") == mate_row.get("mate_id") for row in node["component_mates"]):
                node["component_mates"].append(mate_row)
    for node in node_by_id.values():
        node["component_mate_count"] = len(node.get("component_mates") or [])

def attach_component_mate_selection_references(nodes: list[dict[str, Any]], mate_edges: list[dict[str, Any]]) -> None:
    node_by_id = {node["id"]: node for node in nodes}
    seen: set[tuple[str, str, str]] = set()
    for edge in mate_edges:
        for entity in (edge.get("selection") or {}).get("entities") or []:
            comp_id = entity.get("component_id")
            if not comp_id or comp_id not in node_by_id:
                continue
            topo_id = entity.get("local_topology_id") or entity.get("selection_topology_id") or entity.get("face_id") or entity.get("edge_id") or entity.get("vertex_id")
            if not topo_id:
                continue
            key = (comp_id, str(topo_id), str(edge.get("id")))
            if key in seen:
                continue
            seen.add(key)
            node = node_by_id[comp_id]
            refs = node.setdefault("brep_mate_selection_references", [])
            refs.append({
                "mate_edge_id": edge.get("id"),
                "mate_name_raw": edge.get("mate_name_raw"),
                "solidworks_type": edge.get("solidworks_type"),
                "entity_kind": entity.get("entity_type") or entity.get("entity_kind"),
                "local_topology_id": entity.get("local_topology_id"),
                "selection_topology_id": entity.get("selection_topology_id"),
                "face_id": entity.get("face_id"),
                "edge_id": entity.get("edge_id"),
                "vertex_id": entity.get("vertex_id"),
                "persistent_ref": entity.get("persistent_ref"),
                "selected_reference": entity.get("selected_reference"),
                "reference_kind": entity.get("reference_kind"),
                "component_reference_name": entity.get("component_reference_name"),
                "component_reference_name_raw": entity.get("component_reference_name_raw"),
                "surface_type": entity.get("surface_type"),
                "axis_point_assembly": entity.get("axis_point_assembly"),
                "axis_dir_assembly": entity.get("axis_dir_assembly"),
                "plane_origin_assembly": entity.get("plane_origin_assembly"),
                "plane_normal_assembly": entity.get("plane_normal_assembly"),
                "radius_mm": entity.get("radius_mm"),
            })
    for node in nodes:
        refs = node.get("brep_mate_selection_references") or []
        if refs:
            node["brep_mate_selection_summary"] = {
                "reference_count": len(refs),
                "entity_type_counts": dict(Counter(ref.get("entity_kind") for ref in refs)),
                "persistent_reference_count": sum(1 for ref in refs if (ref.get("persistent_ref") or {}).get("available")),
            }


def topology_quality_summary(nodes: list[dict[str, Any]], mate_edges: list[dict[str, Any]], assembly_ref_mode: str = "off") -> dict[str, Any]:
    topology_refs = [ref for node in nodes for ref in (node.get("brep_topology_references") or [])]
    surface_parse_failed = 0
    surface_type_counts = Counter()
    persistent_missing = 0
    topology_entity_counts = Counter()
    for ref in topology_refs:
        topology_entity_counts[ref.get("entity_kind", "unknown")] += 1
        if not ((ref.get("persistent_ref") or {}).get("available")):
            persistent_missing += 1
        desc = ref.get("descriptor") or {}
        surface_type = desc.get("surface_type")
        if surface_type:
            surface_type_counts[surface_type] += 1
        if desc.get("parse_status") and desc.get("parse_status") != "ok":
            surface_parse_failed += 1

    selection_entities = []
    for edge in mate_edges:
        for entity in (edge.get("selection") or {}).get("entities", []):
            item = dict(entity)
            item["mate_edge_id"] = edge.get("id")
            selection_entities.append(item)
    reference_counter = Counter()
    brep_selection_entities: list[dict[str, Any]] = []
    for entity in selection_entities:
        is_component_reference = entity.get("reference_kind") == "component_reference_plane" or entity.get("entity_kind") == "component_reference_plane"
        is_assembly_reference = bool(entity.get("assembly_reference_id")) or entity.get("entity_kind") == "assembly_reference_plane" or entity.get("entity_type") == "assembly_reference"
        if is_component_reference:
            reference_counter["component_reference_selection_count"] += 1
            if entity.get("component_reference_node_id") or entity.get("selected_reference"):
                reference_counter["component_reference_node_match"] += 1
            continue
        if is_assembly_reference:
            reference_counter["assembly_reference_selection_count"] += 1
            if entity.get("assembly_reference_id"):
                reference_counter["assembly_reference_node_match"] += 1
            continue
        if entity.get("entity_type") in {"face", "edge", "vertex"}:
            brep_selection_entities.append(entity)

    reference_total = reference_counter["component_reference_selection_count"] + reference_counter["assembly_reference_selection_count"]
    reference_matched = reference_counter["component_reference_node_match"] + reference_counter["assembly_reference_node_match"]
    reference_matching_summary = {
        "component_reference_selection_count": reference_counter["component_reference_selection_count"],
        "component_reference_node_match": reference_counter["component_reference_node_match"],
        "assembly_reference_selection_count": reference_counter["assembly_reference_selection_count"],
        "assembly_reference_node_match": reference_counter["assembly_reference_node_match"],
        "reference_selection_count": reference_total,
        "reference_node_match": reference_matched,
        "reference_match_rate": round(reference_matched / reference_total, 6) if reference_total else None,
    }

    match_counter = Counter()
    collision_groups: dict[tuple[str, str], list[dict[str, Any]]] = {}
    for entity in brep_selection_entities:
        status = entity.get("match_status") or {}
        method = status.get("match_method", "unmatched")
        match_counter[method] += 1
        pref_hex = (((entity.get("mate_selection_context") or {}).get("persistent_ref") or {}).get("hex")) or ((entity.get("persistent_ref") or {}).get("hex"))
        comp_id = entity.get("component_id")
        if pref_hex and comp_id:
            collision_groups.setdefault((str(comp_id), str(pref_hex)), []).append(entity)

    suspicious_collisions = []
    for (comp_id, pref_hex), entities in collision_groups.items():
        signatures = {
            json.dumps({
                "entity_type": e.get("entity_type"),
                "surface_type": e.get("surface_type"),
                "axis_point_assembly": e.get("axis_point_assembly"),
                "axis_dir_assembly": e.get("axis_dir_assembly"),
                "radius_mm": e.get("radius_mm"),
                "plane_origin_assembly": e.get("plane_origin_assembly"),
                "plane_normal_assembly": e.get("plane_normal_assembly"),
            }, sort_keys=True)
            for e in entities
        }
        if len(signatures) > 1:
            suspicious_collisions.append({
                "component_id": comp_id,
                "persistent_ref_hex": pref_hex,
                "entity_count": len(entities),
                "distinct_geometry_signature_count": len(signatures),
                "mate_edge_ids": sorted({str(e.get("mate_edge_id") or "") for e in entities if e.get("mate_edge_id")}),
            })

    total_selections = len(selection_entities)
    brep_selection_count = len(brep_selection_entities)
    final_matches = sum(1 for e in brep_selection_entities if ((e.get("match_status") or {}).get("final_match")))
    if not topology_refs:
        matching_summary = {
            "status": "not_evaluated",
            "reason": "no_brep_topology_exported",
            "mate_selection_count": total_selections,
            "brep_selection_count": brep_selection_count,
            "assembly_ref_exact_match": None,
            "part_ref_exact_match": None,
            "geometry_fallback_match": None,
            "unmatched": None,
            "final_match": None,
            "assembly_ref_match_rate": None,
            "final_match_rate": None,
        }
    elif assembly_ref_mode == "off":
        matching_summary = {
            "status": "not_evaluated",
            "reason": "assembly_ref_mode_off",
            "mate_selection_count": total_selections,
            "brep_selection_count": brep_selection_count,
            "assembly_ref_exact_match": None,
            "part_ref_exact_match": None,
            "geometry_fallback_match": None,
            "unmatched": None,
            "final_match": None,
            "assembly_ref_match_rate": None,
            "final_match_rate": None,
        }
    elif brep_selection_count == 0:
        matching_summary = {
            "status": "not_applicable_for_reference_plane_only_sample",
            "reason": "no_brep_face_edge_vertex_mate_selections",
            "mate_selection_count": total_selections,
            "brep_selection_count": 0,
            "assembly_ref_exact_match": 0,
            "part_ref_exact_match": 0,
            "geometry_fallback_match": 0,
            "unmatched": 0,
            "final_match": 0,
            "assembly_ref_match_rate": None,
            "final_match_rate": None,
        }
    else:
        matching_summary = {
            "status": "evaluated",
            "mate_selection_count": total_selections,
            "brep_selection_count": brep_selection_count,
            "assembly_ref_exact_match": match_counter.get("assembly_persistent_ref", 0),
            "part_ref_exact_match": match_counter.get("part_persistent_ref", 0),
            "geometry_fallback_match": match_counter.get("geometry_signature", 0),
            "unmatched": match_counter.get("unmatched", 0),
            "final_match": final_matches,
            "assembly_ref_match_rate": round(match_counter.get("assembly_persistent_ref", 0) / brep_selection_count, 6) if brep_selection_count else 0.0,
            "final_match_rate": round(final_matches / brep_selection_count, 6) if brep_selection_count else 0.0,
        }
    return {
        "topology_entity_counts": dict(topology_entity_counts),
        "topology_entity_total": len(topology_refs),
        "surface_type_counts": dict(surface_type_counts),
        "surface_parse_failed_count": surface_parse_failed,
        "persistent_reference_missing_count": persistent_missing,
        "reference_matching_summary": reference_matching_summary,
        "topology_matching_summary": matching_summary,
        "suspicious_persistent_ref_collision_count": len(suspicious_collisions),
        "suspicious_persistent_ref_collisions": suspicious_collisions[:50],
    }


STANDARD_PART_HINTS = (
    "screw", "bolt", "nut", "washer", "bearing", "pin", "dowel", "rivet", "spring",
    "gear", "servo", "motor", "stepper", "encoder", "coupling", "shaft", "键", "螺钉",
    "螺栓", "螺母", "垫圈", "轴承", "销", "弹簧", "电机", "舵机", "标准件",
)


def component_source_key(comp: Any) -> str:
    path = component_path(comp).lower()
    cfg = str(call(comp, "ReferencedConfiguration") or get_attr(comp, "ReferencedConfiguration") or "").lower()
    if path:
        return f"{path}|{cfg}"
    return f"{component_name(comp).lower()}|{cfg}"


def is_standard_or_purchased_component(node: dict[str, Any], comp: Any) -> bool:
    text = " ".join(
        str(value).lower()
        for value in (
            node.get("component_name"),
            node.get("component_name_raw"),
            node.get("component_path"),
            component_name(comp),
            component_path(comp),
        )
        if value
    )
    return any(hint.lower() in text for hint in STANDARD_PART_HINTS)


def effective_component_topology_request(
    topology_mode: str,
    max_topology_entities: int,
    is_standard_part: bool,
    standard_part_topology_limit: int,
) -> tuple[str, int, str | None]:
    """Decide how much topology to export for one component.

    Important convention for validation runs:
    - standard_part_topology_limit <= 0 means DO NOT downgrade standard/purchased parts.
      This is the true-full B-Rep mode used to verify whether grey external
      surfaces are missing because of exporter limits.
    - standard_part_topology_limit > 0 keeps the old bounded behaviour for
      large-scale batch exports.
    """
    if topology_mode == "mate_only":
        return "mate_only", 0, None
    if not is_standard_part:
        limit = max_topology_entities if topology_mode == "bounded" else 0
        return topology_mode, limit, None
    if standard_part_topology_limit <= 0:
        limit = max_topology_entities if topology_mode == "bounded" else 0
        return topology_mode, limit, None
    limit = standard_part_topology_limit
    if topology_mode == "bounded" and max_topology_entities > 0:
        limit = min(max_topology_entities, limit)
    return "bounded", limit, "standard_or_purchased_part_downgraded"


def build_assembly_graph(model: Any, topology_mode: str = "full", max_topology_entities: int = 0, assembly_ref_mode: str = "off", standard_part_topology_limit: int = 300, reuse_duplicate_topology: bool = True) -> dict[str, Any]:
    sw_export_phase("build_graph.active_root_component")
    root = active_root_component(model)
    if root is not None:
        sw_export_phase("build_graph.walk_components")
        nodes, id_by_signature, id_by_name, comp_by_id = walk_components(root)
        component_source_api = "Configuration.GetRootComponent3.FeatureManagerTreeOrder"
    else:
        sw_export_phase("build_graph.collect_components_fallback")
        nodes, id_by_signature, id_by_name, comp_by_id = collect_components_from_model(model)
        component_source_api = "AssemblyDoc.GetComponents.fallback_api_order"
    sw_export_phase(f"build_graph.components_done {len(comp_by_id)}")
    reference_nodes, reference_ids = assembly_reference_nodes()
    nodes.extend(reference_nodes)
    sw_export_phase("build_graph.extract_mates_pre_topology")
    mate_edges_pre_topology, unresolved_mates_pre_topology = extract_mate_edges(
        model,
        id_by_signature,
        id_by_name,
        reference_ids,
        None,
        component_only=(topology_mode == "mate_only"),
    )
    sw_export_phase(f"build_graph.extract_mates_pre_topology_done {len(mate_edges_pre_topology)}")
    topology_by_component: dict[str, dict[str, dict[str, Any]]] = {}
    node_by_id = {node["id"]: node for node in nodes}
    topology_cache_by_source: dict[str, tuple[str, list[dict[str, Any]], dict[str, dict[str, Any]]]] = {}
    standard_downgrade_count = 0
    duplicate_reuse_count = 0
    if topology_mode != "mate_only":
        for comp_id, comp in comp_by_id.items():
            node = node_by_id.get(comp_id)
            is_standard_part = is_standard_or_purchased_component(node or {}, comp)
            effective_mode, limit, downgrade_reason = effective_component_topology_request(
                topology_mode,
                max_topology_entities,
                is_standard_part,
                standard_part_topology_limit,
            )
            source_key = component_source_key(comp)
            if reuse_duplicate_topology and source_key in topology_cache_by_source:
                source_component_id, source_topology_refs, topology_map = topology_cache_by_source[source_key]
                topology_refs = copy.deepcopy(source_topology_refs)
                for ref in topology_refs:
                    ref["component_id"] = comp_id
                    ref["component_name_raw"] = node.get("component_name_raw") if node is not None else ref.get("component_name_raw")
                topology_by_component[comp_id] = topology_map
                duplicate_reuse_count += 1
                if node is not None:
                    node["brep_topology_references"] = topology_refs
                    node["brep_topology_reuse"] = {
                        "enabled": True,
                        "source_component_id": source_component_id,
                        "source_key": source_key,
                        "reason": "duplicate_part_instance",
                        "instance_transform_preserved": True,
                    }
                    node["brep_topology_summary"] = {
                        "entity_count": len(topology_refs),
                        "entity_type_counts": dict(Counter(ref.get("entity_kind") for ref in topology_refs)),
                        "persistent_reference_count": sum(1 for ref in topology_refs if (ref.get("persistent_ref") or {}).get("available")),
                        "topology_mode": effective_mode,
                        "reused_from_component_id": source_component_id,
                        "standard_or_purchased_part": is_standard_part,
                        "downgrade_reason": downgrade_reason,
                    }
                continue
            topology_refs, topology_map = collect_component_topology(model, comp_id, comp, max_entities=limit, assembly_ref_mode=assembly_ref_mode)
            topology_by_component[comp_id] = topology_map
            topology_cache_by_source[source_key] = (comp_id, copy.deepcopy(topology_refs), topology_map)
            if downgrade_reason:
                standard_downgrade_count += 1
            if node is not None:
                node["standard_or_purchased_part"] = is_standard_part
                node["brep_topology_references"] = topology_refs
                node["brep_topology_summary"] = {
                    "entity_count": len(topology_refs),
                    "entity_type_counts": dict(Counter(ref.get("entity_kind") for ref in topology_refs)),
                    "persistent_reference_count": sum(1 for ref in topology_refs if (ref.get("persistent_ref") or {}).get("available")),
                    "topology_mode": effective_mode,
                    "requested_topology_mode": topology_mode,
                    "max_topology_entities": limit,
                    "standard_or_purchased_part": is_standard_part,
                    "downgrade_reason": downgrade_reason,
                    "truncated": effective_mode == "bounded" and limit > 0 and len(topology_refs) >= limit,
                }
    if topology_mode == "mate_only":
        mate_edges = mate_edges_pre_topology
        unresolved_mates = unresolved_mates_pre_topology
        mate_edges_source = "mate_only_single_pass"
    else:
        sw_export_phase("build_graph.extract_mates_post_topology")
        mate_edges, unresolved_mates = extract_mate_edges(model, id_by_signature, id_by_name, reference_ids, topology_by_component)
        mate_edges_source = "post_topology_enriched"
        if not mate_edges and mate_edges_pre_topology:
            mate_edges = mate_edges_pre_topology
            unresolved_mates = unresolved_mates_pre_topology
            mate_edges_source = "pre_topology_fallback"
        sw_export_phase(f"build_graph.extract_mates_post_topology_done {len(mate_edges)}")
    sw_export_phase("build_graph.attach_mate_metadata")
    component_reference_nodes = promote_component_reference_nodes(nodes, mate_edges)
    dependency_edges = dependency_edges_from_mates(mate_edges)
    edges = dependency_edges + mate_edges
    attach_reference_usage(nodes, edges)
    attach_component_mates(nodes, mate_edges)
    attach_component_mate_selection_references(nodes, mate_edges)
    sw_export_phase("build_graph.quality_summary")
    quality = topology_quality_summary(nodes, mate_edges, assembly_ref_mode=assembly_ref_mode)
    sw_export_phase("build_graph.done")
    return {
        "schema": "sw_assembly_component_mate_graph.v2",
        "nodes": nodes,
        "edges": edges,
        "summary": {
            "node_count": len(nodes),
            "edge_count": len(edges),
            "node_type_counts": dict(Counter(n["node_type"] for n in nodes)),
            "edge_type_counts": dict(Counter(e["relation"] for e in edges)),
            "mate_edge_count": len(mate_edges),
            "dependency_edge_count": len(dependency_edges),
            "mate_type_counts": dict(Counter(e["solidworks_type"] for e in mate_edges)),
            "mate_category_counts": dict(Counter(e.get("mate_category", "unknown") for e in mate_edges)),
            "unresolved_mate_count": len(unresolved_mates),
            "mate_edges_source": mate_edges_source,
            "pre_topology_mate_edge_count": len(mate_edges_pre_topology),
            "component_source_api": component_source_api,
            "topology_mode": topology_mode,
            "max_topology_entities": max_topology_entities,
            "assembly_ref_mode": assembly_ref_mode,
            "standard_part_topology_limit": standard_part_topology_limit,
            "reuse_duplicate_topology": reuse_duplicate_topology,
            "standard_part_downgrade_count": standard_downgrade_count,
            "duplicate_topology_reuse_count": duplicate_reuse_count,
            "component_reference_node_count": len(component_reference_nodes),
            **quality,
        },
        "unresolved_mates": unresolved_mates,
    }


def _same_model_path(model: Any, path: Path) -> bool:
    try:
        model_path = str(call(model, "GetPathName") or get_attr(model, "GetPathName") or "")
        return Path(model_path).resolve().as_posix().lower() == Path(path).resolve().as_posix().lower()
    except Exception:
        return False


def _find_open_model(sw: Any, path: Path) -> Any:
    for getter in ("ActiveDoc", "IActiveDoc2"):
        try:
            model = getattr(sw, getter)
            model = model() if callable(model) else model
            if model is not None and _same_model_path(model, path):
                return model
        except Exception:
            pass
    for name in (path.name, path.stem):
        try:
            model = sw.GetOpenDocumentByName(str(name))
            if model is not None and _same_model_path(model, path):
                return model
        except Exception:
            pass
    return None


def configure_solidworks_reference_search(sw: Any, path: Path) -> dict[str, Any]:
    """Best-effort setup so OpenDoc6 resolves same-folder references unattended."""
    folder = str(path.parent)
    report: dict[str, Any] = {"folder": folder, "attempts": []}
    try:
        os.chdir(folder)
        report["chdir"] = True
    except Exception as exc:
        report["chdir"] = False
        report["chdir_error"] = repr(exc)
    for method, args in (
        ("SetCurrentWorkingDirectory", (folder,)),
        ("SetSearchFolders", (folder,)),
        ("SetSearchFolders2", (folder,)),
    ):
        row = {"method": method}
        try:
            value = getattr(sw, method)(*args)
            row["ok"] = True
            row["return"] = str(value)
        except Exception as exc:
            row["ok"] = False
            row["error"] = repr(exc)
        report["attempts"].append(row)
    return report


def open_assembly(sw: Any, path: Path) -> Any:
    errors = win32com.client.VARIANT(pythoncom.VT_BYREF | pythoncom.VT_I4, 0)
    warnings = win32com.client.VARIANT(pythoncom.VT_BYREF | pythoncom.VT_I4, 0)
    open_options = SW_OPEN_SILENT | SW_OPEN_READONLY
    model = sw.OpenDoc6(str(path), SW_DOC_ASSEMBLY, open_options, "", errors, warnings)
    if model is None:
        model = _find_open_model(sw, path)
    if model is None:
        raise RuntimeError(f"OpenDoc6 failed: {path} errors={errors.value} warnings={warnings.value}")
    try:
        call(model, "SetSaveFlag")
    except Exception:
        pass
    for method, args in (
        ("ResolveAllLightWeightComponents", (True,)),
        ("EditRebuild3", ()),
        ("ForceRebuild3", (False,)),
    ):
        try:
            getattr(model, method)(*args)
        except Exception:
            pass
    try:
        sw.ActivateDoc3(str(path.name), False, 0, win32com.client.VARIANT(pythoncom.VT_BYREF | pythoncom.VT_I4, 0))
    except Exception:
        pass
    return model


def save_close_quit_solidworks(sw: Any, model: Any | None) -> None:
    if model is not None:
        try:
            call(model, "SetSaveFlag")
        except Exception:
            pass
        try:
            sw.CloseDoc(model.GetTitle())
        except Exception:
            pass
    try:
        sw.CloseAllDocuments(True)
    except Exception:
        pass
    try:
        sw.ExitApp()
    except Exception:
        pass


def document_type_for_path(path: str) -> int:
    suffix = Path(path).suffix.lower()
    if suffix == ".sldasm":
        return SW_DOC_ASSEMBLY
    return SW_DOC_PART


def save_model_thumbnail(sw: Any, model_doc: Any, image_path: Path) -> bool:
    image_path.parent.mkdir(parents=True, exist_ok=True)
    try:
        call(model_doc, "ShowNamedView2", "*Isometric", 7)
    except Exception:
        pass
    for method in ("ViewZoomtofit2", "ViewZoomToFit2", "GraphicsRedraw2"):
        try:
            call(model_doc, method)
        except Exception:
            pass
    time.sleep(0.15)
    for attempt in (
        lambda: call(model_doc, "SaveAs3", str(image_path), 0, SW_SAVE_SILENT),
        lambda: call(model_doc, "SaveAs2", str(image_path), 0, SW_SAVE_SILENT, False, False),
        lambda: call(model_doc, "SaveAs", str(image_path)),
    ):
        try:
            result = attempt()
            if image_path.exists() and image_path.stat().st_size > 0:
                return True
            if result and image_path.exists() and image_path.stat().st_size > 0:
                return True
        except Exception:
            pass
    ext = call(model_doc, "Extension") or get_attr(model_doc, "Extension")
    if ext is not None:
        try:
            errors = win32com.client.VARIANT(pythoncom.VT_BYREF | pythoncom.VT_I4, 0)
            warnings = win32com.client.VARIANT(pythoncom.VT_BYREF | pythoncom.VT_I4, 0)
            call(ext, "SaveAs", str(image_path), 0, SW_SAVE_SILENT, None, errors, warnings)
            return image_path.exists() and image_path.stat().st_size > 0
        except Exception:
            pass
    return False


def save_model_mesh_stl(model_doc: Any, stl_path: Path, preferred_token: str = "") -> Path | None:
    stl_path.parent.mkdir(parents=True, exist_ok=True)
    for old_path in stl_path.parent.glob(f"{stl_path.stem}*.stl"):
        try:
            old_path.unlink()
        except Exception:
            pass
    for old_path in stl_path.parent.glob(f"{stl_path.stem}*.STL"):
        try:
            old_path.unlink()
        except Exception:
            pass

    def actual_stl_path() -> Path | None:
        exact_path = stl_path if stl_path.exists() and stl_path.stat().st_size > 0 else None
        candidates = [p for p in stl_path.parent.glob(f"{stl_path.stem}*.stl") if p.stat().st_size > 0]
        candidates += [p for p in stl_path.parent.glob(f"{stl_path.stem}*.STL") if p.stat().st_size > 0]
        token = preferred_token.lower().replace("<", "").replace(">", "")
        if token:
            token_matches = [p for p in candidates if token in p.stem.lower().replace("<", "").replace(">", "")]
            if token_matches:
                return sorted(token_matches, key=lambda p: (len(p.name), p.name.lower()))[0]
            return exact_path
        if exact_path is not None:
            return exact_path
        if not candidates:
            return None
        return sorted(candidates, key=lambda p: (-p.stat().st_size, p.name.lower()))[0]

    for attempt in (
        lambda: call(model_doc, "SaveAs3", str(stl_path), 0, SW_SAVE_SILENT),
        lambda: call(model_doc, "SaveAs2", str(stl_path), 0, SW_SAVE_SILENT, False, False),
        lambda: call(model_doc, "SaveAs", str(stl_path)),
    ):
        try:
            result = attempt()
            actual = actual_stl_path()
            if actual is not None:
                return actual
            if result:
                actual = actual_stl_path()
                if actual is not None:
                    return actual
        except Exception:
            pass
    return None


def convert_mesh_to_obj(mesh_path: Path, obj_path: Path) -> bool:
    try:
        import pyvista as pv
        mesh = pv.read(str(mesh_path))
        if not hasattr(mesh, "n_points") or mesh.n_points == 0:
            return False
        obj_path.parent.mkdir(parents=True, exist_ok=True)
        mesh.save(str(obj_path))
        return obj_path.exists() and obj_path.stat().st_size > 0
    except Exception:
        return False


def assembly_stl_candidates(obj_dir: Path, stem: str = "assembly") -> list[Path]:
    paths: list[Path] = []
    for pat in (f"{stem}*.stl", f"{stem}*.STL"):
        for path in obj_dir.glob(pat):
            try:
                if path.is_file() and path.stat().st_size > 0 and path not in paths:
                    paths.append(path)
            except Exception:
                pass
    return sorted(paths, key=lambda p: p.name.lower())


def convert_meshes_to_obj(mesh_paths: list[Path], obj_path: Path) -> bool:
    try:
        import pyvista as pv
        meshes = []
        for mesh_path in mesh_paths:
            mesh = pv.read(str(mesh_path))
            if hasattr(mesh, "n_points") and mesh.n_points > 0:
                meshes.append(mesh)
        if not meshes:
            return False
        merged = pv.MultiBlock(meshes).combine() if len(meshes) > 1 else meshes[0]
        if hasattr(merged, "extract_surface"):
            merged = merged.extract_surface(algorithm="dataset_surface").triangulate()
        if not hasattr(merged, "n_points") or merged.n_points == 0:
            return False
        obj_path.parent.mkdir(parents=True, exist_ok=True)
        merged.save(str(obj_path))
        return obj_path.exists() and obj_path.stat().st_size > 0
    except Exception:
        return False


def export_direct_assembly_mesh(model_doc: Any, out_dir: Path) -> dict[str, Any]:
    """Export the current SolidWorks assembly as one assembly-level mesh.

    This mesh comes from SolidWorks' active assembly document. It is not rebuilt
    from component OBJ files or component poses.
    """
    obj_dir = out_dir / "obj"
    stl_path = obj_dir / "assembly.stl"
    obj_path = obj_dir / "assembly.mesh.obj"
    report: dict[str, Any] = {
        "status": "missing",
        "assembly_stl": None,
        "assembly_stl_files": [],
        "assembly_stl_count": 0,
        "assembly_mesh_obj": None,
        "assembly_mesh_source": None,
    }
    actual_stl = save_model_mesh_stl(model_doc, stl_path, preferred_token="assembly")
    stl_files = assembly_stl_candidates(obj_dir, stem="assembly")
    if actual_stl is not None and actual_stl.exists() and actual_stl.stat().st_size > 0 and actual_stl not in stl_files:
        stl_files.append(actual_stl)
    stl_files = sorted(stl_files, key=lambda p: p.name.lower())
    if stl_files:
        report["assembly_stl"] = str(stl_files[0])
        report["assembly_stl_files"] = [str(p) for p in stl_files]
        report["assembly_stl_count"] = len(stl_files)
        if convert_meshes_to_obj(stl_files, obj_path):
            report.update({
                "status": "ok",
                "assembly_mesh_obj": str(obj_path),
                "assembly_mesh_source": "direct_sldasm_stl_converted",
            })
            return report
        report["status"] = "stl_exported_obj_convert_failed"
        report["assembly_mesh_source"] = "direct_sldasm_stl_export_only"
        return report
    report["status"] = "solidworks_assembly_stl_export_failed"
    return report


def export_direct_assembly_step(sw: Any, model_doc: Any, out_dir: Path) -> dict[str, Any]:
    """Export the current SolidWorks assembly as one AP203 STEP file."""
    step_path = out_dir / "assembly.step"
    ok = save_model_step(model_doc, step_path, sw=sw)
    return {
        "status": "ok" if ok else "failed",
        "assembly_step": str(step_path) if ok else None,
        "assembly_step_source": "direct_sldasm_ap203_step_export" if ok else None,
        "step_ap": "AP203",
    }


def model_part_box_mm(model_doc: Any) -> list[float] | None:
    try:
        values = call(model_doc, "GetPartBox", True)
        if values and len(values) >= 6:
            return [round(float(v) * 1000.0, 6) for v in list(values)[:6]]
    except Exception:
        pass
    return None


def mesh_bbox_correction_payload(mesh_path: Path | None, model_bbox_mm: list[float] | None) -> dict[str, Any]:
    if not mesh_path or not model_bbox_mm:
        return {"mesh_local_bbox_mm": model_bbox_mm, "mesh_coordinate_correction_mm": None}
    try:
        import pyvista as pv
        mesh = pv.read(str(mesh_path))
        bounds = [float(v) for v in mesh.bounds]
        correction = [
            round(float(model_bbox_mm[0]) - bounds[0], 6),
            round(float(model_bbox_mm[1]) - bounds[2], 6),
            round(float(model_bbox_mm[2]) - bounds[4], 6),
        ]
        if max(abs(v) for v in correction) < 1e-6:
            correction = [0.0, 0.0, 0.0]
        return {
            "mesh_local_bbox_mm": model_bbox_mm,
            "mesh_export_bbox_mm": [
                round(bounds[0], 6), round(bounds[2], 6), round(bounds[4], 6),
                round(bounds[1], 6), round(bounds[3], 6), round(bounds[5], 6),
            ],
            "mesh_coordinate_correction_mm": correction,
            "mesh_coordinate_correction_reason": "align_stl_positive_coordinates_to_solidworks_part_local_bbox",
        }
    except Exception as exc:
        return {
            "mesh_local_bbox_mm": model_bbox_mm,
            "mesh_coordinate_correction_mm": None,
            "mesh_coordinate_correction_error": repr(exc),
        }


def sw_constant(name: str, default: Any = None) -> Any:
    try:
        return getattr(win32com.client.constants, name)
    except Exception:
        return default


def set_step_ap203(sw: Any) -> tuple[Any, Any]:
    pref = sw_constant("swStepAP")
    ap203 = sw_constant("swStepAP203")
    if pref is None or ap203 is None:
        return None, None
    old_value = None
    try:
        old_value = call(sw, "GetUserPreferenceIntegerValue", pref)
    except Exception:
        old_value = None
    try:
        call(sw, "SetUserPreferenceIntegerValue", pref, ap203)
    except Exception:
        pass
    return pref, old_value


def restore_step_ap(sw: Any, pref: Any, old_value: Any) -> None:
    if pref is None or old_value is None:
        return
    try:
        call(sw, "SetUserPreferenceIntegerValue", pref, old_value)
    except Exception:
        pass


def save_model_step(model_doc: Any, step_path: Path, sw: Any | None = None) -> bool:
    step_path.parent.mkdir(parents=True, exist_ok=True)
    pref = old_value = None
    if sw is not None:
        pref, old_value = set_step_ap203(sw)
    try:
        for attempt in (
            lambda: call(model_doc, "SaveAs3", str(step_path), 0, SW_SAVE_SILENT),
            lambda: call(model_doc, "SaveAs2", str(step_path), 0, SW_SAVE_SILENT, False, False),
            lambda: call(model_doc, "SaveAs", str(step_path)),
        ):
            try:
                result = attempt()
                if step_path.exists() and step_path.stat().st_size > 0:
                    return True
                if result and step_path.exists() and step_path.stat().st_size > 0:
                    return True
            except Exception:
                pass
        return False
    finally:
        if sw is not None:
            restore_step_ap(sw, pref, old_value)


def sw_transform_to_pose(transform: dict[str, Any] | None) -> dict[str, Any]:
    values = (transform or {}).get("array_data") or []
    if len(values) < 12:
        return {
            "matrix4x4": None,
            "coordinates_mm": [0.0, 0.0, 0.0],
            "translation_mm": [0.0, 0.0, 0.0],
            "rotation_matrix": None,
            "rotation_deg": [0.0, 0.0, 0.0],
            "source": "SolidWorks.IComponent2.Transform2",
        }
    vals = [float(v) for v in values]
    rotation_matrix = [
        [vals[0], vals[3], vals[6]],
        [vals[1], vals[4], vals[7]],
        [vals[2], vals[5], vals[8]],
    ]
    matrix = [
        [rotation_matrix[0][0], rotation_matrix[0][1], rotation_matrix[0][2], vals[9] * 1000.0],
        [rotation_matrix[1][0], rotation_matrix[1][1], rotation_matrix[1][2], vals[10] * 1000.0],
        [rotation_matrix[2][0], rotation_matrix[2][1], rotation_matrix[2][2], vals[11] * 1000.0],
        [0.0, 0.0, 0.0, 1.0],
    ]
    coordinates_mm = [round(vals[9] * 1000.0, 6), round(vals[10] * 1000.0, 6), round(vals[11] * 1000.0, 6)]
    return {
        "matrix4x4": matrix,
        "coordinates_mm": coordinates_mm,
        "translation_mm": coordinates_mm,
        "rotation_matrix": rotation_matrix,
        "rotation_deg": rotation_matrix_to_euler_xyz_deg(rotation_matrix),
        "source": "SolidWorks.IComponent2.Transform2",
    }


def rotation_matrix_to_euler_xyz_deg(matrix: list[list[float]] | None) -> list[float]:
    if not matrix:
        return [0.0, 0.0, 0.0]
    r00, r01, r02 = matrix[0]
    r10, r11, r12 = matrix[1]
    r20, r21, r22 = matrix[2]
    sy = math.sqrt(r00 * r00 + r10 * r10)
    singular = sy < 1e-9
    if not singular:
        x = math.atan2(r21, r22)
        y = math.atan2(-r20, sy)
        z = math.atan2(r10, r00)
    else:
        x = math.atan2(-r12, r11)
        y = math.atan2(-r20, sy)
        z = 0.0
    return [round(math.degrees(v), 6) for v in (x, y, z)]


def render_assembly_groundtruth_scene(spec: dict[str, Any], out_dir: Path) -> dict[str, Any]:
    try:
        import numpy as np
        import pyvista as pv
    except Exception as exc:
        return {"status": "skipped", "reason": "pyvista_or_numpy_unavailable", "error": repr(exc)}

    render_dir = out_dir / "renders"
    render_dir.mkdir(parents=True, exist_ok=True)
    views = {
        "isometric": "iso",
        "front": "xy",
        "right": "yz",
        "top": "xz",
    }
    outputs: dict[str, str] = {}
    base_dir = out_dir

    try:
        plotter = pv.Plotter(off_screen=True, window_size=(1280, 900))
        plotter.set_background("white")
        plotter.add_axes(line_width=2)
        added = 0
        for index, comp in enumerate(spec.get("components", [])):
            if comp.get("mesh_status") != "ok":
                continue
            mesh_value = comp.get("mesh_path") or comp.get("mesh")
            if not mesh_value:
                continue
            mesh_path = Path(mesh_value)
            if not mesh_path.is_absolute():
                mesh_path = base_dir / mesh_path
            if not mesh_path.exists() and comp.get("mesh"):
                fallback_path = base_dir / str(comp.get("mesh"))
                if fallback_path.exists():
                    mesh_path = fallback_path
            if not mesh_path.exists():
                continue
            mesh = pv.read(str(mesh_path))
            if not isinstance(mesh, pv.PolyData):
                mesh = mesh.extract_surface().triangulate()
            else:
                mesh = mesh.triangulate()
            matrix = (comp.get("transform") or {}).get("matrix4x4")
            mesh_frame = comp.get("mesh_coordinate_frame") or "part_local"
            correction = comp.get("mesh_coordinate_correction_mm")
            if correction and mesh_frame != "assembly_context_export":
                mesh.translate(np.array(correction, dtype=float), inplace=True)
            if matrix and mesh_frame != "assembly_context_export":
                mesh.transform(np.array(matrix, dtype=float), inplace=True)
            plotter.add_mesh(
                mesh,
                color=[
                    "#6baed6", "#fd8d3c", "#74c476", "#9e9ac8", "#fdd049",
                    "#8dd3c7", "#fb8072", "#80b1d3", "#b3de69", "#bc80bd",
                ][index % 10],
                opacity=1.0,
                smooth_shading=True,
                show_edges=False,
            )
            added += 1
        if added == 0:
            return {"status": "failed", "reason": "no_component_meshes_rendered"}
        for view_name, camera_position in views.items():
            out_png = render_dir / f"assembly_gt_{view_name}.png"
            plotter.camera_position = camera_position
            plotter.reset_camera()
            plotter.screenshot(str(out_png))
            outputs[f"{view_name}_png"] = str(out_png)
        plotter.close()
        pose_application = "identity_mesh_already_in_assembly_context" if any(
            (comp.get("mesh_coordinate_frame") == "assembly_context_export") for comp in spec.get("components", [])
        ) else "applied_transform2_matrix4x4"
        return {"status": "ok", "component_rendered_count": added, "pose_application": pose_application, **outputs}
    except Exception as exc:
        try:
            plotter.close()
        except Exception:
            pass
        return {"status": "failed", "error": repr(exc)}


def render_assembly_interactive_html(spec: dict[str, Any], out_dir: Path) -> dict[str, Any]:
    try:
        import numpy as np
        import pyvista as pv
    except Exception as exc:
        return {"status": "skipped", "reason": "pyvista_or_numpy_unavailable", "error": repr(exc)}

    render_dir = out_dir / "renders"
    render_dir.mkdir(parents=True, exist_ok=True)
    base_dir = out_dir
    palette = [
        "#1f77b4", "#ff7f0e", "#2ca02c", "#d62728",
        "#9467bd", "#8c564b", "#e377c2", "#7f7f7f",
        "#bcbd22", "#17becf", "#4e79a7", "#f28e2b",
        "#59a14f", "#e15759", "#b07aa1", "#9c755f",
    ]
    traces: list[dict[str, Any]] = []
    component_infos: list[dict[str, Any]] = []
    all_bounds: list[float] | None = None
    hidden_count = 0
    mesh_error_count = 0

    def update_bounds(points: Any) -> None:
        nonlocal all_bounds
        mins = points.min(axis=0)
        maxs = points.max(axis=0)
        row = [float(mins[0]), float(mins[1]), float(mins[2]), float(maxs[0]), float(maxs[1]), float(maxs[2])]
        if all_bounds is None:
            all_bounds = row
        else:
            all_bounds = [
                min(all_bounds[0], row[0]), min(all_bounds[1], row[1]), min(all_bounds[2], row[2]),
                max(all_bounds[3], row[3]), max(all_bounds[4], row[4]), max(all_bounds[5], row[5]),
            ]

    for index, comp in enumerate(spec.get("components", [])):
        transform = comp.get("transform") or {}
        visible = not bool(comp.get("hidden") or comp.get("suppressed") or comp.get("is_hidden") or comp.get("is_suppressed"))
        info = {
            "component_id": comp.get("component_id") or comp.get("id"),
            "part_id": comp.get("part_id"),
            "component_display_order": comp.get("component_display_order"),
            "component_id_source": comp.get("component_id_source"),
            "component_name": comp.get("component_name"),
            "component_name_raw": comp.get("component_name_raw"),
            "component_path": comp.get("component_path"),
            "visible": visible,
            "hidden": bool(comp.get("hidden") or comp.get("is_hidden")),
            "suppressed": bool(comp.get("suppressed") or comp.get("is_suppressed")),
            "drawn_in_viewer": False,
            "mesh": comp.get("mesh"),
            "mesh_path": comp.get("mesh_path"),
            "mesh_status": comp.get("mesh_status"),
            "mesh_coordinate_frame": comp.get("mesh_coordinate_frame"),
            "mesh_coordinate_correction_mm": comp.get("mesh_coordinate_correction_mm"),
            "mesh_unit": comp.get("mesh_unit"),
            "pose_unit": comp.get("pose_unit"),
            "coordinates_mm": transform.get("coordinates_mm") or transform.get("translation_mm"),
            "rotation_deg": transform.get("rotation_deg"),
            "rotation_matrix": transform.get("rotation_matrix"),
            "matrix4x4": transform.get("matrix4x4"),
            "component_mates": comp.get("component_mates") or comp.get("mate_edges") or [],
        }
        component_infos.append(info)
        if not visible:
            hidden_count += 1
            continue
        if comp.get("mesh_status") != "ok":
            continue
        mesh_value = comp.get("mesh_path") or comp.get("mesh")
        if not mesh_value:
            continue
        mesh_path = Path(mesh_value)
        if not mesh_path.is_absolute():
            mesh_path = base_dir / mesh_path
        if not mesh_path.exists() and comp.get("mesh"):
            fallback_path = base_dir / str(comp.get("mesh"))
            if fallback_path.exists():
                mesh_path = fallback_path
        if not mesh_path.exists():
            mesh_error_count += 1
            info["mesh_read_status"] = "missing_mesh_file"
            continue

        try:
            mesh = pv.read(str(mesh_path))
            if not isinstance(mesh, pv.PolyData):
                mesh = mesh.extract_surface().triangulate()
            else:
                mesh = mesh.triangulate()
            matrix = (comp.get("transform") or {}).get("matrix4x4")
            mesh_frame = comp.get("mesh_coordinate_frame") or "part_local"
            correction = comp.get("mesh_coordinate_correction_mm")
            if correction and mesh_frame != "assembly_context_export":
                mesh.translate(np.array(correction, dtype=float), inplace=True)
            if matrix and mesh_frame != "assembly_context_export":
                mesh.transform(np.array(matrix, dtype=float), inplace=True)
            if mesh.n_points == 0 or mesh.n_cells == 0:
                info["mesh_read_status"] = "empty_mesh"
                mesh_error_count += 1
                continue
            faces = np.asarray(mesh.faces).reshape((-1, 4))
            triangles = faces[faces[:, 0] == 3][:, 1:4]
            if triangles.size == 0:
                info["mesh_read_status"] = "no_triangles"
                mesh_error_count += 1
                continue
        except Exception as exc:
            info["mesh_read_status"] = "interactive_read_failed"
            info["error"] = repr(exc)
            mesh_error_count += 1
            continue

        points = np.asarray(mesh.points)
        update_bounds(points)
        color = palette[index % len(palette)]
        name = f"{info.get('component_id')} | {info.get('component_name_raw')}"
        info["drawn_in_viewer"] = True
        traces.append({
            "type": "mesh3d",
            "x": points[:, 0].round(6).tolist(),
            "y": points[:, 1].round(6).tolist(),
            "z": points[:, 2].round(6).tolist(),
            "i": triangles[:, 0].tolist(),
            "j": triangles[:, 1].tolist(),
            "k": triangles[:, 2].tolist(),
            "name": name,
            "color": color,
            "opacity": 1.0,
            "flatshading": True,
            "meta": info,
            "hovertemplate": (
                "<b>%{fullData.name}</b><br>"
                "visible=%{meta.visible}<br>"
                "x=%{x:.3f} mm<br>"
                "y=%{y:.3f} mm<br>"
                "z=%{z:.3f} mm<extra></extra>"
            ),
        })

    if not traces:
        return {"status": "failed", "reason": "no_visible_component_meshes_for_interactive_html", "component_info_count": len(component_infos)}

    if all_bounds is None:
        center = [0.0, 0.0, 0.0]
        bounds = [0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
    else:
        bounds = [round(v, 6) for v in all_bounds]
        center = [
            round((all_bounds[0] + all_bounds[3]) / 2.0, 6),
            round((all_bounds[1] + all_bounds[4]) / 2.0, 6),
            round((all_bounds[2] + all_bounds[5]) / 2.0, 6),
        ]

    plot_data_json = json.dumps(traces, ensure_ascii=False)
    component_index_json = json.dumps(component_infos, ensure_ascii=False, indent=2)
    view_pose = {
        "rotation_deg": [0.0, 0.0, 0.0],
        "scale": 1.0,
        "rotation_unit": "degree",
        "scale_semantics": "camera_zoom_not_geometry_scale",
        "internal_rotation_center_mm": center,
        "bounds_mm": bounds,
        "api": "window.setAssemblyViewPose({rotation_deg:[rx,ry,rz], scale:s})",
    }
    view_pose_json = json.dumps(view_pose, ensure_ascii=False, indent=2)
    layout_json = json.dumps({
        "title": "Assembly Groundtruth Viewer",
        "scene": {
            "xaxis": {"title": "X / mm"},
            "yaxis": {"title": "Y / mm"},
            "zaxis": {"title": "Z / mm"},
            "aspectmode": "data",
        },
        "showlegend": True,
        "margin": {"l": 0, "r": 0, "t": 40, "b": 0},
    }, ensure_ascii=False)
    html = f"""<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Assembly Groundtruth Viewer</title>
<script src="https://cdn.plot.ly/plotly-2.35.2.min.js"></script>
<style>
body {{
    margin: 0;
    font-family: Arial, sans-serif;
    display: flex;
    height: 100vh;
    color: #222;
}}
#viewer {{
    flex: 1;
    min-width: 0;
}}
#assembly_viewer {{
    width: 100%;
    height: 100vh;
}}
#panel {{
    width: 470px;
    border-left: 1px solid #ddd;
    padding: 14px;
    overflow: auto;
    background: #fafafa;
}}
h2, h3 {{
    margin: 0 0 10px 0;
}}
.hint {{
    font-size: 13px;
    color: #666;
    line-height: 1.4;
    margin-bottom: 12px;
}}
label {{
    display: block;
    font-size: 12px;
    color: #444;
    margin-top: 6px;
}}
input {{
    width: 100%;
    box-sizing: border-box;
    padding: 5px 6px;
    border: 1px solid #d0d0d0;
    border-radius: 4px;
    font-size: 12px;
}}
button {{
    margin-top: 8px;
    padding: 6px 10px;
    border: 1px solid #bbb;
    border-radius: 4px;
    background: white;
    cursor: pointer;
}}
pre {{
    white-space: pre-wrap;
    word-break: break-word;
    font-size: 12px;
    background: #fff;
    border: 1px solid #e3e3e3;
    border-radius: 6px;
    padding: 10px;
}}
</style>
</head>
<body>
<div id="viewer"><div id="assembly_viewer"></div></div>
<div id="panel">
<h2>Assembly Control</h2>
<div class="hint">The global view below is editable without mouse dragging. An agent can call <code>window.setAssemblyViewPose({{rotation_deg:[rx,ry,rz], scale:s}})</code>. Scale is camera zoom, not geometry scale.</div>
<label>rotation_deg [rx,ry,rz]</label><input id="rotation_deg" value="0,0,0">
<label>scale / camera zoom</label><input id="scale" value="1">
<button onclick="applyPoseFromInputs()">Apply View Pose</button>
<button onclick="resetPose()">Reset</button>
<h3>Current View Pose</h3>
<pre id="view_pose"></pre>
<h2>Component Info</h2>
<div class="hint">Invisible or suppressed components are listed here with visible=false, but are not drawn in the 3D viewport.</div>
<h3>Selected</h3>
<pre id="info">No component selected.</pre>
<h3>All Components</h3>
<pre id="all_components"></pre>
</div>
<script>
const plotData = {plot_data_json};
const layout = {layout_json};
const componentIndex = {component_index_json};
const initialViewPose = {view_pose_json};
let currentViewPose = JSON.parse(JSON.stringify(initialViewPose));
const config = {{responsive: true, displaylogo: false}};
const originalMeshes = plotData.map(trace => ({{
    x: trace.x.slice(),
    y: trace.y.slice(),
    z: trace.z.slice()
}}));

function parseTriple(text, fallback) {{
    const values = String(text || '').split(',').map(v => Number(v.trim()));
    if (values.length !== 3 || values.some(v => !Number.isFinite(v))) return fallback.slice();
    return values;
}}

function degToRad(v) {{ return v * Math.PI / 180.0; }}

function rotatePoint(p, center, rotationDeg) {{
    let x = p[0] - center[0];
    let y = p[1] - center[1];
    let z = p[2] - center[2];
    const rx = degToRad(rotationDeg[0]);
    const ry = degToRad(rotationDeg[1]);
    const rz = degToRad(rotationDeg[2]);
    let cy = Math.cos(rx), sy = Math.sin(rx);
    let y1 = y * cy - z * sy;
    let z1 = y * sy + z * cy;
    y = y1; z = z1;
    cy = Math.cos(ry); sy = Math.sin(ry);
    let x1 = x * cy + z * sy;
    z1 = -x * sy + z * cy;
    x = x1; z = z1;
    cy = Math.cos(rz); sy = Math.sin(rz);
    x1 = x * cy - y * sy;
    y1 = x * sy + y * cy;
    x = x1; y = y1;
    return [x + center[0], y + center[1], z + center[2]];
}}

function setInputsFromPose(pose) {{
    document.getElementById('rotation_deg').value = pose.rotation_deg.join(',');
    document.getElementById('scale').value = String(pose.scale);
    document.getElementById('view_pose').textContent = JSON.stringify({{
        rotation_deg: pose.rotation_deg,
        rotation_unit: 'degree',
        scale: pose.scale,
        scale_semantics: 'camera_zoom_not_geometry_scale',
        api: 'window.setAssemblyViewPose({{rotation_deg:[rx,ry,rz], scale:s}})'
    }}, null, 2);
}}

window.setAssemblyViewPose = function(pose) {{
    const next = {{
        rotation_deg: Array.isArray(pose.rotation_deg) ? pose.rotation_deg.map(Number) : currentViewPose.rotation_deg.slice(),
        scale: Number.isFinite(Number(pose.scale)) ? Number(pose.scale) : currentViewPose.scale,
        internal_rotation_center_mm: initialViewPose.internal_rotation_center_mm,
        bounds_mm: initialViewPose.bounds_mm,
        api: initialViewPose.api
    }};
    const center = next.internal_rotation_center_mm || [0,0,0];
    currentViewPose = next;
    const updates = {{x: [], y: [], z: []}};
    for (let t = 0; t < originalMeshes.length; t++) {{
        const src = originalMeshes[t];
        const nx = [], ny = [], nz = [];
        for (let i = 0; i < src.x.length; i++) {{
            const p = rotatePoint([src.x[i], src.y[i], src.z[i]], center, next.rotation_deg);
            nx.push(p[0]);
            ny.push(p[1]);
            nz.push(p[2]);
        }}
        updates.x.push(nx); updates.y.push(ny); updates.z.push(nz);
    }}
    Plotly.restyle('assembly_viewer', updates);
    const zoom = Math.max(0.05, Number(next.scale) || 1.0);
    Plotly.relayout('assembly_viewer', {{
        'scene.camera.eye': {{x: 1.55 / zoom, y: 1.55 / zoom, z: 1.25 / zoom}}
    }});
    setInputsFromPose(next);
    return next;
}};

function applyPoseFromInputs() {{
    return window.setAssemblyViewPose({{
        rotation_deg: parseTriple(document.getElementById('rotation_deg').value, [0,0,0]),
        scale: Number(document.getElementById('scale').value)
    }});
}}

function resetPose() {{
    return window.setAssemblyViewPose(initialViewPose);
}}

document.getElementById('all_components').textContent = JSON.stringify(componentIndex.map(c => {{
    return {{
        component_id: c.component_id,
        component_display_order: c.component_display_order,
        part_id: c.part_id,
        component_name_raw: c.component_name_raw,
        visible: c.visible,
        drawn_in_viewer: c.drawn_in_viewer,
        mesh_coordinate_frame: c.mesh_coordinate_frame,
        coordinates_mm: c.coordinates_mm,
        rotation_deg: c.rotation_deg,
        rotation_unit: 'degree',
        component_mate_count: (c.component_mates || []).length,
        component_mates: (c.component_mates || []).map(m => ({{
            mate_id: m.mate_id,
            mate_name_raw: m.mate_name_raw,
            solidworks_tree_display: m.solidworks_tree_display,
            solidworks_type: m.solidworks_type,
            selection_summary: m.selection_summary,
            feature_history_path: m.feature_history_path,
            connected_component_ids: m.connected_component_ids
        }}))
    }};
}}), null, 2);
setInputsFromPose(currentViewPose);
Plotly.newPlot('assembly_viewer', plotData, layout, config).then(function(gd) {{
    gd.on('plotly_click', function(data) {{
        if (!data || !data.points || data.points.length === 0) return;
        const curveIndex = data.points[0].curveNumber;
        const trace = gd.data[curveIndex];
        const info = trace.meta || {{}};
        document.getElementById('info').textContent = JSON.stringify(info, null, 2);
    }});
}});
</script>
</body>
</html>
"""
    html_path = render_dir / "assembly_interactive.html"
    html_path.write_text(html, encoding="utf-8")
    return {
        "status": "ok",
        "interactive_html": str(html_path),
        "component_trace_count": len(traces),
        "component_info_count": len(component_infos),
        "hidden_or_suppressed_component_count": hidden_count,
        "mesh_error_component_count": mesh_error_count,
        "view_pose": view_pose,
    }


def representative_point_from_descriptor(ref: dict[str, Any]) -> list[float] | None:
    desc = ref.get("descriptor") or {}
    box = desc.get("bbox_mm") or []
    if len(box) >= 6:
        return [round((float(box[i]) + float(box[i + 3])) / 2.0, 6) for i in range(3)]
    surface = desc.get("surface") or {}
    if (surface.get("plane") or {}).get("origin_mm"):
        return (surface.get("plane") or {}).get("origin_mm")
    if (surface.get("cylinder") or {}).get("origin_mm"):
        return (surface.get("cylinder") or {}).get("origin_mm")
    curve = desc.get("curve") or {}
    if (curve.get("circle") or {}).get("center_mm"):
        return (curve.get("circle") or {}).get("center_mm")
    if desc.get("point_mm"):
        return desc.get("point_mm")
    if desc.get("point_assembly"):
        return desc.get("point_assembly")
    for key in ("center_assembly", "axis_point_assembly", "plane_origin_assembly"):
        if desc.get(key):
            return desc.get(key)
    corners = desc.get("bbox_corners_assembly_sample") or []
    if len(corners) >= 2 and len(corners[0]) >= 3 and len(corners[1]) >= 3:
        return [round((float(corners[0][i]) + float(corners[1][i])) / 2.0, 6) for i in range(3)]
    return None


def component_brep_selection_lookup(graph: dict[str, Any], component_id: str) -> dict[str, list[dict[str, Any]]]:
    lookup: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for edge in graph.get("edges", []) or []:
        if edge.get("relation") != "mate" and edge.get("assembly_relation") != "assembly:mate":
            continue
        for summary in edge.get("selection_summary") or []:
            if str(summary.get("component_id") or "") != str(component_id):
                continue
            selection_id = summary.get("selection_id") or summary.get("raw_selection_id") or summary.get("solidworks_selection_id_original")
            if not selection_id:
                continue
            lookup[str(selection_id)].append({
                "mate_id": edge.get("id"),
                "mate_name_raw": edge.get("mate_name_raw"),
                "solidworks_tree_display": edge.get("solidworks_tree_display"),
                "solidworks_type": edge.get("solidworks_type"),
                "mate_category": edge.get("mate_category"),
                "selection_summary": summary,
            })
    return lookup


def _plane_from_tessellation(face: dict[str, Any]) -> dict[str, Any] | None:
    tess = face.get("tessellation") or {}
    vertices = tess.get("vertices_mm") or []
    if len(vertices) < 3:
        return None
    points: list[list[float]] = []
    for point in vertices:
        xyz = _as_xyz(point)
        if xyz:
            points.append(xyz)
    if len(points) < 3:
        return None
    normal = None
    origin = [
        sum(point[0] for point in points) / len(points),
        sum(point[1] for point in points) / len(points),
        sum(point[2] for point in points) / len(points),
    ]
    for idx in range(len(points) - 2):
        candidate = _vec_unit(_vec_cross(_vec_sub(points[idx + 1], points[idx]), _vec_sub(points[idx + 2], points[idx])))
        if candidate:
            normal = candidate
            break
    if normal is None:
        return None
    return {"origin_mm": origin, "normal": normal}


def _alias_match_face_by_geometry(selection_summary: dict[str, Any], faces: list[dict[str, Any]]) -> dict[str, Any] | None:
    local_geometry = selection_summary.get("local_geometry") or {}
    if local_geometry.get("geometry_type") != "plane":
        return None
    target_origin = _as_xyz(local_geometry.get("origin_mm"))
    target_normal = _vec_unit(_as_xyz(local_geometry.get("normal")) or [])
    if not target_origin or not target_normal:
        return None
    best: dict[str, Any] | None = None
    best_score = float("inf")
    for face in faces:
        descriptor = face.get("descriptor") or {}
        surface_type = descriptor.get("surface_type") or ((descriptor.get("surface") or {}).get("surface_type"))
        if surface_type and str(surface_type).lower() != "plane":
            continue
        plane = _plane_from_tessellation(face)
        if not plane:
            continue
        origin = _as_xyz(plane.get("origin_mm"))
        normal = _vec_unit(_as_xyz(plane.get("normal")) or [])
        if not origin or not normal:
            continue
        normal_delta = 1.0 - abs(_vec_dot(normal, target_normal))
        plane_distance = abs(_vec_dot(_vec_sub(target_origin, origin), normal))
        centroid_distance = _vec_norm(_vec_sub(target_origin, origin))
        score = plane_distance + normal_delta * 1000.0 + centroid_distance * 0.01
        if score < best_score:
            best_score = score
            best = {
                "canonical_topology_id": face.get("face_id") or face.get("id"),
                "canonical_entity_kind": "face",
                "match_method": "geometry_fallback_plane_from_face2_tessellation",
                "plane_distance_mm": round(plane_distance, 6),
                "normal_delta": round(normal_delta, 9),
                "centroid_distance_mm": round(centroid_distance, 6),
                "match_score": round(score, 6),
                "canonical_entity": face,
            }
    if best is None:
        return None
    if best["normal_delta"] > 0.05 or best["plane_distance_mm"] > 5.0:
        return {
            "canonical_topology_id": None,
            "canonical_entity_kind": "face",
            "match_method": "geometry_fallback_rejected",
            "match_rejected_reason": "plane_distance_or_normal_delta_exceeds_threshold",
            "candidate_topology_id": best.get("canonical_topology_id"),
            "candidate_plane_distance_mm": best.get("plane_distance_mm"),
            "candidate_normal_delta": best.get("normal_delta"),
            "candidate_centroid_distance_mm": best.get("centroid_distance_mm"),
            "candidate_match_score": best.get("match_score"),
        }
    return best


def write_component_obj_from_mesh(mesh_path: Path | None, obj_path: Path) -> bool:
    if mesh_path is None or not mesh_path.exists():
        return False
    try:
        import pyvista as pv
        mesh = pv.read(str(mesh_path))
        if not isinstance(mesh, pv.PolyData):
            mesh = mesh.extract_surface()
        # This OBJ is the visual solid base used by the component inspector.
        # Keep it as a real surface mesh rather than a point/edge abstraction.
        # Triangulate curved STL/STEP-derived surfaces so Plotly can render a
        # closed solid; if a reader leaves small boundary gaps, try a safe visual
        # fill without making the whole export fail.
        try:
            mesh = mesh.clean(tolerance=0.0)
        except Exception:
            pass
        try:
            open_edges = int(getattr(mesh, "n_open_edges", 0) or 0)
        except Exception:
            open_edges = 0
        if open_edges > 0:
            try:
                mesh = mesh.fill_holes(1_000_000.0)
            except Exception:
                pass
        mesh = mesh.triangulate()
        obj_path.parent.mkdir(parents=True, exist_ok=True)
        mesh.save(str(obj_path))
        return obj_path.exists() and obj_path.stat().st_size > 0
    except Exception:
        return False


def component_brep_payload(node: dict[str, Any], graph: dict[str, Any], obj_relative_path: str | None) -> dict[str, Any]:
    refs = node.get("brep_topology_references") or []
    selection_lookup = component_brep_selection_lookup(graph, str(node.get("id")))
    entities: dict[str, list[dict[str, Any]]] = {"bodies": [], "faces": [], "loops": [], "edges": [], "vertices": [], "selection_aliases": []}
    for ref in refs:
        kind = str(ref.get("entity_kind") or "")
        entity_id = ref.get("local_topology_id") or ref.get(f"{kind}_id")
        row = {
            "id": entity_id,
            "entity_kind": kind,
            "component_id": node.get("id"),
            "component_name_raw": node.get("component_name_raw"),
            "persistent_ref_hash": ref.get("persistent_ref_hash"),
            "persistent_ref": ref.get("persistent_ref"),
            "part_context": ref.get("part_context"),
            "assembly_context": ref.get("assembly_context"),
            "debug_sequence_id": ref.get("debug_sequence_id"),
            "descriptor": ref.get("descriptor") or {},
            "tessellation": ref.get("tessellation"),
            "representative_point_assembly_mm": representative_point_from_descriptor(ref),
            "mate_references": selection_lookup.get(str(entity_id), []),
        }
        if kind == "body":
            entities["bodies"].append(row)
        elif kind == "face":
            row["face_id"] = ref.get("face_id") or entity_id
            row["body_id"] = ref.get("body_id")
            row["loop_ids"] = ref.get("loop_ids")
            entities["faces"].append(row)
        elif kind == "loop":
            row["loop_id"] = entity_id
            row["face_id"] = ref.get("face_id")
            row["edge_ids"] = ref.get("edge_ids")
            entities["loops"].append(row)
        elif kind == "edge":
            row["edge_id"] = ref.get("edge_id") or entity_id
            row["face_ids"] = ref.get("face_ids")
            row["loop_ids"] = ref.get("loop_ids")
            row["vertex_ids"] = ref.get("vertex_ids")
            entities["edges"].append(row)
        elif kind == "vertex":
            row["vertex_id"] = ref.get("vertex_id") or entity_id
            row["edge_ids"] = ref.get("edge_ids")
            entities["vertices"].append(row)
    canonical_ids = {
        str(row.get("face_id") or row.get("edge_id") or row.get("vertex_id") or row.get("id"))
        for group in (entities["faces"], entities["edges"], entities["vertices"])
        for row in group
    }
    for selection_id, references in selection_lookup.items():
        if not selection_id or str(selection_id) in canonical_ids:
            continue
        summary = (references[0] or {}).get("selection_summary") or {}
        alias: dict[str, Any] = {
            "id": str(selection_id),
            "selection_id": str(selection_id),
            "entity_kind": f"{summary.get('entity_kind') or summary.get('entity_type') or 'selection'}_alias",
            "component_id": node.get("id"),
            "component_name_raw": node.get("component_name_raw"),
            "source": "mate_selection_unmatched_alias",
            "mate_references": references,
            "selection_summary": summary,
        }
        if summary.get("entity_kind") == "face" or summary.get("entity_type") == "face":
            match = _alias_match_face_by_geometry(summary, entities["faces"])
            if match:
                alias.update({k: v for k, v in match.items() if k != "canonical_entity"})
                alias["canonical_entity"] = match.get("canonical_entity")
        entities["selection_aliases"].append(alias)
    return {
        "schema": "sw_component_brep_package.v1",
        "unit": "mm",
        "component": {
            "component_id": node.get("id"),
            "component_name": node.get("component_name"),
            "component_name_raw": node.get("component_name_raw"),
            "component_path": node.get("component_path"),
            "referenced_configuration": node.get("referenced_configuration"),
            "visible": not bool(node.get("hidden") or node.get("suppressed")),
            "hidden": bool(node.get("hidden")),
            "suppressed": bool(node.get("suppressed")),
            "fixed": bool(node.get("fixed")),
            "transform": sw_transform_to_pose(node.get("transform")),
        },
        "mesh": {
            "obj_file": obj_relative_path,
            "source_mesh_path": node.get("mesh_path"),
            "mesh_status": node.get("mesh_status"),
            "mesh_coordinate_frame": node.get("mesh_coordinate_frame"),
            "mesh_coordinate_correction_mm": node.get("mesh_coordinate_correction_mm"),
            "mesh_coordinate_correction_reason": node.get("mesh_coordinate_correction_reason"),
            "mesh_local_bbox_mm": node.get("mesh_local_bbox_mm"),
            "mesh_export_bbox_mm": node.get("mesh_export_bbox_mm"),
            "mesh_unit": "mm",
        },
        "entities": entities,
        "summary": {
            "body_count": len(entities["bodies"]),
            "face_count": len(entities["faces"]),
            "exact_face_tessellation_count": sum(
                1
                for face in entities["faces"]
                if (
                    ((face.get("tessellation") or {}).get("available"))
                    and ((face.get("tessellation") or {}).get("vertices_mm"))
                    and ((face.get("tessellation") or {}).get("triangles"))
                )
            ),
            "loop_count": len(entities["loops"]),
            "edge_count": len(entities["edges"]),
            "vertex_count": len(entities["vertices"]),
            "selection_alias_count": len(entities["selection_aliases"]),
            "mate_mapped_entity_count": sum(1 for rows in selection_lookup.values() if rows),
        },
    }


def _as_xyz(value: Any) -> list[float] | None:
    vals = float_list(value)
    if len(vals) < 3:
        return None
    return [float(vals[0]), float(vals[1]), float(vals[2])]


def _vec_sub(a: list[float], b: list[float]) -> list[float]:
    return [float(a[0]) - float(b[0]), float(a[1]) - float(b[1]), float(a[2]) - float(b[2])]


def _vec_dot(a: list[float], b: list[float]) -> float:
    return float(a[0]) * float(b[0]) + float(a[1]) * float(b[1]) + float(a[2]) * float(b[2])


def _vec_cross(a: list[float], b: list[float]) -> list[float]:
    return [
        float(a[1]) * float(b[2]) - float(a[2]) * float(b[1]),
        float(a[2]) * float(b[0]) - float(a[0]) * float(b[2]),
        float(a[0]) * float(b[1]) - float(a[1]) * float(b[0]),
    ]


def _vec_norm(a: list[float]) -> float:
    return math.sqrt(_vec_dot(a, a))


def _vec_unit(a: list[float]) -> list[float] | None:
    if len(a) < 3:
        return None
    n = _vec_norm(a)
    if n <= 1e-12:
        return None
    return [float(a[0]) / n, float(a[1]) / n, float(a[2]) / n]


def _edge_polyline_points(edge: dict[str, Any], use_assembly_frame: bool) -> list[list[float]]:
    desc = edge.get("descriptor") or {}
    curve = desc.get("curve") or {}
    circle = curve.get("circle") or {}
    if use_assembly_frame:
        start = _as_xyz(desc.get("start_point_assembly")) or _as_xyz((desc.get("start") or {}).get("point_mm"))
        end = _as_xyz(desc.get("end_point_assembly")) or _as_xyz((desc.get("end") or {}).get("point_mm"))
        center = _as_xyz(desc.get("center_assembly")) or _as_xyz(circle.get("center_mm"))
        axis = _vec_unit(_as_xyz(desc.get("axis_dir_assembly")) or _as_xyz(circle.get("axis")) or [])
    else:
        start = _as_xyz((desc.get("start") or {}).get("point_mm")) or _as_xyz(desc.get("start_point_assembly"))
        end = _as_xyz((desc.get("end") or {}).get("point_mm")) or _as_xyz(desc.get("end_point_assembly"))
        center = _as_xyz(circle.get("center_mm")) or _as_xyz(desc.get("center_assembly"))
        axis = _vec_unit(_as_xyz(circle.get("axis")) or _as_xyz(desc.get("axis_dir_assembly")) or [])
    radius = circle.get("radius_mm") or desc.get("radius_mm")
    if center and axis and radius is not None:
        try:
            radius_f = abs(float(radius))
        except Exception:
            radius_f = 0.0
        if radius_f > 1e-9:
            if start and _vec_norm(_vec_sub(start, center)) > 1e-9:
                u = _vec_unit(_vec_sub(start, center))
            else:
                ref = [1.0, 0.0, 0.0] if abs(axis[0]) < 0.9 else [0.0, 1.0, 0.0]
                u = _vec_unit(_vec_cross(axis, ref))
            if u:
                v = _vec_unit(_vec_cross(axis, u))
                if v:
                    if start and end and _vec_norm(_vec_sub(start, end)) > 1e-6:
                        rel_end = _vec_sub(end, center)
                        angle = math.atan2(_vec_dot(rel_end, v), _vec_dot(rel_end, u))
                        if angle < 0:
                            angle += 2 * math.pi
                        if angle > math.pi:
                            angle -= 2 * math.pi
                        steps = max(10, min(96, int(abs(angle) / (math.pi / 36)) + 2))
                        return [[
                            round(center[0] + radius_f * (math.cos(angle * s / (steps - 1)) * u[0] + math.sin(angle * s / (steps - 1)) * v[0]), 6),
                            round(center[1] + radius_f * (math.cos(angle * s / (steps - 1)) * u[1] + math.sin(angle * s / (steps - 1)) * v[1]), 6),
                            round(center[2] + radius_f * (math.cos(angle * s / (steps - 1)) * u[2] + math.sin(angle * s / (steps - 1)) * v[2]), 6),
                        ] for s in range(steps)]
                    steps = 96
                    return [[
                        round(center[0] + radius_f * (math.cos(2 * math.pi * s / steps) * u[0] + math.sin(2 * math.pi * s / steps) * v[0]), 6),
                        round(center[1] + radius_f * (math.cos(2 * math.pi * s / steps) * u[1] + math.sin(2 * math.pi * s / steps) * v[1]), 6),
                        round(center[2] + radius_f * (math.cos(2 * math.pi * s / steps) * u[2] + math.sin(2 * math.pi * s / steps) * v[2]), 6),
                    ] for s in range(steps + 1)]
    if start and end:
        return [start, end]
    return []


def _vertex_display_point(vertex: dict[str, Any], use_assembly_frame: bool) -> list[float] | None:
    desc = vertex.get("descriptor") or {}
    if use_assembly_frame:
        return _as_xyz(desc.get("point_assembly")) or _as_xyz(desc.get("point_mm")) or _as_xyz(vertex.get("representative_point_assembly_mm"))
    return _as_xyz(desc.get("point_mm")) or _as_xyz(desc.get("point_assembly")) or _as_xyz(vertex.get("representative_point_assembly_mm"))


def _hsl_to_hex(h: float, s: float, l: float) -> str:
    """Small deterministic HSL->HEX helper for per-face colors in the HTML inspector."""
    h = (float(h) % 360.0) / 360.0
    s = max(0.0, min(1.0, float(s)))
    l = max(0.0, min(1.0, float(l)))

    def hue_to_rgb(p: float, q: float, t: float) -> float:
        if t < 0:
            t += 1
        if t > 1:
            t -= 1
        if t < 1 / 6:
            return p + (q - p) * 6 * t
        if t < 1 / 2:
            return q
        if t < 2 / 3:
            return p + (q - p) * (2 / 3 - t) * 6
        return p

    if s == 0:
        r = g = b = l
    else:
        q = l * (1 + s) if l < 0.5 else l + s - l * s
        p = 2 * l - q
        r = hue_to_rgb(p, q, h + 1 / 3)
        g = hue_to_rgb(p, q, h)
        b = hue_to_rgb(p, q, h - 1 / 3)
    return "#{:02x}{:02x}{:02x}".format(int(round(r * 255)), int(round(g * 255)), int(round(b * 255)))


def _face_display_color(face: dict[str, Any], face_index: int) -> str:
    """Return a stable, high-contrast color for one B-Rep face.

    The old inspector used one grey closed mesh plus very transparent face
    overlays, so visually everything looked grey.  Here every Face2 mesh gets
    its own stable color keyed by face_id, while the closed solid mesh remains a
    low-opacity background only.
    """
    face_id = str(face.get("face_id") or face.get("local_topology_id") or face_index)
    surface_type = str(((face.get("descriptor") or {}).get("surface_type")) or "")
    seed = int(stable_hash(f"{face_id}|{surface_type}|{face_index}", 8), 16)
    # Golden-angle distribution prevents adjacent face ids from cycling through
    # a tiny 8-color palette.  Keep saturation/lightness controlled for readable
    # colors over a light grey backing mesh.
    hue = (seed % 360 + face_index * 137.508) % 360
    saturation = 0.58 + ((seed >> 8) % 18) / 100.0
    lightness = 0.50 + ((seed >> 16) % 10) / 100.0
    return _hsl_to_hex(hue, saturation, lightness)


def write_component_brep_inspector_html(payload: dict[str, Any], html_path: Path) -> None:
    component = payload.get("component") or {}
    entities = payload.get("entities") or {}
    faces = entities.get("faces") or []
    edges = entities.get("edges") or []
    vertices = entities.get("vertices") or []
    mesh_payload = payload.get("mesh") or {}
    obj_file = mesh_payload.get("obj_file")
    mesh_frame = str(mesh_payload.get("mesh_coordinate_frame") or "part_local")
    display_in_assembly_frame = mesh_frame == "assembly_context_export"
    display_frame_label = "assembly" if display_in_assembly_frame else "part_local"
    mesh_correction = _as_xyz(mesh_payload.get("mesh_coordinate_correction_mm")) if not display_in_assembly_frame else None
    face_traces: list[dict[str, Any]] = []
    for face_index, face in enumerate(faces):
        tess = face.get("tessellation") or {}
        if not tess.get("available"):
            continue
        tess_vertices = (tess.get("vertices_assembly_mm") if display_in_assembly_frame else tess.get("vertices_mm")) or []
        if display_in_assembly_frame and not tess_vertices:
            tess_vertices = tess.get("vertices_mm") or []
        triangles = tess.get("triangles") or []
        if not tess_vertices or not triangles:
            continue
        face_id = str(face.get("face_id") or face.get("id") or f"face_{face_index + 1:05d}")
        tess_summary = {
            k: tess.get(k)
            for k in ("available", "status", "source", "source_method", "coordinate_frame", "unit", "vertex_count", "triangle_count", "parse_stride", "bbox_score_m")
        }
        raw = {**face, "tessellation": tess_summary, "pick_method": "solidworks_face2_tessellation", "display_frame": display_frame_label, "tessellation_payload_omitted_in_hover": True}
        face_traces.append({
            "type": "mesh3d",
            "name": face_id,
            "x": [round(float(p[0]), 6) for p in tess_vertices],
            "y": [round(float(p[1]), 6) for p in tess_vertices],
            "z": [round(float(p[2]), 6) for p in tess_vertices],
            "i": [int(t[0]) for t in triangles],
            "j": [int(t[1]) for t in triangles],
            "k": [int(t[2]) for t in triangles],
            "color": _face_display_color(face, face_index),
            "opacity": 0.82,
            "flatshading": False,
            "lighting": {"ambient": 0.62, "diffuse": 0.72, "specular": 0.18, "roughness": 0.78},
            "hovertemplate": f"{html_lib.escape(face_id)}<extra>face</extra>",
            "meta": {"kind": "face", "id": face_id, "raw": raw},
            "showscale": False,
        })
    fallback_mesh_trace: dict[str, Any] | None = None
    if obj_file:
        obj_path = html_path.parent / str(obj_file)
        if obj_path.exists():
            try:
                import numpy as np
                import pyvista as pv
                mesh = pv.read(str(obj_path))
                if not isinstance(mesh, pv.PolyData):
                    mesh = mesh.extract_surface().triangulate()
                else:
                    mesh = mesh.triangulate()
                faces_raw = mesh.faces.reshape((-1, 4)) if mesh.faces is not None and len(mesh.faces) else []
                tri_faces = np.array([row[1:4].tolist() for row in faces_raw if int(row[0]) == 3], dtype=int)
                points_arr = np.array(mesh.points, dtype=float)
                if mesh_correction and len(points_arr):
                    points_arr = points_arr + np.array(mesh_correction, dtype=float)
                if len(points_arr) and len(tri_faces):
                    fallback_mesh_trace = {
                        "type": "mesh3d",
                        "name": "closed component solid mesh",
                        "x": [round(float(v), 6) for v in points_arr[:, 0]],
                        "y": [round(float(v), 6) for v in points_arr[:, 1]],
                        "z": [round(float(v), 6) for v in points_arr[:, 2]],
                        "i": [int(f[0]) for f in tri_faces],
                        "j": [int(f[1]) for f in tri_faces],
                        "k": [int(f[2]) for f in tri_faces],
                        "color": "#aeb7c4",
                        "opacity": 0.65,
                        "flatshading": False,
                        "lighting": {"ambient": 0.55, "diffuse": 0.65, "specular": 0.08, "roughness": 0.92},
                        "hovertemplate": "closed visual solid mesh; click colored Face2 surface / B-Rep edge / B-Rep vertex for exact IDs<extra></extra>",
                        "meta": {"kind": "mesh", "id": "component_solid_mesh", "raw": {"pick_method": "closed_visual_solid_mesh", "display_frame": display_frame_label, "mesh_coordinate_frame": mesh_frame, "mesh_coordinate_correction_mm": mesh_correction}},
                        "showscale": False,
                    }
            except Exception:
                fallback_mesh_trace = None
    edge_x: list[Any] = []
    edge_y: list[Any] = []
    edge_z: list[Any] = []
    edge_text: list[str] = []
    edge_data: list[Any] = []
    for edge in edges:
        pts = _edge_polyline_points(edge, use_assembly_frame=display_in_assembly_frame)
        if len(pts) < 2:
            continue
        edge_id = str(edge.get("edge_id") or edge.get("id") or "edge")
        raw = {**edge, "pick_method": "direct_edge_polyline_trace", "display_frame": display_frame_label}
        for pt in pts:
            edge_x.append(round(float(pt[0]), 6))
            edge_y.append(round(float(pt[1]), 6))
            edge_z.append(round(float(pt[2]), 6))
            edge_text.append(edge_id)
            edge_data.append(raw)
        edge_x.append(None)
        edge_y.append(None)
        edge_z.append(None)
        edge_text.append("")
        edge_data.append(None)
    edge_trace = {
        "type": "scatter3d",
        "mode": "lines",
        "name": "B-Rep edges",
        "x": edge_x,
        "y": edge_y,
        "z": edge_z,
        "text": edge_text,
        "customdata": edge_data,
        "line": {"color": "#111827", "width": 4},
        "hovertemplate": "%{text}<extra>edge</extra>",
        "connectgaps": False,
    } if edge_x else None
    vertex_points: list[dict[str, Any]] = []
    for vertex in vertices:
        point = _vertex_display_point(vertex, use_assembly_frame=display_in_assembly_frame)
        if point and len(point) >= 3:
            vertex_id = str(vertex.get("vertex_id") or vertex.get("id") or "vertex")
            raw = {**vertex, "pick_method": "direct_vertex_marker", "display_frame": display_frame_label}
            vertex_points.append({"id": vertex_id, "point": [round(float(point[0]), 6), round(float(point[1]), 6), round(float(point[2]), 6)], "raw": raw})
    vertex_trace = {
        "type": "scatter3d",
        "mode": "markers",
        "name": "B-Rep vertices",
        "x": [row["point"][0] for row in vertex_points],
        "y": [row["point"][1] for row in vertex_points],
        "z": [row["point"][2] for row in vertex_points],
        "text": [row["id"] for row in vertex_points],
        "customdata": [row["raw"] for row in vertex_points],
        "marker": {"size": 3, "color": "#d22f27", "symbol": "circle"},
        "hovertemplate": "%{text}<extra>vertex</extra>",
    } if vertex_points else None
    payload_json = json.dumps(payload, ensure_ascii=False)
    face_traces_json = json.dumps(face_traces, ensure_ascii=False)
    fallback_mesh_json = json.dumps(fallback_mesh_trace, ensure_ascii=False)
    edge_trace_json = json.dumps(edge_trace, ensure_ascii=False)
    vertex_trace_json = json.dumps(vertex_trace, ensure_ascii=False)
    exact_face_count = len(face_traces)
    title = f"{component.get('component_id')} {component.get('component_name_raw')}"
    html = f"""<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>{html_lib.escape(title)}</title>
<script src="https://cdn.plot.ly/plotly-2.35.2.min.js"></script>
<style>
body {{ margin:0; font-family:Segoe UI, Arial, sans-serif; display:grid; grid-template-columns:1fr 460px; height:100vh; color:#172033; }}
#plot {{ width:100%; height:100vh; }}
#side {{ border-left:1px solid #d8dee8; padding:14px; overflow:auto; background:#f8fafc; }}
h2 {{ margin:0 0 8px 0; font-size:18px; }}
h3 {{ margin:16px 0 8px 0; font-size:15px; }}
pre {{ white-space:pre-wrap; word-break:break-word; background:#fff; border:1px solid #d8dee8; padding:10px; border-radius:6px; font-size:12px; }}
.badge {{ display:inline-block; margin:2px 4px 8px 0; padding:3px 7px; background:#e8eef8; border-radius:5px; font-size:12px; }}
.hint {{ color:#475569; line-height:1.45; font-size:13px; margin:8px 0 10px 0; }}
button {{ border:1px solid #cbd5e1; background:#fff; border-radius:5px; padding:5px 8px; cursor:pointer; margin-right:4px; }}
input {{ width:100%; box-sizing:border-box; border:1px solid #cbd5e1; border-radius:5px; padding:6px; margin:6px 0; }}
.entity-list {{ background:#fff; border:1px solid #d8dee8; border-radius:6px; max-height:280px; overflow:auto; padding:6px; font-size:12px; }}
.entity-row {{ display:grid; grid-template-columns:52px 1fr 42px; gap:6px; align-items:center; padding:3px 4px; border-bottom:1px solid #edf2f7; transition:background 120ms ease, color 120ms ease; }}
.entity-row:last-child {{ border-bottom:0; }}
.entity-row.selected {{ background:#1e3a8a; color:#fff; border-radius:4px; }}
.entity-row.selected .entity-kind {{ color:#bfdbfe; }}
.entity-row.selected .entity-id {{ color:#fff; font-weight:700; }}
.entity-row.selected button {{ background:#0f172a; border-color:#020617; color:#fff; font-weight:700; }}
.entity-id {{ font-family:Consolas, monospace; word-break:break-all; }}
.entity-kind {{ color:#64748b; }}
.entity-row button {{ padding:2px 5px; font-size:11px; }}
</style>
</head>
<body>
<div id="plot"></div>
<div id="side">
<h2>{html_lib.escape(str(title))}</h2>
<div>
<span class="badge">faces {len(faces)}</span>
<span class="badge">exact face meshes {exact_face_count}</span>\r\n<span class="badge">closed visual solid {"yes" if fallback_mesh_trace else "no"}</span>\r\n<span class="badge">display frame {html_lib.escape(display_frame_label)}</span>\r\n<span class="badge">mesh correction {"yes" if mesh_correction else "no"}</span>\r\n<span class="badge">missing exact face meshes {max(0, len(faces) - exact_face_count)}</span>
<span class="badge">edges {len(edges)}</span>
<span class="badge">vertices {len(vertices)}</span>
</div>
<div class="hint">页面以完整闭合的元件实体为主体：浅灰色整体 mesh 只作为低透明度闭合底模，保证弧面/曲面和缺失面仍可见；每个可提取 Face2 tessellation 的 B-Rep 面使用独立高对比颜色并贴在实体表面，用于直接点击 face_id；黑色线和红色点来自真实 B-Rep edge / vertex。若 STL/OBJ 与 B-Rep 坐标有偏移，已自动应用 mesh_coordinate_correction_mm，避免实体和点线面分离。</div>
<input id="search" placeholder="输入 face/edge/vertex ID 后回车搜索">
<button onclick="copyCurrentId()">复制当前ID</button>
<button onclick="resetCamera()">重置视角</button>
<h3>Manual Mapping</h3>
<div class="hint">用于 unresolved / low confidence。先搜索 raw id，再输入你人工确认的 canonical B-Rep ID，保存后可导出修正 JSON。</div>
<input id="manualCanonicalId" placeholder="canonical B-Rep ID，例如 face_xxx / edge_xxx / vertex_xxx">
<button onclick="saveManualMapping()">保存人工映射</button>
<button onclick="exportManualMappings()">导出修正JSON</button>
<h3>Picked Entity</h3>
<pre id="brief">Hover or click a face / edge / vertex on the solid model.</pre>
<h3>Entity Index</h3>
<div class="hint">这里列出全部 face / edge / vertex。可以 Ctrl+F 搜 ID，也可以在上方搜索框输入 ID 后回车高亮。</div>
<div id="entityIndex" class="entity-list"></div>
<h3>Full Data</h3>
<pre id="info"></pre>
</div>
<script>
const BREP = {payload_json};
const FACE_TRACES = {face_traces_json};
const FALLBACK_MESH = {fallback_mesh_json};
const EDGE_TRACE = {edge_trace_json};
const VERTEX_TRACE = {vertex_trace_json};
let currentEntity = null;
const traces = [];
if (FALLBACK_MESH) traces.push(FALLBACK_MESH);
if (FACE_TRACES && FACE_TRACES.length) traces.push(...FACE_TRACES);
if (EDGE_TRACE) traces.push(EDGE_TRACE);
if (VERTEX_TRACE) traces.push(VERTEX_TRACE);
const layout = {{
  scene: {{
    aspectmode:'data',
    xaxis:{{title:'X mm', zeroline:false}},
    yaxis:{{title:'Y mm', zeroline:false}},
    zaxis:{{title:'Z mm', zeroline:false}}
  }},
  margin: {{l:0,r:0,t:18,b:0}},
  showlegend: false,
  hovermode: 'closest'
}};
const config = {{responsive:true, displaylogo:false, scrollZoom:true}};
Plotly.newPlot('plot', traces, layout, config);
const ENTITY_INDEX = [];
(BREP.entities.faces || []).forEach(x => ENTITY_INDEX.push(x));
(BREP.entities.edges || []).forEach(x => ENTITY_INDEX.push(x));
(BREP.entities.vertices || []).forEach(x => ENTITY_INDEX.push(x));
(BREP.entities.selection_aliases || []).forEach(x => ENTITY_INDEX.push(x));
let highlightTraceIndices = [];
let highlightBlinkTimers = [];
let highlightBlinkOn = true;
let selectedEntityIndex = null;
function idOf(row) {{
  if (!row) return null;
  return row.face_id || row.edge_id || row.vertex_id || row.id || row.local_topology_id || row.selection_topology_id || row.raw_selection_id || row.solidworks_selection_id_original || null;
}}
function kindOf(row) {{
  if (!row) return 'unknown';
  return row.entity_kind || (row.face_id ? 'face' : row.edge_id ? 'edge' : row.vertex_id ? 'vertex' : 'unknown');
}}
function showEntity(row, point) {{
  currentEntity = row || null;
  const mates = (row && row.mate_references) ? row.mate_references : [];
  const brief = {{
    entity_kind: kindOf(row),
    id: idOf(row),
    debug_candidate_only: !!(row && !row.canonical_entity && row.candidate_topology_id),
    candidate_topology_id: row && row.candidate_topology_id,
    match_rejected_reason: row && row.match_rejected_reason,
    clicked_or_hover_point_mm: point || null,
    mate_reference_count: mates.length,
    mate_references: mates.map(m => {{ return {{mate_id:m.mate_id, mate_name_raw:m.mate_name_raw, mate_category:m.mate_category, selection_id:m.selection_summary && m.selection_summary.selection_id}}; }}),
    persistent_ref_hash: row && row.persistent_ref_hash,
    pick_method: row && row.pick_method
  }};
  document.getElementById('brief').textContent = JSON.stringify(brief, null, 2);
  document.getElementById('info').textContent = JSON.stringify(row || null, null, 2);
}}
function tessellationOf(row) {{
  return row && row.tessellation ? row.tessellation : null;
}}
function offsetFaceVertices(vertices, triangles, amount) {{
  if (!vertices || !vertices.length || !triangles || !triangles.length) return vertices || [];
  let nx = 0, ny = 0, nz = 1;
  for (const tri of triangles) {{
    const a = vertices[tri[0]], b = vertices[tri[1]], c = vertices[tri[2]];
    if (!a || !b || !c) continue;
    const ux = b[0] - a[0], uy = b[1] - a[1], uz = b[2] - a[2];
    const vx = c[0] - a[0], vy = c[1] - a[1], vz = c[2] - a[2];
    const tx = uy * vz - uz * vy;
    const ty = uz * vx - ux * vz;
    const tz = ux * vy - uy * vx;
    const len = Math.sqrt(tx * tx + ty * ty + tz * tz);
    if (len > 1e-9) {{ nx = tx / len; ny = ty / len; nz = tz / len; break; }}
  }}
  return vertices.map(p => [p[0] + nx * amount, p[1] + ny * amount, p[2] + nz * amount]);
}}
function clearHighlight() {{
  if (highlightBlinkTimers.length) {{
    highlightBlinkTimers.forEach(timer => clearTimeout(timer));
    highlightBlinkTimers = [];
  }}
  if (highlightTraceIndices.length) {{
    const sorted = [...highlightTraceIndices].sort((a, b) => b - a);
    Plotly.deleteTraces('plot', sorted);
    highlightTraceIndices = [];
  }}
}}
function blinkStyle(blinkMode, on) {{
  if (blinkMode === 'face') return {{opacity: on ? 1.0 : 0.36}};
  if (blinkMode === 'debug_face') return {{opacity: on ? 0.94 : 0.34}};
  if (blinkMode === 'edge') return {{'line.color': [on ? '#ff2d2d' : '#ffd400'], 'line.width': [on ? 12 : 5]}};
  if (blinkMode === 'vertex') return {{'marker.size': [on ? 11 : 5], 'marker.color': [on ? '#ff2d2d' : '#ffd400']}};
  return null;
}}
function startHighlightBlink(blinkMode) {{
  highlightBlinkTimers.forEach(timer => clearTimeout(timer));
  highlightBlinkTimers = [];
  const pulses = [false, true, false, true, false, true];
  pulses.forEach((state, index) => {{
    const timer = setTimeout(() => {{
      if (!highlightTraceIndices.length) return;
      const style = blinkStyle(blinkMode, state);
      if (style) Plotly.restyle('plot', style, highlightTraceIndices);
    }}, 260 * (index + 1));
    highlightBlinkTimers.push(timer);
  }});
  const cleanupTimer = setTimeout(() => {{
    highlightBlinkTimers = [];
  }}, 260 * (pulses.length + 1));
  highlightBlinkTimers.push(cleanupTimer);
}}
function addHighlightTrace(trace, blinkMode) {{
  clearHighlight();
  highlightBlinkOn = true;
  const traceList = Array.isArray(trace) ? trace : [trace];
  Plotly.addTraces('plot', traceList).then(() => {{
    const gd = document.getElementById('plot');
    const start = gd.data.length - traceList.length;
    highlightTraceIndices = traceList.map((_, i) => start + i);
    startHighlightBlink(blinkMode);
  }});
}}
function edgePointsById(edgeId) {{
  if (!EDGE_TRACE) return [];
  const pts = [];
  let current = [];
  for (let i = 0; i < (EDGE_TRACE.x || []).length; i++) {{
    const raw = EDGE_TRACE.customdata && EDGE_TRACE.customdata[i];
    const x = EDGE_TRACE.x[i], y = EDGE_TRACE.y[i], z = EDGE_TRACE.z[i];
    if (x === null || y === null || z === null) {{
      if (current.length) {{
        pts.push(current);
        current = [];
      }}
      continue;
    }}
    if (raw && String(idOf(raw)) === String(edgeId)) current.push([x, y, z]);
  }}
  if (current.length) pts.push(current);
  return pts.flat();
}}
function entityById(entityId) {{
  return ENTITY_INDEX.find(x => String(idOf(x)) === String(entityId) || String(x.local_topology_id || '') === String(entityId)) || null;
}}
function highlightEntity(row) {{
  if (!row || row.error) {{
    clearHighlight();
    return;
  }}
  const candidateRow = (!row.canonical_entity && row.candidate_topology_id) ? entityById(row.candidate_topology_id) : null;
  const highlightRow = row.canonical_entity || candidateRow || row;
  const debugCandidateOnly = !!candidateRow && !row.canonical_entity;
  const kind = kindOf(row);
  const id = idOf(row);
  const highlightKind = kindOf(highlightRow);
  const highlightId = idOf(highlightRow);
  if (highlightKind === 'face') {{
    const tess = tessellationOf(highlightRow);
    const verts = tess && (tess.vertices_mm || tess.vertices_assembly_mm);
    if (tess && verts && tess.triangles) {{
      const amount = debugCandidateOnly ? 0.65 : 0.55;
      const liftedPlus = offsetFaceVertices(verts, tess.triangles, amount);
      const liftedMinus = offsetFaceVertices(verts, tess.triangles, -amount);
      const makeFaceTrace = (liftedVertices, suffix) => ({{
        type:'mesh3d',
        name:'highlight ' + id + suffix,
        x:liftedVertices.map(p => p[0]),
        y:liftedVertices.map(p => p[1]),
        z:liftedVertices.map(p => p[2]),
        i:tess.triangles.map(t => t[0]),
        j:tess.triangles.map(t => t[1]),
        k:tess.triangles.map(t => t[2]),
        color: debugCandidateOnly ? '#ff7a00' : '#facc15',
        opacity: debugCandidateOnly ? 0.94 : 1.0,
        flatshading:false,
        lighting:{{ambient:0.92, diffuse:0.85, specular:0.45, roughness:0.35}},
        hovertemplate:String(id) + ' ? ' + String(highlightId) + (debugCandidateOnly ? ' rejected candidate' : '') + '<extra>highlight face</extra>',
        showscale:false
      }});
      addHighlightTrace([makeFaceTrace(liftedPlus, ' +'), makeFaceTrace(liftedMinus, ' -')], debugCandidateOnly ? 'debug_face' : 'face');
    }}
  }} else if (highlightKind === 'edge') {{
    const pts = edgePointsById(highlightId);
    if (pts.length) {{
      addHighlightTrace({{
        type:'scatter3d',
        mode:'lines',
        name:'highlight ' + id,
        x:pts.map(p => p[0]),
        y:pts.map(p => p[1]),
        z:pts.map(p => p[2]),
        line:{{color:'#ff2d2d', width:10}},
        hovertemplate:String(id) + ' → ' + String(highlightId) + '<extra>highlight edge</extra>'
      }}, 'edge');
    }}
  }} else if (highlightKind === 'vertex') {{
    const desc = highlightRow.descriptor || {{}};
    const p = desc.point_mm || desc.point_assembly || highlightRow.representative_point_assembly_mm;
    if (p && p.length >= 3) {{
      addHighlightTrace({{
        type:'scatter3d',
        mode:'markers',
        name:'highlight ' + id,
        x:[p[0]], y:[p[1]], z:[p[2]],
        marker:{{size:9, color:'#ff2d2d', symbol:'diamond'}},
        hovertemplate:String(id) + '<extra>highlight vertex</extra>'
      }}, 'vertex');
    }}
  }}
}}
function markSelectedEntity(row) {{
  if (selectedEntityIndex !== null) {{
    const oldEl = document.getElementById('idx_' + selectedEntityIndex);
    if (oldEl) oldEl.classList.remove('selected');
  }}
  selectedEntityIndex = null;
  if (!row || row.error) return;
  const rowId = String(idOf(row) || '');
  const idx = ENTITY_INDEX.findIndex(x => String(idOf(x) || '') === rowId || String(x.local_topology_id || '') === rowId);
  if (idx >= 0) {{
    selectedEntityIndex = idx;
    const el = document.getElementById('idx_' + idx);
    if (el) {{
      el.classList.add('selected');
      el.scrollIntoView({{block:'nearest'}});
    }}
  }}
}}
function selectEntity(row, point) {{
  showEntity(row, point || null);
  highlightEntity(row);
  markSelectedEntity(row);
}}
function manualStorageKey() {{
  return 'sw_brep_manual_mappings:' + (BREP.component && BREP.component.component_id ? BREP.component.component_id : 'component');
}}
function loadManualMappings() {{
  try {{ return JSON.parse(localStorage.getItem(manualStorageKey()) || '[]'); }} catch (err) {{ return []; }}
}}
function saveManualMappings(rows) {{
  localStorage.setItem(manualStorageKey(), JSON.stringify(rows, null, 2));
}}
function saveManualMapping() {{
  const rawId = currentEntity && (currentEntity.raw_selection_id || currentEntity.selection_id || currentEntity.id);
  const canonicalId = document.getElementById('manualCanonicalId').value.trim();
  if (!rawId || !canonicalId) {{
    document.getElementById('brief').textContent = JSON.stringify({{error:'select_raw_entity_and_enter_canonical_id', rawId, canonicalId}}, null, 2);
    return;
  }}
  const canonical = entityById(canonicalId);
  const rows = loadManualMappings().filter(r => !(r.raw_selection_id === rawId && r.component_id === (BREP.component && BREP.component.component_id)));
  const row = {{
    component_id: BREP.component && BREP.component.component_id,
    component_name_raw: BREP.component && BREP.component.component_name_raw,
    raw_selection_id: rawId,
    canonical_brep_id: canonicalId,
    canonical_exists_in_component: !!canonical,
    saved_at: new Date().toISOString(),
    note: 'manual_debug_mapping_from_brep_inspector'
  }};
  rows.push(row);
  saveManualMappings(rows);
  if (canonical) selectEntity(canonical, null);
  document.getElementById('brief').textContent = JSON.stringify({{manual_mapping_saved: row, mapping_count: rows.length}}, null, 2);
}}
function exportManualMappings() {{
  const rows = loadManualMappings();
  const blob = new Blob([JSON.stringify({{schema:'sw_manual_brep_selection_mappings.v1', component: BREP.component, mappings: rows}}, null, 2)], {{type:'application/json'}});
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = ((BREP.component && BREP.component.component_id) || 'component') + '.manual_brep_mappings.json';
  a.click();
  URL.revokeObjectURL(url);
}}
function rowFromPoint(p) {{
  if (!p) return null;
  if (p.customdata) return p.customdata;
  if (p.data && p.data.meta && p.data.meta.raw) return p.data.meta.raw;
  return null;
}}
document.getElementById('plot').on('plotly_click', ev => {{
  const p = ev.points && ev.points[0];
  selectEntity(rowFromPoint(p), p && p.x !== undefined ? [p.x, p.y, p.z] : null);
}});
document.getElementById('plot').on('plotly_hover', ev => {{
  const p = ev.points && ev.points[0];
  showEntity(rowFromPoint(p), p && p.x !== undefined ? [p.x, p.y, p.z] : null);
}});
document.getElementById('search').addEventListener('keydown', ev => {{
  if (ev.key !== 'Enter') return;
  const q = ev.target.value.trim();
  if (!q) return;
  const found = ENTITY_INDEX.find(x => String(idOf(x)) === q || String(x.local_topology_id || '') === q);
  selectEntity(found || {{error:'id_not_found', query:q}}, null);
}});
function renderEntityIndex() {{
  const root = document.getElementById('entityIndex');
  root.innerHTML = ENTITY_INDEX.map((row, idx) => {{
    const id = String(idOf(row) || '');
    const kind = String(kindOf(row) || '');
    return `<div class="entity-row" id="idx_${{idx}}"><span class="entity-kind">${{kind}}</span><span class="entity-id">${{id}}</span><button onclick="selectEntityByIndex(${{idx}})">亮显</button></div>`;
  }}).join('');
}}
function selectEntityByIndex(idx) {{
  const row = ENTITY_INDEX[idx];
  selectEntity(row, null);
  const el = document.getElementById('idx_' + idx);
  if (el) el.scrollIntoView({{block:'center'}});
}}
renderEntityIndex();
function copyCurrentId() {{
  const id = idOf(currentEntity);
  if (!id) return;
  navigator.clipboard && navigator.clipboard.writeText(String(id));
}}
function resetCamera() {{
  Plotly.relayout('plot', {{'scene.camera': null}});
}}
</script>
</body>
</html>"""
    html_path.write_text(html, encoding="utf-8")

def export_component_brep_packages(graph: dict[str, Any], out_dir: Path) -> dict[str, Any]:
    package_dir = out_dir / "component_brep_packages"
    if package_dir.exists():
        shutil.rmtree(package_dir)
    package_dir.mkdir(parents=True, exist_ok=True)
    stats = Counter()
    rows = []
    mesh_by_component_id: dict[str, dict[str, Any]] = {}
    pose_spec_path = out_dir / "assembly_pose_spec.json"
    if pose_spec_path.exists():
        try:
            pose_spec = json.loads(pose_spec_path.read_text(encoding="utf-8"))
            for comp in pose_spec.get("components", []) or []:
                comp_id = str(comp.get("component_id") or comp.get("id") or "")
                if comp_id:
                    mesh_by_component_id[comp_id] = comp
        except Exception:
            pass
    for node in graph.get("nodes", []) or []:
        if node.get("node_type") != "component":
            continue
        component_id = str(node.get("id"))
        linked_mesh = mesh_by_component_id.get(component_id) or {}
        for key in ("mesh_path", "mesh_status", "mesh_coordinate_frame", "mesh_relative_path"):
            if not node.get(key) and linked_mesh.get(key):
                node[key] = linked_mesh.get(key)
        if (not node.get("mesh_path") or not Path(str(node.get("mesh_path"))).exists()) and linked_mesh.get("mesh"):
            mesh_candidate = Path(str(linked_mesh.get("mesh")))
            if not mesh_candidate.is_absolute():
                mesh_candidate = out_dir / mesh_candidate
            if mesh_candidate.exists():
                node["mesh_path"] = str(mesh_candidate)
        slug = ascii_slug(str(node.get("component_name_raw") or node.get("component_name") or component_id), component_id)
        comp_dir = package_dir / f"{component_id}_{slug}"
        comp_dir.mkdir(parents=True, exist_ok=True)
        mesh_path = Path(str(node.get("mesh_path") or "")) if node.get("mesh_path") else None
        obj_name = f"{component_id}_{slug}.obj"
        obj_path = comp_dir / obj_name
        obj_ok = write_component_obj_from_mesh(mesh_path, obj_path)
        payload = component_brep_payload(node, graph, obj_name if obj_ok else None)
        json_path = comp_dir / f"{component_id}_{slug}.brep.json"
        html_path = comp_dir / f"{component_id}_{slug}.brep_inspector.html"
        output_payload = compact_persistent_references_for_output(payload)
        json_path.write_text(json.dumps(output_payload, ensure_ascii=False, indent=2), encoding="utf-8")
        write_component_brep_inspector_html(output_payload, html_path)
        summary = payload.get("summary") or {}
        face_count = int(summary.get("face_count") or 0)
        exact_face_count = int(summary.get("exact_face_tessellation_count") or 0)
        if face_count and exact_face_count:
            package_status = "ok_exact_face2_tessellation"
        elif face_count:
            package_status = "missing_face2_tessellation"
        else:
            package_status = "no_brep_topology"
        node["component_brep_package"] = {
            "brep_json": str(json_path),
            "obj_mesh": str(obj_path) if obj_ok else None,
            "inspector_html": str(html_path),
            "status": package_status,
            "face_count": face_count,
            "exact_face_tessellation_count": exact_face_count,
        }
        stats["components"] += 1
        stats["obj_ok" if obj_ok else "obj_failed"] += 1
        rows.append(node["component_brep_package"] | {"component_id": component_id, "component_name_raw": node.get("component_name_raw")})
    manifest = {
        "schema": "sw_component_brep_package_manifest.v1",
        "package_dir": str(package_dir),
        "summary": dict(stats),
        "components": rows,
    }
    manifest_path = package_dir / "manifest.json"
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    graph.setdefault("summary", {})["component_brep_package_summary"] = {**dict(stats), "manifest": str(manifest_path)}
    return manifest


def canonicalize_mate_selection_ids_from_component_packages(graph: dict[str, Any], out_dir: Path) -> dict[str, Any]:
    """Rewrite mate face/edge/vertex IDs to canonical B-rep IDs when an alias is trusted."""
    package_dir = out_dir / "component_brep_packages"
    alias_map: dict[tuple[str, str], dict[str, Any]] = {}
    if package_dir.exists():
        for json_path in package_dir.glob("**/*.brep.json"):
            try:
                payload = json.loads(json_path.read_text(encoding="utf-8"))
            except Exception:
                continue
            comp_id = str(((payload.get("component") or {}).get("component_id")) or "")
            if not comp_id:
                continue
            for alias in ((payload.get("entities") or {}).get("selection_aliases") or []):
                original_id = str(alias.get("selection_id") or alias.get("id") or "")
                canonical_id = alias.get("canonical_topology_id")
                if original_id and canonical_id:
                    alias_map[(comp_id, original_id)] = alias
    if not alias_map:
        graph.setdefault("summary", {})["mate_selection_canonicalization_summary"] = {
            "status": "no_aliases_to_canonicalize",
            "canonicalized_count": 0,
        }
        return {"canonicalized_count": 0, "alias_count": 0}

    def canonicalize_row(row: dict[str, Any], alias: dict[str, Any]) -> bool:
        canonical_id = str(alias.get("canonical_topology_id") or "")
        if not canonical_id:
            return False
        original_id = str(row.get("selection_id") or row.get("topology_selection_id") or row.get("selection_topology_id") or "")
        if not original_id or original_id == canonical_id:
            return False
        entity_kind = str(row.get("entity_kind") or row.get("entity_type") or alias.get("canonical_entity_kind") or "")
        row.setdefault("solidworks_selection_id_original", original_id)
        row.setdefault("solidworks_selection_persistent_ref_hash", row.get("persistent_ref_hash") or original_id.replace("face_", "").replace("edge_", "").replace("vertex_", ""))
        row["selection_id"] = canonical_id
        row["selection_id_source"] = "canonical_brep_topology_id"
        row["display_id"] = canonical_id
        row["display_id_source"] = "canonical_brep_topology_id"
        row["selection_surface_id"] = canonical_id
        row["brep_topology_id"] = canonical_id
        row["topology_selection_id"] = canonical_id
        row["selection_topology_id"] = canonical_id
        if entity_kind == "face":
            row["face_id"] = canonical_id
        elif entity_kind == "edge":
            row["edge_id"] = canonical_id
        elif entity_kind == "vertex":
            row["vertex_id"] = canonical_id
        low_confidence = False
        row["brep_mapping_status"] = "canonical_brep_id_from_selection_alias"
        row["canonicalization"] = {
            "status": "canonicalized",
            "from_selection_id": original_id,
            "to_brep_topology_id": canonical_id,
            "method": alias.get("match_method"),
            "plane_distance_mm": alias.get("plane_distance_mm"),
            "normal_delta": alias.get("normal_delta"),
            "centroid_distance_mm": alias.get("centroid_distance_mm"),
        }
        match_status = row.setdefault("match_status", {})
        if isinstance(match_status, dict):
            match_status.update({
                "final_match": True,
                "match_method": row["brep_mapping_status"],
                "match_confidence": 0.75,
                "canonicalized_from_selection_id": original_id,
            })
        return True

    canonicalized = 0
    for edge in graph.get("edges", []) or []:
        if edge.get("relation") != "mate" and edge.get("assembly_relation") != "assembly:mate":
            continue
        for entity in ((edge.get("selection") or {}).get("entities") or []):
            comp_id = str(entity.get("component_id") or "")
            ids = [
                str(entity.get("selection_id") or ""),
                str(entity.get("selection_topology_id") or ""),
                str(entity.get("topology_selection_id") or ""),
                str(entity.get("face_id") or entity.get("edge_id") or entity.get("vertex_id") or ""),
            ]
            alias = next((alias_map.get((comp_id, item)) for item in ids if item), None)
            if alias and canonicalize_row(entity, alias):
                identity = entity.get("selection_identity")
                if isinstance(identity, dict):
                    canonicalize_row(identity, alias)
                canonicalized += 1
        edge["selection_summary"] = summarize_mate_selection_entities((edge.get("selection") or {}).get("entities") or [])

    graph.setdefault("summary", {})["mate_selection_canonicalization_summary"] = {
        "status": "ok",
        "alias_count": len(alias_map),
        "canonicalized_count": canonicalized,
        "canonical_id_policy": "mate point/edge/face selection IDs use canonical B-rep topology IDs; original SolidWorks selection IDs are kept in solidworks_selection_id_original.",
    }
    return {"canonicalized_count": canonicalized, "alias_count": len(alias_map)}


def undo_low_confidence_mate_selection_canonicalization(graph: dict[str, Any]) -> dict[str, Any]:
    restored = 0

    def restore_row(row: dict[str, Any]) -> bool:
        canon = row.get("canonicalization") or {}
        if canon.get("status") != "canonicalized_low_confidence":
            return False
        original_id = row.get("solidworks_selection_id_original") or canon.get("from_selection_id")
        if not original_id:
            return False
        entity_kind = str(row.get("entity_kind") or row.get("entity_type") or "")
        row["selection_id"] = original_id
        row["raw_selection_id"] = original_id
        row["raw_selection_id_source"] = "solidworks_selection_persistent_ref_hash"
        row["selection_id"] = None
        row["selection_id_source"] = None
        row["display_id"] = original_id
        row["display_id_source"] = "solidworks_selection_persistent_ref_hash"
        row["selection_surface_id"] = None
        row["brep_topology_id"] = None
        row["topology_selection_id"] = None
        row["selection_topology_id"] = None
        if entity_kind == "face":
            row["face_id"] = None
        elif entity_kind == "edge":
            row["edge_id"] = None
        elif entity_kind == "vertex":
            row["vertex_id"] = None
        row["brep_mapping_status"] = "unmatched_low_confidence_candidate_rejected"
        row["canonicalization"] = {
            "status": "not_canonicalized_low_confidence",
            "selection_id": original_id,
            "rejected_candidate_topology_id": canon.get("to_brep_topology_id"),
            "reason": canon.get("match_rejected_reason") or "low_confidence_geometry_fallback",
            "candidate_plane_distance_mm": canon.get("candidate_plane_distance_mm"),
            "candidate_normal_delta": canon.get("candidate_normal_delta"),
            "candidate_centroid_distance_mm": canon.get("candidate_centroid_distance_mm"),
        }
        match_status = row.setdefault("match_status", {})
        if isinstance(match_status, dict):
            match_status.update({
                "final_match": False,
                "match_method": "unmatched_low_confidence_candidate_rejected",
                "match_confidence": 0.0,
                "canonicalization_low_confidence": False,
                "rejected_candidate_topology_id": canon.get("to_brep_topology_id"),
            })
        return True

    for edge in graph.get("edges", []) or []:
        if edge.get("relation") != "mate" and edge.get("assembly_relation") != "assembly:mate":
            continue
        for entity in ((edge.get("selection") or {}).get("entities") or []):
            if restore_row(entity):
                identity = entity.get("selection_identity")
                if isinstance(identity, dict):
                    restore_row(identity)
                restored += 1
        edge["selection_summary"] = summarize_mate_selection_entities((edge.get("selection") or {}).get("entities") or [])
    graph.setdefault("summary", {})["low_confidence_canonicalization_restore_summary"] = {
        "restored_count": restored,
        "policy": "Low-confidence geometry fallback candidates are not used as mate point/edge/face IDs.",
    }
    return {"restored_count": restored}


def sw_export_phase(name: str) -> None:
    print(f"[SW_EXPORT_PHASE] {time.strftime('%Y-%m-%d %H:%M:%S')} {name}", flush=True)


def safe_print_json(data: Any) -> None:
    print(json.dumps(data, ensure_ascii=True, indent=2), flush=True)


def export_component_meshes_and_pose_spec(
    sw: Any,
    graph: dict[str, Any],
    out_dir: Path,
    export_brep_packages: bool = True,
    export_component_steps: bool = True,
) -> dict[str, Any]:
    mesh_dir = out_dir / "component_meshes"
    geometry_dir = out_dir / "component_geometry"
    component_mates_by_id: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for edge in graph.get("edges", []) or []:
        if edge.get("relation") != "mate" and edge.get("assembly_relation") != "assembly:mate":
            continue
        mate_row = {
            "mate_id": edge.get("id"),
            "mate_name_raw": edge.get("mate_name_raw"),
            "solidworks_tree_display": edge.get("solidworks_tree_display"),
            "solidworks_type": edge.get("solidworks_type"),
            "mate_category": edge.get("mate_category"),
            "selection_summary": edge.get("selection_summary"),
            "feature_history_path": edge.get("feature_history_path"),
            "feature_history_path_text": edge.get("feature_history_path_text"),
            "connected_component_ids": edge.get("component_ids"),
            "connected_component_names_raw": edge.get("connected_component_names_raw"),
            "source": edge.get("source"),
            "target": edge.get("target"),
        }
        for comp_id in edge.get("component_ids") or []:
            component_mates_by_id[str(comp_id)].append(mate_row)
    by_component_path: dict[str, dict[str, Any]] = {}
    part_geometries: list[dict[str, Any]] = []
    spec_components: list[dict[str, Any]] = []
    timings: list[dict[str, Any]] = []
    stats = Counter()
    component_nodes = [node for node in graph.get("nodes", []) or [] if node.get("node_type") == "component"]
    total_components = len(component_nodes)
    for idx, node in enumerate(component_nodes, 1):
        if node.get("node_type") != "component":
            continue
        if idx == 1 or idx % 5 == 0 or idx == total_components:
            sw_export_phase(f"component_mesh {idx}/{total_components} {node.get('id')}")
        t0 = time.time()
        comp_path = str(node.get("component_path") or "")
        referenced_configuration = str(node.get("referenced_configuration") or "")
        mesh_payload: dict[str, Any] = {"mesh_status": "component_path_missing"}
        if comp_path and Path(comp_path).exists():
            key = f"{comp_path.lower()}|{referenced_configuration}"
            cached = by_component_path.get(key)
            if cached and cached.get("mesh_coordinate_frame") != "assembly_context_export":
                mesh_payload = {**cached, "mesh_reused": True}
                stats["reused"] += 1
            else:
                part_id = f"p{len(part_geometries) + 1:05d}"
                part_name = ascii_slug(Path(comp_path).stem, "part")
                mesh_name = f"{part_id}_{part_name}.stl"
                step_name = f"{part_id}_{part_name}.step"
                mesh_path = mesh_dir / mesh_name
                step_path = geometry_dir / step_name
                model_doc = None
                mesh_actual_path: Path | None = None
                step_ok = False
                bbox_payload: dict[str, Any] = {}
                try:
                    errors = win32com.client.VARIANT(pythoncom.VT_BYREF | pythoncom.VT_I4, 0)
                    warnings = win32com.client.VARIANT(pythoncom.VT_BYREF | pythoncom.VT_I4, 0)
                    model_doc = sw.OpenDoc6(comp_path, document_type_for_path(comp_path), SW_OPEN_SILENT, "", errors, warnings)
                    if model_doc is not None:
                        try:
                            doc_title = call(model_doc, "GetTitle")
                            if doc_title:
                                sw.ActivateDoc3(doc_title, False, 0, win32com.client.VARIANT(pythoncom.VT_BYREF | pythoncom.VT_I4, 0))
                        except Exception:
                            pass
                        if referenced_configuration:
                            try:
                                call(model_doc, "ShowConfiguration2", referenced_configuration)
                            except Exception:
                                pass
                        try:
                            call(model_doc, "EditRebuild3")
                        except Exception:
                            pass
                        mesh_actual_path = save_model_mesh_stl(model_doc, mesh_path, preferred_token=str(node.get("component_name_raw") or ""))
                        bbox_payload = mesh_bbox_correction_payload(mesh_actual_path, model_part_box_mm(model_doc))
                        if export_component_steps:
                            step_ok = save_model_step(model_doc, step_path, sw=sw)
                except Exception as exc:
                    mesh_payload["mesh_error"] = repr(exc)
                finally:
                    if model_doc is not None:
                        try:
                            sw.CloseDoc(model_doc.GetTitle())
                        except Exception:
                            pass
                mesh_payload = {
                    **mesh_payload,
                    **bbox_payload,
                    "part_id": part_id,
                    "mesh_status": "ok" if mesh_actual_path else "failed",
                    "mesh_path": str(mesh_actual_path) if mesh_actual_path else None,
                    "mesh_relative_path": f"component_meshes/{mesh_actual_path.name}" if mesh_actual_path else None,
                    "mesh_coordinate_frame": "assembly_context_export" if mesh_actual_path and mesh_actual_path.name.lower() != mesh_name.lower() else "part_local",
                    "step_status": "ok" if step_ok else ("skipped" if not export_component_steps else "failed"),
                    "step_path": str(step_path) if step_ok else None,
                    "step_relative_path": f"component_geometry/{step_name}" if step_ok else None,
                }
                by_component_path[key] = mesh_payload
                part_geometries.append({
                    "part_id": part_id,
                    "part_name": part_name,
                    "part_name_raw": Path(comp_path).stem,
                    "source_part_path": comp_path,
                    "referenced_configuration": referenced_configuration,
                    "mesh_file": mesh_payload.get("mesh_relative_path"),
                    "mesh_path": mesh_payload.get("mesh_path"),
                    "mesh_status": mesh_payload.get("mesh_status"),
                    "mesh_coordinate_frame": mesh_payload.get("mesh_coordinate_frame"),
                    "mesh_local_bbox_mm": mesh_payload.get("mesh_local_bbox_mm"),
                    "mesh_export_bbox_mm": mesh_payload.get("mesh_export_bbox_mm"),
                    "mesh_coordinate_correction_mm": mesh_payload.get("mesh_coordinate_correction_mm"),
                    "mesh_coordinate_correction_reason": mesh_payload.get("mesh_coordinate_correction_reason"),
                    "step_file": mesh_payload.get("step_relative_path"),
                    "step_path": mesh_payload.get("step_path"),
                    "step_status": mesh_payload.get("step_status"),
                    "mesh_unit": "mm",
                    "brep_unit": "mm",
                    "unit": "mm",
                    "geometry_role": "unique_part_geometry",
                })
                stats["ok" if mesh_actual_path else "failed"] += 1
        else:
            stats["component_path_missing"] += 1
        node.update(mesh_payload)
        pose = sw_transform_to_pose(node.get("transform"))
        spec_components.append({
            "id": node.get("id"),
            "component_id": node.get("id"),
            "part_id": mesh_payload.get("part_id"),
            "name": node.get("component_name_raw") or node.get("component_name"),
            "component_name": node.get("component_name"),
            "component_name_raw": node.get("component_name_raw"),
            "component_path": comp_path,
            "hidden": node.get("hidden"),
            "suppressed": node.get("suppressed"),
            "fixed": node.get("fixed"),
            "component_display_order": node.get("component_display_order") or node.get("instance_index"),
            "component_id_source": node.get("component_id_source") or graph.get("summary", {}).get("component_id_source"),
            "component_mates": component_mates_by_id.get(str(node.get("id")), []),
            "mesh": mesh_payload.get("mesh_relative_path"),
            "mesh_path": mesh_payload.get("mesh_path"),
            "mesh_status": mesh_payload.get("mesh_status"),
            "mesh_reused": bool(mesh_payload.get("mesh_reused", False)),
            "mesh_coordinate_frame": mesh_payload.get("mesh_coordinate_frame"),
            "mesh_local_bbox_mm": mesh_payload.get("mesh_local_bbox_mm"),
            "mesh_export_bbox_mm": mesh_payload.get("mesh_export_bbox_mm"),
            "mesh_coordinate_correction_mm": mesh_payload.get("mesh_coordinate_correction_mm"),
            "mesh_coordinate_correction_reason": mesh_payload.get("mesh_coordinate_correction_reason"),
            "mesh_unit": "mm",
            "pose_unit": "mm",
            "transform": pose,
        })
        elapsed = round(time.time() - t0, 3)
        node["component_export_elapsed_sec"] = elapsed
        timings.append({"component_id": node.get("id"), "component_name_raw": node.get("component_name_raw"), "elapsed_sec": elapsed, "mesh_status": mesh_payload.get("mesh_status"), "mesh_reused": mesh_payload.get("mesh_reused", False)})
        if idx == 1 or idx % 5 == 0 or idx == total_components:
            sw_export_phase(f"component_mesh_done {idx}/{total_components} {node.get('id')} {elapsed}s {mesh_payload.get('mesh_status')}")
    spec = {
        "schema": "sw_assembly_groundtruth_scene.v1",
        "unit": "mm",
        "mesh_unit": "mm",
        "pose_unit": "mm",
        "world_frame": "assembly_root",
        "geometry_table": "part_geometries",
        "instance_table": "components",
        "part_geometries": part_geometries,
        "components": spec_components,
        "render_outputs": {},
        "timings": timings,
    }
    sw_export_phase("render_assembly_groundtruth_scene")
    render_outputs = render_assembly_groundtruth_scene(spec, out_dir)
    sw_export_phase("render_assembly_interactive_html")
    interactive_outputs = render_assembly_interactive_html(spec, out_dir)
    spec["render_outputs"] = {**(render_outputs or {}), "interactive": interactive_outputs}
    spec_path = out_dir / "assembly_pose_spec.json"
    sw_export_phase("write_assembly_pose_spec")
    spec_path.write_text(json.dumps(spec, ensure_ascii=False, indent=2), encoding="utf-8")
    scene_path = out_dir / "assembly_groundtruth_scene.json"
    scene_path.write_text(json.dumps(spec, ensure_ascii=False, indent=2), encoding="utf-8")
    if export_brep_packages:
        sw_export_phase("export_component_brep_packages")
        brep_package_manifest = export_component_brep_packages(graph, out_dir)
        sw_export_phase("canonicalize_mate_selection_ids")
        canonicalization = canonicalize_mate_selection_ids_from_component_packages(graph, out_dir)
        if canonicalization.get("canonicalized_count"):
            sw_export_phase("reexport_component_brep_packages_after_canonicalize")
            brep_package_manifest = export_component_brep_packages(graph, out_dir)
    else:
        sw_export_phase("skip_component_brep_packages")
        brep_package_manifest = mark_component_brep_packages_skipped(graph, "disabled_for_mesh_only_stage1")
    graph.setdefault("summary", {})["component_mesh_summary"] = dict(stats)
    graph.setdefault("summary", {})["component_brep_package_manifest"] = brep_package_manifest.get("package_dir")
    graph.setdefault("summary", {})["component_export_timing"] = {
        "component_count": len(timings),
        "total_sec": round(sum(row["elapsed_sec"] for row in timings), 3),
        "avg_sec": round(sum(row["elapsed_sec"] for row in timings) / len(timings), 3) if timings else 0.0,
        "rows": timings,
    }
    graph.setdefault("summary", {})["assembly_pose_spec"] = str(spec_path)
    graph.setdefault("summary", {})["assembly_groundtruth_scene"] = str(scene_path)
    return spec


def mark_component_brep_packages_skipped(graph: dict[str, Any], reason: str) -> dict[str, Any]:
    summary = {
        "status": "skipped",
        "reason": reason,
        "package_dir": None,
        "manifest": None,
    }
    for node in graph.get("nodes", []) or []:
        if node.get("node_type") == "component":
            node["component_brep_package"] = {"status": "skipped", "reason": reason}
    graph.setdefault("summary", {})["component_brep_package_summary"] = summary
    return summary


def attach_component_thumbnails(sw: Any, graph: dict[str, Any], out_dir: Path) -> dict[str, Any]:
    image_dir = out_dir / "component_images"
    by_component_path: dict[str, dict[str, Any]] = {}
    stats = Counter()
    for node in graph.get("nodes", []) or []:
        if node.get("node_type") != "component":
            continue
        comp_path = str(node.get("component_path") or "")
        if not comp_path or not Path(comp_path).exists():
            node["thumbnail_status"] = "component_path_missing"
            stats["component_path_missing"] += 1
            continue
        key = comp_path.lower()
        cached = by_component_path.get(key)
        if cached:
            node.update(cached)
            node["thumbnail_reused"] = True
            stats["reused"] += 1
            continue
        image_name = f"{node.get('id')}_{ascii_slug(Path(comp_path).stem, 'component')}.png"
        image_path = image_dir / image_name
        model_doc = None
        ok = False
        try:
            errors = win32com.client.VARIANT(pythoncom.VT_BYREF | pythoncom.VT_I4, 0)
            warnings = win32com.client.VARIANT(pythoncom.VT_BYREF | pythoncom.VT_I4, 0)
            model_doc = sw.OpenDoc6(comp_path, document_type_for_path(comp_path), SW_OPEN_SILENT, "", errors, warnings)
            if model_doc is not None:
                try:
                    sw.ActivateDoc3(Path(comp_path).name, False, 0, win32com.client.VARIANT(pythoncom.VT_BYREF | pythoncom.VT_I4, 0))
                except Exception:
                    pass
                ok = save_model_thumbnail(sw, model_doc, image_path)
        except Exception as exc:
            node["thumbnail_error"] = repr(exc)
        finally:
            if model_doc is not None:
                try:
                    sw.CloseDoc(model_doc.GetTitle())
                except Exception:
                    pass
        payload = {
            "thumbnail_status": "ok" if ok else "failed",
            "thumbnail_path": str(image_path) if ok else None,
            "thumbnail_relative_path": f"component_images/{image_name}" if ok else None,
        }
        node.update(payload)
        by_component_path[key] = payload
        stats["ok" if ok else "failed"] += 1
    graph.setdefault("summary", {})["component_thumbnail_summary"] = dict(stats)
    return graph


def relink_existing_component_thumbnails(graph: dict[str, Any], out_dir: Path) -> dict[str, Any]:
    """Keep graph component nodes image-backed when thumbnails already exist on disk."""
    image_dir = out_dir / "component_images"
    image_dir.mkdir(parents=True, exist_ok=True)
    stats = Counter()
    search_dirs = [
        image_dir,
        out_dir / "component_images_generated",
        out_dir.parent / "level1_default" / "component_images",
        out_dir.parent / "level1_default" / "component_images_generated",
        out_dir.parent / "level1_default_fixed" / "component_images",
        out_dir.parent / "level1_default_fixed" / "component_images_generated",
    ]
    available: list[Path] = []
    seen_paths: set[str] = set()
    for directory in search_dirs:
        if not directory.exists():
            continue
        for image_path in sorted(directory.glob("*.png")):
            resolved = str(image_path.resolve()).lower()
            if resolved in seen_paths:
                continue
            seen_paths.add(resolved)
            available.append(image_path)
    images_by_slug: dict[str, Path] = {}
    for image_path in available:
        stem = image_path.stem.lower()
        images_by_slug[stem] = image_path
        # Files are normally c00001_part-name.png; index by the part-name tail too.
        if "_" in stem:
            images_by_slug[stem.split("_", 1)[1]] = image_path
    by_component_path: dict[str, dict[str, Any]] = {}
    for node in graph.get("nodes", []) or []:
        if node.get("node_type") != "component":
            continue
        comp_path = str(node.get("component_path") or "")
        key = comp_path.lower()
        cached = by_component_path.get(key)
        if cached:
            node.update(cached)
            node["thumbnail_reused"] = True
            stats["reused"] += 1
            continue
        slug = ascii_slug(Path(comp_path).stem if comp_path else str(node.get("component_name_raw") or ""), "component").lower()
        raw_slug = ascii_slug(str(node.get("component_name_raw") or ""), "component").lower()
        candidates = [
            images_by_slug.get(f"{str(node.get('id') or '').lower()}_{slug}"),
            images_by_slug.get(f"{str(node.get('id') or '').lower()}_{raw_slug}"),
            images_by_slug.get(slug),
            images_by_slug.get(raw_slug),
        ]
        image_path = next((p for p in candidates if p is not None and p.exists()), None)
        if image_path is None:
            node["thumbnail_status"] = "missing_existing_thumbnail"
            stats["missing_existing_thumbnail"] += 1
            continue
        local_name = f"{str(node.get('id') or 'component').lower()}_{ascii_slug(Path(image_path).stem, 'component')}.png"
        local_path = image_dir / local_name
        if image_path.resolve() != local_path.resolve():
            try:
                shutil.copy2(image_path, local_path)
                stats["copied_existing_thumbnail"] += 1
            except Exception as exc:
                node["thumbnail_copy_error"] = repr(exc)
                local_path = image_path
        payload = {
            "thumbnail_status": "relinked_existing",
            "thumbnail_path": str(local_path),
            "thumbnail_relative_path": f"component_images/{local_path.name}" if local_path.parent.resolve() == image_dir.resolve() else str(local_path),
        }
        node.update(payload)
        if key:
            by_component_path[key] = payload
        stats["relinked_existing"] += 1
    status = "relinked_existing" if stats.get("relinked_existing") or stats.get("reused") else "skipped_no_existing_images"
    graph.setdefault("summary", {})["component_thumbnail_summary"] = {"status": status, **dict(stats)}
    return graph


def skipped_export_record(path: Path, out_dir: Path, started: float, started_at: str, reason: str, extra: dict[str, Any] | None = None) -> dict[str, Any]:
    assembly_name = ascii_slug(path.stem, "assembly")
    out_dir.mkdir(parents=True, exist_ok=True)
    status = {
        "success": False,
        "skipped": True,
        "skip_reason": reason,
        "started_at": started_at,
        "ended_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        "elapsed_sec": round(time.time() - started, 3),
        "solidworks_opened": True,
        "error": None,
    }
    if extra:
        status.update(extra)
    record = {
        "schema": "sw_assembly_graph_dataset_record.v1",
        "assembly_id": f"{assembly_name}_{stable_hash(str(path.resolve()))}",
        "assembly_name": assembly_name,
        "assembly_name_raw": path.stem,
        "source": {"assembly_path": str(path)},
        "dependency_graph": {"nodes": [], "edges": [], "summary": dict(extra or {})},
        "export_status": status,
    }
    json_path = out_dir / f"{assembly_name}.assembly_graph.json"
    json_path.write_text(json.dumps(record, ensure_ascii=False, indent=2), encoding="utf-8")
    record["output"] = {"json": str(json_path), "html": None}
    return record


def has_extractable_feature_tree(model: Any) -> bool:
    try:
        first = call(model, "FirstFeature") or call(model, "IFirstFeature")
        return first is not None
    except Exception:
        return False


def export_assembly(
    path: Path,
    out_dir: Path,
    topology_mode: str = "full",
    max_topology_entities: int = 0,
    assembly_ref_mode: str = "off",
    standard_part_topology_limit: int = 300,
    reuse_duplicate_topology: bool = True,
    export_thumbnails: bool = True,
    export_groundtruth_scene: bool = True,
    export_brep_packages: bool = True,
    export_component_steps: bool = True,
    max_visible_components: int = 0,
) -> dict[str, Any]:
    started = time.time()
    started_at = time.strftime("%Y-%m-%d %H:%M:%S")
    pythoncom.CoInitialize()
    sw = None
    model = None
    dialog_watchdog = SolidWorksDialogWatchdog().start()
    dialog_watchdog_summary: dict[str, Any] | None = None
    reference_search_report: dict[str, Any] | None = None
    try:
        try:
            sw_export_phase("dispatch_solidworks")
            sw = win32com.client.DispatchEx("SldWorks.Application")
        except Exception:
            sw = win32com.client.Dispatch("SldWorks.Application")
        try:
            sw.Visible = False
        except Exception:
            pass
        try:
            sw.UserControl = False
        except Exception:
            pass
        try:
            sw.CommandInProgress = True
        except Exception:
            pass
        reference_search_report = configure_solidworks_reference_search(sw, path)
        ok_methods = sum(1 for row in reference_search_report.get("attempts", []) if row.get("ok"))
        sw_export_phase(f"configure_reference_search_done ok_methods={ok_methods}")
        sw_export_phase("open_assembly")
        model = open_assembly(sw, path)
        sw_export_phase("check_feature_tree")
        if not has_extractable_feature_tree(model):
            dialog_watchdog_summary = dialog_watchdog.stop()
            return skipped_export_record(
                path,
                out_dir,
                started,
                started_at,
                "feature_tree_not_extractable",
                {"solidworks_dialog_watchdog": dialog_watchdog_summary},
            )
        sw_export_phase("collect_components_precheck")
        pre_nodes, _pre_sig, _pre_name, _pre_comp = collect_components_from_model(model)
        visible_pre_nodes = [n for n in pre_nodes if not bool(n.get("hidden") or n.get("suppressed") or n.get("is_hidden") or n.get("is_suppressed"))]
        visible_component_count = len(visible_pre_nodes)
        if max_visible_components and max_visible_components > 0 and visible_component_count > max_visible_components:
            dialog_watchdog_summary = dialog_watchdog.stop()
            return skipped_export_record(
                path,
                out_dir,
                started,
                started_at,
                "visible_component_count_gt_limit",
                {
                    "visible_component_count": visible_component_count,
                    "max_visible_components": max_visible_components,
                    "solidworks_dialog_watchdog": dialog_watchdog_summary,
                },
            )
        sw_export_phase("export_direct_assembly_mesh")
        direct_assembly_mesh = export_direct_assembly_mesh(model, out_dir)
        sw_export_phase("export_direct_assembly_step")
        direct_assembly_step = export_direct_assembly_step(sw, model, out_dir)
        sw_export_phase("build_assembly_graph")
        graph = build_assembly_graph(
            model,
            topology_mode=topology_mode,
            max_topology_entities=max_topology_entities,
            assembly_ref_mode=assembly_ref_mode,
            standard_part_topology_limit=standard_part_topology_limit,
            reuse_duplicate_topology=reuse_duplicate_topology,
        )
        sw_export_phase("resolve_missing_component_paths")
        graph = resolve_missing_component_paths(graph, path)
        if export_thumbnails:
            sw_export_phase("attach_component_thumbnails")
            graph = attach_component_thumbnails(sw, graph, out_dir)
        else:
            graph = relink_existing_component_thumbnails(graph, out_dir)
        graph.setdefault("summary", {})["direct_assembly_mesh_export"] = direct_assembly_mesh
        graph.setdefault("summary", {})["direct_assembly_step_export"] = direct_assembly_step
        if export_groundtruth_scene:
            sw_export_phase("export_component_meshes_and_pose_spec")
            export_component_meshes_and_pose_spec(
                sw,
                graph,
                out_dir,
                export_brep_packages=export_brep_packages,
                export_component_steps=export_component_steps,
            )
        else:
            graph.setdefault("summary", {})["component_mesh_summary"] = {"status": "skipped"}
            graph.setdefault("summary", {})["assembly_groundtruth_scene"] = None
        assembly_name = ascii_slug(path.stem, "assembly")
        record = {
            "schema": "sw_assembly_graph_dataset_record.v1",
            "assembly_id": f"{assembly_name}_{stable_hash(str(path.resolve()))}",
            "assembly_name": assembly_name,
            "assembly_name_raw": path.stem,
            "source": {"assembly_path": str(path)},
            "dependency_graph": graph,
            "export_status": {
                "success": True,
                "topology_mode": topology_mode,
                "max_topology_entities": max_topology_entities,
                "assembly_ref_mode": assembly_ref_mode,
                "started_at": started_at,
                "ended_at": time.strftime("%Y-%m-%d %H:%M:%S"),
                "elapsed_sec": round(time.time() - started, 3),
                "solidworks_opened": True,
                "saved_before_close": False,
                "closed_document": True,
                "quit_solidworks": True,
                "export_thumbnails": export_thumbnails,
                "export_groundtruth_scene": export_groundtruth_scene,
                "export_brep_packages": export_brep_packages,
                "export_component_steps": export_component_steps,
                "solidworks_dialog_watchdog": dialog_watchdog_summary or dialog_watchdog.summary(),
                "solidworks_reference_search": reference_search_report,
                "error": None,
            },
            "command_counts": {
                "component": graph["summary"]["node_type_counts"].get("component", 0),
                "assembly_reference": graph["summary"]["node_type_counts"].get("assembly_reference", 0),
                "dependency": graph["summary"].get("dependency_edge_count", 0),
                "mate": graph["summary"].get("mate_edge_count", 0),
            },
        }
        out_dir.mkdir(parents=True, exist_ok=True)
        json_path = out_dir / f"{assembly_name}.assembly_graph.json"
        html_path = out_dir / f"{assembly_name}.assembly_graph.html"
        output_record = compact_persistent_references_for_output(record)
        sw_export_phase("write_json_output")
        json_path.write_text(json.dumps(output_record, ensure_ascii=False, indent=2), encoding="utf-8")
        sw_export_phase("write_html_output")
        write_cad_graph_html(output_record, html_path)
        sw_export_phase("write_outputs_done")
        output_record["output"] = {"json": str(json_path), "html": str(html_path)}
        return output_record
    finally:
        if sw is not None:
            try:
                sw.CommandInProgress = False
            except Exception:
                pass
            save_close_quit_solidworks(sw, model)
        try:
            dialog_watchdog_summary = dialog_watchdog.stop()
        except Exception:
            pass
        try:
            pythoncom.CoUninitialize()
        except Exception:
            pass


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument("assembly", type=Path)
    parser.add_argument("--out", type=Path, default=Path("assembly_graph_probe"))
    parser.add_argument("--topology-mode", choices=["full", "bounded", "mate_only"], default="full")
    parser.add_argument("--max-topology-entities", type=int, default=0)
    parser.add_argument("--assembly-ref-mode", choices=["off", "selected", "all"], default="off")
    parser.add_argument("--standard-part-topology-limit", type=int, default=300, help="For validation, use 0 to disable standard-part downgrade and export true full B-Rep")
    parser.add_argument("--no-reuse-duplicate-topology", action="store_true", help="Export topology independently for every component instance; slower but avoids duplicate-instance assembly-coordinate/ref reuse")
    parser.add_argument("--no-thumbnails", action="store_true", help="Skip per-component PNG thumbnails")
    parser.add_argument("--no-groundtruth-scene", action="store_true", help="Skip component STL/scene-spec export")
    parser.add_argument("--no-brep-packages", action="store_true", help="Skip per-component B-Rep package export.")
    parser.add_argument("--no-component-step", action="store_true", help="Skip per-component STEP export while keeping component mesh export.")
    parser.add_argument("--max-visible-components", type=int, default=0, help="Skip assemblies above this visible component count before heavy export. 0 disables.")
    args = parser.parse_args()
    result = export_assembly(
        args.assembly,
        args.out,
        topology_mode=args.topology_mode,
        max_topology_entities=args.max_topology_entities,
        assembly_ref_mode=args.assembly_ref_mode,
        standard_part_topology_limit=args.standard_part_topology_limit,
        reuse_duplicate_topology=not args.no_reuse_duplicate_topology,
        export_thumbnails=not args.no_thumbnails,
        export_groundtruth_scene=not args.no_groundtruth_scene,
        export_brep_packages=not args.no_brep_packages,
        export_component_steps=not args.no_component_step,
        max_visible_components=args.max_visible_components,
    )
    if result.get("export_status", {}).get("skipped"):
        safe_print_json({"skipped": True, "export_status": result.get("export_status"), "json": result.get("output", {}).get("json")})
        raise SystemExit(3)
    safe_print_json({
        "json": result["output"]["json"],
        "html": result["output"]["html"],
        "summary": result["dependency_graph"]["summary"],
    })






