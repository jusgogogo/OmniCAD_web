#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Visualize a predicted component-level CAD assembly.

Input:
  sample folder with component_library/c000xx.mesh.obj
  assembly_prediction.json with nodes + undirected edges.components

Output:
  assembly_prediction.html
  predicted_front/top/right/iso.png

Only component-level mapping is implemented. No face/edge/vertex mate mapping.
"""
from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import numpy as np

from cad_assembly_dataset import VIEW_NAMES, view_direction

from cad_assembly_dataset import discover_component_library, load_exported_gt


def read_json(path: Path) -> Any:
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def write_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")


def euler_xyz_to_matrix(rx_deg: float, ry_deg: float, rz_deg: float) -> np.ndarray:
    rx, ry, rz = map(math.radians, [rx_deg, ry_deg, rz_deg])
    cx, sx = math.cos(rx), math.sin(rx)
    cy, sy = math.cos(ry), math.sin(ry)
    cz, sz = math.cos(rz), math.sin(rz)
    Rx = np.array([[1, 0, 0], [0, cx, -sx], [0, sx, cx]], dtype=float)
    Ry = np.array([[cy, 0, sy], [0, 1, 0], [-sy, 0, cy]], dtype=float)
    Rz = np.array([[cz, -sz, 0], [sz, cz, 0], [0, 0, 1]], dtype=float)
    return Rz @ Ry @ Rx


def matrix_to_euler_xyz_deg(R: np.ndarray) -> Tuple[float, float, float]:
    sy = math.sqrt(float(R[0, 0] * R[0, 0] + R[1, 0] * R[1, 0]))
    singular = sy < 1e-9
    if not singular:
        x = math.atan2(float(R[2, 1]), float(R[2, 2]))
        y = math.atan2(float(-R[2, 0]), sy)
        z = math.atan2(float(R[1, 0]), float(R[0, 0]))
    else:
        x = math.atan2(float(-R[1, 2]), float(R[1, 1]))
        y = math.atan2(float(-R[2, 0]), sy)
        z = 0.0
    return tuple(round(math.degrees(v), 6) for v in (x, y, z))


def _as_matrix_array(value: Any) -> Optional[np.ndarray]:
    if not isinstance(value, list):
        return None
    try:
        M = np.asarray(value, dtype=float)
    except Exception:
        return None
    if M.shape == (4, 4) or M.shape == (3, 3):
        return M
    if M.size == 16:
        return M.reshape(4, 4)
    if M.size == 9:
        return M.reshape(3, 3)
    return None


def _vector3_from_any(value: Any, scale: float = 1.0) -> Optional[np.ndarray]:
    if isinstance(value, dict):
        if all(k in value for k in ("x", "y", "z")):
            return np.array([float(value["x"]), float(value["y"]), float(value["z"])], dtype=float) * scale
    if isinstance(value, (list, tuple)) and len(value) >= 3:
        return np.array([float(value[0]), float(value[1]), float(value[2])], dtype=float) * scale
    return None


def sw_array_to_rt(arr: List[float]) -> Tuple[np.ndarray, np.ndarray]:
    """Convert SolidWorks MathTransform ArrayData to mm-space R,t."""
    vals = [float(v) for v in arr]
    R = np.array([
        [vals[0], vals[3], vals[6]],
        [vals[1], vals[4], vals[7]],
        [vals[2], vals[5], vals[8]],
    ], dtype=float)
    t = np.asarray(vals[9:12], dtype=float) * 1000.0
    return R, t


def _rt_from_transform(transform: Any) -> Optional[Tuple[np.ndarray, np.ndarray]]:
    if not isinstance(transform, dict):
        return None
    for key in ("matrix4x4", "matrix_4x4", "matrix", "transform_matrix"):
        M = _as_matrix_array(transform.get(key))
        if M is not None and M.shape == (4, 4):
            return M[:3, :3], M[:3, 3].astype(float)
    R = None
    for key in ("rotation_matrix", "rotation", "R"):
        M = _as_matrix_array(transform.get(key))
        if M is not None and M.shape == (3, 3):
            R = M
            break
    t = None
    for key in ("translation", "position", "t"):
        t = _vector3_from_any(transform.get(key), scale=1.0)
        if t is not None:
            break
    if R is not None and t is not None:
        return R, t
    arr = transform.get("array_data") or transform.get("ArrayData")
    if isinstance(arr, list) and len(arr) >= 12:
        return sw_array_to_rt(arr)
    return None


def pose_to_rt(node: Dict[str, Any]) -> Tuple[np.ndarray, np.ndarray]:
    pose = node.get("pose") or {}
    for tr in (pose.get("transform"), node.get("transform")):
        rt = _rt_from_transform(tr)
        if rt is not None:
            return rt
    p = pose.get("position") or node.get("position") or {}
    o = pose.get("orientation") or node.get("orientation") or {}
    if isinstance(o, dict):
        for key in ("matrix4x4", "matrix_4x4", "matrix", "transform_matrix"):
            M = _as_matrix_array(o.get(key))
            if M is not None and M.shape == (4, 4):
                return M[:3, :3], M[:3, 3].astype(float)
        M = _as_matrix_array(o.get("rotation_matrix"))
        if M is not None and M.shape == (3, 3):
            t0 = _vector3_from_any(p, scale=1.0)
            return M, (t0 if t0 is not None else np.zeros(3, dtype=float))
    t = _vector3_from_any(p, scale=1.0)
    if t is None:
        t = np.zeros(3, dtype=float)
    if isinstance(o, dict) and isinstance(o.get("euler_xyz_deg"), dict):
        e = o.get("euler_xyz_deg") or {}
        return euler_xyz_to_matrix(float(e.get("x", 0)), float(e.get("y", 0)), float(e.get("z", 0))), t
    if not isinstance(o, dict):
        o = {}
    return euler_xyz_to_matrix(float(o.get("rx", 0.0)), float(o.get("ry", 0.0)), float(o.get("rz", 0.0))), t

def parse_obj(path: Path, max_faces: int = 30000) -> Tuple[np.ndarray, np.ndarray]:
    verts: List[List[float]] = []
    faces: List[List[int]] = []
    if not path.exists():
        return np.zeros((0, 3)), np.zeros((0, 3), dtype=int)
    with path.open("r", encoding="utf-8", errors="ignore") as f:
        for line in f:
            if line.startswith("v "):
                parts = line.split()
                if len(parts) >= 4:
                    try:
                        verts.append([float(parts[1]), float(parts[2]), float(parts[3])])
                    except Exception:
                        pass
            elif line.startswith("f "):
                parts = line.split()[1:]
                idxs: List[int] = []
                for token in parts:
                    try:
                        raw = int(token.split("/")[0])
                        idxs.append(raw - 1 if raw > 0 else len(verts) + raw)
                    except Exception:
                        pass
                if len(idxs) >= 3:
                    for k in range(1, len(idxs) - 1):
                        faces.append([idxs[0], idxs[k], idxs[k + 1]])
                        if len(faces) >= max_faces:
                            break
    return np.asarray(verts, dtype=float), np.asarray(faces, dtype=int)


def transform_vertices(V: np.ndarray, R: np.ndarray, t: np.ndarray) -> np.ndarray:
    if V.size == 0:
        return V
    return (R @ V.T).T + t.reshape(1, 3)


def library_obj_map(sample_dir: Path, obj_kind: str) -> Dict[str, Path]:
    lib = discover_component_library(sample_dir, obj_kind=obj_kind, raw_obj_mode="none")
    out: Dict[str, Path] = {}
    for item in lib.get("library", []):
        lib_id = str(item.get("library_id") or item.get("component_id") or "")
        p = Path(item.get("obj_file", ""))
        if not p.is_absolute():
            p = sample_dir / p
        if lib_id and p.exists():
            out[lib_id] = p
    return out


def prediction_nodes(pred: Dict[str, Any]) -> List[Dict[str, Any]]:
    if isinstance(pred.get("nodes"), list):
        return [n for n in pred["nodes"] if isinstance(n, dict)]
    out = []
    for n in pred.get("node_parts") or []:
        if isinstance(n, dict):
            cid = n.get("id") or n.get("component_id")
            out.append({"component_id": cid, "component_name": n.get("name") or n.get("component_name") or cid, "pose": {"position": n.get("position") or {}, "orientation": n.get("orientation") or {}}})
    return out


def color_for_index(i: int) -> str:
    palette = [
        "#1f77b4", "#ff7f0e", "#2ca02c", "#d62728", "#9467bd", "#8c564b",
        "#e377c2", "#7f7f7f", "#bcbd22", "#17becf", "#aec7e8", "#ffbb78",
        "#98df8a", "#ff9896", "#c5b0d5", "#c49c94", "#f7b6d2", "#c7c7c7",
    ]
    return palette[i % len(palette)]


def html_plot(meshes: List[Dict[str, Any]], edges: List[Dict[str, Any]]) -> str:
    data = []
    component_index = []
    all_points = []
    for i, m in enumerate(meshes):
        V = m["vertices"]
        F = m["faces"]
        cid = m["component_id"]
        if V.size == 0 or F.size == 0:
            continue
        p0 = m.get("position") or {}
        o0 = m.get("orientation") or {}
        R0 = euler_xyz_to_matrix(float(o0.get("rx", 0.0)), float(o0.get("ry", 0.0)), float(o0.get("rz", 0.0)))
        t0 = np.array([float(p0.get("x", 0.0)), float(p0.get("y", 0.0)), float(p0.get("z", 0.0))], dtype=float)
        all_points.append(transform_vertices(V, R0, t0))
        center = V.mean(axis=0).round(6).tolist()
        meta = {
            "component_id": cid,
            "component_name": m.get("component_name") or cid,
            "position": m.get("position") or {},
            "orientation": m.get("orientation") or {},
            "trace_index": len(data),
        }
        component_index.append(meta)
        data.append({
            "type": "mesh3d",
            "x": V[:, 0].round(6).tolist(),
            "y": V[:, 1].round(6).tolist(),
            "z": V[:, 2].round(6).tolist(),
            "i": F[:, 0].astype(int).tolist(),
            "j": F[:, 1].astype(int).tolist(),
            "k": F[:, 2].astype(int).tolist(),
            "name": cid,
            "color": m["color"],
            "opacity": 0.82,
            "flatshading": True,
            "meta": meta,
            "hovertemplate": f"{cid}<extra></extra>",
        })
    bounds = None
    if all_points:
        P = np.vstack(all_points)
        mins = P.min(axis=0)
        maxs = P.max(axis=0)
        center = ((mins + maxs) / 2).round(6).tolist()
        bounds = [float(mins[0]), float(mins[1]), float(mins[2]), float(maxs[0]), float(maxs[1]), float(maxs[2])]
    else:
        center = [0.0, 0.0, 0.0]
        bounds = [0.0, 0.0, 0.0, 1.0, 1.0, 1.0]
    return f"""<!doctype html>
<html><head><meta charset='utf-8'><title>CAD assembly prediction</title>
<script src='https://cdn.plot.ly/plotly-2.35.2.min.js'></script>
<style>
body{{margin:0;font-family:Arial,sans-serif;display:flex;height:100vh;color:#222}}
#viewer{{flex:1;min-width:0}} #plot{{width:100%;height:100vh}}
#panel{{width:470px;border-left:1px solid #ddd;padding:14px;overflow:auto;background:#fafafa}}
h2,h3{{margin:0 0 10px 0}} label{{display:block;font-size:12px;color:#444;margin-top:6px}}
input,select{{width:100%;box-sizing:border-box;padding:5px 6px;border:1px solid #d0d0d0;border-radius:4px;font-size:12px}}
button{{margin-top:8px;padding:6px 10px;border:1px solid #bbb;border-radius:4px;background:white;cursor:pointer}}
pre{{white-space:pre-wrap;word-break:break-word;font-size:12px;background:#fff;border:1px solid #e3e3e3;border-radius:6px;padding:10px}}
.hint{{font-size:13px;color:#666;line-height:1.4;margin-bottom:12px}}
</style></head>
<body><div id='viewer'><div id='plot'></div></div>
<div id='panel'>
<h2>Assembly Control</h2>
<div class='hint'>No mate lines are drawn here. Use global rotation/scale for the page view, or edit a component's position/orientation.</div>
<label>global rotation_deg [rx,ry,rz]</label><input id='rotation_deg' value='0,0,0'>
<label>scale / camera zoom</label><input id='scale' value='1'>
<button onclick='applyViewPoseFromInputs()'>Apply View Pose</button>
<button onclick='resetViewPose()'>Reset View</button>
<h3>Component Pose</h3>
<select id='component_select'></select>
<label>position [x,y,z] mm</label><input id='component_position' value='0,0,0'>
<label>orientation [rx,ry,rz] deg</label><input id='component_orientation' value='0,0,0'>
<button onclick='applyComponentPoseFromInputs()'>Apply Component Pose</button>
<button onclick='resetComponentPose()'>Reset Component</button>
<h3>Current View Pose</h3><pre id='view_pose'></pre>
<h3>Selected Component</h3><pre id='component_info'>No component selected.</pre>
<h3>All Components</h3><pre id='all_components'></pre>
</div><script>
const data = {json.dumps(data)};
const componentIndex = {json.dumps(component_index)};
const initialViewPose = {{rotation_deg:[0,0,0], scale:1, internal_rotation_center_mm:{json.dumps(center)}, bounds_mm:{json.dumps(bounds)}}};
let currentViewPose = JSON.parse(JSON.stringify(initialViewPose));
const layout = {{scene: {{aspectmode:'data', xaxis:{{title:'X mm'}}, yaxis:{{title:'Y mm'}}, zaxis:{{title:'Z mm'}}, camera:{{eye:{{x:1.55,y:1.55,z:1.25}}}}}}, margin: {{l:0,r:0,t:30,b:0}}, title:'Predicted CAD Assembly', showlegend:true}};
const config = {{responsive:true, displaylogo:false}};
const originalMeshes = data.map(trace => ({{x: trace.x.slice(), y: trace.y.slice(), z: trace.z.slice()}}));
const componentPoseState = {{}};

function parseTriple(text, fallback) {{
  const values = String(text || '').split(',').map(v => Number(v.trim()));
  if (values.length !== 3 || values.some(v => !Number.isFinite(v))) return fallback.slice();
  return values;
}}
function degToRad(v) {{ return v * Math.PI / 180.0; }}
function rotatePoint(p, center, rotationDeg) {{
  let x = p[0] - center[0], y = p[1] - center[1], z = p[2] - center[2];
  let c = Math.cos(degToRad(rotationDeg[0])), s = Math.sin(degToRad(rotationDeg[0]));
  let y1 = y * c - z * s, z1 = y * s + z * c; y = y1; z = z1;
  c = Math.cos(degToRad(rotationDeg[1])); s = Math.sin(degToRad(rotationDeg[1]));
  let x1 = x * c + z * s; z1 = -x * s + z * c; x = x1; z = z1;
  c = Math.cos(degToRad(rotationDeg[2])); s = Math.sin(degToRad(rotationDeg[2]));
  x1 = x * c - y * s; y1 = x * s + y * c; x = x1; y = y1;
  return [x + center[0], y + center[1], z + center[2]];
}}
function poseToRt(position, orientation) {{
  const p = position || {{}};
  const o = orientation || {{}};
  const t = [Number(p.x)||0, Number(p.y)||0, Number(p.z)||0];
  const rx = degToRad(Number(o.rx)||0), ry = degToRad(Number(o.ry)||0), rz = degToRad(Number(o.rz)||0);
  const cx=Math.cos(rx), sx=Math.sin(rx), cy=Math.cos(ry), sy=Math.sin(ry), cz=Math.cos(rz), sz=Math.sin(rz);
  const R = [
    [cz*cy, cz*sy*sx - sz*cx, cz*sy*cx + sz*sx],
    [sz*cy, sz*sy*sx + cz*cx, sz*sy*cx - cz*sx],
    [-sy, cy*sx, cy*cx]
  ];
  return {{R,t}};
}}
function transformLocalPoint(p, pose) {{
  const rt = poseToRt(pose.position, pose.orientation);
  return [
    rt.R[0][0]*p[0]+rt.R[0][1]*p[1]+rt.R[0][2]*p[2]+rt.t[0],
    rt.R[1][0]*p[0]+rt.R[1][1]*p[1]+rt.R[1][2]*p[2]+rt.t[1],
    rt.R[2][0]*p[0]+rt.R[2][1]*p[1]+rt.R[2][2]*p[2]+rt.t[2]
  ];
}}
function refreshTrace(traceIndex) {{
  const pose = componentPoseState[traceIndex] || {{position:{{x:0,y:0,z:0}}, orientation:{{rx:0,ry:0,rz:0}}}};
  const src = originalMeshes[traceIndex];
  const nx=[], ny=[], nz=[];
  for (let i=0; i<src.x.length; i++) {{
    const local = transformLocalPoint([src.x[i], src.y[i], src.z[i]], pose);
    const global = rotatePoint(local, currentViewPose.internal_rotation_center_mm || [0,0,0], currentViewPose.rotation_deg);
    nx.push(global[0]); ny.push(global[1]); nz.push(global[2]);
  }}
  Plotly.restyle('plot', {{x:[nx], y:[ny], z:[nz]}}, [traceIndex]);
}}
window.setAssemblyViewPose = function(pose) {{
  currentViewPose = {{
    rotation_deg: Array.isArray(pose.rotation_deg) ? pose.rotation_deg.map(Number) : currentViewPose.rotation_deg.slice(),
    scale: Number.isFinite(Number(pose.scale)) ? Number(pose.scale) : currentViewPose.scale,
    internal_rotation_center_mm: initialViewPose.internal_rotation_center_mm,
    bounds_mm: initialViewPose.bounds_mm
  }};
  for (let i=0; i<originalMeshes.length; i++) refreshTrace(i);
  const zoom = Math.max(0.05, Number(currentViewPose.scale) || 1.0);
  Plotly.relayout('plot', {{'scene.camera.eye': {{x:1.55/zoom, y:1.55/zoom, z:1.25/zoom}}}});
  setViewInputs();
  return currentViewPose;
}};
window.setComponentPose = function(componentId, pose) {{
  const item = componentIndex.find(c => c.component_id === componentId);
  if (!item) return null;
  componentPoseState[item.trace_index] = {{
    position: {{x:Number((pose.position||{{}}).x)||0, y:Number((pose.position||{{}}).y)||0, z:Number((pose.position||{{}}).z)||0}},
    orientation: {{rx:Number((pose.orientation||{{}}).rx)||0, ry:Number((pose.orientation||{{}}).ry)||0, rz:Number((pose.orientation||{{}}).rz)||0}}
  }};
  refreshTrace(item.trace_index);
  renderComponentInfo(item);
  return componentPoseState[item.trace_index];
}};
function setViewInputs() {{
  document.getElementById('rotation_deg').value = currentViewPose.rotation_deg.join(',');
  document.getElementById('scale').value = String(currentViewPose.scale);
  document.getElementById('view_pose').textContent = JSON.stringify({{rotation_deg: currentViewPose.rotation_deg, scale: currentViewPose.scale, api:'window.setAssemblyViewPose({{rotation_deg:[rx,ry,rz], scale:s}})'}}, null, 2);
}}
function applyViewPoseFromInputs() {{ return window.setAssemblyViewPose({{rotation_deg:parseTriple(document.getElementById('rotation_deg').value,[0,0,0]), scale:Number(document.getElementById('scale').value)}}); }}
function resetViewPose() {{ return window.setAssemblyViewPose(initialViewPose); }}
function selectedComponent() {{ return componentIndex.find(c => c.component_id === document.getElementById('component_select').value); }}
function renderComponentInfo(item) {{
  if (!item) return;
  const pose = componentPoseState[item.trace_index] || {{position:{{x:0,y:0,z:0}}, orientation:{{rx:0,ry:0,rz:0}}}};
  document.getElementById('component_position').value = [pose.position.x, pose.position.y, pose.position.z].join(',');
  document.getElementById('component_orientation').value = [pose.orientation.rx, pose.orientation.ry, pose.orientation.rz].join(',');
    document.getElementById('component_info').textContent = JSON.stringify({{...item, editable_pose:pose, api:'window.setComponentPose(componentId, {{position:{{x,y,z}}, orientation:{{rx,ry,rz}}}})'}}, null, 2);
}}
function applyComponentPoseFromInputs() {{
  const item = selectedComponent(); if (!item) return null;
  const p = parseTriple(document.getElementById('component_position').value, [0,0,0]);
  const r = parseTriple(document.getElementById('component_orientation').value, [0,0,0]);
  return window.setComponentPose(item.component_id, {{position:{{x:p[0],y:p[1],z:p[2]}}, orientation:{{rx:r[0],ry:r[1],rz:r[2]}}}});
}}
function resetComponentPose() {{
  const item = selectedComponent(); if (!item) return null;
  return window.setComponentPose(item.component_id, {{position:item.position || {{x:0,y:0,z:0}}, orientation:item.orientation || {{rx:0,ry:0,rz:0}}}});
}}
const select = document.getElementById('component_select');
for (const c of componentIndex) {{
  const opt = document.createElement('option'); opt.value = c.component_id; opt.textContent = c.component_id + ' ' + (c.component_name || '');
  select.appendChild(opt);
  componentPoseState[c.trace_index] = {{position:c.position || {{x:0,y:0,z:0}}, orientation:c.orientation || {{rx:0,ry:0,rz:0}}}};
}}
select.addEventListener('change', () => renderComponentInfo(selectedComponent()));
document.getElementById('all_components').textContent = JSON.stringify(componentIndex, null, 2);
setViewInputs();
Plotly.newPlot('plot', data, layout, config).then(function(gd) {{
  for (let i=0; i<originalMeshes.length; i++) refreshTrace(i);
  gd.on('plotly_click', function(evt) {{
    if (!evt || !evt.points || !evt.points.length) return;
    const item = componentIndex.find(c => c.trace_index === evt.points[0].curveNumber);
    if (item) {{ select.value = item.component_id; renderComponentInfo(item); }}
  }});
  renderComponentInfo(selectedComponent());
}});
</script></body></html>"""


def render_png(meshes: List[Dict[str, Any]], out: Path, view: str, edge_color: str = "black") -> None:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from mpl_toolkits.mplot3d.art3d import Poly3DCollection

    fig = plt.figure(figsize=(8, 8), dpi=180)
    ax = fig.add_subplot(111, projection="3d")
    allv = []
    for m in meshes:
        V, F = m["vertices"], m["faces"]
        if V.size == 0 or F.size == 0:
            continue
        allv.append(V)
        if len(F) > 6000:
            step = max(1, len(F) // 6000)
            F2 = F[::step]
        else:
            F2 = F
        tris = [V[f] for f in F2 if max(f) < len(V)]
        coll = Poly3DCollection(tris, facecolor=m["color"], edgecolor=edge_color, linewidths=0.08, alpha=0.9)
        ax.add_collection3d(coll)
    if allv:
        P = np.vstack(allv)
        mins, maxs = P.min(axis=0), P.max(axis=0)
        center = (mins + maxs) / 2
        radius = max((maxs - mins).max() / 2, 1e-6)
        ax.set_xlim(center[0] - radius, center[0] + radius)
        ax.set_ylim(center[1] - radius, center[1] + radius)
        ax.set_zlim(center[2] - radius, center[2] + radius)
    try:
        direction = np.asarray(view_direction(view), dtype=float)
        direction = direction / max(float(np.linalg.norm(direction)), 1e-12)
        elev = float(np.degrees(np.arctan2(direction[2], np.linalg.norm(direction[:2]))))
        azim = float(np.degrees(np.arctan2(direction[1], direction[0])))
        ax.view_init(elev=elev, azim=azim)
    except Exception:
        ax.view_init(elev=25, azim=-45)
    ax.set_axis_off()
    try:
        ax.set_box_aspect((1, 1, 1))
    except Exception:
        pass
    out.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(out, bbox_inches="tight", pad_inches=0.02)
    plt.close(fig)

def visualize(sample_dir: Path, pred_json: Path, out_dir: Path, obj_kind: str = "auto") -> None:
    pred = read_json(pred_json)
    obj_map = library_obj_map(sample_dir, obj_kind)
    html_meshes: List[Dict[str, Any]] = []
    png_meshes: List[Dict[str, Any]] = []
    for idx, n in enumerate(prediction_nodes(pred)):
        cid = str(n.get("component_id"))
        lib_id = str(n.get("library_id") or "")
        p = obj_map.get(lib_id)
        if not p:
            continue
        V, F = parse_obj(p)
        R, t = pose_to_rt(n)
        Vt = transform_vertices(V, R, t)
        pose = n.get("pose") or {}
        rx, ry, rz = matrix_to_euler_xyz_deg(R)
        initial_position = {"x": float(t[0]), "y": float(t[1]), "z": float(t[2])}
        initial_orientation = {"rx": rx, "ry": ry, "rz": rz}
        html_meshes.append({
            "component_id": cid,
            "component_name": n.get("component_name") or n.get("name") or cid,
            "vertices": V,
            "faces": F,
            "color": color_for_index(idx),
            "position": initial_position,
            "orientation": initial_orientation,
        })
        png_meshes.append({
            "component_id": cid,
            "vertices": Vt,
            "faces": F,
            "color": color_for_index(idx),
        })
    out_dir.mkdir(parents=True, exist_ok=True)
    write_text(out_dir / "assembly_prediction.html", html_plot(html_meshes, pred.get("edges") or []))
    for view in VIEW_NAMES:
        render_png(png_meshes, out_dir / f"predicted_{view}.png", view)


def main() -> None:
    ap = argparse.ArgumentParser(description="Render predicted CAD assembly to 3D HTML and projection PNGs.")
    ap.add_argument("sample_dir", type=Path)
    ap.add_argument("prediction_json", type=Path)
    ap.add_argument("--out", type=Path, required=True)
    ap.add_argument("--obj-kind", choices=["mesh", "brep", "auto"], default="mesh")
    # Legacy compatibility
    ap.add_argument("--obj-source", choices=["obj", "brep_obj"], default=None)
    args = ap.parse_args()
    obj_kind = args.obj_kind
    if args.obj_source and args.obj_kind == "auto":
        obj_kind = "brep" if args.obj_source == "brep_obj" else "mesh"
    visualize(args.sample_dir, args.prediction_json, args.out, obj_kind=obj_kind)


if __name__ == "__main__":
    main()
