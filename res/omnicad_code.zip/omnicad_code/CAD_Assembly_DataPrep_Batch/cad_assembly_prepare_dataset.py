﻿#!/usr/bin/env python3
# -*- coding: utf-8 -*-
r"""Robust Stage-A CLI: build a prepared CAD assembly dataset at scale.

This script is intentionally separated from model/API execution. It only runs
front-end data preparation:

  A1. .sldasm or raw SolidWorks exporter output -> temporary Stage1 sample
      via cad_assembly_export_solidworks_sample.py

  A2. temporary Stage1 sample -> prepared experiment sample
      via cad_assembly_prepare_experiment_sample.py

It is designed for large batches: resume, retries, timeouts, atomic writes,
one optional detailed JSON log, and strict validation. Raw
SolidWorks exports and Stage1 samples use a temporary workspace by default and
are removed after the batch. Pass explicit intermediate roots only when those
artifacts need to be retained for diagnosis.

Typical usage:

  # Existing Stage1 samples -> prepared dataset
  python cad_assembly_prepare_dataset.py \
    --stage1-input-root D:\\cad_stage1_dataset \
    --prepared-root D:\\cad_prepared_dataset \
    --workers 4 \
    --resume

  # Raw exporter outputs -> Stage1 -> prepared dataset
  python cad_assembly_prepare_dataset.py \
    --exported-root D:\\raw_sw_exports \
    --stage1-output-root D:\\cad_stage1_dataset \
    --prepared-root D:\\cad_prepared_dataset \
    --workers 4 \
    --resume

  # .sldasm -> Stage1 -> prepared dataset. SolidWorks export is kept sequential.
  python cad_assembly_prepare_dataset.py \
    --sldasm-root D:\\assemblies \
    --stage1-output-root D:\\cad_stage1_dataset \
    --raw-export-root D:\\cad_raw_export \
    --prepared-root D:\\cad_prepared_dataset \
    --resume
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
import queue
import re
import shutil
import subprocess
import sys
import tempfile
import threading
import time
import traceback
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

ROOT = Path(__file__).resolve().parent
VIEW_NAMES = [f"v{i:02d}" for i in range(1, 9)]


def now_text() -> str:
    return time.strftime("%Y-%m-%d %H:%M:%S")


def write_json(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def write_json_atomic(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(f"{path.name}.tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(path)


def read_json(path: Path) -> Any:
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def append_jsonl(path: Path, data: Any, lock: Optional[threading.Lock] = None) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    line = json.dumps(data, ensure_ascii=False)
    if lock:
        with lock:
            with path.open("a", encoding="utf-8", newline="\n") as f:
                f.write(line + "\n")
    else:
        with path.open("a", encoding="utf-8", newline="\n") as f:
            f.write(line + "\n")


def sanitize_name(text: str, max_len: int = 96) -> str:
    text = re.sub(r"[^A-Za-z0-9._-]+", "_", str(text or "")).strip("._-")
    text = re.sub(r"_+", "_", text)
    return (text[:max_len].strip("._-") or "sample")


def sha1_text(text: str, n: int = 8) -> str:
    return hashlib.sha1(text.encode("utf-8", errors="ignore")).hexdigest()[:n]


def safe_rel(path: Path, root: Optional[Path]) -> str:
    if root is None:
        return path.as_posix()
    try:
        return path.resolve().relative_to(root.resolve()).as_posix()
    except Exception:
        return path.as_posix()


def path_from_line(line: str) -> Optional[Path]:
    line = line.lstrip("\ufeff").strip().strip('"')
    if not line or line.startswith("#"):
        return None
    return Path(line)


def read_path_list(path: Optional[Path]) -> List[Path]:
    if not path:
        return []
    out: List[Path] = []
    for line in path.read_text(encoding="utf-8", errors="ignore").splitlines():
        p = path_from_line(line)
        if p is not None:
            out.append(p)
    return out


def unique_paths(paths: Iterable[Path]) -> List[Path]:
    seen: set[str] = set()
    out: List[Path] = []
    for p in paths:
        key = str(p.resolve()) if p.exists() else str(p)
        if key in seen:
            continue
        seen.add(key)
        out.append(p)
    return out


def discover_sldasm(root: Optional[Path], single: Optional[Path], path_list: Optional[Path]) -> List[Path]:
    items: List[Path] = []
    if single:
        if single.exists() and single.is_dir():
            items += sorted(single.rglob("*.sldasm"))
            items += sorted(single.rglob("*.SLDASM"))
        else:
            items.append(single)
    items += read_path_list(path_list)
    if root:
        items += sorted(root.rglob("*.sldasm"))
        items += sorted(root.rglob("*.SLDASM"))
    return unique_paths([p for p in items if p.exists() and p.is_file()])


def looks_like_stage1_sample(p: Path) -> bool:
    return p.is_dir() and (p / "assembly_graph_gt.json").exists()


def discover_stage1(root: Optional[Path], single: Optional[Path], path_list: Optional[Path]) -> List[Path]:
    items: List[Path] = []
    if single:
        items.append(single)
    items += read_path_list(path_list)
    if root:
        if looks_like_stage1_sample(root):
            items.append(root)
        else:
            items += sorted({p.parent for p in root.rglob("assembly_graph_gt.json")})
    return unique_paths([p for p in items if looks_like_stage1_sample(p)])


def looks_like_raw_export_dir(p: Path) -> bool:
    if not p.is_dir():
        return False
    if (p / "assembly_pose_spec.json").exists() or (p / "component_brep_packages" / "manifest.json").exists():
        return True
    for child in p.glob("*.json"):
        if child.name in {"assembly_groundtruth_scene.json", "assembly_pose_spec.json"}:
            continue
        try:
            data = read_json(child)
        except Exception:
            continue
        if isinstance(data, dict) and ("dependency_graph" in data or "node_parts" in data or "nodes" in data):
            return True
    return False


def discover_exported(root: Optional[Path], single: Optional[Path], path_list: Optional[Path]) -> List[Path]:
    items: List[Path] = []
    if single:
        items.append(single)
    items += read_path_list(path_list)
    if root:
        if looks_like_raw_export_dir(root):
            items.append(root)
        else:
            # Depth-limited first, then recursive JSON parents. This avoids scanning
            # every OBJ under a large raw-export root as a candidate.
            for p in sorted(root.iterdir()) if root.exists() else []:
                if looks_like_raw_export_dir(p):
                    items.append(p)
            items += sorted({p.parent for p in root.rglob("*.assembly_graph.json")})
    return unique_paths([p for p in items if p.exists() and p.is_dir()])


def sample_name_for(path: Path, input_root: Optional[Path], name_mode: str) -> str:
    if name_mode == "stem":
        return sanitize_name(path.stem if path.suffix else path.name)
    rel = safe_rel(path, input_root)
    base = path.stem if path.suffix else path.name
    return sanitize_name(f"{base}_{sha1_text(rel)}")


def kill_solidworks_processes() -> Dict[str, Any]:
    cmd = ["taskkill", "/F", "/IM", "SLDWORKS.exe", "/T"]
    try:
        proc = subprocess.run(cmd, text=True, capture_output=True, timeout=30)
        return {"cmd": cmd, "returncode": proc.returncode, "stdout": proc.stdout, "stderr": proc.stderr}
    except Exception as exc:
        return {"cmd": cmd, "returncode": 1, "stderr": repr(exc), "exception": traceback.format_exc()}


def run_cmd(cmd: Sequence[str], timeout_sec: int = 0, cwd: Optional[Path] = None, kill_sw_on_timeout: bool = False) -> Dict[str, Any]:
    start = time.time()
    try:
        proc = subprocess.run(
            list(cmd),
            cwd=str(cwd or ROOT),
            text=True,
            capture_output=True,
            timeout=timeout_sec if timeout_sec and timeout_sec > 0 else None,
        )
        return {
            "cmd": list(cmd),
            "cwd": str(cwd or ROOT),
            "returncode": proc.returncode,
            "stdout": proc.stdout,
            "stderr": proc.stderr,
            "elapsed_sec": round(time.time() - start, 3),
            "timeout_sec": timeout_sec or None,
        }
    except subprocess.TimeoutExpired as exc:
        return {
            "cmd": list(cmd),
            "cwd": str(cwd or ROOT),
            "returncode": 124,
            "stdout": exc.stdout or "",
            "stderr": (exc.stderr or "") + f"\n[TIMEOUT after {timeout_sec}s]",
            "elapsed_sec": round(time.time() - start, 3),
            "timeout_sec": timeout_sec,
            "timeout": True,
            "solidworks_kill": kill_solidworks_processes() if kill_sw_on_timeout else None,
        }
    except Exception as exc:
        return {
            "cmd": list(cmd),
            "cwd": str(cwd or ROOT),
            "returncode": 1,
            "stdout": "",
            "stderr": repr(exc),
            "elapsed_sec": round(time.time() - start, 3),
            "exception": traceback.format_exc(),
        }


def retry_cmd(cmd: Sequence[str], retries: int, timeout_sec: int, retry_sleep_sec: float, kill_sw_on_timeout: bool = False) -> Dict[str, Any]:
    attempts: List[Dict[str, Any]] = []
    total_start = time.time()
    for attempt in range(1, max(1, retries + 1) + 1):
        result = run_cmd(cmd, timeout_sec=timeout_sec, cwd=ROOT, kill_sw_on_timeout=kill_sw_on_timeout)
        result["attempt"] = attempt
        attempts.append(result)
        if result.get("returncode") == 0:
            break
        if attempt < max(1, retries + 1) and retry_sleep_sec > 0:
            time.sleep(retry_sleep_sec)
    final = dict(attempts[-1])
    final["attempts"] = attempts
    final["total_elapsed_sec"] = round(time.time() - total_start, 3)
    return final


def has_all_views(style_dir: Path, allow_missing: bool = False) -> Tuple[bool, List[str]]:
    missing: List[str] = []
    for view in VIEW_NAMES:
        ok = False
        for ext in [".png", ".jpg", ".jpeg", ".webp"]:
            if (style_dir / f"assembly_{view}{ext}").exists():
                ok = True
                break
        if not ok:
            missing.append(view)
    return (allow_missing or not missing), missing


def validate_stage1(stage1: Path, require_reference_obj: bool) -> Dict[str, Any]:
    missing: List[str] = []
    warnings: List[str] = []
    graph = stage1 / "assembly_graph_gt.json"
    if not graph.exists():
        missing.append("assembly_graph_gt.json")
    comp_dir = stage1 / "obj" / "components"
    comp_objs = sorted(comp_dir.glob("*.obj")) if comp_dir.exists() else []
    if not comp_objs:
        missing.append("obj/components/*.obj")
    asm_obj = stage1 / "obj" / "assembly.mesh.obj"
    if require_reference_obj and not asm_obj.exists():
        missing.append("obj/assembly.mesh.obj")
    elif not asm_obj.exists():
        warnings.append("missing_direct_assembly_mesh_obj")
    component_geometry = stage1 / "component_geometry"
    component_steps = sorted(component_geometry.glob("*.step")) + sorted(component_geometry.glob("*.stp")) if component_geometry.exists() else []
    if not component_steps:
        warnings.append("missing_component_step_geometry_for_reference_views")
    return {
        "stage1_sample": str(stage1),
        "component_obj_count": len(comp_objs),
        "component_step_count": len(component_steps),
        "has_component_step_geometry": bool(component_steps),
        "has_assembly_graph_gt": graph.exists(),
        "has_assembly_mesh_obj": asm_obj.exists(),
        "missing": missing,
        "warnings": warnings,
        "ok": not missing,
    }


def validate_prepared(prepared: Path, args: argparse.Namespace) -> Dict[str, Any]:
    missing: List[str] = []
    warnings: List[str] = []
    lib_dir = prepared / "component_library"
    lib_objs = sorted(lib_dir.glob("*.obj")) if lib_dir.exists() else []
    if not lib_objs:
        missing.append("component_library/*.obj")

    # New prepared layout is flat. Keep fallback checks for legacy samples, but
    # report the flat root paths as the required canonical paths.
    gt_json = prepared / "assembly_graph_gt.json"
    legacy_gt_json = prepared / "gt" / "assembly_graph_gt.json"
    if not gt_json.exists() and not legacy_gt_json.exists():
        missing.append("assembly_graph_gt.json")

    mate_graph = prepared / "mate_graph.json"
    legacy_mate_graph = prepared / "graph" / "mate_graph.json"
    if args.require_mate_graph and not mate_graph.exists() and not legacy_mate_graph.exists():
        missing.append("mate_graph.json")

    ref_obj = prepared / "assembly.mesh.obj"
    legacy_ref_obj = prepared / "reference_obj" / "assembly.mesh.obj"
    legacy_obj_ref = prepared / "obj" / "assembly.mesh.obj"
    has_ref_obj = ref_obj.exists() or legacy_ref_obj.exists() or legacy_obj_ref.exists()
    if args.require_reference_obj and not has_ref_obj:
        missing.append("assembly.mesh.obj")
    elif not has_ref_obj:
        warnings.append("missing_assembly_mesh_obj_for_exp_zs_ref_obj_and_exp_zs_mate_graph_ref_obj_img")

    if args.require_views:
        ok_same, miss_same = has_all_views(prepared / "reference_views" / "same_color", allow_missing=args.allow_missing_views)
        ok_color, miss_color = has_all_views(prepared / "reference_views" / "color_by_component", allow_missing=args.allow_missing_views)
        if not ok_same:
            missing += [f"reference_views/same_color/assembly_{v}.png" for v in miss_same]
        if not ok_color:
            missing += [f"reference_views/color_by_component/assembly_{v}.png" for v in miss_color]
        if miss_same and args.allow_missing_views:
            warnings.append(f"missing_same_color_views={miss_same}")
        if miss_color and args.allow_missing_views:
            warnings.append(f"missing_color_by_component_views={miss_color}")
    return {
        "prepared_sample": str(prepared),
        "library_count": len(lib_objs),
        "has_gt_json": gt_json.exists() or legacy_gt_json.exists(),
        "has_mate_graph": mate_graph.exists() or legacy_mate_graph.exists(),
        "has_reference_obj": has_ref_obj,
        "missing": missing,
        "warnings": warnings,
        "ok": not missing,
    }


def remove_if_exists(path: Path) -> None:
    if path.exists():
        if path.is_dir():
            shutil.rmtree(path)
        else:
            path.unlink()


def move_replace(src: Path, dst: Path) -> None:
    remove_if_exists(dst)
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.move(str(src), str(dst))


@dataclass
class WorkItem:
    source_type: str  # sldasm | exported | stage1
    source: Path
    sample_name: str
    stage1_sample: Path
    raw_export_dir: Optional[Path]
    prepared_sample: Path


class DatasetPreparer:
    def __init__(self, args: argparse.Namespace) -> None:
        self.args = args
        self.write_detail_logs = False
        self.log_root = None
        self.lock = threading.Lock()

    def append_record(self, record: Dict[str, Any]) -> None:
        return

    def append_command(self, sample_name: str, stage: str, result: Dict[str, Any]) -> None:
        return

    def stage1_from_sldasm(self, item: WorkItem) -> Tuple[bool, Dict[str, Any]]:
        args = self.args
        target = item.stage1_sample
        out_for_run = target if not args.atomic else args.stage1_output_root / "_tmp" / f"{item.sample_name}_{os.getpid()}_{int(time.time()*1000)}"
        raw = item.raw_export_dir or (args.raw_export_root / item.sample_name)
        if args.force:
            remove_if_exists(out_for_run)
            remove_if_exists(target)
        cmd = [
            sys.executable,
            "-u",
            str(ROOT / "cad_assembly_export_solidworks_sample.py"),
            str(item.source),
            str(out_for_run),
            "--export-work-dir",
            str(raw),
            "--topology-mode",
            args.topology_mode,
        ]
        if args.max_visible_components > 0:
            cmd += ["--max-visible-components", str(args.max_visible_components)]
        if args.export_timeout_sec and args.export_timeout_sec > 60:
            cmd += ["--exporter-timeout-sec", str(max(1, args.export_timeout_sec - 30))]
        if args.exporter:
            cmd += ["--exporter", str(args.exporter)]
        if args.no_overwrite and not args.force:
            cmd.append("--no-overwrite")
        if args.dry_run:
            return True, {"dry_run": True, "cmd": cmd, "stage1_sample": str(target)}
        result = retry_cmd(cmd, args.export_retries, args.export_timeout_sec, args.retry_sleep_sec, kill_sw_on_timeout=args.kill_solidworks_on_timeout)
        self.append_command(item.sample_name, "export_sldasm_to_stage1", result)
        if result.get("returncode") != 0:
            if args.atomic and out_for_run.exists() and not args.keep_failed_temp:
                remove_if_exists(out_for_run)
            return False, result
        if args.atomic and out_for_run != target:
            move_replace(out_for_run, target)
        validation = validate_stage1(target, require_reference_obj=args.require_reference_obj)
        result["stage1_validation"] = validation
        return bool(validation.get("ok")), result

    def stage1_from_exported(self, item: WorkItem) -> Tuple[bool, Dict[str, Any]]:
        args = self.args
        target = item.stage1_sample
        out_for_run = target if not args.atomic else args.stage1_output_root / "_tmp" / f"{item.sample_name}_{os.getpid()}_{int(time.time()*1000)}"
        if args.force:
            remove_if_exists(out_for_run)
            remove_if_exists(target)
        cmd = [
            sys.executable,
            str(ROOT / "cad_assembly_export_solidworks_sample.py"),
            str(out_for_run),
            "--exported-dir",
            str(item.source),
        ]
        if args.no_overwrite and not args.force:
            cmd.append("--no-overwrite")
        if args.dry_run:
            return True, {"dry_run": True, "cmd": cmd, "stage1_sample": str(target)}
        result = retry_cmd(cmd, args.organize_retries, args.organize_timeout_sec, args.retry_sleep_sec)
        self.append_command(item.sample_name, "organize_exported_to_stage1", result)
        if result.get("returncode") != 0:
            if args.atomic and out_for_run.exists() and not args.keep_failed_temp:
                remove_if_exists(out_for_run)
            return False, result
        if args.atomic and out_for_run != target:
            move_replace(out_for_run, target)
        validation = validate_stage1(target, require_reference_obj=args.require_reference_obj)
        result["stage1_validation"] = validation
        return bool(validation.get("ok")), result

    def prepare_from_stage1(self, item: WorkItem) -> Tuple[bool, Dict[str, Any]]:
        args = self.args
        target = item.prepared_sample
        out_for_run = target if not args.atomic else args.prepared_tmp_root / f"{item.sample_name}_{os.getpid()}_{int(time.time()*1000)}"
        if args.force:
            remove_if_exists(out_for_run)
            remove_if_exists(target)
        cmd = [
            sys.executable,
            str(ROOT / "cad_assembly_prepare_experiment_sample.py"),
            str(item.stage1_sample),
            str(out_for_run),
            "--component-obj-frame",
            args.component_obj_frame,
        ]
        if args.keep_solidworks_original:
            cmd.append("--keep-solidworks-original")
        if args.no_overwrite and not args.force:
            cmd.append("--no-overwrite")
        if args.dry_run:
            return True, {"dry_run": True, "cmd": cmd, "prepared_sample": str(target)}
        result = retry_cmd(cmd, args.prepare_retries, args.prepare_timeout_sec, args.retry_sleep_sec)
        self.append_command(item.sample_name, "prepare_stage1_to_dataset", result)
        if result.get("returncode") != 0:
            if args.atomic and out_for_run.exists() and not args.keep_failed_temp:
                remove_if_exists(out_for_run)
            return False, result
        validation = validate_prepared(out_for_run, args)
        result["prepared_validation"] = validation
        if not validation.get("ok"):
            if args.atomic and out_for_run.exists() and not args.keep_failed_temp:
                # Keep validation failures only if requested; otherwise remove to avoid
                # confusing resume checks with partial/corrupt samples.
                remove_if_exists(out_for_run)
            return False, result
        if args.atomic and out_for_run != target:
            move_replace(out_for_run, target)
            validation = validate_prepared(target, args)
            result["prepared_validation_after_move"] = validation
        return True, result

    def should_skip(self, item: WorkItem) -> Optional[Dict[str, Any]]:
        args = self.args
        if not args.resume or args.force:
            return None
        if item.prepared_sample.exists():
            validation = validate_prepared(item.prepared_sample, args)
            if validation.get("ok"):
                return {
                    "sample_name": item.sample_name,
                    "source_type": item.source_type,
                    "source": str(item.source),
                    "stage1_sample": str(item.stage1_sample),
                    "prepared_sample": str(item.prepared_sample),
                    "status": "skipped_resume_prepared_exists",
                    "prepared_validation": validation,
                    "start_time": now_text(),
                    "end_time": now_text(),
                    "runtime_sec": 0.0,
                }
        return None

    def process_one(self, item: WorkItem) -> Dict[str, Any]:
        start = time.time()
        record: Dict[str, Any] = {
            "sample_name": item.sample_name,
            "source_type": item.source_type,
            "source": str(item.source),
            "stage1_sample": str(item.stage1_sample),
            "raw_export_dir": str(item.raw_export_dir) if item.raw_export_dir else None,
            "prepared_sample": str(item.prepared_sample),
            "start_time": now_text(),
        }
        skipped = self.should_skip(item)
        if skipped is not None:
            self.append_record(skipped)
            return skipped
        try:
            if item.source_type == "sldasm":
                ok, result = self.stage1_from_sldasm(item)
                record["export"] = result
                if not ok:
                    if result.get("returncode") == 3:
                        record["status"] = "skipped_exporter_policy"
                    else:
                        record["status"] = "export_failed" if result.get("returncode") != 0 else "stage1_validation_failed"
                    return self.finish(record, start)
            elif item.source_type == "exported":
                ok, result = self.stage1_from_exported(item)
                record["organize_exported"] = result
                if not ok:
                    record["status"] = "organize_exported_failed" if result.get("returncode") != 0 else "stage1_validation_failed"
                    return self.finish(record, start)
            elif item.source_type == "stage1":
                validation = validate_stage1(item.stage1_sample, require_reference_obj=self.args.require_reference_obj)
                record["stage1_validation"] = validation
                if not validation.get("ok") and self.args.strict_stage1:
                    record["status"] = "stage1_validation_failed"
                    return self.finish(record, start)
            else:
                record["status"] = "bad_source_type"
                return self.finish(record, start)

            ok, prep_result = self.prepare_from_stage1(item)
            record["prepare"] = prep_result
            if not ok:
                record["status"] = "prepare_failed" if prep_result.get("returncode") != 0 else "prepared_validation_failed"
            else:
                validation = prep_result.get("prepared_validation_after_move") or prep_result.get("prepared_validation") or {}
                record["status"] = "ok_with_warnings" if validation.get("warnings") else "ok"
        except Exception as exc:
            record["status"] = "exception"
            record["error"] = repr(exc)
            record["traceback"] = traceback.format_exc()
        return self.finish(record, start)

    def finish(self, record: Dict[str, Any], start: float) -> Dict[str, Any]:
        record["end_time"] = now_text()
        record["runtime_sec"] = round(time.time() - start, 3)
        self.append_record(record)
        return record


def build_work_items(args: argparse.Namespace) -> Tuple[str, List[WorkItem]]:
    args.prepared_root.mkdir(parents=True, exist_ok=True)
    args.stage1_output_root.mkdir(parents=True, exist_ok=True)
    if args.raw_export_root:
        args.raw_export_root.mkdir(parents=True, exist_ok=True)

    stage1_inputs = discover_stage1(args.stage1_input_root, args.stage1_sample, args.stage1_list)
    exported_inputs = discover_exported(args.exported_root, args.exported_dir, args.exported_list)
    sldasm_inputs = discover_sldasm(args.sldasm_root, args.sldasm, args.sldasm_list)

    non_empty = [("stage1", stage1_inputs), ("exported", exported_inputs), ("sldasm", sldasm_inputs)]
    non_empty = [(name, vals) for name, vals in non_empty if vals]
    if len(non_empty) > 1 and not args.allow_mixed_inputs:
        raise SystemExit("Multiple input types found. Use only one of stage1/exported/sldasm, or pass --allow-mixed-inputs.")
    if not non_empty:
        raise SystemExit("No input found. Provide --stage1-*, --exported-*, or --sldasm-*.")

    items: List[WorkItem] = []
    source_mode = "+".join(name for name, _vals in non_empty)
    for source_type, paths in non_empty:
        input_root = {
            "stage1": args.stage1_input_root,
            "exported": args.exported_root,
            "sldasm": args.sldasm_root,
        }.get(source_type)
        for source in paths:
            name = sample_name_for(source, input_root, args.name_mode)
            stage1 = source if source_type == "stage1" else args.stage1_output_root / name
            raw = args.raw_export_root / name if source_type == "sldasm" and args.raw_export_root else None
            prepared = args.prepared_root / name
            items.append(WorkItem(source_type=source_type, source=source, sample_name=name, stage1_sample=stage1, raw_export_dir=raw, prepared_sample=prepared))

    if args.max_samples > 0:
        items = items[: args.max_samples]
    return source_mode, items


def parse_json_from_stdout(stdout: str) -> Dict[str, Any]:
    text = (stdout or "").strip()
    if not text:
        return {}
    start = text.find("{")
    end = text.rfind("}")
    if start < 0 or end <= start:
        return {}
    try:
        data = json.loads(text[start:end + 1])
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def export_status_from_result(result: Dict[str, Any]) -> Dict[str, Any]:
    attempts = result.get("attempts") if isinstance(result.get("attempts"), list) else [result]
    for attempt in reversed(attempts):
        if not isinstance(attempt, dict):
            continue
        payload = parse_json_from_stdout(str(attempt.get("stdout") or ""))
        status = payload.get("export_status") if isinstance(payload, dict) else None
        if isinstance(status, dict):
            return status
    return {}


def terminal_result(record: Dict[str, Any]) -> Dict[str, Any]:
    for key in ("export", "organize_exported", "prepare"):
        value = record.get(key)
        if isinstance(value, dict):
            return value
    return {}


def write_csv_summary(path: Path, records: List[Dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fields = [
        "sample_name", "source_type", "source", "status", "runtime_sec",
        "stage1_sample", "prepared_sample", "library_count", "has_reference_obj",
        "has_mate_graph", "missing", "warnings",
    ]
    with path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        for r in records:
            validation = {}
            prep = r.get("prepare") if isinstance(r.get("prepare"), dict) else {}
            if isinstance(prep, dict):
                validation = prep.get("prepared_validation_after_move") or prep.get("prepared_validation") or {}
            if not validation and isinstance(r.get("prepared_validation"), dict):
                validation = r.get("prepared_validation")
            writer.writerow({
                "sample_name": r.get("sample_name"),
                "source_type": r.get("source_type"),
                "source": r.get("source"),
                "status": r.get("status"),
                "runtime_sec": r.get("runtime_sec"),
                "stage1_sample": r.get("stage1_sample"),
                "prepared_sample": r.get("prepared_sample"),
                "library_count": validation.get("library_count"),
                "has_reference_obj": validation.get("has_reference_obj"),
                "has_mate_graph": validation.get("has_mate_graph"),
                "missing": json.dumps(validation.get("missing") or [], ensure_ascii=False),
                "warnings": json.dumps(validation.get("warnings") or [], ensure_ascii=False),
            })


def write_skipped_failed_csv(path: Path, records: List[Dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fields = [
        "sample_name", "source_type", "source", "status", "runtime_sec",
        "returncode", "timeout", "skip_reason", "visible_component_count",
        "max_visible_components", "solidworks_kill_returncode", "stage1_sample",
        "prepared_sample", "stderr_tail",
    ]
    rows: List[Dict[str, Any]] = []
    ok_statuses = {"ok", "ok_with_warnings", "skipped_resume_prepared_exists"}
    for record in records:
        status = str(record.get("status") or "")
        if status in ok_statuses:
            continue
        result = terminal_result(record)
        export_status = export_status_from_result(result)
        kill = result.get("solidworks_kill") if isinstance(result.get("solidworks_kill"), dict) else {}
        attempts = result.get("attempts") if isinstance(result.get("attempts"), list) else []
        timed_out = bool(result.get("timeout") or any(isinstance(a, dict) and a.get("timeout") for a in attempts))
        stderr = str(result.get("stderr") or "")
        rows.append({
            "sample_name": record.get("sample_name"),
            "source_type": record.get("source_type"),
            "source": record.get("source"),
            "status": status,
            "runtime_sec": record.get("runtime_sec"),
            "returncode": result.get("returncode"),
            "timeout": timed_out,
            "skip_reason": export_status.get("skip_reason") or record.get("skip_reason"),
            "visible_component_count": export_status.get("visible_component_count"),
            "max_visible_components": export_status.get("max_visible_components"),
            "solidworks_kill_returncode": kill.get("returncode"),
            "stage1_sample": record.get("stage1_sample"),
            "prepared_sample": record.get("prepared_sample"),
            "stderr_tail": stderr[-500:],
        })
    with path.open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow(row)


def skip_fail_counts(records: List[Dict[str, Any]]) -> Dict[str, Any]:
    out: Dict[str, Any] = {
        "skipped_exporter_policy": 0,
        "skip_reason_counts": {},
        "timeout_count": 0,
        "failed_non_policy_count": 0,
    }
    ok_statuses = {"ok", "ok_with_warnings", "skipped_resume_prepared_exists"}
    for record in records:
        status = str(record.get("status") or "")
        if status in ok_statuses:
            continue
        result = terminal_result(record)
        export_status = export_status_from_result(result)
        reason = export_status.get("skip_reason")
        if status == "skipped_exporter_policy":
            out["skipped_exporter_policy"] += 1
            key = str(reason or "unknown_policy_skip")
            out["skip_reason_counts"][key] = int(out["skip_reason_counts"].get(key, 0)) + 1
        else:
            out["failed_non_policy_count"] += 1
        attempts = result.get("attempts") if isinstance(result.get("attempts"), list) else []
        if (
            result.get("timeout")
            or result.get("returncode") == 124
            or any(isinstance(a, dict) and (a.get("timeout") or a.get("returncode") == 124) for a in attempts)
        ):
            out["timeout_count"] += 1
    return out


def validation_summary(record: Dict[str, Any], result: Dict[str, Any]) -> Dict[str, Any]:
    validation: Dict[str, Any] = {}
    for key in ("stage1_validation", "prepared_validation", "prepared_validation_after_move"):
        value = record.get(key)
        if isinstance(value, dict):
            validation = value
            break
    if not validation:
        for key in ("stage1_validation", "prepared_validation_after_move", "prepared_validation"):
            value = result.get(key)
            if isinstance(value, dict):
                validation = value
                break
    return {
        "missing": validation.get("missing") or [],
        "warnings": validation.get("warnings") or [],
        "library_count": validation.get("library_count"),
        "component_obj_count": validation.get("component_obj_count"),
        "component_step_count": validation.get("component_step_count"),
        "has_assembly_mesh_obj": validation.get("has_assembly_mesh_obj"),
        "has_reference_obj": validation.get("has_reference_obj"),
        "has_mate_graph": validation.get("has_mate_graph"),
    }


def compact_problem_record(record: Dict[str, Any]) -> Dict[str, Any]:
    result = terminal_result(record)
    export_status = export_status_from_result(result)
    attempts = result.get("attempts") if isinstance(result.get("attempts"), list) else []
    timed_out = bool(
        result.get("timeout")
        or result.get("returncode") == 124
        or any(isinstance(a, dict) and (a.get("timeout") or a.get("returncode") == 124) for a in attempts)
    )
    stderr = str(result.get("stderr") or "")
    stdout = str(result.get("stdout") or "")
    payload: Dict[str, Any] = {
        "sample_name": record.get("sample_name"),
        "source_type": record.get("source_type"),
        "source": record.get("source"),
        "status": record.get("status"),
        "runtime_sec": record.get("runtime_sec"),
        "returncode": result.get("returncode"),
        "timeout": timed_out,
        "skip_reason": export_status.get("skip_reason") or record.get("skip_reason"),
        "stage1_sample": record.get("stage1_sample"),
        "prepared_sample": record.get("prepared_sample"),
        "validation": validation_summary(record, result),
    }
    if export_status.get("visible_component_count") is not None:
        payload["visible_component_count"] = export_status.get("visible_component_count")
    if export_status.get("max_visible_components") is not None:
        payload["max_visible_components"] = export_status.get("max_visible_components")
    if attempts:
        payload["attempts"] = [
            {
                "attempt": a.get("attempt"),
                "returncode": a.get("returncode"),
                "timeout": bool(a.get("timeout")),
                "elapsed_sec": a.get("elapsed_sec"),
            }
            for a in attempts
            if isinstance(a, dict)
        ]
    if stdout:
        payload["stdout_tail"] = stdout[-8000:]
    if stderr:
        payload["stderr_tail"] = stderr[-1000:]
    return payload


def progress_payload(
    records: List[Dict[str, Any]],
    total: int,
    batch_start: float,
    plan_start_time: str,
    source_mode: str,
    workers: int,
    prepared_root: Path,
    status: str,
    current_item: Optional[WorkItem] = None,
) -> Dict[str, Any]:
    ok_statuses = {"ok", "ok_with_warnings", "skipped_resume_prepared_exists"}
    done = len(records)
    success = sum(1 for r in records if r.get("status") in ok_statuses)
    skipped = sum(1 for r in records if str(r.get("status", "")).startswith("skipped"))
    failed = done - success - skipped
    status_counts: Dict[str, int] = {}
    for record in records:
        key = str(record.get("status") or "unknown")
        status_counts[key] = status_counts.get(key, 0) + 1
    failed_records: List[Dict[str, Any]] = []
    skipped_records: List[Dict[str, Any]] = []
    for record in records:
        record_status = str(record.get("status") or "")
        if record_status in ok_statuses:
            continue
        if record_status.startswith("skipped"):
            skipped_records.append(compact_problem_record(record))
        else:
            failed_records.append(compact_problem_record(record))
    elapsed = round(time.time() - batch_start, 3)
    avg_sec = round(elapsed / done, 3) if done else None
    remaining = max(0, total - done)
    eta_sec = round(avg_sec * remaining, 3) if avg_sec is not None else None
    current_payload = None
    if current_item is not None:
        current_payload = {
            "sample_name": current_item.sample_name,
            "source_type": current_item.source_type,
            "source": str(current_item.source),
            "stage1_sample": str(current_item.stage1_sample),
            "prepared_sample": str(current_item.prepared_sample),
        }
    last_record = records[-1] if records else None
    last_payload = None
    if isinstance(last_record, dict):
        result = terminal_result(last_record)
        export_status = export_status_from_result(result)
        last_payload = {
            "sample_name": last_record.get("sample_name"),
            "source_type": last_record.get("source_type"),
            "source": last_record.get("source"),
            "status": last_record.get("status"),
            "runtime_sec": last_record.get("runtime_sec"),
            "returncode": result.get("returncode"),
            "timeout": bool(result.get("timeout")),
            "skip_reason": export_status.get("skip_reason") or last_record.get("skip_reason"),
        }
    return {
        "schema": "cad_assembly_prepare_dataset_progress.v1",
        "status": status,
        "source_mode": source_mode,
        "start_time": plan_start_time,
        "updated_time": now_text(),
        "prepared_root": str(prepared_root),
        "workers": workers,
        "total_planned": total,
        "done": done,
        "in_progress_or_pending": remaining,
        "success_or_resume_skipped": success,
        "success_without_resume_skipped": sum(1 for r in records if r.get("status") in {"ok", "ok_with_warnings"}),
        "skipped": skipped,
        "failed": failed,
        "status_counts": status_counts,
        "skip_fail_summary": skip_fail_counts(records),
        "failed_records": failed_records,
        "skipped_records": skipped_records,
        "elapsed_sec": elapsed,
        "avg_sec_per_done_sample": avg_sec,
        "estimated_remaining_sec": eta_sec,
        "current_item": current_payload,
        "last_record": last_payload,
    }


def write_progress(
    path: Path,
    records: List[Dict[str, Any]],
    total: int,
    batch_start: float,
    plan_start_time: str,
    source_mode: str,
    workers: int,
    prepared_root: Path,
    status: str,
    current_item: Optional[WorkItem] = None,
) -> None:
    write_json_atomic(
        path,
        progress_payload(
            records=records,
            total=total,
            batch_start=batch_start,
            plan_start_time=plan_start_time,
            source_mode=source_mode,
            workers=workers,
            prepared_root=prepared_root,
            status=status,
            current_item=current_item,
        ),
    )


def main() -> None:
    ap = argparse.ArgumentParser(description="Build prepared CAD assembly dataset samples at scale; does not call any GPT/API model.")
    # Input modes
    ap.add_argument("--sldasm", type=Path, default=None, help="Single .sldasm file.")
    ap.add_argument("--sldasm-root", type=Path, default=None, help="Root directory recursively containing .sldasm files.")
    ap.add_argument("--sldasm-list", type=Path, default=None, help="Text file with one .sldasm path per line.")
    ap.add_argument("--exported-dir", type=Path, default=None, help="Single raw SolidWorks exporter output directory.")
    ap.add_argument("--exported-root", type=Path, default=None, help="Root directory containing raw exporter output directories.")
    ap.add_argument("--exported-list", type=Path, default=None, help="Text file with one raw exporter output directory per line.")
    ap.add_argument("--stage1-sample", type=Path, default=None, help="Single Stage1 sample directory.")
    ap.add_argument("--stage1-input-root", type=Path, default=None, help="Root directory containing Stage1 samples.")
    ap.add_argument("--stage1-list", type=Path, default=None, help="Text file with one Stage1 sample directory per line.")
    ap.add_argument("--allow-mixed-inputs", action="store_true", help="Allow mixing stage1/exported/sldasm inputs in one run.")

    # Outputs
    ap.add_argument("--prepared-root", type=Path, required=True, help="Output root for prepared samples.")
    ap.add_argument(
        "--stage1-output-root",
        type=Path,
        default=None,
        help="Optional persistent Stage1 root. Omit to use an automatically cleaned temporary workspace.",
    )
    ap.add_argument(
        "--raw-export-root",
        type=Path,
        default=None,
        help="Optional persistent raw SolidWorks export root. Omit to use an automatically cleaned temporary workspace.",
    )
    ap.add_argument("--log-root", type=Path, default=None, help="Deprecated compatibility option. Details are written to dataset_progress.json.")
    ap.add_argument("--write-detail-logs", action="store_true", help="Deprecated compatibility option. Details are written to dataset_progress.json.")
    ap.add_argument("--prepared-tmp-root", type=Path, default=None, help="Optional atomic temp root for prepared sample builds. Default uses the system temp directory.")
    ap.add_argument("--name-mode", choices=["relative_hash", "stem"], default="relative_hash", help="Use relative_hash for large datasets to avoid duplicate sample names.")

    # Script options passed through
    ap.add_argument("--exporter", type=Path, default=None, help="Underlying SolidWorks exporter used by Stage1 wrapper.")
    ap.add_argument("--topology-mode", choices=["full", "bounded", "mate_only"], default="mate_only")
    ap.add_argument("--component-obj-frame", choices=["auto", "local", "assembly"], default="auto")
    ap.add_argument("--keep-solidworks-original", action="store_true")

    # Large-batch controls
    ap.add_argument("--workers", type=int, default=1, help="Parallel workers for Stage1/exported-dir preparation. .sldasm export is forced to 1 for SolidWorks safety.")
    ap.add_argument("--max-samples", type=int, default=0)
    ap.add_argument("--resume", action="store_true", help="Skip samples whose prepared output already passes validation.")
    ap.add_argument("--force", action="store_true", help="Delete and rebuild outputs even if they exist.")
    ap.add_argument("--dry-run", action="store_true", help="Only discover inputs and write planned commands; do not execute.")
    ap.add_argument("--atomic", action="store_true", default=True, help="Build into _tmp then move into final output after success. Default enabled.")
    ap.add_argument("--no-atomic", dest="atomic", action="store_false")
    ap.add_argument("--no-overwrite", action="store_true", help="Pass --no-overwrite to child scripts when not forcing.")
    ap.add_argument("--keep-failed-temp", action="store_true", help="Keep failed _tmp outputs for debugging.")
    ap.add_argument("--fail-fast", action="store_true")
    ap.add_argument("--max-visible-components", type=int, default=30, help="Skip .sldasm assemblies whose visible component count exceeds this value. Use 0 to disable.")

    # Reliability controls
    ap.add_argument("--export-timeout-sec", type=int, default=1800, help="Timeout for one SolidWorks export. 0 disables timeout.")
    ap.add_argument("--organize-timeout-sec", type=int, default=600, help="Timeout for organizing one raw exporter output. 0 disables timeout.")
    ap.add_argument("--prepare-timeout-sec", type=int, default=900, help="Timeout for preparing one Stage1 sample. 0 disables timeout.")
    ap.add_argument("--export-retries", type=int, default=0)
    ap.add_argument("--organize-retries", type=int, default=0)
    ap.add_argument("--prepare-retries", type=int, default=1)
    ap.add_argument("--retry-sleep-sec", type=float, default=2.0)
    ap.add_argument("--kill-solidworks-on-timeout", action="store_true", default=True, help="Kill SLDWORKS.exe when a SolidWorks export subprocess times out. Default enabled.")
    ap.add_argument("--no-kill-solidworks-on-timeout", dest="kill_solidworks_on_timeout", action="store_false")

    # Validation policy
    ap.add_argument("--strict-stage1", action="store_true", help="Fail before prepare if Stage1 validation is incomplete.")
    ap.add_argument("--require-reference-obj", action="store_true", default=True, help="Require direct assembly OBJ so experiments 2/5 can run. Default enabled.")
    ap.add_argument("--allow-missing-reference-obj", dest="require_reference_obj", action="store_false")
    ap.add_argument("--require-views", action="store_true", default=True)
    ap.add_argument("--allow-missing-views", action="store_true")
    ap.add_argument("--require-mate-graph", action="store_true", default=True)
    ap.add_argument("--allow-missing-mate-graph", dest="require_mate_graph", action="store_false")
    args = ap.parse_args()

    if args.force and args.resume:
        # force wins; keep it explicit in logs.
        args.resume = False

    temporary_workspace: Optional[tempfile.TemporaryDirectory[str]] = None
    temporary_stage1 = args.stage1_output_root is None
    temporary_raw_export = args.raw_export_root is None
    temporary_log_root = True
    temporary_prepared_tmp = args.prepared_tmp_root is None
    temp_parent = args.prepared_root.parent
    temp_parent.mkdir(parents=True, exist_ok=True)
    if args.prepared_tmp_root is None:
        args.prepared_tmp_root = Path(tempfile.mkdtemp(prefix="cad_dataprep_atomic_", dir=str(temp_parent)))
    temporary_intermediates = temporary_stage1 or temporary_raw_export
    if temporary_intermediates:
        args.prepared_root.mkdir(parents=True, exist_ok=True)
        temporary_workspace = tempfile.TemporaryDirectory(prefix="cad_dataprep_pipeline_", dir=str(temp_parent), ignore_cleanup_errors=True)
        temp_root = Path(temporary_workspace.name)
        if args.stage1_output_root is None:
            args.stage1_output_root = temp_root / "stage1"
        if args.raw_export_root is None:
            args.raw_export_root = temp_root / "raw_export"

    source_mode, items = build_work_items(args)
    if not items:
        raise SystemExit("No work items after discovery/max-samples filtering.")

    # SolidWorks is not safe to drive in multiple processes against one desktop
    # session; keep direct .sldasm export sequential. Raw-export and Stage1
    # preparation can use workers.
    if any(i.source_type == "sldasm" for i in items) and args.workers != 1:
        print("[WARN] .sldasm input detected; forcing --workers 1 for SolidWorks COM/export safety.", file=sys.stderr)
        args.workers = 1
    args.workers = max(1, int(args.workers))

    plan = {
        "schema": "cad_assembly_prepare_dataset_plan.v2",
        "source_mode": source_mode,
        "start_time": now_text(),
        "prepared_root": str(args.prepared_root),
        "intermediate_storage": {
            "stage1": "temporary" if temporary_stage1 else "persistent",
            "raw_export": "temporary" if temporary_raw_export else "persistent",
        },
        "stage1_output_root": None if temporary_stage1 else str(args.stage1_output_root),
        "raw_export_root": None if temporary_raw_export else str(args.raw_export_root),
        "log_root": None,
        "prepared_tmp_root": None if temporary_prepared_tmp else str(args.prepared_tmp_root),
        "workers": args.workers,
        "total_planned": len(items),
        "items": [
            {
                "sample_name": i.sample_name,
                "source_type": i.source_type,
                "source": str(i.source),
                "stage1_sample": str(i.stage1_sample),
                "prepared_sample": str(i.prepared_sample),
            }
            for i in items
        ],
    }
    preparer = DatasetPreparer(args)
    records: List[Dict[str, Any]] = []
    batch_start = time.time()
    progress_path = args.prepared_root / "dataset_progress.json"
    write_progress(progress_path, records, len(items), batch_start, plan["start_time"], source_mode, args.workers, args.prepared_root, "running")
    print(f"[PLAN] {len(items)} samples | source={source_mode} | workers={args.workers} | prepared_root={args.prepared_root}")

    if args.workers == 1:
        for idx, item in enumerate(items, start=1):
            print(f"[{idx}/{len(items)}] {item.sample_name} ({item.source_type})")
            write_progress(progress_path, records, len(items), batch_start, plan["start_time"], source_mode, args.workers, args.prepared_root, "running", current_item=item)
            record = preparer.process_one(item)
            records.append(record)
            write_progress(progress_path, records, len(items), batch_start, plan["start_time"], source_mode, args.workers, args.prepared_root, "running")
            print(f"  -> {record.get('status')} in {record.get('runtime_sec')}s")
            if args.fail_fast and record.get("status") not in {"ok", "ok_with_warnings", "skipped_resume_prepared_exists"}:
                break
    else:
        with ThreadPoolExecutor(max_workers=args.workers) as ex:
            fut_map = {ex.submit(preparer.process_one, item): item for item in items}
            done_count = 0
            for fut in as_completed(fut_map):
                item = fut_map[fut]
                done_count += 1
                try:
                    record = fut.result()
                except Exception as exc:
                    record = {
                        "sample_name": item.sample_name,
                        "source_type": item.source_type,
                        "source": str(item.source),
                        "stage1_sample": str(item.stage1_sample),
                        "prepared_sample": str(item.prepared_sample),
                        "status": "future_exception",
                        "error": repr(exc),
                        "traceback": traceback.format_exc(),
                    }
                    preparer.append_record(record)
                records.append(record)
                write_progress(progress_path, records, len(items), batch_start, plan["start_time"], source_mode, args.workers, args.prepared_root, "running")
                print(f"[{done_count}/{len(items)}] {item.sample_name} -> {record.get('status')} ({record.get('runtime_sec')}s)")
                if args.fail_fast and record.get("status") not in {"ok", "ok_with_warnings", "skipped_resume_prepared_exists"}:
                    # Existing futures will keep running; fail-fast mainly prevents
                    # overusing sequential mode. We do not kill child processes here.
                    pass

    ok_statuses = {"ok", "ok_with_warnings", "skipped_resume_prepared_exists"}
    success = sum(1 for r in records if r.get("status") in ok_statuses)
    skipped = sum(1 for r in records if str(r.get("status", "")).startswith("skipped"))
    failed = len(records) - success
    summary = {
        "schema": "cad_assembly_prepare_dataset_log.v2",
        "source_mode": source_mode,
        "start_time": plan["start_time"],
        "end_time": now_text(),
        "total_planned": len(items),
        "total_run_or_skipped": len(records),
        "total_success_or_skipped": success,
        "total_success_without_skipped": sum(1 for r in records if r.get("status") in {"ok", "ok_with_warnings"}),
        "total_skipped": skipped,
        "total_fail": failed,
        "total_runtime_sec": round(time.time() - batch_start, 3),
        "workers": args.workers,
        "skip_fail_summary": skip_fail_counts(records),
        "records": records,
    }
    write_progress(progress_path, records, len(items), batch_start, plan["start_time"], source_mode, args.workers, args.prepared_root, "completed" if failed == 0 else "completed_with_failures")
    print(json.dumps({k: v for k, v in summary.items() if k != "records"}, ensure_ascii=False, indent=2))
    if temporary_workspace is not None:
        try:
            temporary_workspace.cleanup()
        except Exception:
            pass
    if temporary_prepared_tmp and args.prepared_tmp_root.exists() and not any(args.prepared_tmp_root.iterdir()):
        args.prepared_tmp_root.rmdir()
    if failed > 0:
        raise SystemExit(2)


if __name__ == "__main__":
    main()

