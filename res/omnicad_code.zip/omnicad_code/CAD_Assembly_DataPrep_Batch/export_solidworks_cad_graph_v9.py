from __future__ import annotations
import re
from typing import Any

def ascii_slug(text: Any, default: str = "item") -> str:
    s = str(text or "").strip()
    s = s.encode("ascii", "ignore").decode("ascii")
    s = re.sub(r"[^A-Za-z0-9]+", "_", s).strip("_").lower()
    return s or default

def call(obj: Any, name: str, *args: Any) -> Any:
    if obj is None:
        return None
    try:
        attr = getattr(obj, name)
    except Exception:
        return None
    if args:
        try:
            return attr(*args)
        except Exception:
            return None
    # SolidWorks COM exposes both true methods and property dispatches.
    # Some property dispatches look callable but fail if called; keep the raw property then.
    if callable(attr):
        try:
            return attr()
        except Exception:
            return attr
    return attr
