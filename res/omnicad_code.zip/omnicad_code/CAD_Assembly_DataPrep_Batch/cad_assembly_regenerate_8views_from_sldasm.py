#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Regenerate flat prepared-sample reference views as 8 STEP/B-rep views.

This utility is for samples that have already been prepared. It does not rebuild
the graph, mate data, component library, or assembly OBJ. For each sample it:

1. Opens the source .SLDASM in SolidWorks.
2. Exports sample_root/assembly.step and temporary component STEP files.
3. Keeps component poses in memory and renders 8 cube-vertex STEP/B-rep views
   using the same renderer as the main DataPrep pipeline.
4. Overwrites reference_views/{same_color,color_by_component}/assembly_v01..v08.png.

Old assembly_v09..assembly_v20.png files in those two reference-view folders are
removed so downstream validation sees only the 8-view layout.
"""
from __future__ import annotations

import argparse
import json
import shutil
import sys
import tempfile
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional

import numpy as np

VIEW_NAMES = [f"v{i:02d}" for i in range(1, 9)]


def read_json(path: Path) -> Any:
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def sample_dirs(root: Path) -> List[Path]:
    if (root / "assembly_graph_gt.json").exists():
        return [root]
    return sorted(p for p in root.rglob("*") if p.is_dir() and (p / "assembly_graph_gt.json").exists())


def sldasm_files(root: Path) -> List[Path]:
    if root.is_file() and root.suffix.lower() == ".sldasm":
        return [root]
    return sorted(p for p in root.rglob("*") if p.is_file() and p.suffix.lower() == ".sldasm")


def normalize_token(value: str) -> str:
    return "".join(ch.lower() for ch in value if ch.isalnum())


def sample_match_tokens(sample: Path) -> List[str]:
    tokens = [normalize_token(sample.name)]
    graph = sample / "assembly_graph_gt.json"
    if graph.exists():
        try:
            data = read_json(graph)
            for key in ("assembly_name", "assembly_id", "name"):
                value = data.get(key)
                if value:
                    tokens.append(normalize_token(str(value)))
        except Exception:
            pass
    return [t for t in tokens if t]


def build_sldasm_index(paths: Iterable[Path]) -> Dict[str, Path]:
    index: Dict[str, Path] = {}
    for path in paths:
        keys = {
            normalize_token(path.stem),
            normalize_token(path.parent.name),
        }
        for key in keys:
            if key and key not in index:
                index[key] = path
    return index


def resolve_sldasm(sample: Path, explicit: Optional[Path], index: Dict[str, Path]) -> Optional[Path]:
    if explicit is not None:
        return explicit
    tokens = sample_match_tokens(sample)
    for token in tokens:
        if token in index:
            return index[token]

    # Prepared sample names are often hashes, while source SLDASM names are
    # human-readable. Allow only a conservative unique fuzzy match; ambiguous
    # matches still fail instead of guessing the wrong assembly.
    candidates: Dict[str, Path] = {}
    for token in tokens:
        if len(token) < 6:
            continue
        for key, path in index.items():
            if len(key) < 6:
                continue
            if token in key or key in token:
                candidates[str(path.resolve()).lower() if path.exists() else str(path).lower()] = path
    if len(candidates) == 1:
        return next(iter(candidates.values()))
    return None


def is_visible_node(node: Dict[str, Any]) -> bool:
    return not bool(node.get("hidden") or node.get("suppressed") or node.get("is_hidden") or node.get("is_suppressed"))


def matrix4x4_from_transform(transform: Dict[str, Any] | None) -> Optional[np.ndarray]:
    values = (transform or {}).get("array_data") or []
    if len(values) < 12:
        return None
    vals = [float(v) for v in values]
    return np.asarray([
        [vals[0], vals[3], vals[6], vals[9] * 1000.0],
        [vals[1], vals[4], vals[7], vals[10] * 1000.0],
        [vals[2], vals[5], vals[8], vals[11] * 1000.0],
        [0.0, 0.0, 0.0, 1.0],
    ], dtype=float)


def export_lightweight_step_assets(sldasm: Path, sample: Path, temp_dir: Path, max_visible_components: int = 0) -> Dict[str, Any]:
    import pythoncom  # type: ignore
    import win32com.client  # type: ignore
    import export_solidworks_assembly_graph_v1_true_full_brep_match as exporter
    import cad_assembly_export_solidworks_sample as stage1_export

    pythoncom.CoInitialize()
    sw = None
    asm_doc = None
    opened_docs: List[Any] = []
    resolver_report: Dict[str, Any] | None = None
    sldasm_for_open = sldasm
    try:
        # Match Stage1 behaviour: mirror all SLDPRT files from the suite folder
        # into a temporary SolidWorks-friendly input tree before opening the
        # assembly. This avoids stale saved component paths and nested-part
        # layouts breaking lightweight view regeneration.
        try:
            resolver_report = stage1_export.prepare_resolved_sldasm_input(sldasm, temp_dir)
            sldasm_for_open = Path(str(resolver_report.get("resolved_assembly") or sldasm))
        except Exception as exc:
            resolver_report = {"source_assembly": str(sldasm), "error": repr(exc)}
            sldasm_for_open = sldasm

        try:
            sw = win32com.client.DispatchEx("SldWorks.Application")
        except Exception:
            sw = win32com.client.Dispatch("SldWorks.Application")
        sw.Visible = False
        asm_doc = exporter.open_assembly(sw, sldasm_for_open)
        nodes, _, _, _ = exporter.collect_components_from_model(asm_doc)
        graph = {"nodes": nodes, "summary": {}}
        graph = exporter.resolve_missing_component_paths(graph, sldasm_for_open)
        visible_nodes = [node for node in graph.get("nodes", []) if is_visible_node(node)]
        if max_visible_components and len(visible_nodes) > max_visible_components:
            return {
                "ok": False,
                "stage": "max_visible_components",
                "visible_component_count": len(visible_nodes),
                "max_visible_components": max_visible_components,
            }

        assembly_step = sample / "assembly.step"
        assembly_ok = exporter.save_model_step(asm_doc, assembly_step, sw=sw)
        if not assembly_ok:
            return {"ok": False, "stage": "export_assembly_step", "assembly_step": str(assembly_step)}

        component_dir = temp_dir / "component_steps"
        component_dir.mkdir(parents=True, exist_ok=True)
        cache: Dict[str, Path] = {}
        components: List[Dict[str, Any]] = []
        errors: List[str] = []
        for idx, node in enumerate(visible_nodes):
            comp_path = str(node.get("component_path") or "")
            referenced_configuration = str(node.get("referenced_configuration") or "")
            if not comp_path or not Path(comp_path).exists():
                errors.append(f"missing_component_path:{node.get('id') or idx + 1}:{comp_path}")
                continue
            cache_key = f"{Path(comp_path).resolve()}|{referenced_configuration}".lower()
            step_path = cache.get(cache_key)
            if step_path is None:
                step_path = component_dir / f"part_{len(cache) + 1:05d}.step"
                part_doc = None
                try:
                    errs = win32com.client.VARIANT(pythoncom.VT_BYREF | pythoncom.VT_I4, 0)
                    warns = win32com.client.VARIANT(pythoncom.VT_BYREF | pythoncom.VT_I4, 0)
                    part_doc = sw.OpenDoc6(comp_path, exporter.document_type_for_path(comp_path), exporter.SW_OPEN_SILENT, "", errs, warns)
                    if part_doc is None:
                        errors.append(f"open_component_failed:{comp_path}")
                        continue
                    opened_docs.append(part_doc)
                    try:
                        title = exporter.call(part_doc, "GetTitle")
                        if title:
                            sw.ActivateDoc3(title, False, 0, win32com.client.VARIANT(pythoncom.VT_BYREF | pythoncom.VT_I4, 0))
                    except Exception:
                        pass
                    if referenced_configuration:
                        try:
                            exporter.call(part_doc, "ShowConfiguration2", referenced_configuration)
                        except Exception:
                            pass
                    try:
                        exporter.call(part_doc, "EditRebuild3")
                    except Exception:
                        pass
                    if not exporter.save_model_step(part_doc, step_path, sw=sw):
                        errors.append(f"export_component_step_failed:{comp_path}")
                        continue
                    cache[cache_key] = step_path
                finally:
                    if part_doc is not None:
                        try:
                            title = exporter.call(part_doc, "GetTitle")
                            if title:
                                sw.CloseDoc(title)
                        except Exception:
                            pass
            components.append({
                "component_id": str(node.get("id") or node.get("component_id") or f"c{idx + 1:05d}"),
                "step_path": step_path,
                "matrix4x4": matrix4x4_from_transform(node.get("transform")),
            })
        return {
            "ok": bool(components),
            "stage": "ok" if components else "no_visible_component_steps",
            "assembly_step": str(assembly_step),
            "component_count": len(components),
            "unique_step_count": len(cache),
            "components": components,
            "errors": errors,
            "component_path_resolution": graph.get("summary", {}).get("component_path_resolution"),
            "resolved_input": resolver_report,
            "opened_sldasm": str(sldasm_for_open),
        }
    finally:
        if sw is not None and asm_doc is not None:
            try:
                title = exporter.call(asm_doc, "GetTitle")
                if title:
                    sw.CloseDoc(title)
            except Exception:
                pass
        if sw is not None:
            try:
                sw.ExitApp()
            except Exception:
                pass
        try:
            pythoncom.CoUninitialize()
        except Exception:
            pass


def remove_old_reference_views(style_dir: Path) -> None:
    style_dir.mkdir(parents=True, exist_ok=True)
    for path in style_dir.glob("assembly_v*.png"):
        try:
            path.unlink()
        except Exception:
            pass


def has_complete_8views(style_dir: Path) -> bool:
    if not style_dir.exists():
        return False
    for view in VIEW_NAMES:
        if not (style_dir / f"assembly_{view}.png").exists():
            return False
    for old_index in range(9, 21):
        if (style_dir / f"assembly_v{old_index:02d}.png").exists():
            return False
    return True


def sample_is_complete(sample: Path) -> bool:
    step = sample / "assembly.step"
    return (
        step.exists()
        and step.is_file()
        and step.stat().st_size > 0
        and has_complete_8views(sample / "reference_views" / "color_by_component")
        and has_complete_8views(sample / "reference_views" / "same_color")
    )


def apply_matrix(vertices: np.ndarray, matrix: Optional[np.ndarray]) -> np.ndarray:
    if matrix is None or vertices.size == 0:
        return np.asarray(vertices, dtype=float)
    hom = np.column_stack([np.asarray(vertices, dtype=float), np.ones((len(vertices),), dtype=float)])
    return (hom @ matrix.T)[:, :3]


def build_scene_from_components(components: List[Dict[str, Any]]) -> Dict[str, np.ndarray]:
    from cad_assembly_prepare_experiment_sample import load_step_brep_wire_geometry

    cache: Dict[str, Dict[str, np.ndarray]] = {}
    vertices_blocks: List[np.ndarray] = []
    edges_blocks: List[np.ndarray] = []
    surface_faces_blocks: List[np.ndarray] = []
    surface_component_ids: List[np.ndarray] = []
    vertex_offset = 0
    for component_index, comp in enumerate(components):
        step_path = Path(comp["step_path"])
        key = str(step_path.resolve()).lower()
        base = cache.get(key)
        if base is None:
            base = load_step_brep_wire_geometry(step_path)
            cache[key] = base
        vertices = apply_matrix(base["vertices"], comp.get("matrix4x4"))
        edges = np.asarray(base["edges"], dtype=int) + vertex_offset
        faces = np.asarray(base.get("surface_faces"), dtype=int)
        if faces.size:
            surface_faces_blocks.append(faces + vertex_offset)
            surface_component_ids.append(np.full((len(faces),), component_index, dtype=int))
        vertices_blocks.append(vertices)
        edges_blocks.append(edges)
        vertex_offset += len(vertices)
    if not vertices_blocks or not edges_blocks:
        raise RuntimeError("no_component_step_geometry")
    return {
        "vertices": np.vstack(vertices_blocks),
        "edges": np.vstack(edges_blocks).astype(int),
        "surface_faces": np.vstack(surface_faces_blocks).astype(int) if surface_faces_blocks else np.zeros((0, 3), dtype=int),
        "surface_component_ids": np.concatenate(surface_component_ids).astype(int) if surface_component_ids else np.zeros((0,), dtype=int),
    }


def regenerate_views_from_components(components: List[Dict[str, Any]], sample: Path) -> Dict[str, Any]:
    from cad_assembly_prepare_experiment_sample import render_step_wire_scene_png

    for style in ("color_by_component", "same_color"):
        remove_old_reference_views(sample / "reference_views" / style)
    scene = build_scene_from_components(components)
    render_backends: Dict[str, str] = {}
    rendered_color: List[str] = []
    rendered_same: List[str] = []
    for view in VIEW_NAMES:
        target = sample / "reference_views" / "color_by_component" / f"assembly_{view}.png"
        render_step_wire_scene_png(scene, target, view, same_color=False)
        render_backends[f"color_by_component/assembly_{view}.png"] = "step_brep_wireframe_in_memory"
        rendered_color.append(view)
    for view in VIEW_NAMES:
        target = sample / "reference_views" / "same_color" / f"assembly_{view}.png"
        render_step_wire_scene_png(scene, target, view, same_color=True)
        render_backends[f"same_color/assembly_{view}.png"] = "step_brep_wireframe_in_memory"
        rendered_same.append(view)
    return {
        "ok": True,
        "reference_view_geometry": "component_step_brep_in_memory",
        "component_count": len(components),
        "rendered_color_by_component_views": rendered_color,
        "rendered_same_color_views": rendered_same,
        "render_backends": render_backends,
        "render_backend_summary": {"step_brep_wireframe_in_memory": len(render_backends)},
    }


def process_one(args: argparse.Namespace, sample: Path, sldasm: Path) -> Dict[str, Any]:
    with tempfile.TemporaryDirectory(prefix="_component_steps_for_8views_", dir=str(sample.parent)) as tmp_name:
        temp_dir = Path(tmp_name)
        export_report = export_lightweight_step_assets(sldasm, sample, temp_dir, max_visible_components=args.max_visible_components)
        if not export_report.get("ok"):
            return {"sample": str(sample), "sldasm": str(sldasm), "ok": False, "stage": export_report.get("stage"), "export": export_report}
        render_report = regenerate_views_from_components(export_report["components"], sample)
        return {
            "sample": str(sample),
            "sldasm": str(sldasm),
            "ok": bool(render_report.get("ok")),
            "assembly_step": str(sample / "assembly.step"),
            "component_count": export_report.get("component_count"),
            "unique_step_count": export_report.get("unique_step_count"),
            "export_errors": export_report.get("errors"),
            "views": render_report,
        }


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Regenerate prepared samples from 20 reference views to 8 STEP/B-rep reference views.")
    parser.add_argument("--sample", type=Path, help="Single prepared sample directory.")
    parser.add_argument("--sample-root", type=Path, help="Root containing prepared sample directories.")
    parser.add_argument("--sldasm", type=Path, help="Source SLDASM for --sample.")
    parser.add_argument("--sldasm-root", type=Path, help="Root to recursively search source SLDASM files for --sample-root.")
    parser.add_argument("--max-visible-components", type=int, default=0, help="Skip source assemblies above this visible-component count; 0 disables the limit.")
    parser.add_argument("--resume", action="store_true", help="Skip samples that already have assembly.step and complete 8-view reference_views.")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    if not args.sample and not args.sample_root:
        raise SystemExit("Provide --sample or --sample-root.")
    if args.sample and not args.sldasm:
        raise SystemExit("--sample requires --sldasm.")
    if args.sample_root and not args.sldasm_root and not args.sldasm:
        raise SystemExit("--sample-root requires --sldasm-root, unless --sldasm is used for one sample.")
    samples = [args.sample] if args.sample else sample_dirs(args.sample_root)
    samples = [p for p in samples if p is not None]
    if not samples:
        raise SystemExit("No prepared samples found.")

    sldasm_index: Dict[str, Path] = {}
    if args.sldasm_root:
        sldasm_index = build_sldasm_index(sldasm_files(args.sldasm_root))

    results: List[Dict[str, Any]] = []
    failed = 0
    skipped = 0
    for index, sample in enumerate(samples, start=1):
        if args.resume and sample_is_complete(sample):
            skipped += 1
            record = {"sample": str(sample), "ok": True, "skipped": True, "skip_reason": "complete_8views_and_assembly_step"}
            results.append(record)
            print(f"[{index}/{len(samples)}] {sample.name} -> resume_skipped", flush=True)
            continue
        sldasm = resolve_sldasm(sample, args.sldasm if len(samples) == 1 else None, sldasm_index)
        if sldasm is None or not sldasm.exists():
            failed += 1
            record = {"sample": str(sample), "ok": False, "stage": "resolve_sldasm", "error": "source_sldasm_not_found"}
            results.append(record)
            print(f"[{index}/{len(samples)}] {sample.name} -> source_sldasm_not_found", flush=True)
            continue
        print(f"[{index}/{len(samples)}] {sample.name} <- {sldasm}", flush=True)
        record = process_one(args, sample, sldasm)
        results.append(record)
        if not record.get("ok"):
            failed += 1
            print(f"  -> failed:{record.get('stage') or 'render'}", flush=True)
        else:
            print("  -> ok", flush=True)

    print(json.dumps({
        "schema": "cad_assembly_regenerate_8views_from_sldasm.v1",
        "total": len(results),
        "ok": len(results) - failed,
        "skipped": skipped,
        "failed": failed,
        "failed_records": [r for r in results if not r.get("ok")],
    }, ensure_ascii=False, indent=2))
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
