#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Stage 1 pipeline: SolidWorks assembly -> mesh-only exported sample.

Output layout:
  assembly_graph_gt.json
  obj/assembly.mesh.obj
  obj/components/c00001.mesh.obj
  views/assembly/assembly_front.png
  views/assembly/assembly_top.png
  views/assembly/assembly_right.png
  views/assembly/assembly_iso.png
  assembly_pose_spec.json      # copied when available
  component_geometry/*.step     # copied when available; used only for STEP-rendered reference views
  export_pipeline_report.json
"""
from __future__ import annotations

import argparse
import os
import json
import shutil
import struct
import subprocess
import sys
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

VIEW_MAP = {
    "front": ["assembly_gt_front.png", "assembly_front.png"],
    "top": ["assembly_gt_top.png", "assembly_top.png"],
    "right": ["assembly_gt_right.png", "assembly_right.png"],
    "iso": ["assembly_gt_isometric.png", "assembly_gt_iso.png", "assembly_iso.png"],
}

ROOT = Path(__file__).resolve().parent
DEFAULT_EXPORTER = ROOT / "export_solidworks_assembly_graph_v1_true_full_brep_match.py"


def kill_solidworks_processes() -> Dict[str, Any]:
    cmd = ["taskkill", "/F", "/IM", "SLDWORKS.exe", "/T"]
    try:
        proc = subprocess.run(cmd, text=True, capture_output=True, timeout=30)
        return {"cmd": cmd, "returncode": proc.returncode, "stdout": proc.stdout, "stderr": proc.stderr}
    except Exception as exc:
        return {"cmd": cmd, "returncode": 1, "stderr": repr(exc)}


def read_json(path: Path) -> Any:
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def write_json(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def safe_print_json(data: Any) -> None:
    print(json.dumps(data, ensure_ascii=True, indent=2), flush=True)


def parse_json_from_stdout(stdout: str) -> Dict[str, Any]:
    text = (stdout or "").strip()
    if not text:
        return {}
    start = text.find("{")
    end = text.rfind("}")
    if start < 0 or end <= start:
        return {}
    try:
        data = json.loads(text[start:end + 1])
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def phase_lines_from_stdout(stdout: str) -> List[str]:
    return [line for line in str(stdout or "").splitlines() if "[SW_EXPORT_PHASE]" in line][-30:]


def clean_stage1_dirs(out_dir: Path) -> None:
    out_dir.mkdir(parents=True, exist_ok=True)
    for name in ["obj", "views", "component_meshes", "component_geometry"]:
        p = out_dir / name
        if p.exists():
            shutil.rmtree(p)
    for name in ["assembly_graph_gt.json", "assembly_pose_spec.json", "export_pipeline_report.json"]:
        p = out_dir / name
        if p.exists():
            p.unlink()


def link_or_copy(src: Path, dst: Path) -> str:
    dst.parent.mkdir(parents=True, exist_ok=True)
    if dst.exists():
        return "exists"
    try:
        os.link(src, dst)
        return "hardlink"
    except Exception:
        shutil.copy2(src, dst)
        return "copy"


def prepare_resolved_sldasm_input(assembly: Path, export_dir: Path) -> Dict[str, Any]:
    """Create a SolidWorks-friendly input folder for distributed suite layouts.

    Some distributed samples put the root SLDASM at suite root while referenced
    SLDASM subassemblies and SLDPRT files live under nested folders. SolidWorks
    often does not resolve those references when the saved component path is
    stale, so opening the assembly can hang on hidden file-resolution dialogs.

    Before opening SolidWorks, mirror all same-suite SLDASM/SLDPRT files into a
    temporary input folder by hardlink/copy. We preserve the original relative
    structure and also place uniquely named referenced files next to the root
    SLDASM so filename-only references resolve.
    """
    suite_root = assembly.parent
    resolved_root = export_dir / "_resolved_input"
    if resolved_root.exists():
        shutil.rmtree(resolved_root)
    resolved_root.mkdir(parents=True, exist_ok=True)

    resolved_asm = resolved_root / assembly.name
    asm_mode = link_or_copy(assembly, resolved_asm)

    referenced_files = sorted(
        [
            p
            for p in suite_root.rglob("*")
            if p.is_file()
            and p.resolve() != assembly.resolve()
            and p.suffix.lower() in {".sldprt", ".sldasm"}
        ],
        key=lambda p: str(p).lower(),
    )
    name_counts: Dict[str, int] = {}
    for p in referenced_files:
        name_counts[p.name.lower()] = name_counts.get(p.name.lower(), 0) + 1

    rel_modes: Dict[str, int] = {}
    flat_modes: Dict[str, int] = {}
    duplicate_flat_skipped = 0
    sldprt_count = 0
    sldasm_count = 0
    for src in referenced_files:
        if src.suffix.lower() == ".sldprt":
            sldprt_count += 1
        elif src.suffix.lower() == ".sldasm":
            sldasm_count += 1
        try:
            rel = src.relative_to(suite_root)
        except ValueError:
            rel = Path(src.name)
        mode = link_or_copy(src, resolved_root / rel)
        rel_modes[mode] = rel_modes.get(mode, 0) + 1
        if name_counts.get(src.name.lower(), 0) == 1:
            mode = link_or_copy(src, resolved_root / src.name)
            flat_modes[mode] = flat_modes.get(mode, 0) + 1
        else:
            duplicate_flat_skipped += 1

    report = {
        "source_assembly": str(assembly),
        "suite_root": str(suite_root),
        "resolved_root": str(resolved_root),
        "resolved_assembly": str(resolved_asm),
        "assembly_link_mode": asm_mode,
        "sldprt_count": sldprt_count,
        "sldasm_count": sldasm_count,
        "referenced_file_count": len(referenced_files),
        "relative_link_modes": rel_modes,
        "flat_unique_link_modes": flat_modes,
        "duplicate_flat_skipped": duplicate_flat_skipped,
        "policy": "Preserve relative SLDASM/SLDPRT layout and additionally hardlink uniquely named referenced files beside the root SLDASM before opening SolidWorks.",
    }
    write_json(export_dir / "resolved_input_report.json", report)
    return report


def run_solidworks_exporter(assembly: Path, exporter: Path, export_dir: Path, python_exe: str, topology_mode: str, max_visible_components: int = 0, resolve_prt_folder: bool = True, timeout_sec: int = 0, export_thumbnails: bool = False) -> Dict[str, Any]:
    export_dir.mkdir(parents=True, exist_ok=True)
    start = time.time()
    resolver_report: Dict[str, Any] | None = None
    assembly_for_export = assembly
    if resolve_prt_folder:
        resolver_report = prepare_resolved_sldasm_input(assembly, export_dir)
        assembly_for_export = Path(str(resolver_report["resolved_assembly"]))
    cmd = [python_exe, "-u", str(exporter), str(assembly_for_export), "--out", str(export_dir), "--topology-mode", topology_mode]
    if max_visible_components and max_visible_components > 0:
        cmd += ["--max-visible-components", str(max_visible_components)]
    if not export_thumbnails:
        cmd.append("--no-thumbnails")
    cmd.append("--no-brep-packages")
    cmd.append("--no-component-step")
    timeout = timeout_sec if timeout_sec and timeout_sec > 0 else None
    run_cwd = assembly_for_export.parent if assembly_for_export.parent.exists() else ROOT
    try:
        proc = subprocess.run(cmd, cwd=str(run_cwd), text=True, capture_output=True, timeout=timeout)
        returncode = proc.returncode
        stdout = proc.stdout
        stderr = proc.stderr
        timed_out = False
        sw_kill = None
    except subprocess.TimeoutExpired as exc:
        returncode = 124
        stdout = exc.stdout or ""
        stderr = (exc.stderr or "") + f"\n[TIMEOUT after {timeout_sec}s]"
        timed_out = True
        sw_kill = kill_solidworks_processes()
    cleanup_error = None
    if resolver_report:
        try:
            resolved_root = Path(str(resolver_report.get("resolved_root") or ""))
            if resolved_root.exists() and resolved_root.name == "_resolved_input":
                shutil.rmtree(resolved_root)
                resolver_report["resolved_root_cleaned"] = True
        except Exception as exc:
            cleanup_error = repr(exc)
            resolver_report["resolved_root_cleaned"] = False
            resolver_report["cleanup_error"] = cleanup_error
    return {
        "command": cmd,
        "cwd": str(run_cwd),
        "returncode": returncode,
        "stdout": stdout,
        "stderr": stderr,
        "timeout": timed_out,
        "timeout_sec": timeout_sec or None,
        "elapsed_sec": round(time.time() - start, 3),
        "solidworks_kill": sw_kill,
        "resolved_input": resolver_report,
    }


def find_graph_json(export_dir: Path) -> Optional[Path]:
    hits = sorted(export_dir.glob("*.assembly_graph.json"))
    if hits:
        return hits[0]
    for p in sorted(export_dir.glob("*.json")):
        if p.name in {"assembly_groundtruth_scene.json", "assembly_pose_spec.json"}:
            continue
        try:
            data = read_json(p)
        except Exception:
            continue
        if isinstance(data, dict) and ("dependency_graph" in data or "node_parts" in data or "nodes" in data):
            return p
    return None


def load_component_manifest(export_dir: Path) -> Dict[str, Dict[str, Any]]:
    manifest_path = export_dir / "component_brep_packages" / "manifest.json"
    if not manifest_path.exists():
        return {}
    data = read_json(manifest_path)
    out: Dict[str, Dict[str, Any]] = {}
    for item in data.get("components") or []:
        if isinstance(item, dict) and item.get("component_id"):
            out[str(item["component_id"])] = item
    return out


def component_nodes_from_graph(graph: Dict[str, Any]) -> List[Dict[str, Any]]:
    dep = graph.get("dependency_graph") if isinstance(graph.get("dependency_graph"), dict) else graph
    raw_nodes = dep.get("nodes") or graph.get("node_parts") or graph.get("nodes") or []
    out: List[Dict[str, Any]] = []
    for node in raw_nodes:
        if not isinstance(node, dict):
            continue
        if node.get("node_type") not in (None, "component", "Node Part"):
            continue
        if node.get("component_id") or node.get("id"):
            out.append(node)
    return out


_FALSE_STRINGS = {"false", "0", "hidden", "invisible", "suppressed", "no", "off", "none", "null"}
_TRUE_STRINGS = {"true", "1", "visible", "shown", "yes", "on"}


def _boolish(value: Any) -> Optional[bool]:
    if value is None:
        return None
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return bool(value)
    if isinstance(value, str):
        text = value.strip().lower()
        if text in _FALSE_STRINGS:
            return False
        if text in _TRUE_STRINGS:
            return True
    return None


def is_component_visible(record: Dict[str, Any]) -> bool:
    hidden_keys = [
        "hidden", "is_hidden", "component_hidden", "hidden_in_assembly",
        "suppressed", "is_suppressed", "component_suppressed",
        "exclude_from_reference_view", "exclude_from_dataset",
    ]
    for key in hidden_keys:
        if key in record and _boolish(record.get(key)) is True:
            return False
    visible_keys = ["visible", "is_visible", "component_visible", "visible_in_assembly", "shown", "is_shown"]
    for key in visible_keys:
        if key in record:
            parsed = _boolish(record.get(key))
            if parsed is not None:
                return parsed
    visibility = record.get("visibility") or record.get("display_state") or record.get("state")
    if isinstance(visibility, str) and visibility.strip().lower() in {"hidden", "invisible", "suppressed", "not_visible", "not shown", "not_shown"}:
        return False
    return True


def is_component_explicitly_hidden(record: Dict[str, Any]) -> bool:
    hidden_keys = [
        "hidden", "is_hidden", "component_hidden", "hidden_in_assembly",
        "suppressed", "is_suppressed", "component_suppressed",
        "exclude_from_reference_view", "exclude_from_dataset",
    ]
    for key in hidden_keys:
        if key in record and _boolish(record.get(key)) is True:
            return True
    visibility = record.get("visibility") or record.get("display_state") or record.get("state")
    if isinstance(visibility, str) and visibility.strip().lower() in {"hidden", "invisible", "suppressed", "not_visible", "not shown", "not_shown"}:
        return True
    return False


def resolve_export_asset(export_dir: Path, value: Any) -> Optional[Path]:
    if not value:
        return None
    path = Path(str(value))
    candidates = [path] if path.is_absolute() else [export_dir / path, export_dir / str(value)]
    for candidate in candidates:
        if candidate.exists() and candidate.is_file():
            return candidate
    return None


def find_component_source(export_dir: Path, cid: str, node: Dict[str, Any], manifest: Dict[str, Dict[str, Any]]) -> Optional[Path]:
    item = manifest.get(cid) or {}
    for record in (node, item):
        for key in ["obj_mesh", "mesh_path", "mesh_file", "mesh", "mesh_relative_path"]:
            p = resolve_export_asset(export_dir, record.get(key))
            if p is not None and p.suffix.lower() in {".obj", ".stl"}:
                return p
    roots = [
        export_dir / "component_meshes",
        export_dir / "component_brep_packages",
        export_dir / "obj" / "components",
        export_dir / "component_library",
    ]
    for root in roots:
        if not root.exists():
            continue
        for ext in ["obj", "stl", "STL"]:
            for pat in [f"{cid}*.{ext}", f"**/{cid}*.{ext}"]:
                for p in sorted(root.glob(pat)):
                    if p.exists() and p.is_file():
                        return p
    return None


def find_component_assembly_stl(export_dir: Path, node: Dict[str, Any]) -> Optional[Path]:
    raw_name = str(
        node.get("component_name_raw")
        or node.get("component_name")
        or node.get("name")
        or ""
    ).strip()
    if not raw_name:
        return None
    obj_dir = export_dir / "obj"
    if not obj_dir.exists():
        return None
    expected = f"assembly - {raw_name}.stl".casefold()
    for path in obj_dir.glob("*.STL"):
        if path.name.casefold() == expected:
            return path
    for path in obj_dir.glob("*.stl"):
        if path.name.casefold() == expected:
            return path
    return None


def convert_stl_to_obj_builtin(src: Path, dst: Path) -> bool:
    try:
        data = src.read_bytes()
        triangles: List[Tuple[Tuple[float, float, float], Tuple[float, float, float], Tuple[float, float, float]]] = []
        if len(data) >= 84:
            tri_count = struct.unpack_from("<I", data, 80)[0]
            expected_size = 84 + tri_count * 50
            if tri_count > 0 and expected_size <= len(data):
                offset = 84
                for _ in range(tri_count):
                    vals = struct.unpack_from("<12fH", data, offset)
                    triangles.append((
                        (vals[3], vals[4], vals[5]),
                        (vals[6], vals[7], vals[8]),
                        (vals[9], vals[10], vals[11]),
                    ))
                    offset += 50
        if not triangles:
            vertices: List[Tuple[float, float, float]] = []
            for line in data.decode("utf-8", errors="ignore").splitlines():
                parts = line.strip().split()
                if len(parts) == 4 and parts[0].lower() == "vertex":
                    vertices.append((float(parts[1]), float(parts[2]), float(parts[3])))
                    if len(vertices) == 3:
                        triangles.append((vertices[0], vertices[1], vertices[2]))
                        vertices = []
        if not triangles:
            return False
        dst.parent.mkdir(parents=True, exist_ok=True)
        with dst.open("w", encoding="utf-8", newline="\n") as f:
            f.write(f"# converted from {src.name}\n")
            index = 1
            for tri in triangles:
                for vertex in tri:
                    f.write(f"v {vertex[0]:.9g} {vertex[1]:.9g} {vertex[2]:.9g}\n")
                f.write(f"f {index} {index + 1} {index + 2}\n")
                index += 3
        return dst.exists() and dst.stat().st_size > 0
    except Exception:
        return False


def convert_mesh_to_obj(src: Path, dst: Path) -> bool:
    try:
        import pyvista as pv
        mesh = pv.read(str(src))
        if not isinstance(mesh, pv.PolyData):
            mesh = mesh.extract_surface().triangulate()
        else:
            mesh = mesh.triangulate()
        if mesh.n_points == 0 or mesh.n_cells == 0:
            return False
        dst.parent.mkdir(parents=True, exist_ok=True)
        mesh.save(str(dst))
        return dst.exists() and dst.stat().st_size > 0
    except Exception:
        if src.suffix.lower() == ".stl":
            return convert_stl_to_obj_builtin(src, dst)
        return False


def find_direct_assembly_mesh_obj(export_dir: Path) -> Optional[Path]:
    """Find an assembly-level OBJ exported directly from the .sldasm exporter.

    Do not synthesize this file from component OBJ files; the direct assembly
    export preserves the exporter/SolidWorks assembly mesh semantics.
    """
    preferred = [
        export_dir / "assembly.mesh.obj",
        export_dir / "assembly.obj",
        export_dir / "obj" / "assembly.mesh.obj",
        export_dir / "obj" / "assembly.obj",
        export_dir / "meshes" / "assembly.mesh.obj",
        export_dir / "meshes" / "assembly.obj",
    ]
    for p in preferred:
        if p.exists() and p.is_file():
            return p
    hits: List[Path] = []
    for pat in ["*assembly*.mesh.obj", "*assembly*.obj", "**/*assembly*.mesh.obj", "**/*assembly*.obj"]:
        for p in sorted(export_dir.glob(pat)):
            if not p.exists() or not p.is_file():
                continue
            parts = {x.lower() for x in p.parts}
            if {"components", "component_library", "component_meshes"} & parts:
                continue
            hits.append(p)
    return hits[0] if hits else None


def copy_direct_assembly_mesh_obj(export_dir: Path, out_dir: Path) -> Optional[Path]:
    src = find_direct_assembly_mesh_obj(export_dir)
    dst = out_dir / "obj" / "assembly.mesh.obj"
    dst.parent.mkdir(parents=True, exist_ok=True)
    if src:
        shutil.copy2(src, dst)
        return dst
    for candidate in sorted((export_dir / "obj").glob("assembly*.STL")) + sorted((export_dir / "obj").glob("assembly*.stl")):
        if candidate.exists() and candidate.is_file() and convert_mesh_to_obj(candidate, dst):
            return dst
    return None


def find_direct_assembly_step(export_dir: Path) -> Optional[Path]:
    preferred = [
        export_dir / "assembly.step",
        export_dir / "assembly.stp",
        export_dir / "obj" / "assembly.step",
        export_dir / "obj" / "assembly.stp",
    ]
    for p in preferred:
        if p.exists() and p.is_file() and p.stat().st_size > 0:
            return p
    hits: List[Path] = []
    for pat in ["*assembly*.step", "*assembly*.stp", "**/*assembly*.step", "**/*assembly*.stp"]:
        for p in sorted(export_dir.glob(pat)):
            if not p.exists() or not p.is_file() or p.stat().st_size <= 0:
                continue
            parts = {x.lower() for x in p.parts}
            if {"component_geometry", "components", "component_library", "component_meshes"} & parts:
                continue
            hits.append(p)
    return hits[0] if hits else None


def copy_direct_assembly_step(export_dir: Path, out_dir: Path) -> Optional[Path]:
    src = find_direct_assembly_step(export_dir)
    if not src:
        return None
    dst = out_dir / "assembly.step"
    shutil.copy2(src, dst)
    return dst


def copy_component_objs(export_dir: Path, out_dir: Path, graph: Dict[str, Any]) -> Dict[str, Any]:
    manifest = load_component_manifest(export_dir)
    copied: Dict[str, str] = {}
    missing: List[str] = []
    skipped_invisible: List[str] = []
    for node in component_nodes_from_graph(graph):
        cid = str(node.get("component_id") or node.get("id"))
        src = find_component_source(export_dir, cid, node, manifest)
        if is_component_explicitly_hidden(node) or (not is_component_visible(node) and src is None):
            skipped_invisible.append(cid)
            continue
        mesh_dst = out_dir / "obj" / "components" / f"{cid}.mesh.obj"
        if src:
            mesh_dst.parent.mkdir(parents=True, exist_ok=True)
            if src.suffix.lower() == ".obj":
                shutil.copy2(src, mesh_dst)
                copied[cid] = str(src)
                continue
            if convert_mesh_to_obj(src, mesh_dst):
                copied[cid] = f"mesh_convert:{src}"
                continue
        stl = find_component_assembly_stl(export_dir, node)
        if stl and convert_mesh_to_obj(stl, mesh_dst):
            copied[cid] = f"assembly_stl_fallback:{stl}"
            continue
        missing.append(cid)
    assembly_obj = copy_direct_assembly_mesh_obj(export_dir, out_dir)
    return {
        "component_count": len(copied),
        "copied_from": copied,
        "missing_component_objs": missing,
        "skipped_invisible_component_objs": skipped_invisible,
        "skipped_invisible_component_count": len(skipped_invisible),
        "assembly_mesh_obj": str(assembly_obj) if assembly_obj else None,
        "assembly_mesh_source": "direct_sldasm_export" if assembly_obj else None,
        "missing_direct_assembly_mesh_obj": assembly_obj is None,
    }



def find_pose_spec_asset(export_dir: Path) -> Dict[str, Any]:
    copied: Dict[str, Any] = {"pose_spec": None, "component_geometry_dir": None}
    pose = export_dir / "assembly_pose_spec.json"
    if pose.exists():
        copied["pose_spec"] = str(pose)
    geom_dir = export_dir / "component_geometry"
    if geom_dir.exists() and geom_dir.is_dir():
        copied["component_geometry_dir"] = str(geom_dir)
    return copied

def copy_assembly_views(export_dir: Path, out_dir: Path) -> Dict[str, Any]:
    copied: Dict[str, str] = {}
    missing: List[str] = []
    render_dir = export_dir / "renders"
    view_dir = out_dir / "views" / "assembly"
    for view, names in VIEW_MAP.items():
        src = None
        for name in names:
            p = render_dir / name
            if p.exists():
                src = p
                break
        if src is None:
            missing.append(view)
            continue
        dst = view_dir / f"assembly_{view}.png"
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)
        copied[view] = str(dst)
    return {"copied_views": copied, "missing_views": missing}


def organize_exported_sample(export_dir: Path, out_dir: Path, overwrite: bool = True) -> Dict[str, Any]:
    if overwrite:
        clean_stage1_dirs(out_dir)
    else:
        out_dir.mkdir(parents=True, exist_ok=True)
    graph_path = find_graph_json(export_dir)
    if not graph_path:
        raise FileNotFoundError(f"No assembly graph json found under {export_dir}")
    graph = read_json(graph_path)
    shutil.copy2(graph_path, out_dir / "assembly_graph_gt.json")
    component_report = copy_component_objs(export_dir, out_dir, graph)
    assembly_step = copy_direct_assembly_step(export_dir, out_dir)
    pose_asset_report = find_pose_spec_asset(export_dir)
    if pose_asset_report.get("pose_spec"):
        pose_src = Path(str(pose_asset_report["pose_spec"]))
        if pose_src.exists():
            pose_dst = out_dir / "assembly_pose_spec.json"
            shutil.copy2(pose_src, pose_dst)
            pose_asset_report["pose_spec_copied"] = str(pose_dst)
    if pose_asset_report.get("component_geometry_dir"):
        geom_src = Path(str(pose_asset_report["component_geometry_dir"]))
        geom_dst = out_dir / "component_geometry"
        if geom_dst.exists():
            shutil.rmtree(geom_dst)
        shutil.copytree(geom_src, geom_dst)
        pose_asset_report["component_geometry_copied"] = str(geom_dst)
        pose_asset_report["component_step_count"] = len(list(geom_dst.glob("*.step"))) + len(list(geom_dst.glob("*.stp")))
    view_report = copy_assembly_views(export_dir, out_dir)
    report = {
        "schema": "cad_assembly_stage1_mesh_export_report.v1",
        "source_export_dir": str(export_dir),
        "out_dir": str(out_dir),
        "graph_json": str(graph_path),
        "assembly_graph_gt": str(out_dir / "assembly_graph_gt.json"),
        "assembly_step": str(assembly_step) if assembly_step else None,
        "assembly_step_source": "direct_sldasm_ap203_step_export" if assembly_step else None,
        **component_report,
        "pose_assets": pose_asset_report,
        **view_report,
        "notes": [
            "Stage 1 keeps mesh OBJ as the baseline geometry input.",
            "assembly.step is copied from the direct SolidWorks AP203 assembly STEP export.",
            "component_geometry/*.step is copied only to render CAD-style reference views; it is not used as topology input.",
            "assembly.mesh.obj is copied from the direct .sldasm exporter output, not synthesized from component OBJ files.",
            "Stage 2 reduces mate data to component pairs; Stage 1 preserves assembly_graph_gt.json."
        ],
    }
    write_json(out_dir / "export_pipeline_report.json", report)
    return report


def main() -> None:
    parser = argparse.ArgumentParser(description="Run/organize Stage 1 SolidWorks export for mesh-only CAD assembly baseline.")
    parser.add_argument("assembly", nargs="?", type=Path, help="Input .sldasm. Required unless --exported-dir is used.")
    parser.add_argument("out_sample", nargs="?", type=Path, help="Stage 1 sample output directory. Defaults to D:\\Desktop\\cad_assembly_stage1\\<sample>.")
    parser.add_argument("--exporter", type=Path, default=DEFAULT_EXPORTER)
    parser.add_argument("--export-work-dir", type=Path, default=None)
    parser.add_argument("--exported-dir", type=Path, default=None, help="Use an existing raw exporter output instead of opening SolidWorks.")
    parser.add_argument("--python", default=sys.executable)
    parser.add_argument("--topology-mode", choices=["full", "bounded", "mate_only"], default="mate_only")
    parser.add_argument("--max-visible-components", type=int, default=0, help="Skip assemblies above this visible component count before heavy export. 0 disables.")
    parser.add_argument("--exporter-timeout-sec", type=int, default=0, help="Timeout for the inner SolidWorks exporter process. 0 disables.")
    parser.add_argument("--export-thumbnails", action="store_true", help="Export per-component PNG thumbnails. Disabled by default for unattended batch stability.")
    parser.add_argument("--no-resolve-prt-folder", action="store_true", help="Disable temporary SLDASM/SLDPRT hardlink folder used to resolve nested part layouts.")
    parser.add_argument("--no-overwrite", action="store_true")
    args = parser.parse_args()
    if args.exported_dir and args.out_sample is None and args.assembly is not None:
        args.out_sample = args.assembly
        args.assembly = None
    if args.out_sample is None:
        if args.exported_dir:
            sample_name = args.exported_dir.name
        elif args.assembly:
            sample_name = args.assembly.stem
        else:
            parser.error("out_sample can be omitted only when assembly or --exported-dir gives a sample name")
        args.out_sample = Path("cad_assembly_stage1") / sample_name

    if args.exported_dir:
        export_dir = args.exported_dir
        export_run = {"skipped": True, "reason": "--exported-dir supplied"}
    else:
        if args.assembly is None:
            parser.error("assembly is required unless --exported-dir is supplied")
        export_dir = args.export_work_dir or (args.out_sample / "_raw_solidworks_export")
        export_run = run_solidworks_exporter(
            args.assembly,
            args.exporter,
            export_dir,
            args.python,
            args.topology_mode,
            args.max_visible_components,
            resolve_prt_folder=not args.no_resolve_prt_folder,
            timeout_sec=args.exporter_timeout_sec,
            export_thumbnails=args.export_thumbnails,
        )
        if export_run["returncode"] != 0:
            payload = parse_json_from_stdout(str(export_run.get("stdout") or ""))
            failure_payload = {
                "export_status": {
                    "success": False,
                    "stage": "solidworks_exporter",
                    "returncode": export_run.get("returncode"),
                    "timeout": bool(export_run.get("timeout")),
                    "timeout_sec": export_run.get("timeout_sec"),
                    "elapsed_sec": export_run.get("elapsed_sec"),
                },
                "exporter_stdout_json": payload,
                "phase_lines": phase_lines_from_stdout(str(export_run.get("stdout") or "")),
                "stdout_tail": str(export_run.get("stdout") or "")[-4000:],
                "stderr_tail": str(export_run.get("stderr") or "")[-4000:],
                "resolved_input": export_run.get("resolved_input"),
                "solidworks_kill": export_run.get("solidworks_kill"),
            }
            write_json(args.out_sample / "export_pipeline_report.json", {"export_run": export_run, **failure_payload})
            safe_print_json(failure_payload)
            raise SystemExit(export_run["returncode"])

    report = organize_exported_sample(export_dir, args.out_sample, overwrite=not args.no_overwrite)
    report["export_run"] = export_run
    write_json(args.out_sample / "export_pipeline_report.json", report)
    safe_print_json({"out_sample": str(args.out_sample), "summary": report})


if __name__ == "__main__":
    main()
