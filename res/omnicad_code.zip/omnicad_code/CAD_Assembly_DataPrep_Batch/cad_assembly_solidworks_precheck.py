#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Exact SolidWorks precheck for unattended CAD assembly batches.

This script opens assemblies in SolidWorks, but does not export meshes, STEP,
views, or graphs. It only checks:

1. feature tree extractable
2. visible component count <= limit

Each assembly is checked in a child Python process with timeout. If SolidWorks
hangs, the parent kills SLDWORKS.exe, records timeout, and continues.
"""
from __future__ import annotations

import argparse
import csv
import json
import subprocess
import sys
import time
import traceback
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parent


def read_path_list(path: Path | None) -> list[Path]:
    if not path or not path.exists():
        return []
    return [Path(line.strip().strip('"')) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]


def kill_solidworks() -> dict[str, Any]:
    cmd = ["taskkill", "/F", "/IM", "SLDWORKS.exe", "/T"]
    try:
        proc = subprocess.run(cmd, text=True, capture_output=True, timeout=30)
        return {"cmd": cmd, "returncode": proc.returncode, "stdout": proc.stdout, "stderr": proc.stderr}
    except Exception as exc:
        return {"cmd": cmd, "returncode": 1, "stderr": repr(exc), "exception": traceback.format_exc()}


def visible_count_from_nodes(nodes: list[dict[str, Any]]) -> int:
    return sum(
        1 for node in nodes
        if not bool(node.get("hidden") or node.get("suppressed") or node.get("is_hidden") or node.get("is_suppressed"))
    )


def precheck_one(assembly: Path, max_visible_components: int) -> dict[str, Any]:
    import pythoncom
    import win32com.client
    import export_solidworks_assembly_graph_v1_true_full_brep_match as exporter

    start = time.time()
    sw = None
    model = None
    pythoncom.CoInitialize()
    try:
        try:
            sw = win32com.client.DispatchEx("SldWorks.Application")
        except Exception:
            sw = win32com.client.Dispatch("SldWorks.Application")
        sw.Visible = False
        model = exporter.open_assembly(sw, assembly)
        if not exporter.has_extractable_feature_tree(model):
            status = "skip"
            reason = "feature_tree_not_extractable"
            count = None
        else:
            nodes, _sig, _name, _comp = exporter.collect_components_from_model(model)
            count = visible_count_from_nodes(nodes)
            if max_visible_components > 0 and count > max_visible_components:
                status = "skip"
                reason = "visible_component_count_gt_limit"
            else:
                status = "keep"
                reason = ""
        return {
            "assembly": str(assembly),
            "status": status,
            "skip_reason": reason,
            "visible_component_count": count,
            "max_visible_components": max_visible_components,
            "elapsed_sec": round(time.time() - start, 3),
        }
    except Exception as exc:
        return {
            "assembly": str(assembly),
            "status": "skip",
            "skip_reason": "precheck_exception",
            "visible_component_count": None,
            "max_visible_components": max_visible_components,
            "elapsed_sec": round(time.time() - start, 3),
            "error": repr(exc),
            "traceback": traceback.format_exc(),
        }
    finally:
        if sw is not None:
            try:
                exporter.save_close_quit_solidworks(sw, model)
            except Exception:
                pass
        try:
            pythoncom.CoUninitialize()
        except Exception:
            pass


def parse_json(stdout: str) -> dict[str, Any]:
    text = (stdout or "").strip()
    start = text.find("{")
    end = text.rfind("}")
    if start < 0 or end <= start:
        return {}
    try:
        data = json.loads(text[start:end + 1])
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def run_child(assembly: Path, args: argparse.Namespace) -> dict[str, Any]:
    cmd = [
        sys.executable,
        str(Path(__file__).resolve()),
        "--one",
        str(assembly),
        "--max-visible-components",
        str(args.max_visible_components),
    ]
    start = time.time()
    try:
        proc = subprocess.run(
            cmd,
            cwd=str(ROOT),
            text=True,
            capture_output=True,
            timeout=args.timeout_sec if args.timeout_sec and args.timeout_sec > 0 else None,
        )
        payload = parse_json(proc.stdout)
        if not payload:
            payload = {
                "assembly": str(assembly),
                "status": "skip",
                "skip_reason": "precheck_no_json",
                "visible_component_count": None,
            }
        payload.update({
            "returncode": proc.returncode,
            "child_elapsed_sec": round(time.time() - start, 3),
            "stderr_tail": (proc.stderr or "")[-500:],
        })
        return payload
    except subprocess.TimeoutExpired as exc:
        kill = kill_solidworks() if args.kill_solidworks_on_timeout else None
        return {
            "assembly": str(assembly),
            "status": "skip",
            "skip_reason": "timeout",
            "visible_component_count": None,
            "max_visible_components": args.max_visible_components,
            "returncode": 124,
            "child_elapsed_sec": round(time.time() - start, 3),
            "timeout_sec": args.timeout_sec,
            "solidworks_kill_returncode": (kill or {}).get("returncode"),
            "stderr_tail": str(exc.stderr or "")[-500:],
        }


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", type=Path, default=None)
    ap.add_argument("--sldasm-list", type=Path, default=None)
    ap.add_argument("--sldasm", type=Path, default=None)
    ap.add_argument("--out-dir", type=Path, default=None)
    ap.add_argument("--max-visible-components", type=int, default=30)
    ap.add_argument("--timeout-sec", type=int, default=180)
    ap.add_argument("--max-samples", type=int, default=0)
    ap.add_argument("--progress-every", type=int, default=20)
    ap.add_argument("--kill-solidworks-on-timeout", action="store_true", default=True)
    ap.add_argument("--no-kill-solidworks-on-timeout", dest="kill_solidworks_on_timeout", action="store_false")
    ap.add_argument("--one", type=Path, default=None, help=argparse.SUPPRESS)
    args = ap.parse_args()

    if args.one is not None:
        print(json.dumps(precheck_one(args.one, args.max_visible_components), ensure_ascii=False, indent=2))
        return

    if args.out_dir is None:
        raise SystemExit("--out-dir is required")
    args.out_dir.mkdir(parents=True, exist_ok=True)
    assemblies: list[Path] = []
    if args.sldasm:
        assemblies.append(args.sldasm)
    assemblies += read_path_list(args.sldasm_list)
    if args.root:
        assemblies += sorted(args.root.rglob("*.sldasm"))
    seen: set[str] = set()
    unique: list[Path] = []
    for path in assemblies:
        key = str(path).casefold()
        if key not in seen and path.exists():
            seen.add(key)
            unique.append(path)
    if args.max_samples > 0:
        unique = unique[:args.max_samples]

    all_csv = args.out_dir / "solidworks_precheck_all.csv"
    keep_txt = args.out_dir / f"solidworks_precheck_keep_le_{args.max_visible_components}.txt"
    skip_csv = args.out_dir / "solidworks_precheck_skipped.csv"
    fields = [
        "assembly", "status", "skip_reason", "visible_component_count",
        "max_visible_components", "returncode", "timeout_sec",
        "solidworks_kill_returncode", "child_elapsed_sec", "elapsed_sec",
        "stderr_tail", "error",
    ]
    keep_count = 0
    skip_count = 0
    with all_csv.open("w", encoding="utf-8-sig", newline="") as all_f, \
            skip_csv.open("w", encoding="utf-8-sig", newline="") as skip_f, \
            keep_txt.open("w", encoding="utf-8") as keep_f:
        all_writer = csv.DictWriter(all_f, fieldnames=fields)
        skip_writer = csv.DictWriter(skip_f, fieldnames=fields)
        all_writer.writeheader()
        skip_writer.writeheader()
        for idx, assembly in enumerate(unique, start=1):
            row = run_child(assembly, args)
            all_writer.writerow({k: row.get(k) for k in fields})
            if row.get("status") == "keep":
                keep_f.write(str(assembly) + "\n")
                keep_count += 1
            else:
                skip_writer.writerow({k: row.get(k) for k in fields})
                skip_count += 1
            if idx % max(1, args.progress_every) == 0:
                print(f"[precheck] {idx}/{len(unique)} keep={keep_count} skip={skip_count}", flush=True)

    summary = {
        "total": len(unique),
        "keep": keep_count,
        "skip": skip_count,
        "all_csv": str(all_csv),
        "keep_txt": str(keep_txt),
        "skip_csv": str(skip_csv),
    }
    (args.out_dir / "solidworks_precheck_summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
