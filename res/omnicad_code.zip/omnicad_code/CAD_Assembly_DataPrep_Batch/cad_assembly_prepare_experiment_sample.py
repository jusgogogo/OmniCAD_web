#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Prepare a mesh-only v4.2 component-level experiment sample from Stage 1.

Expected input from Stage 1:
  assembly_graph_gt.json
  obj/assembly.mesh.obj
  obj/components/c00001.mesh.obj
  views/assembly/assembly_front.png ...

Output layout:
  component_library/lib00001.mesh.obj
  assembly.mesh.obj
  assembly_graph_gt.json
  mate_graph.json
  reference_views/same_color/assembly_v01.png ... assembly_v08.png
  reference_views/color_by_component/assembly_v01.png ... assembly_v08.png

The prepared sample is intentionally flat: assembly.mesh.obj, assembly_graph_gt.json,
and mate_graph.json are written at the sample root. Nested reference_obj/, gt/,
graph/, obj/, and reference_views/components/ copies are not generated.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import shutil
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

import numpy as np

from cad_assembly_dataset import VIEW_NAMES, load_exported_gt, safe_rel, view_direction
from cad_assembly_visualize_prediction import color_for_index, euler_xyz_to_matrix, parse_obj, pose_to_rt, transform_vertices

IMG_EXTS = [".png", ".jpg", ".jpeg", ".webp"]


def file_sha1(path: Path, chunk_size: int = 1024 * 1024) -> str:
    h = hashlib.sha1()
    with path.open("rb") as f:
        while True:
            chunk = f.read(chunk_size)
            if not chunk:
                break
            h.update(chunk)
    return h.hexdigest()


def library_id_for_index(index: int) -> str:
    return f"lib{index:05d}"


_FALSE_STRINGS = {"false", "0", "hidden", "invisible", "suppressed", "no", "off", "none", "null"}
_TRUE_STRINGS = {"true", "1", "visible", "shown", "yes", "on"}


def _boolish(value: Any) -> Optional[bool]:
    """Parse SolidWorks/exporter visibility flags without treating 'False' as truthy."""
    if value is None:
        return None
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return bool(value)
    if isinstance(value, str):
        text = value.strip().lower()
        if text in _FALSE_STRINGS:
            return False
        if text in _TRUE_STRINGS:
            return True
    return None


def has_exported_component_geometry(record: Dict[str, Any]) -> bool:
    mesh_status = str(record.get("mesh_status") or "").strip().lower()
    step_status = str(record.get("step_status") or "").strip().lower()
    if mesh_status in {"ok", "reused"} or step_status == "ok":
        return True
    for key in ["mesh_path", "mesh_file", "mesh", "mesh_relative_path", "step_path", "step_file", "step_relative_path"]:
        if record.get(key):
            return True
    return False


def is_component_explicitly_hidden(record: Dict[str, Any]) -> bool:
    hidden_keys = [
        "hidden", "is_hidden", "component_hidden", "hidden_in_assembly",
        "suppressed", "is_suppressed", "component_suppressed",
        "exclude_from_reference_view", "exclude_from_dataset",
    ]
    for key in hidden_keys:
        if key in record and _boolish(record.get(key)) is True:
            return True
    visibility = record.get("visibility") or record.get("display_state") or record.get("state")
    if isinstance(visibility, str) and visibility.strip().lower() in {"hidden", "invisible", "suppressed", "not_visible", "not shown", "not_shown"}:
        return True
    return False


def is_component_visible(record: Dict[str, Any]) -> bool:
    """Best-effort visibility check for SolidWorks/exporter component records.

    Hidden/suppressed components must not enter component_library, assembly_graph_gt,
    mate_graph, or reference-view rendering. This parser is intentionally strict
    about hidden/suppressed flags and robust to string values like "False".
    """
    hidden_keys = [
        "hidden", "is_hidden", "component_hidden", "hidden_in_assembly",
        "suppressed", "is_suppressed", "component_suppressed",
        "exclude_from_reference_view", "exclude_from_dataset",
    ]
    for key in hidden_keys:
        if key in record and _boolish(record.get(key)) is True:
            return False

    visible_keys = ["visible", "is_visible", "component_visible", "visible_in_assembly", "shown", "is_shown"]
    for key in visible_keys:
        if key in record:
            parsed = _boolish(record.get(key))
            if parsed is not None:
                return parsed

    visibility = record.get("visibility") or record.get("display_state") or record.get("state")
    if isinstance(visibility, str):
        text = visibility.strip().lower()
        if text in {"hidden", "invisible", "suppressed", "not_visible", "not shown", "not_shown"}:
            return False
        if text in {"visible", "shown", "resolved", "lightweight"}:
            return True
    if not is_component_explicitly_hidden(record) and has_exported_component_geometry(record):
        return True
    return True


def visible_component_ids(gt: Dict[str, Any]) -> set[str]:
    return {
        str(n.get("component_id") or n.get("id") or "")
        for n in (gt.get("nodes") or [])
        if isinstance(n, dict) and is_component_visible(n) and str(n.get("component_id") or n.get("id") or "")
    }


def filter_gt_to_visible_components(gt: Dict[str, Any]) -> Tuple[Dict[str, Any], set[str]]:
    """Return a GT-like dict containing only visible component nodes and visible-visible mate edges."""
    keep_ids = visible_component_ids(gt)
    visible_nodes = [
        n for n in (gt.get("nodes") or [])
        if isinstance(n, dict) and str(n.get("component_id") or n.get("id") or "") in keep_ids
    ]
    visible_edges = []
    for e in gt.get("edges") or []:
        if not isinstance(e, dict):
            continue
        a, b = edge_source_target(e)
        if a in keep_ids and b in keep_ids:
            visible_edges.append(e)
    out = dict(gt)
    out["nodes"] = visible_nodes
    out["node_parts"] = visible_nodes
    out["edges"] = visible_edges
    return out, keep_ids


def component_identity_key(node: Dict[str, Any], mesh_src: Path, manifest: Dict[str, Dict[str, Any]]) -> Optional[str]:
    cid = str(node.get("component_id") or node.get("id") or "")
    item = manifest.get(cid) or {}
    for key in ["part_id", "document_id", "document_path", "referenced_document", "part_file", "model_path", "file_path", "path"]:
        value = item.get(key) or node.get(key)
        if value:
            return f"{key}:{value}"
    try:
        return f"source_sha1:{file_sha1(mesh_src)}"
    except Exception:
        return None


VIEW_SURFACE_SAME_COLOR = "#cfd7df"
VIEW_EDGE_COLOR = "#17212b"
# CAD-style bright pastel colors, close to omnimech_tools wireframe renders.
VIEW_PASTEL_PALETTE = [
    "#d9dc83", "#d98bc9", "#ffc178", "#8fd48f", "#c8c8c8", "#9bc9ee",
    "#f3a6c9", "#a8e0ae", "#ffae64", "#89bde8", "#bfa7e8", "#d7ad96",
    "#efe58a", "#f5a3a3", "#8ed8df", "#c4dd86", "#ffcf8a", "#bfc7d5",
]


def _hex_to_rgb(color: Any) -> Tuple[float, float, float]:
    if isinstance(color, str):
        c = color.strip()
        if c.startswith("#") and len(c) == 7:
            try:
                return (int(c[1:3], 16) / 255.0, int(c[3:5], 16) / 255.0, int(c[5:7], 16) / 255.0)
            except Exception:
                pass
    return (0.78, 0.82, 0.86)


def _rgb_to_hex(rgb: Tuple[float, float, float]) -> str:
    return "#" + "".join(f"{int(max(0.0, min(1.0, v)) * 255 + 0.5):02x}" for v in rgb)


def _lighten_hex(color: Any, amount: float = 0.42) -> str:
    rgb = _hex_to_rgb(color)
    return _rgb_to_hex(tuple(v + (1.0 - v) * amount for v in rgb))


def view_color_for_index(index: int, same_color: bool = False) -> str:
    if same_color:
        return VIEW_SURFACE_SAME_COLOR
    if index < len(VIEW_PASTEL_PALETTE):
        return VIEW_PASTEL_PALETTE[index]
    return _lighten_hex(color_for_index(index), amount=0.46)


def _shade_rgb(rgb: Tuple[float, float, float], shade: float) -> Tuple[float, float, float]:
    shade = max(0.0, min(float(shade), 1.0))
    ambient = 0.72
    factor = ambient + (1.0 - ambient) * shade
    lit = tuple(v * factor for v in rgb)
    return tuple(max(0.0, min(1.0, v + 0.06 * (1.0 - v))) for v in lit)



def _camera_frame_for_view(view: str) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    direction = np.asarray(view_direction(view), dtype=float)
    norm = float(np.linalg.norm(direction))
    if norm < 1e-12:
        direction = np.array([1.0, 1.0, 1.0], dtype=float)
        norm = float(np.linalg.norm(direction))
    direction = direction / norm
    forward = -direction
    up_hint = np.array([0.0, 0.0, 1.0], dtype=float)
    if abs(float(np.dot(up_hint, forward))) > 0.92:
        up_hint = np.array([0.0, 1.0, 0.0], dtype=float)
    right = np.cross(forward, up_hint)
    if float(np.linalg.norm(right)) < 1e-12:
        up_hint = np.array([1.0, 0.0, 0.0], dtype=float)
        right = np.cross(forward, up_hint)
    right = right / max(float(np.linalg.norm(right)), 1e-12)
    up = np.cross(right, forward)
    up = up / max(float(np.linalg.norm(up)), 1e-12)
    return forward, right, up


def project_vertices(vertices: np.ndarray, view: str) -> Tuple[np.ndarray, np.ndarray]:
    if vertices.size == 0:
        return np.zeros((0, 2), dtype=float), np.zeros((0,), dtype=float)
    forward, right, up = _camera_frame_for_view(view)
    mins = vertices.min(axis=0)
    maxs = vertices.max(axis=0)
    center = (mins + maxs) / 2.0
    diag = float(np.linalg.norm(maxs - mins))
    cam_dist = max(diag * 2.4, 1.0)
    cam_pos = center - forward * cam_dist
    rel = vertices - cam_pos
    z = rel @ forward
    x = rel @ right
    y = rel @ up
    eps = max(diag * 1e-4, 1e-6)
    denom = np.maximum(z, eps)
    xy = np.column_stack([x / denom, y / denom])
    return xy, z

def render_projected_png(meshes: List[Dict[str, Any]], out: Path, view: str, edge: bool, max_faces_total: int = 70000) -> None:
    """Fallback shaded mesh renderer used when PyVista/offscreen rendering fails."""
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib.collections import PolyCollection

    polygons: List[np.ndarray] = []
    colors: List[Any] = []
    depths: List[float] = []
    remaining = max_faces_total
    forward, right, up = _camera_frame_for_view(view)
    light_dir = -(forward - 0.35 * up + 0.20 * right)
    light_dir = light_dir / max(float(np.linalg.norm(light_dir)), 1e-12)
    for mesh_idx, mesh in enumerate(meshes):
        V, F = mesh["vertices"], mesh["faces"]
        if V.size == 0 or F.size == 0 or remaining <= 0:
            continue
        if len(F) > remaining:
            step = max(1, len(F) // max(1, remaining))
            F_use = F[::step][:remaining]
        else:
            F_use = F
        remaining -= len(F_use)
        xy, depth = project_vertices(V, view)
        base_rgb = _hex_to_rgb(mesh.get("color") or color_for_index(mesh_idx))
        for tri in F_use:
            try:
                pts3 = V[tri]
                n = np.cross(pts3[1] - pts3[0], pts3[2] - pts3[0])
                n_norm = float(np.linalg.norm(n))
                if n_norm > 1e-12:
                    n = n / n_norm
                    shade = abs(float(np.dot(n, light_dir)))
                else:
                    shade = 0.55
                polygons.append(xy[tri])
                depths.append(float(depth[tri].mean()))
                colors.append(_shade_rgb(base_rgb, 0.45 + 0.55 * shade))
            except Exception:
                pass
    order = np.argsort(depths)[::-1] if depths else []
    polygons = [polygons[i] for i in order]
    colors = [colors[i] for i in order]
    fig, ax = plt.subplots(figsize=(7.2, 7.2), dpi=180)
    if polygons:
        pc = PolyCollection(polygons, facecolors=colors, edgecolors="black" if edge else "none", linewidths=0.12 if edge else 0.0, alpha=1.0)
        ax.add_collection(pc)
        all_pts = np.concatenate(polygons, axis=0)
        mins = all_pts.min(axis=0)
        maxs = all_pts.max(axis=0)
        span = max(float((maxs - mins).max()), 1.0)
        center = (mins + maxs) / 2
        pad = span * 0.06
        ax.set_xlim(center[0] - span / 2 - pad, center[0] + span / 2 + pad)
        ax.set_ylim(center[1] - span / 2 - pad, center[1] + span / 2 + pad)
    ax.set_aspect("equal", adjustable="box")
    ax.axis("off")
    out.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(out, bbox_inches="tight", pad_inches=0.02)
    plt.close(fig)


def build_component_gt(gt: Dict[str, Any], component_to_library: Dict[str, str]) -> Dict[str, Any]:
    node_parts: List[Dict[str, Any]] = []
    valid_ids = set(component_to_library.keys())
    for n in gt.get("nodes") or []:
        cid = str(n.get("component_id") or n.get("id") or "")
        if not cid or cid not in valid_ids:
            continue
        position = n.get("position") or (n.get("pose") or {}).get("position") or {}
        orientation = n.get("orientation") or (n.get("pose") or {}).get("orientation") or {}
        node = {"component_id": cid}
        library_id = component_to_library.get(cid)
        if library_id:
            node["library_id"] = library_id
        node["pose"] = {"position": position, "orientation": orientation}
        node_parts.append(node)
    edges = []
    for e in gt.get("edges") or []:
        a, b = edge_source_target(e)
        if not a or not b or a not in valid_ids or b not in valid_ids:
            continue
        edges.append({
            "source_component": a,
            "target_component": b,
            "mate_type": str(e.get("mate_type") or "UnknownMate"),
        })
    return {"assembly_id": gt.get("assembly_id"), "nodes": node_parts, "edges": edges}

def read_json(path: Path) -> Any:
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def write_json(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def copy_file(src: Optional[Path], dst: Path, overwrite: bool = True) -> bool:
    if src is None or not src.exists():
        return False
    dst.parent.mkdir(parents=True, exist_ok=True)
    if dst.exists() and not overwrite:
        return True
    shutil.copy2(src, dst)
    return True


def _polydata_arrays(mesh: Any) -> Tuple[np.ndarray, np.ndarray]:
    faces = np.asarray(mesh.faces).reshape((-1, 4))
    triangles = faces[faces[:, 0] == 3][:, 1:4]
    return np.asarray(mesh.points, dtype=float), triangles.astype(int)


def write_obj(path: Path, vertices: np.ndarray, faces: np.ndarray) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="\n") as f:
        f.write("# component mesh in local component coordinates\n")
        for x, y, z in np.asarray(vertices, dtype=float):
            f.write(f"v {x:.9g} {y:.9g} {z:.9g}\n")
        for a, b, c in np.asarray(faces, dtype=int):
            f.write(f"f {int(a) + 1} {int(b) + 1} {int(c) + 1}\n")


def local_component_mesh_from_pose_spec(src_sample: Path, cid: str) -> Tuple[Optional[np.ndarray], Optional[np.ndarray], Optional[str]]:
    """Return component geometry in local coordinates, using the raw SW pose spec when available."""
    try:
        import pyvista as pv
    except Exception as exc:
        return None, None, f"pose_spec_pyvista_unavailable:{exc!r}"
    last_error: Optional[str] = None
    for pose_path, pose_root in pose_spec_candidates(src_sample):
        try:
            spec = read_json(pose_path)
            geoms = {str(g.get("part_id")): g for g in spec.get("part_geometries") or [] if isinstance(g, dict)}
            comp = next((c for c in spec.get("components") or [] if str(c.get("component_id") or c.get("id") or "") == cid), None)
            if not isinstance(comp, dict):
                last_error = f"pose_spec_missing_component:{cid}"
                continue
            geom = geoms.get(str(comp.get("part_id"))) or {}
            mesh_value = geom.get("mesh_file") or geom.get("mesh_path") or comp.get("mesh") or comp.get("mesh_path")
            if not mesh_value:
                last_error = f"pose_spec_missing_mesh:{cid}"
                continue
            mesh_path = Path(str(mesh_value))
            if not mesh_path.is_absolute():
                mesh_path = pose_root / mesh_path
            if not mesh_path.exists():
                last_error = f"pose_spec_missing_mesh_file:{cid}:{mesh_value}"
                continue
            mesh = pv.read(str(mesh_path))
            if not isinstance(mesh, pv.PolyData):
                mesh = mesh.extract_surface().triangulate()
            else:
                mesh = mesh.triangulate()
            mesh_frame = geom.get("mesh_coordinate_frame") or comp.get("mesh_coordinate_frame") or "part_local"
            correction = geom.get("mesh_coordinate_correction_mm") or comp.get("mesh_coordinate_correction_mm")
            matrix = (comp.get("transform") or {}).get("matrix4x4")
            if mesh_frame == "assembly_context_export":
                if matrix:
                    mesh.transform(np.linalg.inv(np.array(matrix, dtype=float)), inplace=True)
                else:
                    last_error = f"pose_spec_assembly_frame_without_transform:{cid}"
                    continue
            elif correction:
                mesh.translate(np.array(correction, dtype=float), inplace=True)
            vertices, faces = _polydata_arrays(mesh)
            if vertices.size == 0 or faces.size == 0:
                last_error = f"pose_spec_empty_mesh:{cid}"
                continue
            return vertices, faces, f"pose_spec:{pose_path}"
        except Exception as exc:
            last_error = f"pose_spec_local_mesh_failed:{cid}:{exc!r}"
    return None, None, last_error


def localize_existing_component_obj(mesh_src: Path, node: Dict[str, Any]) -> Tuple[np.ndarray, np.ndarray]:
    vertices, faces = parse_obj(mesh_src, max_faces=10_000_000)
    pred_node = {
        "component_id": str(node.get("component_id") or node.get("id") or ""),
        "pose": {
            "position": node.get("position") or (node.get("pose") or {}).get("position") or {},
            "orientation": node.get("orientation") or (node.get("pose") or {}).get("orientation") or {},
            "transform": node.get("transform") or {},
        },
        "transform": node.get("transform") or {},
    }
    R, t = pose_to_rt(pred_node)
    return (vertices - t) @ R, faces


def write_local_component_obj(src_sample: Path, node: Dict[str, Any], mesh_src: Path, mesh_dst: Path) -> Tuple[bool, str]:
    cid = str(node.get("component_id") or node.get("id") or "")
    vertices, faces, source = local_component_mesh_from_pose_spec(src_sample, cid)
    if vertices is not None and faces is not None:
        write_obj(mesh_dst, vertices, faces)
        return True, source or "pose_spec"
    try:
        vertices, faces = localize_existing_component_obj(mesh_src, node)
        write_obj(mesh_dst, vertices, faces)
        return True, f"inverse_gt_pose:{safe_rel(mesh_src, src_sample)}"
    except Exception as exc:
        return False, f"localize_failed:{cid}:{source or ''}:{exc!r}"


def _manifest_items(src_sample: Path) -> Dict[str, Dict[str, Any]]:
    path = src_sample / "component_brep_packages" / "manifest.json"
    if not path.exists():
        return {}
    try:
        data = read_json(path)
    except Exception:
        return {}
    out: Dict[str, Dict[str, Any]] = {}
    for item in data.get("components") or []:
        if isinstance(item, dict) and item.get("component_id"):
            out[str(item["component_id"])] = item
    return out


def _mesh_candidates(src_sample: Path, node: Dict[str, Any], manifest: Dict[str, Dict[str, Any]]) -> Iterable[Path]:
    cid = str(node.get("component_id") or node.get("id") or "")
    assets = node.get("assets") or {}
    for key in ["mesh_obj", "obj", "component_obj"]:
        if assets.get(key):
            yield src_sample / str(assets[key])
    item = manifest.get(cid) or {}
    if item.get("obj_mesh"):
        yield Path(str(item["obj_mesh"]))
    roots = [src_sample / "obj" / "components", src_sample / "obj", src_sample / "component_library"]
    for root in roots:
        if not root.exists():
            continue
        for pat in [f"{cid}.mesh.obj", f"{cid}.obj", f"{cid}*.mesh.obj", f"{cid}*.obj"]:
            yield from sorted(root.glob(pat))


def find_component_mesh_obj(src_sample: Path, node: Dict[str, Any], manifest: Dict[str, Dict[str, Any]]) -> Optional[Path]:
    seen: set[str] = set()
    for p in _mesh_candidates(src_sample, node, manifest):
        key = str(p)
        if key in seen:
            continue
        seen.add(key)
        if p.exists() and p.is_file():
            return p
    return None


def find_original_view(src_sample: Path, view: str) -> Optional[Path]:
    roots = [src_sample / "views" / "assembly", src_sample / "renders", src_sample / "reference_views" / "same_color", src_sample / "views", src_sample]
    aliases = [view] + (["isometric"] if view == "iso" else [])
    for root in roots:
        if not root.exists():
            continue
        patterns: List[str] = []
        for alias in aliases:
            patterns += [f"assembly_{alias}*", f"assembly_gt_{alias}*", f"*_{alias}*", f"*{alias}*"]
        for pat in patterns:
            for p in sorted(root.glob(pat)):
                if p.is_file() and p.suffix.lower() in IMG_EXTS:
                    return p
    return None


def copy_original_assembly_views(src_sample: Path, out_sample: Path, overwrite: bool = True) -> Dict[str, str]:
    """Keep raw SolidWorks/exporter views for debugging, not as experiment reference_views."""
    copied: Dict[str, str] = {}
    for view in VIEW_NAMES:
        src = find_original_view(src_sample, view)
        if src:
            dst = out_sample / "reference_views" / "solidworks_original" / f"assembly_{view}.png"
            copy_file(src, dst, overwrite=overwrite)
            copied[view] = safe_rel(dst, out_sample)
    return copied


def copy_reference_mesh_obj(src_sample: Path, out_sample: Path, overwrite: bool = True) -> Dict[str, Any]:
    """Copy the direct assembly-level mesh OBJ to sample_root/assembly.mesh.obj.

    This function intentionally copies only direct Stage1/exporter assembly OBJ
    files. It does not synthesize an assembly OBJ from component poses. The
    prepared-sample layout keeps only one copy of this file at the sample root.
    """
    candidates = [
        src_sample / "obj" / "assembly.mesh.obj",
        src_sample / "reference_obj" / "assembly.mesh.obj",  # backward compatibility with old Stage1/prepared layouts
        src_sample / "obj" / "assembly.obj",
        src_sample / "assembly.mesh.obj",
        src_sample / "assembly.obj",
    ]
    for src in candidates:
        if not src.exists() or not src.is_file():
            continue
        dst = out_sample / "assembly.mesh.obj"
        copy_file(src, dst, overwrite=overwrite)
        return {
            "source": safe_rel(src, src_sample),
            "assembly_mesh_source": "direct_stage1_assembly_obj",
            "is_direct_assembly_export": True,
            "written": {"root": safe_rel(dst, out_sample)},
        }
    return {
        "assembly_mesh_source": "missing",
        "is_direct_assembly_export": False,
        "written": {},
    }


def copy_reference_step(src_sample: Path, out_sample: Path, overwrite: bool = True) -> Dict[str, Any]:
    """Copy the direct assembly-level STEP to sample_root/assembly.step."""
    candidates = [
        src_sample / "assembly.step",
        src_sample / "assembly.stp",
        src_sample / "obj" / "assembly.step",
        src_sample / "obj" / "assembly.stp",
    ]
    for src in candidates:
        if not src.exists() or not src.is_file() or src.stat().st_size <= 0:
            continue
        dst = out_sample / "assembly.step"
        copy_file(src, dst, overwrite=overwrite)
        return {
            "source": safe_rel(src, src_sample),
            "assembly_step_source": "direct_stage1_assembly_step",
            "is_direct_assembly_step_export": True,
            "written": {"root": safe_rel(dst, out_sample)},
        }
    return {
        "assembly_step_source": "missing",
        "is_direct_assembly_step_export": False,
        "written": {},
    }



def pose_spec_candidates(src_sample: Path) -> List[Tuple[Path, Path]]:
    out: List[Tuple[Path, Path]] = []
    direct = src_sample / "assembly_pose_spec.json"
    if direct.exists():
        out.append((direct, src_sample))
    report_path = src_sample / "export_pipeline_report.json"
    if report_path.exists():
        try:
            report = read_json(report_path)
            raw_dir = Path(str(report.get("source_export_dir") or ""))
            raw_pose = raw_dir / "assembly_pose_spec.json"
            if raw_pose.exists():
                out.append((raw_pose, raw_dir))
        except Exception:
            pass
    return out


def build_meshes_from_pose_spec(pose_path: Path, pose_root: Path, same_color: bool = False) -> Tuple[List[Dict[str, Any]], List[str]]:
    if not pose_path.exists():
        return [], ["missing_pose_spec"]
    try:
        import pyvista as pv
        spec = read_json(pose_path)
    except Exception as exc:
        return [], [f"pose_spec_read_failed:{exc!r}"]
    geoms = {str(g.get("part_id")): g for g in spec.get("part_geometries") or [] if isinstance(g, dict)}
    meshes: List[Dict[str, Any]] = []
    errors: List[str] = []
    for idx, comp in enumerate(spec.get("components") or []):
        if not isinstance(comp, dict):
            continue
        if not is_component_visible(comp):
            continue
        cid = str(comp.get("component_id") or comp.get("id") or "")
        geom = geoms.get(str(comp.get("part_id"))) or {}
        mesh_value = geom.get("mesh_file") or geom.get("mesh_path") or comp.get("mesh") or comp.get("mesh_path")
        if not mesh_value:
            errors.append(f"missing_pose_mesh:{cid}")
            continue
        mesh_path = Path(str(mesh_value))
        if not mesh_path.is_absolute():
            mesh_path = pose_root / mesh_path
        if not mesh_path.exists():
            errors.append(f"missing_pose_mesh_file:{cid}:{mesh_value}")
            continue
        try:
            mesh = pv.read(str(mesh_path))
            if not isinstance(mesh, pv.PolyData):
                mesh = mesh.extract_surface().triangulate()
            else:
                mesh = mesh.triangulate()
            mesh_frame = geom.get("mesh_coordinate_frame") or comp.get("mesh_coordinate_frame") or "part_local"
            correction = geom.get("mesh_coordinate_correction_mm") or comp.get("mesh_coordinate_correction_mm")
            if correction and mesh_frame != "assembly_context_export":
                mesh.translate(np.array(correction, dtype=float), inplace=True)
            matrix = (comp.get("transform") or {}).get("matrix4x4")
            if matrix and mesh_frame != "assembly_context_export":
                mesh.transform(np.array(matrix, dtype=float), inplace=True)
            faces = np.asarray(mesh.faces).reshape((-1, 4))
            triangles = faces[faces[:, 0] == 3][:, 1:4]
            if mesh.n_points == 0 or triangles.size == 0:
                errors.append(f"empty_pose_mesh:{cid}")
                continue
            meshes.append({
                "component_id": cid,
                "vertices": np.asarray(mesh.points, dtype=float),
                "faces": triangles.astype(int),
                "color": view_color_for_index(idx, same_color=same_color),
            })
        except Exception as exc:
            errors.append(f"pose_mesh_failed:{cid}:{exc!r}")
    return meshes, errors

def make_gt_prediction(gt: Dict[str, Any]) -> Dict[str, Any]:
    nodes = []
    for n in gt.get("nodes") or []:
        cid = str(n.get("component_id") or n.get("id") or "")
        if not cid:
            continue
        pose = {"position": n.get("position") or {}, "orientation": n.get("orientation") or {}}
        if n.get("transform"):
            pose["transform"] = n.get("transform")
        nodes.append({"component_id": cid, "component_name": str(n.get("component_name") or n.get("name") or cid), "pose": pose, "transform": n.get("transform") or {}})
    return {"assembly_id": gt.get("assembly_id"), "nodes": nodes}


def _library_obj_map(out_sample: Path, library: List[Dict[str, str]]) -> Dict[str, Path]:
    out: Dict[str, Path] = {}
    for item in library:
        lib_id = str(item.get("library_id") or item.get("component_id") or "")
        rel = item.get("obj_file")
        if lib_id and rel:
            out[lib_id] = out_sample / rel
    return out


def build_meshes_for_frame(out_sample: Path, gt: Dict[str, Any], library: List[Dict[str, str]], frame: str, same_color: bool = False, component_to_library: Optional[Dict[str, str]] = None) -> Tuple[List[Dict[str, Any]], List[str]]:
    obj_map = _library_obj_map(out_sample, library)
    meshes: List[Dict[str, Any]] = []
    errors: List[str] = []
    component_to_library = component_to_library or {}
    visible_nodes = [n for n in (gt.get("nodes") or []) if isinstance(n, dict) and is_component_visible(n)]
    visible_gt = dict(gt)
    visible_gt["nodes"] = visible_nodes
    for idx, n in enumerate(make_gt_prediction(visible_gt).get("nodes") or []):
        cid = str(n.get("component_id"))
        lib_id = component_to_library.get(cid, cid)
        obj = obj_map.get(lib_id)
        if not obj or not obj.exists():
            errors.append(f"missing_obj:{cid}:{lib_id}")
            continue
        try:
            verts, faces = parse_obj(obj)
            if frame == "local":
                R, t = pose_to_rt(n)
                verts = transform_vertices(verts, R, t)
            elif frame != "assembly":
                raise ValueError(frame)
            meshes.append({"component_id": cid, "vertices": verts, "faces": faces, "color": view_color_for_index(idx, same_color=same_color)})
        except Exception as exc:
            errors.append(f"render_mesh_failed:{cid}:{exc!r}")
    return meshes, errors


def mesh_bbox_diag(meshes: List[Dict[str, Any]]) -> float:
    pts = [m["vertices"] for m in meshes if isinstance(m.get("vertices"), np.ndarray) and m["vertices"].size]
    if not pts:
        return float("inf")
    P = np.vstack(pts)
    return float(np.linalg.norm(P.max(axis=0) - P.min(axis=0)))


def choose_component_obj_frame(out_sample: Path, gt: Dict[str, Any], library: List[Dict[str, str]], requested: str) -> str:
    if requested != "auto":
        return requested
    return "local"



def render_pyvista_png(meshes: List[Dict[str, Any]], out: Path, view: str, show_edges: bool) -> bool:
    """Render assembly reference view.

    show_edges=False:
        shaded pastel rendering, used by color_by_component.

    show_edges=True:
        SolidWorks-like shaded-with-feature-edges rendering.
        Do NOT draw all triangulation edges. Only extract feature/boundary edges.
    """
    try:
        import pyvista as pv
    except Exception:
        return False

    plotter = None
    try:
        plotter = pv.Plotter(off_screen=True, window_size=(1280, 960))
        plotter.set_background("white")
        try:
            plotter.enable_anti_aliasing("ssaa")
        except Exception:
            pass

        added = 0
        all_pts: List[np.ndarray] = []

        for mesh in meshes:
            V, F = mesh["vertices"], mesh["faces"]
            if V.size == 0 or F.size == 0:
                continue

            faces = np.empty((len(F), 4), dtype=np.int64)
            faces[:, 0] = 3
            faces[:, 1:] = F.astype(np.int64)
            poly = pv.PolyData(V, faces.ravel())

            # Key change:
            # Do not use show_edges=True here, because that draws every triangle edge.
            # For same_color views, render smooth shaded body first.
            plotter.add_mesh(
                poly,
                color=mesh.get("color") or "#9aa1ad",
                opacity=1.0,
                smooth_shading=True,
                show_edges=False,
                lighting=True,
                ambient=0.82,
                diffuse=0.22,
                specular=0.0,
                specular_power=8,
            )

            # SolidWorks-like edge effect:
            # draw only sharp feature edges / boundaries, not tessellation edges.
            if show_edges:
                try:
                    feature_edges = poly.extract_feature_edges(
                        feature_angle=18.0,
                        boundary_edges=True,
                        non_manifold_edges=True,
                        feature_edges=True,
                        manifold_edges=False,
                    )
                    if feature_edges.n_points > 0:
                        plotter.add_mesh(
                            feature_edges,
                            color=VIEW_EDGE_COLOR,
                            line_width=1.6,
                            render_lines_as_tubes=False,
                            lighting=False,
                        )
                except Exception:
                    pass

            all_pts.append(np.asarray(V, dtype=float))
            added += 1

        if added == 0 or not all_pts:
            return False

        pts = np.vstack(all_pts)
        bounds_min = pts.min(axis=0)
        bounds_max = pts.max(axis=0)
        center = (bounds_min + bounds_max) * 0.5
        diag = float(np.linalg.norm(bounds_max - bounds_min))
        cam_dist = max(diag * 2.4, 1.0)

        direction = np.asarray(view_direction(view), dtype=float)
        direction = direction / max(float(np.linalg.norm(direction)), 1e-12)
        cam_pos = center + direction * cam_dist

        up_hint = np.array([0.0, 0.0, 1.0], dtype=float)
        if abs(float(np.dot(up_hint, direction))) > 0.92:
            up_hint = np.array([0.0, 1.0, 0.0], dtype=float)

        right = np.cross(up_hint, direction)
        if float(np.linalg.norm(right)) < 1e-12:
            up_hint = np.array([1.0, 0.0, 0.0], dtype=float)
            right = np.cross(up_hint, direction)

        right = right / max(float(np.linalg.norm(right)), 1e-12)
        up = np.cross(direction, right)
        up = up / max(float(np.linalg.norm(up)), 1e-12)

        plotter.camera_position = [
            tuple(cam_pos.tolist()),
            tuple(center.tolist()),
            tuple(up.tolist()),
        ]
        plotter.camera.parallel_projection = True

        offsets = pts - center
        half_width = float(np.max(np.abs(offsets @ right)))
        half_height = float(np.max(np.abs(offsets @ up)))
        aspect = 1280.0 / 960.0
        margin = 0.05
        plotter.camera.parallel_scale = max(half_height, half_width / aspect, 1e-6) / (1.0 - 2.0 * margin)
        plotter.reset_camera_clipping_range()

        out.parent.mkdir(parents=True, exist_ok=True)
        plotter.screenshot(str(out))
        return True

    except Exception:
        return False

    finally:
        try:
            if plotter is not None:
                plotter.close()
        except Exception:
            pass


def render_png_best(meshes: List[Dict[str, Any]], out: Path, view: str, show_edges: bool) -> str:
    if render_pyvista_png(meshes, out, view, show_edges=show_edges):
        return "pyvista"

    try:
        # Fallback keeps the same pastel fill and visible outline style when PyVista/VTK is unavailable.
        render_projected_png(meshes, out, view, edge=show_edges)
        return "projected_fallback"
    except Exception as exc:
        return f"failed:{exc!r}"


def _step_geometry_path(value: Any, pose_root: Path) -> Optional[Path]:
    if not value:
        return None
    path = Path(str(value))
    if not path.is_absolute():
        path = pose_root / path
    return path if path.exists() and path.is_file() else None


def _matrix4x4_from_component(comp: Dict[str, Any]) -> Optional[np.ndarray]:
    matrix = (comp.get("transform") or {}).get("matrix4x4") or comp.get("matrix4x4")
    if matrix is None:
        return None
    try:
        arr = np.asarray(matrix, dtype=float)
        if arr.shape == (4, 4):
            return arr
    except Exception:
        pass
    return None


def _apply_matrix4x4(vertices: np.ndarray, matrix: Optional[np.ndarray]) -> np.ndarray:
    if matrix is None or vertices.size == 0:
        return np.asarray(vertices, dtype=float)
    hom = np.column_stack([np.asarray(vertices, dtype=float), np.ones((len(vertices),), dtype=float)])
    return (hom @ matrix.T)[:, :3]


def load_step_brep_wire_geometry(step_path: Path, curve_samples: int = 96, surface_mesh_size: float = 0.008) -> Dict[str, np.ndarray]:
    """Load true STEP B-rep display geometry.

    This follows omnimech_tools/render_cad_wireframe.py: exact B-rep curves are
    sampled as display edges, while a fine surface mesh is generated only for
    colored fills and hidden-line classification. Triangle mesh edges are never
    used as wireframe lines.
    """
    import gmsh  # type: ignore

    initialized = False
    try:
        gmsh.initialize()
        initialized = True
        gmsh.option.setNumber("General.Terminal", 0)
        gmsh.open(str(step_path))

        def is_smooth_seam(curve_tag: int, start: float, stop: float) -> bool:
            try:
                adjacent_surfaces, _ = gmsh.model.getAdjacencies(1, curve_tag)
                if len(adjacent_surfaces) != 2:
                    return False
                for parameter in np.linspace(start, stop, 3):
                    point = np.asarray(gmsh.model.getValue(1, curve_tag, [float(parameter)]), dtype=float)
                    normals = []
                    for surface_tag in adjacent_surfaces:
                        uv = gmsh.model.getParametrization(2, int(surface_tag), point.tolist())
                        normal = np.asarray(gmsh.model.getNormal(int(surface_tag), uv), dtype=float)
                        norm = float(np.linalg.norm(normal))
                        if norm <= 1e-12:
                            return False
                        normals.append(normal / norm)
                    if abs(float(np.dot(normals[0], normals[1]))) < 0.999:
                        return False
                return True
            except Exception:
                return False

        wire_vertices_blocks: List[np.ndarray] = []
        wire_edges_blocks: List[np.ndarray] = []
        vertex_offset = 0
        for _, tag in gmsh.model.getEntities(dim=1):
            lower, upper = gmsh.model.getParametrizationBounds(1, tag)
            start = float(np.asarray(lower).flat[0])
            stop = float(np.asarray(upper).flat[0])
            if is_smooth_seam(tag, start, stop):
                continue
            curve_type = gmsh.model.getType(1, tag).lower()
            count = max(12, curve_samples // 4) if curve_type == "line" else curve_samples
            parameters = np.linspace(start, stop, count)
            points = np.asarray(gmsh.model.getValue(1, tag, parameters.tolist()), dtype=float).reshape((-1, 3))
            if len(points) < 2 or not np.all(np.isfinite(points)):
                continue
            edges = np.column_stack([
                np.arange(vertex_offset, vertex_offset + len(points) - 1),
                np.arange(vertex_offset + 1, vertex_offset + len(points)),
            ])
            wire_vertices_blocks.append(points)
            wire_edges_blocks.append(edges)
            vertex_offset += len(points)

        if not wire_vertices_blocks:
            raise RuntimeError(f"no_brep_curves:{step_path}")

        wire_vertices = np.vstack(wire_vertices_blocks)
        wire_edges = np.vstack(wire_edges_blocks).astype(int)
        bounds = gmsh.model.getBoundingBox(-1, -1)
        diagonal = float(np.linalg.norm(np.asarray(bounds[3:6], dtype=float) - np.asarray(bounds[0:3], dtype=float)))
        diagonal = max(diagonal, 1e-6)
        gmsh.option.setNumber("Mesh.MeshSizeMax", diagonal * surface_mesh_size)
        gmsh.option.setNumber("Mesh.MeshSizeMin", diagonal * surface_mesh_size * 0.2)
        gmsh.option.setNumber("Mesh.MeshSizeFromCurvature", 32)
        gmsh.option.setNumber("Mesh.MeshSizeExtendFromBoundary", 1)
        gmsh.model.mesh.generate(2)
        node_tags, coordinates, _ = gmsh.model.mesh.getNodes()
        surface_vertices = np.asarray(coordinates, dtype=float).reshape((-1, 3))
        surface_offset = len(wire_vertices)
        tag_to_index = {int(tag): surface_offset + index for index, tag in enumerate(node_tags)}
        surface_faces: List[List[int]] = []
        for _, surface_tag in gmsh.model.getEntities(dim=2):
            element_types, _, element_nodes = gmsh.model.mesh.getElements(dim=2, tag=surface_tag)
            for element_type, flattened_nodes in zip(element_types, element_nodes):
                name, dimension, _, nodes_per_element, _, primary_nodes = gmsh.model.mesh.getElementProperties(element_type)
                if dimension != 2:
                    continue
                nodes = np.asarray(flattened_nodes, dtype=np.int64).reshape((-1, nodes_per_element))[:, :primary_nodes]
                if name.lower().startswith("triangle") and primary_nodes >= 3:
                    for row in nodes:
                        surface_faces.append([tag_to_index[int(tag)] for tag in row[:3]])
                elif name.lower().startswith("quadrilateral") and primary_nodes >= 4:
                    for row in nodes:
                        a, b, c, d = (tag_to_index[int(tag)] for tag in row[:4])
                        surface_faces.extend(([a, b, c], [a, c, d]))

        vertices = np.vstack([wire_vertices, surface_vertices]) if len(surface_vertices) else wire_vertices
        return {
            "vertices": vertices,
            "edges": wire_edges,
            "surface_faces": np.asarray(surface_faces, dtype=int),
        }
    finally:
        if initialized:
            gmsh.finalize()


def build_step_wire_scene_from_pose_spec(pose_path: Path, pose_root: Path, same_color: bool = False) -> Tuple[Optional[Dict[str, np.ndarray]], List[str], int]:
    try:
        spec = read_json(pose_path)
    except Exception as exc:
        return None, [f"step_pose_spec_read_failed:{exc!r}"], 0
    geoms = {str(g.get("part_id")): g for g in spec.get("part_geometries") or [] if isinstance(g, dict)}
    cache: Dict[str, Dict[str, np.ndarray]] = {}
    vertices_blocks: List[np.ndarray] = []
    edges_blocks: List[np.ndarray] = []
    surface_faces_blocks: List[np.ndarray] = []
    surface_component_ids: List[np.ndarray] = []
    errors: List[str] = []
    vertex_offset = 0
    component_count = 0
    for idx, comp in enumerate(spec.get("components") or []):
        if not isinstance(comp, dict) or not is_component_visible(comp):
            continue
        cid = str(comp.get("component_id") or comp.get("id") or f"c{idx + 1:05d}")
        geom = geoms.get(str(comp.get("part_id"))) or {}
        if str(geom.get("step_status") or "").lower() not in {"", "ok"}:
            errors.append(f"step_status_not_ok:{cid}:{geom.get('step_status')}")
            continue
        step_path = _step_geometry_path(geom.get("step_file") or geom.get("step_relative_path") or geom.get("step_path"), pose_root)
        if step_path is None:
            errors.append(f"missing_step_file:{cid}")
            continue
        try:
            key = str(step_path.resolve()).lower()
            base = cache.get(key)
            if base is None:
                base = load_step_brep_wire_geometry(step_path)
                cache[key] = base
            matrix = _matrix4x4_from_component(comp)
            V = _apply_matrix4x4(base["vertices"], matrix)
            E = np.asarray(base["edges"], dtype=int) + vertex_offset
            SF = np.asarray(base["surface_faces"], dtype=int)
            if SF.size:
                SF = SF + vertex_offset
                surface_faces_blocks.append(SF)
                surface_component_ids.append(np.full((len(SF),), component_count, dtype=int))
            vertices_blocks.append(V)
            edges_blocks.append(E)
            vertex_offset += len(V)
            component_count += 1
        except Exception as exc:
            errors.append(f"step_wire_geometry_failed:{cid}:{exc!r}")
    if component_count == 0 or not vertices_blocks or not edges_blocks:
        return None, errors or ["no_step_components"], component_count
    scene = {
        "vertices": np.vstack(vertices_blocks),
        "edges": np.vstack(edges_blocks).astype(int),
        "surface_faces": np.vstack(surface_faces_blocks).astype(int) if surface_faces_blocks else np.zeros((0, 3), dtype=int),
        "surface_component_ids": np.concatenate(surface_component_ids).astype(int) if surface_component_ids else np.zeros((0,), dtype=int),
    }
    return scene, errors, component_count


def render_step_wire_scene_png(scene: Dict[str, np.ndarray], out: Path, view: str, same_color: bool = False, width: int = 1280, height: int = 960) -> None:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib.collections import LineCollection
    import cv2  # type: ignore

    vertices = np.asarray(scene["vertices"], dtype=float)
    edges = np.asarray(scene["edges"], dtype=int)
    faces_value = scene.get("surface_faces")
    component_ids_value = scene.get("surface_component_ids")
    faces = np.asarray(faces_value if faces_value is not None else np.zeros((0, 3), dtype=int), dtype=int)
    surface_component_ids = np.asarray(component_ids_value if component_ids_value is not None else np.zeros((0,), dtype=int), dtype=int)
    if vertices.size == 0 or edges.size == 0:
        raise RuntimeError("empty_step_wire_scene")

    forward, right, up = _camera_frame_for_view(view)
    center = (vertices.min(axis=0) + vertices.max(axis=0)) * 0.5
    centered = vertices - center
    half_width = max(float(np.max(np.abs(centered @ right))), 1e-6)
    half_height = max(float(np.max(np.abs(centered @ up))), 1e-6)
    margin = 0.05
    scale = min(width * (0.5 - margin) / half_width, height * (0.5 - margin) / half_height)
    projected = np.column_stack([
        width * 0.5 + (centered @ right) * scale,
        height * 0.5 - (centered @ up) * scale,
    ])
    diag = max(float(np.linalg.norm(vertices.max(axis=0) - vertices.min(axis=0))), 1.0)
    cam_pos = center - forward * diag * 3.0
    depth = (vertices - cam_pos) @ forward

    dpi = 100
    fig = plt.figure(figsize=(width / dpi, height / dpi), dpi=dpi)
    ax = fig.add_axes([0, 0, 1, 1])
    ax.set_facecolor("white")
    surface_depth = None
    if len(faces) and len(surface_component_ids):
        face_depth = depth[faces].mean(axis=1)
        face_order = np.argsort(face_depth)[::-1]
        face_colors = np.zeros((len(faces), 3), dtype=np.uint8)
        for i in range(len(faces)):
            color = VIEW_SURFACE_SAME_COLOR if same_color else view_color_for_index(int(surface_component_ids[i]), same_color=False)
            face_colors[i] = np.asarray(_hex_to_rgb(color), dtype=float) * 255.0
        # restrained CAD-style illumination, matching omnimech experimental_lighting without heavy shadows
        face_vertices = vertices[faces]
        normals = np.cross(face_vertices[:, 1] - face_vertices[:, 0], face_vertices[:, 2] - face_vertices[:, 0])
        normal_lengths = np.linalg.norm(normals, axis=1)
        valid = normal_lengths > 1e-12
        normals[valid] /= normal_lengths[valid, None]
        light_direction = (-forward - 0.35 * right + 0.55 * up)
        light_direction /= max(float(np.linalg.norm(light_direction)), 1e-12)
        diffuse = np.abs(normals @ light_direction)
        illumination = 0.72 + 0.28 * diffuse
        face_colors = np.asarray(np.clip(face_colors.astype(float) * illumination[:, None], 0, 255), dtype=np.uint8)

        surface_rgb = np.full((height, width, 3), 255, dtype=np.uint8)
        surface_depth = np.full((height, width), np.inf, dtype=np.float32)
        for face_index in face_order:
            polygon = np.rint(projected[faces[face_index]]).astype(np.int32)
            color = tuple(int(v) for v in face_colors[face_index])
            cv2.fillConvexPoly(surface_rgb, polygon, color, lineType=cv2.LINE_8)
            cv2.fillConvexPoly(surface_depth, polygon, float(face_depth[face_index]), lineType=cv2.LINE_8)
        ax.imshow(surface_rgb, origin="upper", extent=(0, width, height, 0))

    source_segments = projected[edges]
    source_depths = depth[edges]
    subdivisions = 8
    starts = np.arange(subdivisions, dtype=float) / subdivisions
    stops = np.arange(1, subdivisions + 1, dtype=float) / subdivisions
    segment_starts = source_segments[:, None, 0, :] * (1.0 - starts[None, :, None]) + source_segments[:, None, 1, :] * starts[None, :, None]
    segment_stops = source_segments[:, None, 0, :] * (1.0 - stops[None, :, None]) + source_segments[:, None, 1, :] * stops[None, :, None]
    segments = np.stack((segment_starts, segment_stops), axis=2).reshape((-1, 2, 2))
    depth_starts = source_depths[:, None, 0] * (1.0 - starts[None, :]) + source_depths[:, None, 1] * starts[None, :]
    depth_stops = source_depths[:, None, 0] * (1.0 - stops[None, :]) + source_depths[:, None, 1] * stops[None, :]
    segment_depths = np.stack((depth_starts, depth_stops), axis=2).reshape((-1, 2))
    front_edges = np.ones(len(segments), dtype=bool)
    if surface_depth is not None:
        sample_t = np.asarray((0.25, 0.5, 0.75))
        sample_points = segments[:, None, 0, :] * (1.0 - sample_t[None, :, None]) + segments[:, None, 1, :] * sample_t[None, :, None]
        sample_depth = segment_depths[:, None, 0] * (1.0 - sample_t[None, :]) + segment_depths[:, None, 1] * sample_t[None, :]
        pixel_x = np.clip(np.rint(sample_points[:, :, 0]).astype(int), 0, width - 1)
        pixel_y = np.clip(np.rint(sample_points[:, :, 1]).astype(int), 0, height - 1)
        front_depth = surface_depth[pixel_y, pixel_x]
        depth_tolerance = max(float(np.ptp(depth)) * 0.015, 1e-9)
        front_samples = np.isinf(front_depth) | (sample_depth <= front_depth + depth_tolerance)
        front_edges = np.count_nonzero(front_samples, axis=1) >= 2

    visibility = front_edges.reshape((-1, subdivisions))
    candidates = [np.zeros(subdivisions, dtype=bool), np.ones(subdivisions, dtype=bool)]
    for split in range(1, subdivisions):
        candidates.append(np.asarray([False] * split + [True] * (subdivisions - split)))
        candidates.append(np.asarray([True] * split + [False] * (subdivisions - split)))
    for index, states in enumerate(visibility):
        visibility[index] = min(candidates, key=lambda candidate: np.count_nonzero(candidate != states))

    front_lines: List[np.ndarray] = []
    front_depths: List[float] = []
    for index, states in enumerate(visibility):
        points = np.vstack((segment_starts[index, 0], segment_stops[index]))
        depths = np.concatenate(([depth_starts[index, 0]], depth_stops[index]))
        run_start = None
        for segment_index, state in enumerate(states):
            if bool(state) and run_start is None:
                run_start = segment_index
            at_end = segment_index == subdivisions - 1
            if run_start is not None and ((not bool(state)) or at_end):
                run_stop = segment_index if bool(state) else segment_index - 1
                front_lines.append(points[run_start:run_stop + 2])
                front_depths.append(float(depths[run_start:run_stop + 2].mean()))
                run_start = None
    if front_lines:
        order = np.argsort(np.asarray(front_depths))[::-1]
        ax.add_collection(LineCollection([front_lines[i] for i in order], colors=VIEW_EDGE_COLOR, linewidths=0.45, alpha=0.86, antialiaseds=True))
    ax.set_xlim(0, width)
    ax.set_ylim(height, 0)
    ax.set_aspect("equal")
    ax.axis("off")
    out.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(out, dpi=dpi, facecolor="white", edgecolor="none")
    plt.close(fig)


def render_step_reference_views(src_sample: Path, out_sample: Path) -> Tuple[bool, Dict[str, Any]]:
    errors: List[str] = []
    for pose_path, pose_root in pose_spec_candidates(src_sample):
        try:
            color_scene, color_errors, color_count = build_step_wire_scene_from_pose_spec(pose_path, pose_root, same_color=False)
            same_scene, same_errors, same_count = build_step_wire_scene_from_pose_spec(pose_path, pose_root, same_color=True)
            errors.extend(color_errors + same_errors)
            if color_scene is None or same_scene is None:
                continue
            render_backends: Dict[str, str] = {}
            rendered_color: List[str] = []
            rendered_same: List[str] = []
            for view in VIEW_NAMES:
                target = out_sample / "reference_views" / "color_by_component" / f"assembly_{view}.png"
                render_step_wire_scene_png(color_scene, target, view, same_color=False)
                render_backends[f"color_by_component/assembly_{view}.png"] = "step_brep_wireframe"
                rendered_color.append(view)
            for view in VIEW_NAMES:
                target = out_sample / "reference_views" / "same_color" / f"assembly_{view}.png"
                render_step_wire_scene_png(same_scene, target, view, same_color=True)
                render_backends[f"same_color/assembly_{view}.png"] = "step_brep_wireframe"
                rendered_same.append(view)
            return True, {
                "internal_pose_spec_used": safe_rel(pose_path, src_sample),
                "reference_view_geometry": "component_step_brep",
                "color_component_count": color_count,
                "same_component_count": same_count,
                "rendered_color_by_component_views": rendered_color,
                "rendered_same_color_views": rendered_same,
                "render_backends": render_backends,
                "render_backend_summary": {"step_brep_wireframe": len(render_backends)},
                "errors": errors,
            }
        except Exception as exc:
            errors.append(f"step_reference_render_failed:{safe_rel(pose_path, src_sample)}:{exc!r}")
    return False, {"reference_view_geometry": "component_step_brep", "errors": errors or ["missing_step_pose_spec"]}


def render_reference_views(src_sample: Path, out_sample: Path, gt: Dict[str, Any], library: List[Dict[str, str]], component_obj_frame: str, component_to_library: Optional[Dict[str, str]] = None) -> Dict[str, Any]:
    step_ok, step_report = render_step_reference_views(src_sample, out_sample)
    if step_ok:
        return {
            "requested_component_obj_frame": component_obj_frame,
            "selected_component_obj_frame": "step_brep",
            **step_report,
        }

    frame = choose_component_obj_frame(out_sample, gt, library, component_obj_frame)
    color_meshes: List[Dict[str, Any]] = []
    same_meshes: List[Dict[str, Any]] = []
    color_errors: List[str] = []
    same_errors: List[str] = []
    pose_source = None
    for pose_path, pose_root in pose_spec_candidates(src_sample):
        color_meshes, color_errors = build_meshes_from_pose_spec(pose_path, pose_root, same_color=False)
        same_meshes, same_errors = build_meshes_from_pose_spec(pose_path, pose_root, same_color=True)
        if color_meshes and same_meshes:
            pose_source = safe_rel(pose_path, src_sample)
            break
    if not color_meshes:
        color_meshes, color_errors = build_meshes_for_frame(out_sample, gt, library, frame, same_color=False, component_to_library=component_to_library)
    if not same_meshes:
        same_meshes, same_errors = build_meshes_for_frame(out_sample, gt, library, frame, same_color=True, component_to_library=component_to_library)
    rendered_color: List[str] = []
    rendered_same_fallback: List[str] = []
    render_backends: Dict[str, str] = {}
    if color_meshes:
        for view in VIEW_NAMES:
            target = out_sample / "reference_views" / "color_by_component" / f"assembly_{view}.png"
            backend = render_png_best(color_meshes, target, view, show_edges=True)
            render_backends[f"color_by_component/assembly_{view}.png"] = backend
            if backend.startswith("failed:"):
                color_errors.append(f"render_color_view_failed:{view}:{backend}")
            rendered_color.append(view)
    if same_meshes:
        for view in VIEW_NAMES:
            target = out_sample / "reference_views" / "same_color" / f"assembly_{view}.png"
            backend = render_png_best(same_meshes, target, view, show_edges=True)
            render_backends[f"same_color/assembly_{view}.png"] = backend
            if backend.startswith("failed:"):
                same_errors.append(f"render_same_view_failed:{view}:{backend}")
            rendered_same_fallback.append(view)
    return {
        "requested_component_obj_frame": component_obj_frame,
        "selected_component_obj_frame": frame,
        "internal_pose_spec_used": pose_source,
        "color_component_count": len(color_meshes),
        "same_component_count": len(same_meshes),
        "rendered_color_by_component_views": rendered_color,
        "rendered_same_color_views": rendered_same_fallback,
        "render_backends": render_backends,
        "render_backend_summary": {k: list(render_backends.values()).count(k) for k in sorted(set(render_backends.values()))},
        "reference_view_geometry": "component_mesh_obj",
        "step_reference_errors": step_report.get("errors", []),
        "errors": color_errors + same_errors,
    }


def edge_source_target(edge: Dict[str, Any]) -> Tuple[Optional[str], Optional[str]]:
    a = edge.get("source_component") or edge.get("source_component_id") or edge.get("component_a") or edge.get("source")
    b = edge.get("target_component") or edge.get("target_component_id") or edge.get("component_b") or edge.get("target")
    comps = edge.get("components")
    if (not a or not b) and isinstance(comps, list) and len(comps) >= 2:
        a, b = comps[0], comps[1]
    return (str(a) if a else None, str(b) if b else None)


def build_component_level_mate_graph(gt: Dict[str, Any], library: List[Dict[str, str]], assembly_id: str, component_to_library: Dict[str, str]) -> Dict[str, Any]:
    graph_library = [{"library_id": item["library_id"], "obj_file": item.get("obj_file") or f"{item['library_id']}.mesh.obj"} for item in library]
    valid_ids = set(component_to_library.keys())
    nodes = []
    for n in gt.get("nodes") or []:
        cid = str(n.get("component_id") or n.get("id") or "")
        if not cid or cid not in valid_ids:
            continue
        node = {"component_id": cid}
        lib_id = component_to_library.get(cid)
        if lib_id:
            node["library_id"] = lib_id
        nodes.append(node)
    edges: List[Dict[str, str]] = []
    for e in gt.get("edges") or []:
        a, b = edge_source_target(e)
        if not a or not b or a not in valid_ids or b not in valid_ids:
            continue
        edges.append({"source_component": a, "target_component": b, "mate_type": str(e.get("mate_type") or "UnknownMate")})
    return {"assembly_id": assembly_id, "library": graph_library, "nodes": nodes, "edges": edges}


def normalize_sample(src_sample: Path, out_sample: Path, component_obj_frame: str = "auto", overwrite: bool = True, keep_solidworks_original: bool = False) -> Dict[str, Any]:
    gt = load_exported_gt(src_sample)
    if not (gt.get("nodes") or gt.get("node_parts")):
        raise RuntimeError(f"Stage1 sample has no component nodes or missing assembly_graph_gt.json: {src_sample}")
    assembly_id = str(gt.get("assembly_id") or src_sample.name)
    raw_component_count = len(gt.get("nodes") or [])
    gt, kept_component_ids = filter_gt_to_visible_components(gt)
    skipped_invisible_component_count = raw_component_count - len(gt.get("nodes") or [])
    if out_sample.exists() and overwrite:
        for name in ["component_library", "reference_views", "reference_obj", "graph", "gt", "obj", "_debug", "component_meshes"]:
            p = out_sample / name
            if p.exists():
                shutil.rmtree(p)
        for name in ["assembly_pose_spec.json", "assembly.mesh.obj", "assembly.step", "assembly_graph_gt.json", "mate_graph.json", "prepare_report.json", "dataset_prepare_report.json", "_prepare_record.json"]:
            p = out_sample / name
            if p.exists():
                p.unlink()
    out_sample.mkdir(parents=True, exist_ok=True)

    manifest = _manifest_items(src_sample)
    library: List[Dict[str, str]] = []
    missing_assets: List[str] = []
    local_mesh_sources: Dict[str, str] = {}
    component_to_library: Dict[str, str] = {}
    mesh_hash_to_library: Dict[str, str] = {}
    tmp_dir = out_sample / "_component_dedupe_tmp"
    if tmp_dir.exists():
        shutil.rmtree(tmp_dir)
    tmp_dir.mkdir(parents=True, exist_ok=True)
    next_lib_index = 1
    for node in gt.get("nodes") or []:
        cid = str(node.get("component_id") or node.get("id") or "")
        if not cid:
            continue
        mesh_src = find_component_mesh_obj(src_sample, node, manifest)
        if mesh_src:
            tmp_mesh = tmp_dir / f"{cid}.mesh.obj"
            ok, local_source = write_local_component_obj(src_sample, node, mesh_src, tmp_mesh)
            if ok:
                identity_key = component_identity_key(node, mesh_src, manifest)
                if identity_key:
                    mesh_key = identity_key
                else:
                    try:
                        mesh_key = file_sha1(tmp_mesh)
                    except Exception:
                        mesh_key = f"{cid}:{tmp_mesh.stat().st_size if tmp_mesh.exists() else 0}"
                lib_id = mesh_hash_to_library.get(mesh_key)
                if not lib_id:
                    lib_id = library_id_for_index(next_lib_index)
                    next_lib_index += 1
                    mesh_hash_to_library[mesh_key] = lib_id
                    mesh_dst = out_sample / "component_library" / f"{lib_id}.mesh.obj"
                    if mesh_dst.exists() and overwrite:
                        mesh_dst.unlink()
                    mesh_dst.parent.mkdir(parents=True, exist_ok=True)
                    shutil.move(str(tmp_mesh), str(mesh_dst))
                    library.append({"library_id": lib_id, "obj_file": safe_rel(mesh_dst, out_sample)})
                    local_mesh_sources[lib_id] = local_source
                component_to_library[cid] = lib_id
            else:
                missing_assets.append(f"{cid}:{local_source}")
        else:
            missing_assets.append(cid)
    if tmp_dir.exists():
        shutil.rmtree(tmp_dir)

    component_gt = build_component_gt(gt, component_to_library)
    write_json(out_sample / "assembly_graph_gt.json", component_gt)
    mate_graph = build_component_level_mate_graph(gt, library, assembly_id, component_to_library)
    write_json(out_sample / "mate_graph.json", mate_graph)
    copied_reference_obj = copy_reference_mesh_obj(src_sample, out_sample, overwrite=overwrite)
    copied_reference_step = copy_reference_step(src_sample, out_sample, overwrite=overwrite)
    copied_original_assembly_views = copy_original_assembly_views(src_sample, out_sample, overwrite=overwrite) if keep_solidworks_original else {}
    render_report = render_reference_views(src_sample, out_sample, gt, library, component_obj_frame=component_obj_frame, component_to_library=component_to_library)

    report = {
        "source_sample": str(src_sample),
        "out_sample": str(out_sample),
        "assembly_id": assembly_id,
        "library_count": len(library),
        "component_instance_count": len(component_to_library),
        "mate_edge_count": len(mate_graph["edges"]),
        "gt_node_count": len(component_gt.get("nodes", [])),
        "skipped_invisible_component_count": skipped_invisible_component_count,
        "kept_visible_component_count": len(kept_component_ids),
        "missing_component_assets": missing_assets,
        "local_component_mesh_sources": local_mesh_sources,
        "component_to_library": component_to_library,
        "copied_reference_obj": copied_reference_obj,
        "copied_reference_step": copied_reference_step,
        "copied_original_assembly_views": copied_original_assembly_views,
        **render_report,
    }
    return report


def main() -> None:
    parser = argparse.ArgumentParser(description="Prepare a flat mesh-only component-level sample from Stage 1 SW export.")
    parser.add_argument("source_sample", type=Path)
    parser.add_argument("out_sample", nargs="?", type=Path)
    parser.add_argument("--component-obj-frame", choices=["auto", "local", "assembly"], default="auto")
    parser.add_argument("--keep-solidworks-original", action="store_true")
    parser.add_argument("--no-overwrite", action="store_true")
    args = parser.parse_args()
    out_sample = args.out_sample or (Path("cad_assembly_prepared") / args.source_sample.name)
    report = normalize_sample(args.source_sample, out_sample, component_obj_frame=args.component_obj_frame, overwrite=not args.no_overwrite, keep_solidworks_original=args.keep_solidworks_original)
    print(json.dumps({"out_sample": str(out_sample), "summary": report}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
