#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Live terminal monitor for one-shot CAD assembly experiment runs.

This script is intentionally read-only: it never changes experiment outputs.
It polls RawApiRun/Output logs and prints a compact dashboard so long batch
runs can be watched from a terminal.
"""

from __future__ import annotations

import argparse
import json
import os
import re
import time
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple


EXP_ORDER = ["Exp1", "Exp2", "Exp3", "Exp4", "Exp5"]


def load_json(path: Path) -> Optional[Dict[str, Any]]:
    try:
        with path.open("r", encoding="utf-8") as f:
            obj = json.load(f)
        return obj if isinstance(obj, dict) else None
    except Exception:
        return None


def as_list(value: Any) -> List[Any]:
    return value if isinstance(value, list) else []


def seconds_to_text(sec: float) -> str:
    sec = max(0, int(round(sec)))
    if sec < 60:
        return f"{sec}s"
    minutes, seconds = divmod(sec, 60)
    if minutes < 60:
        return f"{minutes}m{seconds:02d}s"
    hours, minutes = divmod(minutes, 60)
    return f"{hours}h{minutes:02d}m"


def first_present(obj: Dict[str, Any], keys: Iterable[str]) -> Any:
    for key in keys:
        if key in obj and obj[key] is not None:
            return obj[key]
    return None


def sample_status(sample: Dict[str, Any]) -> str:
    return str(first_present(sample, ["status", "result_status", "state"]) or "").lower()


def is_ok(sample: Dict[str, Any]) -> bool:
    status = sample_status(sample)
    if status in {"ok", "success", "succeeded", "done"}:
        return True
    if sample.get("ok") is True or sample.get("success") is True:
        return True
    return False


def is_err(sample: Dict[str, Any]) -> bool:
    status = sample_status(sample)
    if status in {"ok", "success", "succeeded", "done", "skipped", "resume_skipped"}:
        return False
    if sample.get("ok") is False or sample.get("success") is False:
        return True
    if sample.get("error") or sample.get("error_type") or sample.get("fail_reason"):
        return True
    return bool(status)


def numeric(value: Any) -> float:
    try:
        return float(value)
    except Exception:
        return 0.0


def collect_usage_from_obj(obj: Dict[str, Any]) -> Tuple[int, int, int]:
    usage = obj.get("usage") if isinstance(obj.get("usage"), dict) else obj
    prompt = int(numeric(first_present(usage, ["prompt_tokens", "input_tokens"])))
    completion = int(numeric(first_present(usage, ["completion_tokens", "output_tokens"])))
    total = int(numeric(first_present(usage, ["total_tokens"])))
    if not total:
        total = prompt + completion
    return prompt, completion, total


def collect_usage(samples: List[Any]) -> Tuple[int, int, int]:
    prompt = completion = total = 0
    for item in samples:
        if not isinstance(item, dict):
            continue
        for candidate in (item, item.get("response") if isinstance(item.get("response"), dict) else None):
            if not isinstance(candidate, dict):
                continue
            p, c, t = collect_usage_from_obj(candidate)
            prompt += p
            completion += c
            total += t
            if p or c or t:
                break
    return prompt, completion, total


def infer_model(data: Dict[str, Any], samples: List[Any], fallback: str) -> str:
    model = first_present(data, ["model", "model_name", "api_model"])
    provider = first_present(data, ["provider", "api_provider"])
    if not model:
        for item in samples:
            if isinstance(item, dict):
                model = first_present(item, ["model", "model_name", "api_model"])
                provider = provider or first_present(item, ["provider", "api_provider"])
                if model:
                    break
    if model and provider:
        return f"{provider}/{model}" if not str(model).startswith(str(provider)) else str(model)
    return str(model or fallback)


def summarize_log(log_path: Path, fallback_exp: str, fallback_model: str, target: int) -> Dict[str, Any]:
    data = load_json(log_path) or {}
    samples = as_list(first_present(data, ["samples", "records", "items", "results"]))
    done = int(numeric(first_present(data, ["total_run", "total_done", "done", "processed"])))
    if not done:
        done = len(samples)
    ok = int(numeric(first_present(data, ["total_success", "success", "ok", "total_ok"])))
    err = int(numeric(first_present(data, ["total_fail", "fail", "failed", "error", "total_error"])))
    if samples and (not ok and not err):
        ok = sum(1 for s in samples if isinstance(s, dict) and is_ok(s))
        err = sum(1 for s in samples if isinstance(s, dict) and is_err(s))
    if done and not err:
        err = max(0, done - ok)
    runtime = numeric(first_present(data, ["total_runtime_sec", "runtime_sec", "elapsed_sec"]))
    if not runtime and samples:
        runtime = sum(numeric(s.get("runtime_sec")) for s in samples if isinstance(s, dict))
    prompt_tokens, completion_tokens, total_tokens = collect_usage(samples)
    exp = str(first_present(data, ["experiment", "exp", "experiment_name"]) or fallback_exp)
    return {
        "experiment": exp,
        "model": infer_model(data, samples, fallback_model),
        "done": done,
        "target": target or int(numeric(first_present(data, ["target", "total_planned", "total_samples"]))),
        "ok": ok,
        "err": err,
        "avg_sec": runtime / done if done else 0.0,
        "runtime_sec": runtime,
        "prompt_tokens": prompt_tokens,
        "completion_tokens": completion_tokens,
        "total_tokens": total_tokens,
        "path": str(log_path),
    }


def discover_exp_logs(run_root: Path, target: int) -> List[Dict[str, Any]]:
    rows_by_exp: Dict[str, Dict[str, Any]] = {}
    output_dir = run_root / "Output"
    raw_dir = run_root / "RawApiRun"

    for final_log in sorted(output_dir.glob("Exp*_log.json")):
        match = re.match(r"(Exp\d+)_log\.json$", final_log.name, re.IGNORECASE)
        exp = match.group(1) if match else final_log.stem
        rows_by_exp[exp] = summarize_log(final_log, exp, run_root.name, target)
        rows_by_exp[exp]["phase"] = "final"

    if raw_dir.exists():
        for exp_dir in sorted(p for p in raw_dir.glob("Exp*") if p.is_dir()):
            exp = exp_dir.name
            if exp in rows_by_exp:
                continue
            candidates = [exp_dir / "log.json", exp_dir / "run_log.json"]
            candidates += sorted(exp_dir.glob("*log*.json"))
            for raw_log in candidates:
                if raw_log.exists():
                    rows_by_exp[exp] = summarize_log(raw_log, exp, run_root.name, target)
                    rows_by_exp[exp]["phase"] = "running"
                    break

    def sort_key(item: Tuple[str, Dict[str, Any]]) -> Tuple[int, str]:
        exp = item[0]
        try:
            return (EXP_ORDER.index(exp), exp)
        except ValueError:
            return (99, exp)

    return [row for _, row in sorted(rows_by_exp.items(), key=sort_key)]


def discover_runs(root: Path) -> List[Path]:
    if (root / "Output").exists() or (root / "RawApiRun").exists():
        return [root]
    runs: List[Path] = []
    for child in sorted(p for p in root.iterdir() if p.is_dir()):
        if (child / "Output").exists() or (child / "RawApiRun").exists():
            runs.append(child)
    return runs or [root]


def print_dashboard(run_root: Path, rows: List[Dict[str, Any]]) -> None:
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    width = 112
    print("=" * width)
    print(f"CAD Assembly run monitor | {now}")
    print(f"run_root: {run_root}")
    print("=" * width)
    print(f"{'experiment':<12} {'model':<34} {'done/target':>12} {'ok/err':>12} {'avg/call':>10} {'tokens(total)':>14} {'phase':>9}")
    print("-" * width)
    total_done = total_target = total_ok = total_err = total_tokens = 0
    weighted_runtime = 0.0
    for row in rows:
        done = int(row["done"])
        target = int(row["target"] or done)
        ok = int(row["ok"])
        err = int(row["err"])
        total_done += done
        total_target += target
        total_ok += ok
        total_err += err
        total_tokens += int(row["total_tokens"])
        weighted_runtime += float(row["avg_sec"]) * done
        token_text = f"{int(row['total_tokens']):,}" if row["total_tokens"] else "N/A"
        print(
            f"{row['experiment']:<12} {row['model'][:34]:<34} "
            f"{done:>5}/{target:<6} {ok:>5}/{err:<6} "
            f"{seconds_to_text(row['avg_sec']):>10} {token_text:>14} {row.get('phase', ''):>9}"
        )
    print("-" * width)
    pct = (100.0 * total_done / total_target) if total_target else 0.0
    avg = (weighted_runtime / total_done) if total_done else 0.0
    print(
        f"PROGRESS  {total_done}/{total_target} tasks ({pct:.1f}%) | "
        f"success={total_ok} error={total_err} | avg/call={seconds_to_text(avg)}"
    )
    print(f"TOKENS    total={total_tokens:,}" if total_tokens else "TOKENS    N/A (current runner logs do not expose usage for these calls)")
    print("=" * width)


def main() -> int:
    parser = argparse.ArgumentParser(description="Live monitor for one-shot CAD assembly API runs.")
    parser.add_argument("run_root", type=Path, help="Run folder containing Output/ and optionally RawApiRun/.")
    parser.add_argument("--target", type=int, default=0, help="Expected samples per experiment, used when logs do not include target.")
    parser.add_argument("--watch", action="store_true", help="Refresh the terminal until interrupted.")
    parser.add_argument("--refresh-sec", type=float, default=10.0, help="Refresh interval for --watch.")
    args = parser.parse_args()

    run_root = args.run_root.expanduser().resolve()
    if not run_root.exists():
        raise SystemExit(f"run_root does not exist: {run_root}")

    while True:
        if args.watch:
            os.system("cls" if os.name == "nt" else "clear")
        rows: List[Dict[str, Any]] = []
        for one_run in discover_runs(run_root):
            for row in discover_exp_logs(one_run, args.target):
                if one_run != run_root:
                    row["model"] = one_run.name
                rows.append(row)
        if rows:
            print_dashboard(run_root, rows)
        else:
            print(f"No experiment logs found under: {run_root}")
            print("Expected Output/Exp*_log.json or RawApiRun/Exp*/log.json")
        if not args.watch:
            return 0
        time.sleep(max(1.0, args.refresh_sec))


if __name__ == "__main__":
    raise SystemExit(main())
