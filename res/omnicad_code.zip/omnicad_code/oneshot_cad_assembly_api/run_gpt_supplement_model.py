#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Run previously sampled GPT supplement datasets by model and experiment."""
from __future__ import annotations

import argparse
import subprocess
import sys
import time
from pathlib import Path


ROOT = Path(__file__).resolve().parent
EXPERIMENTS = [
    "exp_zs_img",
    "exp_zs_ref_obj",
    "exp_zs_ref_img_color",
    "exp_zs_mate_graph_img",
    "exp_zs_mate_graph_ref_obj_img",
]
MODEL_CONFIGS = {
    "gpt-5.5": {
        "model": "openai/gpt-5.5",
        "max_full_prompt_chars": 3000000,
    },
    "gpt-5.4-mini": {
        "model": "openai/gpt-5.4-mini",
        "max_full_prompt_chars": 1200000,
    },
}


def run_one(args: argparse.Namespace, exp: str, cfg: dict[str, object], log) -> int:
    input_root = args.supplement_root / args.model_tag / exp / "hardlinked_samples"
    if not input_root.exists():
        log.write(f"\n[SKIP_MISSING_INPUT] {input_root}\n")
        log.flush()
        return 0
    out_root = args.output_root / args.model_tag / exp
    cmd = [
        sys.executable,
        str(ROOT / "cad_assembly_run_prepared_dataset.py"),
        str(input_root),
        "--run-root",
        str(out_root),
        "--experiments",
        exp,
        "--provider",
        "openrouter",
        "--model",
        str(cfg["model"]),
        "--api-key-env",
        args.api_key_env,
        "--response-mode",
        "json_schema",
        "--num-workers",
        str(args.num_workers),
        "--api-timeout-sec",
        str(args.api_timeout_sec),
        "--max-retries",
        str(args.max_retries),
        "--retry-sleep-sec",
        str(args.retry_sleep_sec),
        "--openrouter-response-healing",
        "--resume",
    ]
    limit = int(cfg.get("max_full_prompt_chars") or 0)
    if limit > 0:
        cmd += ["--max-full-prompt-chars", str(limit)]
    if args.max_samples > 0:
        cmd += ["--max-samples", str(args.max_samples)]
    log.write(f"\n===== {time.strftime('%Y-%m-%d %H:%M:%S')} {args.model_tag} {exp} =====\n")
    log.write(" ".join(f'"{x}"' if " " in x else x for x in cmd) + "\n")
    log.flush()
    proc = subprocess.run(cmd, cwd=str(ROOT), text=True, stdout=log, stderr=log)
    log.write(f"\n[RETURN_CODE] {proc.returncode}\n")
    log.flush()
    return int(proc.returncode)


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--model-tag", choices=sorted(MODEL_CONFIGS), required=True)
    p.add_argument("--supplement-root", type=Path, default=Path("<SUPPLEMENT_DATASET_ROOT>"))
    p.add_argument("--output-root", type=Path, default=Path("<OUTPUT_ROOT>"))
    p.add_argument("--api-key-env", default="OPENROUTER_API_KEY")
    p.add_argument("--api-timeout-sec", type=float, default=600.0)
    p.add_argument("--max-retries", type=int, default=2)
    p.add_argument("--retry-sleep-sec", type=float, default=20.0)
    p.add_argument("--num-workers", type=int, default=1)
    p.add_argument("--max-samples", type=int, default=0)
    args = p.parse_args()

    cfg = MODEL_CONFIGS[args.model_tag]
    log_dir = args.output_root / "_process_logs"
    log_dir.mkdir(parents=True, exist_ok=True)
    with (log_dir / f"{args.model_tag}.log").open("a", encoding="utf-8") as log:
        log.write(f"\n### START {time.strftime('%Y-%m-%d %H:%M:%S')} {args.model_tag} ###\n")
        log.flush()
        rc = 0
        for exp in EXPERIMENTS:
            rc = max(rc, run_one(args, exp, cfg, log))
        log.write(f"\n### END {time.strftime('%Y-%m-%d %H:%M:%S')} {args.model_tag} rc={rc} ###\n")
        log.flush()
    raise SystemExit(rc)


if __name__ == "__main__":
    main()
