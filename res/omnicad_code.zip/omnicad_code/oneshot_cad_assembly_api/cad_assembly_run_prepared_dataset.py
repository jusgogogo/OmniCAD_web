﻿#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Stage-B CLI: run API experiments on an already prepared dataset.

This script starts from Stage-A flat prepared samples only. It never opens
SolidWorks, never runs Stage1 export, and never regenerates reference views.

Expected Stage-A sample layout:
  sample/
    component_library/*.obj
    reference_views/same_color/assembly_v01.png ... assembly_v08.png
    reference_views/color_by_component/assembly_v01.png ... assembly_v08.png
    assembly.mesh.obj
    assembly_graph_gt.json
    mate_graph.json
"""
from __future__ import annotations

import argparse
import json
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

ROOT = Path(__file__).resolve().parent

DEFAULT_EXPERIMENTS = [
    "exp_zs_img",
    "exp_zs_ref_obj",
    "exp_zs_ref_img_color",
    "exp_zs_mate_graph_img",
    "exp_zs_mate_graph_ref_obj_img",
]

EXPERIMENT_SCRIPT_MAP = {
    "exp_zs_img": "exp_zs_img.py",
    "exp_zs_ref_obj": "exp_zs_ref_obj.py",
    "exp_zs_ref_img_color": "exp_zs_ref_img_color.py",
    "exp_zs_mate_graph_img": "exp_zs_mate_graph_img.py",
    "exp_zs_mate_graph_ref_obj_img": "exp_zs_mate_graph_ref_obj_img.py",
}

EXPERIMENT_FOLDER_ALIASES = {
    "exp_zs_img": "exp_baseline",
    "exp_zs_ref_obj": "exp_ref_obj",
    "exp_zs_ref_img_color": "exp_ref_img_color",
    "exp_zs_mate_graph": "exp_mate_graph",
    "exp_zs_mate_graph_img": "exp_mate_graph_img",
    "exp_zs_mate_graph_ref_obj_img": "exp_mate_graph_ref_obj_img",
}

EXPERIMENT_LABELS = {
    "exp_zs_img": "Exp1",
    "exp_zs_ref_obj": "Exp2",
    "exp_zs_ref_img_color": "Exp3",
    "exp_zs_mate_graph_img": "Exp4",
    "exp_zs_mate_graph_ref_obj_img": "Exp5",
}

MATE_GRAPH_INPUT_EXPERIMENTS = {
    "exp_zs_mate_graph_img",
    "exp_zs_mate_graph_ref_obj_img",
}

MATE_GRAPH_HTML_OUTPUTS = {"mate_graph.html", "mate_graph_error.txt"}

INPUT_NAMES = {
    "component_library",
    "reference_views",
    "assembly.mesh.obj",
    "mate_graph.json",
    "reference_views.json",
}

OUTPUT_NAMES = {
    "assembly_prediction.json",
    "assembly_prediction_best_effort.json",
    "log.json",
}


def write_json(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def run_cmd(cmd: List[str], cwd: Optional[Path] = None) -> Dict[str, Any]:
    start = time.time()
    proc = subprocess.run(cmd, cwd=str(cwd) if cwd else None, text=True, capture_output=True)
    return {
        "cmd": cmd,
        "cwd": str(cwd) if cwd else None,
        "returncode": proc.returncode,
        "stdout": proc.stdout,
        "stderr": proc.stderr,
        "elapsed_sec": round(time.time() - start, 3),
    }


def copytree_clean(src: Path, dst: Path) -> bool:
    if dst.exists():
        shutil.rmtree(dst)
    if src.exists():
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copytree(src, dst)
        return True
    return False


def copy_file_if_exists(src: Path, dst: Path) -> bool:
    if not src.exists():
        return False
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)
    return True


def copy_path(src: Path, dst: Path) -> bool:
    if not src.exists():
        return False
    if src.is_dir():
        return copytree_clean(src, dst)
    return copy_file_if_exists(src, dst)


def snapshot_code(code_dir: Path) -> None:
    code_dir.mkdir(parents=True, exist_ok=True)
    for pat in ["*.py", "*.md", "*.txt"]:
        for src in ROOT.glob(pat):
            shutil.copy2(src, code_dir / src.name)


def run_experiment(args: argparse.Namespace, exp: str, run_root: Path) -> Dict[str, Any]:
    label = EXPERIMENT_LABELS.get(exp, exp)
    use_persistent_raw = args.keep_raw_api_run or args.resume
    if use_persistent_raw:
        raw_root = run_root / "RawApiRun" / label
        if raw_root.exists() and not args.resume:
            shutil.rmtree(raw_root)
    else:
        raw_root = Path(tempfile.mkdtemp(prefix=f"cad_stage2_{label}_"))
    script_name = EXPERIMENT_SCRIPT_MAP.get(exp)
    if not script_name:
        raise ValueError(f"Unsupported experiment for dedicated-script runner: {exp}")
    cmd = [
        sys.executable,
        str(ROOT / script_name),
        str(args.prepared_root),
        "--out", str(raw_root),
        "--provider", args.provider,
        "--model", args.model,
        "--api-key-env", args.api_key_env,
        "--max-retries", str(args.max_retries),
        "--retry-sleep-sec", str(args.retry_sleep_sec),
        "--response-mode", args.response_mode,
        "--raw-obj-mode", args.raw_obj_mode,
        "--max-raw-obj-chars", str(args.max_raw_obj_chars),
        "--reference-obj-raw-mode", args.reference_obj_raw_mode,
        "--max-reference-obj-chars", str(args.max_reference_obj_chars),
        "--max-output-tokens", str(args.max_output_tokens),
        "--api-timeout-sec", str(args.api_timeout_sec),
        "--max-full-prompt-chars", str(args.max_full_prompt_chars),
        "--node-policy", args.node_policy,
        "--num-workers", str(args.num_workers),
    ]
    if args.recursive:
        cmd.append("--recursive")
    if args.sample_list:
        cmd += ["--sample-list", str(args.sample_list)]
    if args.resume:
        cmd.append("--resume")
    if args.max_samples > 0:
        cmd += ["--max-samples", str(args.max_samples)]
    if args.openrouter_response_healing:
        cmd.append("--openrouter-response-healing")
    if args.allow_missing_views:
        cmd.append("--allow-missing-views")
    if args.ignore_preflight:
        cmd.append("--ignore-preflight")
    if args.save_debug:
        cmd.append("--save-debug")
    if args.no_auto_visualize:
        cmd.append("--no-auto-visualize")
    result = run_cmd(cmd, cwd=ROOT)
    return {"experiment": exp, **result, "raw_root": str(raw_root)}


def sample_key_from_experiment_dir(exp_dir: Path) -> str:
    # dedicated exp_*.py scripts create folders like sample_name__exp_alias.
    if "__" in exp_dir.name:
        return exp_dir.name.rsplit("__", 1)[0]
    return exp_dir.name


def collect_one_experiment_dir(run_root: Path, exp: str, exp_dir: Path) -> Dict[str, Any]:
    sample_key = sample_key_from_experiment_dir(exp_dir)
    output_dir = run_root / exp / sample_key
    if output_dir.exists():
        shutil.rmtree(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    copied_files: List[str] = []
    for src in sorted(exp_dir.iterdir()):
        if src.name in INPUT_NAMES or src.name in OUTPUT_NAMES:
            if exp in MATE_GRAPH_INPUT_EXPERIMENTS and src.name in MATE_GRAPH_HTML_OUTPUTS:
                continue
            copy_path(src, output_dir / src.name)
            copied_files.append(src.name)
    return {
        "experiment": exp,
        "sample": sample_key,
        "raw_experiment_dir": str(exp_dir),
        "output_dir": str(output_dir),
        "files": sorted(copied_files),
    }


def collect_experiment(run_root: Path, exp: str, raw_root: Path) -> Dict[str, Any]:
    exp_dirs = sorted([p for p in raw_root.iterdir() if p.is_dir()]) if raw_root.exists() else []
    sample_records = [collect_one_experiment_dir(run_root, exp, p) for p in exp_dirs]
    return {
        "experiment": exp,
        "raw_root": str(raw_root),
        "sample_count": len(sample_records),
        "samples": sample_records,
    }


def cleanup_path(path: Path) -> None:
    if path.exists():
        shutil.rmtree(path)


def main() -> None:
    ap = argparse.ArgumentParser(description="Run API experiments from an already prepared CAD assembly dataset.")
    ap.add_argument("prepared_root", type=Path, help="Stage-A flat prepared sample folder or prepared dataset root. No SolidWorks export is run here.")
    ap.add_argument("--run-root", "--output-folder", dest="run_root", type=Path, default=Path("cad_assembly_api_runs"), help="Output folder for the organized Stage-B run.")
    ap.add_argument("--experiments", nargs="*", default=DEFAULT_EXPERIMENTS)
    ap.add_argument("--provider", choices=["openai", "openrouter", "azure", "gemini", "dry-run"], default="openrouter")
    ap.add_argument("--model", default="openai/gpt-4.1")
    ap.add_argument("--api-key-env", default="OPENROUTER_API_KEY")
    ap.add_argument("--max-retries", type=int, default=3)
    ap.add_argument("--retry-sleep-sec", type=float, default=2.0)
    ap.add_argument("--response-mode", choices=["auto", "json_schema", "json_object", "none"], default="json_schema")
    ap.add_argument("--raw-obj-mode", choices=["none", "truncated", "full"], default="full")
    ap.add_argument("--max-raw-obj-chars", type=int, default=20000)
    ap.add_argument("--reference-obj-raw-mode", choices=["none", "truncated", "full"], default="full")
    ap.add_argument("--max-reference-obj-chars", type=int, default=40000)
    ap.add_argument("--max-output-tokens", type=int, default=4096, help="Maximum completion tokens passed to each experiment script. Use 0 to omit.")
    ap.add_argument("--api-timeout-sec", type=float, default=600.0, help="Per API request timeout in seconds passed to each experiment script. Use 0 to disable.")
    ap.add_argument("--max-full-prompt-chars", type=int, default=0, help="Skip full-OBJ samples before API call when system+user prompt exceeds this character count. 0 disables.")
    ap.add_argument("--node-policy", choices=["predict_subset", "all_library"], default="predict_subset")
    ap.add_argument("--recursive", action="store_true", help="Recursively discover prepared samples under prepared_root. One-level dataset roots do not need this flag.")
    ap.add_argument("--sample-list", type=Path, default=None, help="Optional text file containing sample folder names or paths to run.")
    ap.add_argument("--resume", action="store_true", help="Pass --resume to the underlying API runner.")
    ap.add_argument("--max-samples", type=int, default=0)
    ap.add_argument("--openrouter-response-healing", action="store_true")
    ap.add_argument("--allow-missing-views", action="store_true")
    ap.add_argument("--ignore-preflight", action="store_true")
    ap.add_argument("--save-debug", action="store_true")
    viz_group = ap.add_mutually_exclusive_group()
    viz_group.add_argument("--auto-visualize", dest="no_auto_visualize", action="store_false", help="Generate HTML visualizations for debugging.")
    viz_group.add_argument("--no-auto-visualize", dest="no_auto_visualize", action="store_true", help="Do not generate HTML visualizations. This is the default for batch runs.")
    ap.set_defaults(no_auto_visualize=True)
    ap.add_argument("--keep-raw-api-run", action="store_true", help="Keep raw per-experiment API outputs under RawApiRun/. Resume also keeps RawApiRun so interrupted runs can continue.")
    ap.add_argument("--num-workers", "--workers", dest="num_workers", type=int, default=1, help="Number of sample-level worker threads passed to each experiment. Default: 1.")
    args = ap.parse_args()

    if args.provider == "openrouter" and args.api_key_env == "OPENAI_API_KEY":
        args.api_key_env = "OPENROUTER_API_KEY"
    if args.provider == "azure" and args.api_key_env == "OPENAI_API_KEY":
        args.api_key_env = "AZURE_OPENAI_API_KEY"

    run_root = args.run_root
    if not (args.keep_raw_api_run or args.resume):
        stale_raw = run_root / "RawApiRun"
        if stale_raw.exists():
            shutil.rmtree(stale_raw)
    run_root.mkdir(parents=True, exist_ok=True)
    print(f"[OUTPUT_FOLDER] {run_root}")
    print("[OUTPUT_LAYOUT] exp_zs_xxx/sample_name/files")
    print(f"[WORKERS] {max(1, int(args.num_workers or 1))}")

    start_ts = time.time()
    start_time = time.strftime("%Y-%m-%d %H:%M:%S")
    results: List[Dict[str, Any]] = []
    collections: List[Dict[str, Any]] = []
    for exp in args.experiments:
        result = run_experiment(args, exp, run_root)
        results.append(result)
        collections.append(collect_experiment(run_root, exp, Path(result["raw_root"])))
        if not (args.keep_raw_api_run or args.resume):
            cleanup_path(Path(result["raw_root"]))

    status = "ok" if all(r.get("returncode") == 0 for r in results) else "completed_with_errors"
    summary = {
        "run_root": str(run_root),
        "status": status,
        "experiments": args.experiments,
        "total_runtime_sec": round(time.time() - start_ts, 3),
    }
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    if status != "ok":
        raise SystemExit(1)


if __name__ == "__main__":
    main()




