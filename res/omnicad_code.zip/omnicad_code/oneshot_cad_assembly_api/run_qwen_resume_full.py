#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Resume Qwen one-shot runs on the 500-sample selection with full OBJ prompts."""
from __future__ import annotations

import argparse
import subprocess
import sys
import time
from pathlib import Path


ROOT = Path(__file__).resolve().parent
SELECTION_ROOT = Path("<SELECTION_ROOT>")
OUTPUT_ROOT = Path("<OUTPUT_ROOT>")
EXPERIMENTS = [
    "exp_zs_img",
    "exp_zs_ref_obj",
    "exp_zs_ref_img_color",
    "exp_zs_mate_graph_img",
    "exp_zs_mate_graph_ref_obj_img",
]
MODEL_CONFIGS = {
    "qwen3_5_9b": {"model": "qwen/qwen3.5-9b", "workers": 4},
    "qwen3_7_plus": {"model": "qwen/qwen3.7-plus", "workers": 4},
}


def run_one(model_tag: str, exp: str, cfg: dict[str, object], args: argparse.Namespace, log) -> int:
    sample_list = SELECTION_ROOT / "missing_only_lists" / model_tag / f"{exp}_missing.txt"
    if not sample_list.exists():
        log.write(f"\n[SKIP_MISSING_LIST] {sample_list}\n")
        log.flush()
        return 0
    out_root = OUTPUT_ROOT / model_tag / exp
    cmd = [
        sys.executable,
        str(ROOT / "cad_assembly_run_prepared_dataset.py"),
        str(SELECTION_ROOT / "hardlinked_samples"),
        "--sample-list",
        str(sample_list),
        "--run-root",
        str(out_root),
        "--experiments",
        exp,
        "--provider",
        "openrouter",
        "--model",
        str(cfg["model"]),
        "--api-key-env",
        "OPENROUTER_API_KEY",
        "--response-mode",
        "json_schema",
        "--raw-obj-mode",
        "full",
        "--reference-obj-raw-mode",
        "full",
        "--max-full-prompt-chars",
        "0",
        "--num-workers",
        str(cfg["workers"]),
        "--api-timeout-sec",
        str(args.api_timeout_sec),
        "--max-retries",
        str(args.max_retries),
        "--retry-sleep-sec",
        str(args.retry_sleep_sec),
        "--openrouter-response-healing",
        "--resume",
    ]
    if args.max_samples > 0:
        cmd += ["--max-samples", str(args.max_samples)]
    log.write(f"\n===== {time.strftime('%Y-%m-%d %H:%M:%S')} {model_tag} {exp} =====\n")
    log.write(" ".join(f'"{x}"' if " " in x else x for x in cmd) + "\n")
    log.flush()
    proc = subprocess.run(cmd, cwd=str(ROOT), text=True, stdout=log, stderr=log)
    log.write(f"\n[RETURN_CODE] {proc.returncode}\n")
    log.flush()
    return int(proc.returncode)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--model-tag", choices=sorted(MODEL_CONFIGS), required=True)
    parser.add_argument("--api-timeout-sec", type=float, default=600.0)
    parser.add_argument("--max-retries", type=int, default=3)
    parser.add_argument("--retry-sleep-sec", type=float, default=20.0)
    parser.add_argument("--max-samples", type=int, default=0)
    args = parser.parse_args()

    cfg = MODEL_CONFIGS[args.model_tag]
    log_dir = OUTPUT_ROOT / "_process_logs"
    log_dir.mkdir(parents=True, exist_ok=True)
    rc = 0
    with (log_dir / f"{args.model_tag}_resume_full.log").open("a", encoding="utf-8") as log:
        log.write(f"\n### START {time.strftime('%Y-%m-%d %H:%M:%S')} {args.model_tag} full OBJ resume ###\n")
        log.flush()
        for exp in EXPERIMENTS:
            rc = max(rc, run_one(args.model_tag, exp, cfg, args, log))
        log.write(f"\n### END {time.strftime('%Y-%m-%d %H:%M:%S')} {args.model_tag} rc={rc} ###\n")
        log.flush()
    raise SystemExit(rc)


if __name__ == "__main__":
    main()
