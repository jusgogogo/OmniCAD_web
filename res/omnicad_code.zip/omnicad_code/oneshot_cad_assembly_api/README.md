# CAD Assembly Baseline API — Stage B Independent Experiment Runner

This repository is the **second-stage API experiment runner** for CAD assembly reconstruction. It starts from the flat prepared dataset produced by Stage A. It does **not** open SolidWorks, does **not** export CAD files, and does **not** regenerate reference views.

The latest structure is:

```text
Prepared Dataset
      ↓
Five independent experiment scripts
      ↓
OpenRouter / OpenAI / Azure API call
      ↓
Normalize prediction JSON
      ↓
Save prediction, visualization, and logs
```

`cad_assembly_schema.py`, `cad_assembly_cli.py`, `cad_assembly_experiment_cli.py`, and the old shared `cad_assembly_baseline_api.py` are no longer part of the active execution path.

---

## 1. Stage A / Stage B handoff layout

Each Stage-A prepared sample must use the flat layout below:

```text
sample_000001/
  component_library/
    lib00001.mesh.obj
    lib00002.mesh.obj
    ...

  reference_views/
    same_color/
      assembly_v01.png
      ...
      assembly_v08.png
    color_by_component/
      assembly_v01.png
      ...
      assembly_v08.png

  assembly.mesh.obj
  assembly_graph_gt.json
  mate_graph.json
```

Do not use old nested folders for Stage-B handoff:

```text
reference_obj/
gt/
graph/
obj/
reference_views/components/
```

The prepared sample should already exclude invisible, hidden, and suppressed components. `component_library`, `assembly_graph_gt.json`, `mate_graph.json`, and `reference_views` should describe the same visible assembly subset.

---

## 2. Active code structure

### 2.1 Five independent experiment files

These are the active single-experiment entry files:

```text
exp_zs_img.py
exp_zs_ref_obj.py
exp_zs_ref_img_color.py
exp_zs_mate_graph_img.py
exp_zs_mate_graph_ref_obj_img.py
```

Each experiment file is self-contained for experiment-specific logic. It directly contains:

```text
EXPERIMENT_MODE
PROMPT_SPEC
MATE_TYPE_DEFINITIONS
ASSEMBLY_PREDICTION_SCHEMA
response_format
build_system_prompt()
build_prompt()
init_conversation()
call_openrouter()
call_openai()
call_azure_openai()
call_provider()
main()
```

The API call is now inside each `exp_*.py` file. For OpenRouter, the call is explicitly written in the same style as the reference OpenRouter script:

```python
response = client.chat.completions.create(
    model=model,
    messages=messages,
    temperature=temperature,
    response_format={
        "type": "json_schema",
        "json_schema": {
            "name": f"{EXPERIMENT_MODE}_assembly_prediction_schema",
            "strict": True,
            "schema": ASSEMBLY_PREDICTION_SCHEMA,
        }
    },
)
```

### 2.2 Shared runtime utilities

```text
cad_assembly_stage2_common.py
```

This file contains only shared non-API runtime utilities:

```text
sample discovery
input loading
input copying
JSON extraction
prediction normalization
prediction validation
logging
visualization dispatch
common CLI parser
sample-level multithreaded execution
```

It does **not** contain OpenRouter/OpenAI API calls. API calls are owned by the five `exp_*.py` files.

### 2.3 Batch runner

```text
cad_assembly_run_prepared_dataset.py
```

This file is only a batch scheduler. It loops over the selected experiments and launches the corresponding `exp_*.py` scripts. It does not build prompts and does not call the API directly.

When `--resume` is enabled, the batch runner uses a stable raw run folder for each experiment:

```text
RawApiRun/
  Exp1/
  Exp2/
  Exp3/
  Exp4/
  Exp5/
```

This makes unattended restart possible. If a run is interrupted, run the same command again with the same `--run-root` and `--resume`; each independent experiment CLI skips samples that already have `assembly_prediction.json`.

---

## 3. Five experiment definitions

### 3.1 `exp_zs_img.py`

```text
Input:
  component_library
  reference_views/same_color

Model output:
  nodes
  edges
```

This is the same-color image experiment. The model must infer component instances, poses, and mate edges from the candidate component library and same-color assembly views.

### 3.2 `exp_zs_ref_obj.py`

```text
Input:
  component_library
  assembly.mesh.obj

Model output:
  nodes
  edges
```

This is the reference assembly OBJ experiment. The model uses `assembly.mesh.obj` as the target assembled geometry condition.

### 3.3 `exp_zs_ref_img_color.py`

```text
Input:
  component_library
  reference_views/color_by_component

Model output:
  nodes
  edges
```

This experiment uses color-by-component views. The model can use color separation to infer component instances, poses, and mate edges.

### 3.4 `exp_zs_mate_graph_img.py`

```text
Input:
  component_library
  mate_graph.json
  reference_views/color_by_component

Model output:
  nodes
```

Because `mate_graph.json` is already provided, the model does **not** output `edges`. It only predicts pose for each predefined `component_id` in `mate_graph.nodes`.

### 3.5 `exp_zs_mate_graph_ref_obj_img.py`

```text
Input:
  component_library
  mate_graph.json
  assembly.mesh.obj
  reference_views/color_by_component

Model output:
  nodes
```

Because `mate_graph.json` is already provided, the model does **not** output `edges`. It only predicts pose for each predefined `component_id` in `mate_graph.nodes`.

---

## 4. Prediction JSON formats

### 4.1 Experiments without input mate graph

For `exp_zs_img`, `exp_zs_ref_obj`, and `exp_zs_ref_img_color`, the model returns only predicted nodes and edges. `assembly_id` is attached by the runtime after the model response:

```json
{
  "nodes": [
    {
      "component_id": "c00001",
      "library_id": "lib00001",
      "pose": {
        "position": {"x": 0.0, "y": 0.0, "z": 0.0},
        "orientation": {"rx": 0.0, "ry": 0.0, "rz": 0.0}
      }
    }
  ],
  "edges": [
    {
      "source_component": "c00001",
      "target_component": "c00002",
      "mate_type": "MateCoincident"
    }
  ]
}
```

### 4.2 Experiments with input mate graph

For `exp_zs_mate_graph_img` and `exp_zs_mate_graph_ref_obj_img`, the model returns only `component_id` and `pose`. `assembly_id` and `library_id` are attached by the runtime after the model response:

```json
{
  "nodes": [
    {
      "component_id": "c00001",
      "pose": {
        "position": {"x": 0.0, "y": 0.0, "z": 0.0},
        "orientation": {"rx": 0.0, "ry": 0.0, "rz": 0.0}
      }
    }
  ]
}
```

The final saved `assembly_prediction.json` still contains `assembly_id`; for mate-graph experiments it also restores `library_id` from `mate_graph.nodes` by `component_id`.

### 4.3 Prompt design in the experiment files

The prompts follow the same structure as the pin-agent prompt: short role statement, separated task sections, strict field definitions, and only experiment-relevant instructions.

Common prompt content:

```text
- Return JSON only.
- Pose is an absolute component pose in the prepared assembly coordinate frame.
- position uses x, y, z in millimeters.
- orientation uses rx, ry, rz in degrees.
- Components should form a physically plausible assembly and avoid large unintended interpenetration.
```

Open-set experiments:

```text
- Predict component instance nodes, absolute poses, and component-level mate edges.
- component_library is a reusable geometry-template library, not the final instance list.
- library_id identifies a reusable template; component_id identifies one output instance.
- Repeated uses of one library_id are separate nodes.
- component-level means whole component instances, not B-Rep faces, mesh triangles, mesh vertices, or OBJ indices.
- mate_type is selected from local MATE_TYPE_DEFINITIONS.
```

Mate-graph experiments:

```text
- For each component_id in mate_graph.nodes, predict its absolute pose.
- mate_graph.json is a component-level assembly graph.
- mate_graph.nodes defines the fixed component instance list.
- mate_graph.edges defines known component-level mate constraints used for pose estimation.
- The model output does not include assembly_id, library_id, or edges.
```

OBJ and view notes are included only when the corresponding experiment uses them. For example, experiments without `assembly.mesh.obj` do not describe `assembly.mesh.obj` in the system prompt.

Input-specific notes:

```text
same_color reference views:
  The view set is rendered from 8 camera directions at the cube corners. Components share one render color; color cannot identify component instances.

color_by_component reference views:
  The view set is rendered from 8 camera directions at the cube corners. Colors are synthetic component-segmentation aids only.

component_library/*.mesh.obj:
  These files describe reusable component-template mesh geometry in the component local frame. They support shape matching between library_id values and the target assembly.

assembly.mesh.obj:
  This appears only in reference-OBJ experiments. It describes the target assembled mesh geometry in the prepared assembly coordinate frame. It is a target shape condition, not a component instance list.

OBJ_CONTENT:
  `v x y z` lines define mesh vertices/points. `f ...` lines define polygon or triangle mesh faces. OBJ vertex and face indices are local mesh indices, not component_id, library_id, mate_id, or CAD B-Rep face IDs.
```

---

## 5. Installation

Install dependencies:

```bat
pip install -r requirements.txt
```

Required packages include:

```text
openai
numpy
matplotlib
pyvista
```

`pyvista` is only needed when enabling debug visualization with `--auto-visualize`. Batch runs do not generate HTML visualization by default.

---

## 6. API key setup

### 6.1 OpenRouter

Windows CMD:

```bat
set OPENROUTER_API_KEY=your_openrouter_key
```

PowerShell:

```powershell
$env:OPENROUTER_API_KEY="your_openrouter_key"
```

The code also accepts the reference-script style environment variable name:

```bat
set openrouter=your_openrouter_key
```

Run with:

```bat
--provider openrouter --model openai/gpt-4.1
```

### 6.2 Dry run

Dry-run tests file discovery, input copying, preflight checks, output folders, and logging without calling any API:

```bat
--provider dry-run
```

---

## 7. Run one experiment on one sample

Single-experiment scripts accept either `--out` or `--output-folder` for the raw experiment output folder.

### Experiment 1: same-color image condition

```bat
python exp_zs_img.py ^
  D:\cad_prepared_dataset\sample_000001 ^
  --out D:\cad_api_runs\raw ^
  --provider openrouter ^
  --model openai/gpt-4.1 ^
  --response-mode json_schema
```

### Experiment 2: reference assembly OBJ condition

```bat
python exp_zs_ref_obj.py ^
  D:\cad_prepared_dataset\sample_000001 ^
  --out D:\cad_api_runs\raw ^
  --provider openrouter ^
  --model openai/gpt-4.1 ^
  --raw-obj-mode full ^
  --reference-obj-raw-mode full ^
  --max-full-prompt-chars 900000 ^
  --response-mode json_schema
```

### Experiment 3: color-by-component image condition

```bat
python exp_zs_ref_img_color.py ^
  D:\cad_prepared_dataset\sample_000001 ^
  --out D:\cad_api_runs\raw ^
  --provider openrouter ^
  --model openai/gpt-4.1 ^
  --response-mode json_schema
```

### Experiment 4: mate graph + color images

```bat
python exp_zs_mate_graph_img.py ^
  D:\cad_prepared_dataset\sample_000001 ^
  --out D:\cad_api_runs\raw ^
  --provider openrouter ^
  --model openai/gpt-4.1 ^
  --response-mode json_schema
```

### Experiment 5: mate graph + reference OBJ + color images

```bat
python exp_zs_mate_graph_ref_obj_img.py ^
  D:\cad_prepared_dataset\sample_000001 ^
  --out D:\cad_api_runs\raw ^
  --provider openrouter ^
  --model openai/gpt-4.1 ^
  --response-mode json_schema
```

---

## 8. Run experiments on a prepared dataset

For a prepared dataset root:

```text
D:\cad_prepared_dataset\
  sample_000001\
  sample_000002\
  sample_000003\
```

Run all five experiments. `--run-root` and `--output-folder` are aliases for the organized Stage-B output folder:

```bat
python cad_assembly_run_prepared_dataset.py ^
  D:\cad_prepared_dataset ^
  --run-root D:\cad_api_runs ^
  --provider openrouter ^
  --model openai/gpt-4.1 ^
  --response-mode json_schema ^
  --num-workers 4 ^
  --resume
```

Run one selected experiment over the dataset:

```bat
python cad_assembly_run_prepared_dataset.py ^
  D:\cad_prepared_dataset ^
  --run-root D:\cad_api_runs ^
  --experiments exp_zs_ref_img_color ^
  --provider openrouter ^
  --model openai/gpt-4.1 ^
  --response-mode json_schema ^
  --num-workers 4 ^
  --resume
```

Run a dry-run check first:

```bat
python cad_assembly_run_prepared_dataset.py ^
  D:\cad_prepared_dataset ^
  --run-root D:\cad_api_runs_dryrun ^
  --experiments exp_zs_mate_graph_img ^
  --provider dry-run ^
  --max-samples 10 ^
  --resume
```

Use `--recursive` only when samples are nested deeper than one level.

---

## 8.1 CLI usage examples

Open PowerShell or Command Prompt in the code folder first:

```bat
cd /d <CODE_ROOT>\oneshot_cad_assembly_api
```

### Case A: dry-run one sample or dataset

Use this before calling the real API. It checks dataset discovery, input copying, preflight, output folders, and logs.

```bat
python cad_assembly_run_prepared_dataset.py ^
  D:\cad_prepared_dataset ^
  --run-root D:\cad_api_runs_dryrun ^
  --provider dry-run ^
  --max-samples 10 ^
  --num-workers 4 ^
  --resume
```

### Case B: run all five experiments

This is the normal unattended Stage-B command.

```bat
python cad_assembly_run_prepared_dataset.py ^
  D:\cad_prepared_dataset ^
  --run-root D:\cad_api_runs ^
  --provider openrouter ^
  --model openai/gpt-4.1 ^
  --response-mode json_schema ^
  --num-workers 4 ^
  --resume
```

### Case C: run only one experiment

For example, run only Exp5:

```bat
python cad_assembly_run_prepared_dataset.py ^
  D:\cad_prepared_dataset ^
  --run-root D:\cad_api_runs ^
  --experiments exp_zs_mate_graph_ref_obj_img ^
  --provider openrouter ^
  --model openai/gpt-4.1 ^
  --response-mode json_schema ^
  --num-workers 4 ^
  --resume
```

Available experiment names:

```text
exp_zs_img
exp_zs_ref_obj
exp_zs_ref_img_color
exp_zs_mate_graph_img
exp_zs_mate_graph_ref_obj_img
```

### Case D: restart after interruption

Use exactly the same command, same `--run-root`, and keep `--resume`.

```bat
python cad_assembly_run_prepared_dataset.py ^
  D:\cad_prepared_dataset ^
  --run-root D:\cad_api_runs ^
  --provider openrouter ^
  --model openai/gpt-4.1 ^
  --response-mode json_schema ^
  --num-workers 4 ^
  --resume
```

The batch runner keeps `RawApiRun/ExpX` when `--resume` is enabled. Each `exp_*.py` script skips a sample if that raw sample folder already has `assembly_prediction.json`.

### Case E: run Exp5 with full OBJ text

Full OBJ is the default input mode. The prompt includes complete component OBJ text and, for reference-OBJ experiments, complete `assembly.mesh.obj` text. This is the preferred setting for model comparison because oversized samples are skipped and recorded instead of silently falling back to truncated geometry.

Use `--max-full-prompt-chars` only when you want a local preflight skip before the API call. The default is `0`, which disables the local character cutoff and lets the provider return a context/token error if the request is too large.

```bat
python cad_assembly_run_prepared_dataset.py ^
  D:\cad_prepared_dataset ^
  --run-root D:\cad_api_runs_exp5_full_obj ^
  --experiments exp_zs_mate_graph_ref_obj_img ^
  --provider openrouter ^
  --model openai/gpt-4.1 ^
  --response-mode json_schema ^
  --max-full-prompt-chars 900000 ^
  --num-workers 4 ^
  --resume
```

When the local cutoff is exceeded, the sample is marked `skipped_context_limit` in `log.json` and is not sent to the API. When the local cutoff is disabled but the provider rejects the request for context/token length, the code also records `skipped_context_limit`.

### Case F: run a single experiment file directly

The independent experiment files can also be called directly. This is useful for debugging one sample or one dataset without the organizer.

```bat
python exp_zs_ref_img_color.py ^
  D:\cad_prepared_dataset\sample_000001 ^
  --out D:\cad_api_runs_raw\Exp3 ^
  --provider openrouter ^
  --model openai/gpt-4.1 ^
  --response-mode json_schema ^
  --num-workers 1 ^
  --resume
```

Direct `exp_*.py` output is raw experiment output. The batch runner `cad_assembly_run_prepared_dataset.py` collects results into the same simple flat experiment layout used for final delivery.

---

## 9. Output layout

The batch runner writes:

```text
D:\cad_api_runs\
  exp_zs_img\
    sample_000001\
      component_library\
      reference_views\
      reference_views.json
      assembly_prediction.json
      log.json

  exp_zs_ref_obj\
    sample_000001\
      component_library\
      assembly.mesh.obj
      assembly_prediction.json
      log.json

  exp_zs_mate_graph_img\
    sample_000001\
      component_library\
      reference_views\
      reference_views.json
      mate_graph.json
      assembly_prediction.json
      log.json

  RawApiRun\    kept only when --resume or --keep-raw-api-run is used
```

There is no extra `Code/`, `Dataset/`, `Output/`, `Log/`, `prompt.txt`, or debug folder in the collected final layout.

### 9.1 Logs

```text
exp_zs_xxx\
  sample_000001\
    log.json
```

Each sample keeps its own `log.json`. Oversized full-OBJ samples are recorded as `skipped_context_limit`.

### 9.2 Visualization

Batch runs do not generate HTML visualization by default. Use `--auto-visualize` only for debugging.

When `--resume` is used, `RawApiRun/ExpX` is retained so the raw per-sample folders can be reused by the next run. Without `--resume` and without `--keep-raw-api-run`, temporary raw API output is cleaned after it is collected into the flat experiment folders.

---

## 10. Important CLI options

```text
--resume
  Skip samples whose raw experiment folder already contains assembly_prediction.json.
  In the batch runner, this also keeps RawApiRun/ExpX stable across restarts.

--max-samples N
  Process only the first N samples.

--output-folder PATH
  Alias for --out in single-experiment scripts and --run-root in the batch runner.

--num-workers N / --workers N
  Run up to N samples concurrently inside each experiment. Default: 1.
  The batch runner runs selected experiments sequentially, and each experiment
  uses this sample-level worker count internally.

--recursive
  Recursively discover prepared samples under prepared_root.

--sample-list PATH
  Run only the samples listed in a UTF-8 text file.
  Each line can be a sample folder name or a full sample path.
  This is useful for missing-only补跑 after reusing previous results.

--raw-obj-mode none|truncated|full
  Controls whether component OBJ text is embedded in the prompt.
  Default: full.

--max-raw-obj-chars N
  Maximum number of OBJ characters per component OBJ prompt section.
  Used only when --raw-obj-mode truncated.

--reference-obj-raw-mode none|truncated|full
  Controls whether assembly.mesh.obj text is embedded in the prompt.
  Default: full.

--max-reference-obj-chars N
  Maximum number of characters for assembly.mesh.obj prompt text.
  Used only when --reference-obj-raw-mode truncated.

--max-full-prompt-chars N
  Local full-OBJ prompt size cutoff. Default: 0, disabled.
  If full OBJ is enabled and system+user prompt exceeds N characters,
  the sample is skipped before the API call and logged as skipped_context_limit.

--response-mode json_schema|json_object|none|auto
  For OpenRouter, use json_schema.

--allow-missing-views
  Do not fail preflight when some reference views are missing.

--ignore-preflight
  Run even when preflight reports missing inputs.

--save-debug
  Save raw responses and intermediate debug artifacts.

--no-auto-visualize
  Do not generate HTML visualizations. This is the default for batch runs.

--auto-visualize
  Generate HTML visualizations for debugging only.
```

---

## 11. Full OBJ and context limits

The default mode is:

```text
--raw-obj-mode full
--reference-obj-raw-mode full
--max-full-prompt-chars 0
```

This means the runner sends full OBJ text by default. If the selected model/provider cannot accept the request, the API context/token error is caught and the sample is logged as `skipped_context_limit`.

For large unattended batches, you can add a local cutoff to skip clearly oversized samples before spending API time:

```bat
python cad_assembly_run_prepared_dataset.py ^
  D:\cad_prepared_dataset ^
  --run-root D:\cad_api_runs_full_obj ^
  --provider openrouter ^
  --model openai/gpt-4.1 ^
  --response-mode json_schema ^
  --max-full-prompt-chars 900000 ^
  --resume
```

`--max-full-prompt-chars` is a character-count guard, not an official token limit. Different models tokenize OBJ text differently. If you do not know the model context window, keep it at `0` for maximum coverage, or set it per model after a small probe run.

---

## 12. Recommended workflow

1. Test the prepared dataset with dry-run:

```bat
python cad_assembly_run_prepared_dataset.py ^
  D:\cad_prepared_dataset ^
  --run-root D:\cad_api_runs_dryrun ^
  --provider dry-run ^
  --max-samples 20 ^
  --resume
```

2. Run a small real OpenRouter batch:

```bat
python cad_assembly_run_prepared_dataset.py ^
  D:\cad_prepared_dataset ^
  --run-root D:\cad_api_runs_test ^
  --provider openrouter ^
  --model openai/gpt-4.1 ^
  --response-mode json_schema ^
  --max-samples 10 ^
  --resume
```

3. Run the full dataset:

```bat
python cad_assembly_run_prepared_dataset.py ^
  D:\cad_prepared_dataset ^
  --run-root D:\cad_api_runs ^
  --provider openrouter ^
  --model openai/gpt-4.1 ^
  --response-mode json_schema ^
  --num-workers 4 ^
  --resume
```


---

## Prompt balance note

The prompt intentionally keeps only experiment-relevant information. `assembly_id` is never requested from the model. In mate-graph experiments, `library_id` is also not requested; it is restored from `mate_graph.nodes` after the model returns component poses. Open-set edge output keeps explicit `source_component` and `target_component` fields and is not described as undirected.
