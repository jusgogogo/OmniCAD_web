#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Run missing-only one-shot experiments for one model tag."""
from __future__ import annotations

import argparse
import csv
import subprocess
import sys
import time
from pathlib import Path


ROOT = Path(__file__).resolve().parent
EXPERIMENTS = [
    "exp_zs_img",
    "exp_zs_ref_obj",
    "exp_zs_ref_img_color",
    "exp_zs_mate_graph_img",
    "exp_zs_mate_graph_ref_obj_img",
]
MODEL_CONFIGS = {
    "gemini_3_1_pro_preview": {
        "model": "google/gemini-3.1-pro-preview",
        "workers": 2,
        "max_full_prompt_chars": 0,
    },
    "qwen3_5_9b": {
        "model": "qwen/qwen3.5-9b",
        "workers": 4,
        "max_full_prompt_chars": 0,
    },
    "qwen3_7_plus": {
        "model": "qwen/qwen3.7-plus",
        "workers": 4,
        "max_full_prompt_chars": 0,
    },
}


def read_missing_counts(selection_root: Path, model_tag: str) -> dict[str, int]:
    csv_path = selection_root / "reports" / "missing_only_summary_3models.csv"
    if not csv_path.exists():
        return {}
    counts: dict[str, int] = {}
    with csv_path.open("r", encoding="utf-8-sig", newline="") as f:
        for row in csv.DictReader(f):
            if row.get("model_tag") == model_tag:
                counts[row["experiment"]] = int(row.get("missing_to_run") or 0)
    return counts


def run_one(args: argparse.Namespace, exp: str, cfg: dict[str, object], log) -> int:
    sample_list = args.selection_root / "missing_only_lists" / args.model_tag / f"{exp}_missing.txt"
    out_root = args.output_root / args.model_tag / exp
    cmd = [
        sys.executable,
        str(ROOT / "cad_assembly_run_prepared_dataset.py"),
        str(args.selection_root / "hardlinked_samples"),
        "--sample-list",
        str(sample_list),
        "--run-root",
        str(out_root),
        "--experiments",
        exp,
        "--provider",
        "openrouter",
        "--model",
        str(cfg["model"]),
        "--api-key-env",
        args.api_key_env,
        "--response-mode",
        "json_schema",
        "--num-workers",
        str(cfg["workers"]),
        "--api-timeout-sec",
        str(args.api_timeout_sec),
        "--max-retries",
        str(args.max_retries),
        "--retry-sleep-sec",
        str(args.retry_sleep_sec),
        "--openrouter-response-healing",
        "--resume",
    ]
    max_full_prompt_chars = int(cfg.get("max_full_prompt_chars") or 0)
    if max_full_prompt_chars > 0:
        cmd += ["--max-full-prompt-chars", str(max_full_prompt_chars)]
    if args.max_samples > 0:
        cmd += ["--max-samples", str(args.max_samples)]

    log.write(f"\n===== {time.strftime('%Y-%m-%d %H:%M:%S')} {args.model_tag} {exp} =====\n")
    log.write(" ".join(f'"{x}"' if " " in x else x for x in cmd) + "\n")
    log.flush()
    proc = subprocess.run(cmd, cwd=str(ROOT), text=True, stdout=log, stderr=log)
    log.write(f"\n[RETURN_CODE] {proc.returncode}\n")
    log.flush()
    return int(proc.returncode)


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--model-tag", choices=sorted(MODEL_CONFIGS), required=True)
    p.add_argument("--selection-root", type=Path, default=Path("<SELECTION_ROOT>"))
    p.add_argument("--output-root", type=Path, default=Path("<OUTPUT_ROOT>"))
    p.add_argument("--api-key-env", default="OPENROUTER_API_KEY")
    p.add_argument("--api-timeout-sec", type=float, default=600.0)
    p.add_argument("--max-retries", type=int, default=3)
    p.add_argument("--retry-sleep-sec", type=float, default=20.0)
    p.add_argument("--max-samples", type=int, default=0)
    args = p.parse_args()

    cfg = MODEL_CONFIGS[args.model_tag]
    log_dir = args.output_root / "_process_logs"
    log_dir.mkdir(parents=True, exist_ok=True)
    counts = read_missing_counts(args.selection_root, args.model_tag)
    with (log_dir / f"{args.model_tag}.log").open("a", encoding="utf-8") as log:
        log.write(f"\n### START {time.strftime('%Y-%m-%d %H:%M:%S')} {args.model_tag} ###\n")
        log.write(f"missing_counts={counts}\n")
        log.flush()
        rc = 0
        for exp in EXPERIMENTS:
            if counts.get(exp, 1) <= 0:
                log.write(f"\n[SKIP_EMPTY] {exp}\n")
                continue
            rc = max(rc, run_one(args, exp, cfg, log))
        log.write(f"\n### END {time.strftime('%Y-%m-%d %H:%M:%S')} {args.model_tag} rc={rc} ###\n")
        log.flush()
    raise SystemExit(rc)


if __name__ == "__main__":
    main()
