#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Dataset discovery utilities for Stage-B CAD assembly API experiments.

This module is intentionally aligned with the Stage-A flat prepared-sample
contract. A prepared sample is expected to contain:

  component_library/*.obj
  reference_views/same_color/assembly_v01.png ... assembly_v08.png
  reference_views/color_by_component/assembly_v01.png ... assembly_v08.png
  assembly.mesh.obj
  assembly_graph_gt.json
  mate_graph.json

Legacy fallback paths are accepted for reading only, so old prepared samples can
still be inspected. New Stage-B outputs do not create graph/, gt/, reference_obj/,
or obj/ folders.
"""
from __future__ import annotations

import hashlib
import json
import math
import re
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

GOLDEN_RATIO = (1.0 + math.sqrt(5.0)) / 2.0
DODECAHEDRON_VIEW_NAMES = [f"v{i:02d}" for i in range(1, 21)]
CUBE_VERTEX_VIEW_NAMES = [f"v{i:02d}" for i in range(1, 9)]
VIEW_NAMES = CUBE_VERTEX_VIEW_NAMES
IMG_EXTS = [".png", ".jpg", ".jpeg", ".webp"]


def dodecahedron_vertex_positions() -> List[Tuple[float, float, float]]:
    """Return 20 regular-dodecahedron vertex directions in a fixed order.

    The reference-view pipeline uses these vertices as camera centers, matching
    the RotationNet case-(ii) setup conceptually: 20 views from the 20 vertices
    of a dodecahedron around the object.
    """
    phi = GOLDEN_RATIO
    inv = 1.0 / phi
    return [
        (0.0,  inv,  phi),
        (1.0,  1.0,  1.0),
        (phi,  0.0,  inv),
        (1.0, -1.0,  1.0),
        (0.0, -inv,  phi),
        (-1.0, -1.0,  1.0),
        (-phi,  0.0,  inv),
        (-1.0,  1.0,  1.0),
        (inv,  phi,  0.0),
        (inv, -phi,  0.0),
        (-inv, -phi,  0.0),
        (-inv,  phi,  0.0),
        (0.0,  inv, -phi),
        (1.0,  1.0, -1.0),
        (phi,  0.0, -inv),
        (1.0, -1.0, -1.0),
        (0.0, -inv, -phi),
        (-1.0, -1.0, -1.0),
        (-phi,  0.0, -inv),
        (-1.0,  1.0, -1.0),
    ]


def cube_vertex_positions() -> List[Tuple[float, float, float]]:
    """Return 8 cube-vertex camera directions in the omnimech static-view order."""
    return [
        (-1.0, -1.0, -1.0),
        (-1.0, -1.0,  1.0),
        (-1.0,  1.0, -1.0),
        (-1.0,  1.0,  1.0),
        ( 1.0, -1.0, -1.0),
        ( 1.0, -1.0,  1.0),
        ( 1.0,  1.0, -1.0),
        ( 1.0,  1.0,  1.0),
    ]


def view_direction(view: str) -> Tuple[float, float, float]:
    legacy = {
        "front": (0.0, -1.0, 0.0),
        "right": (1.0, 0.0, 0.0),
        "top": (0.0, 0.0, 1.0),
        "iso": (1.0, 1.0, 1.0),
    }
    if view in legacy:
        return legacy[view]
    m = re.fullmatch(r"v(\d{2})", str(view).lower())
    if not m:
        raise ValueError(f"Unsupported view name: {view}")
    idx = int(m.group(1)) - 1
    cube_verts = cube_vertex_positions()
    if 0 <= idx < len(cube_verts):
        return cube_verts[idx]
    verts = dodecahedron_vertex_positions()
    if idx < 0 or idx >= len(verts):
        raise ValueError(f"Unsupported dodecahedron view index: {view}")
    return verts[idx]


def read_json(path: Path) -> Any:
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def safe_rel(path: Path, root: Path) -> str:
    try:
        return path.resolve().relative_to(root.resolve()).as_posix()
    except Exception:
        return path.as_posix()


def library_id_from_text(text: str) -> Optional[str]:
    m = re.search(r"(lib\d{5})", str(text), flags=re.IGNORECASE)
    return m.group(1).lower() if m else None


def component_id_from_text(text: str) -> Optional[str]:
    m = re.search(r"(c\d{5})", str(text), flags=re.IGNORECASE)
    return m.group(1).lower() if m else None


def file_sha1(path: Path, chunk_size: int = 1024 * 1024) -> str:
    h = hashlib.sha1()
    with path.open("rb") as f:
        while True:
            chunk = f.read(chunk_size)
            if not chunk:
                break
            h.update(chunk)
    return h.hexdigest()


def parse_obj_basic(path: Path) -> Dict[str, Any]:
    verts: List[Tuple[float, float, float]] = []
    face_count = 0
    if not path.exists():
        return {"status": "missing", "vertex_count": 0, "face_count": 0, "bbox_size_mm": []}
    try:
        with path.open("r", encoding="utf-8", errors="ignore") as f:
            for line in f:
                if line.startswith("v "):
                    parts = line.split()
                    if len(parts) >= 4:
                        try:
                            verts.append((float(parts[1]), float(parts[2]), float(parts[3])))
                        except Exception:
                            pass
                elif line.startswith("f "):
                    face_count += 1
    except Exception as exc:
        return {"status": "read_error", "error": repr(exc), "vertex_count": 0, "face_count": 0, "bbox_size_mm": []}
    if verts:
        xs, ys, zs = zip(*verts)
        size = [round(max(xs) - min(xs), 6), round(max(ys) - min(ys), 6), round(max(zs) - min(zs), 6)]
    else:
        size = []
    return {"status": "ok", "vertex_count": len(verts), "face_count": face_count, "bbox_size_mm": size}


def read_obj_text(path: Path, mode: str = "none", max_chars: int = 60000) -> Optional[str]:
    if mode == "none" or not path.exists():
        return None
    text = path.read_text(encoding="utf-8", errors="ignore")
    if mode == "truncated" and len(text) > max_chars:
        return text[:max_chars] + "\n# [TRUNCATED]"
    return text


def _library_id_for_index(index: int) -> str:
    return f"lib{index:05d}"


def discover_component_library(sample_dir: Path, obj_kind: str = "auto", raw_obj_mode: str = "none", max_raw_obj_chars: int = 60000) -> Dict[str, Any]:
    """Read flat prepared component_library/*.obj as candidate library geometry.

    The library is not an instance list. In open-set experiments, the model must
    decide how many times each library_id is used. In mate-graph experiments,
    mate_graph.json defines the component instances.
    """
    sample_dir = sample_dir.resolve()
    lib_dir = sample_dir / "component_library"
    objs: List[Path] = []
    if lib_dir.exists():
        objs = sorted(p for p in lib_dir.glob("*.obj") if p.is_file())
    if obj_kind == "mesh":
        objs = [p for p in objs if ".brep.obj" not in p.name]
    elif obj_kind == "brep":
        objs = [p for p in objs if ".brep.obj" in p.name]

    library: List[Dict[str, Any]] = []
    seen: set[str] = set()
    next_idx = 1
    used_ids: set[str] = set()
    for p in objs:
        try:
            key = file_sha1(p)
        except Exception:
            key = p.resolve().as_posix()
        if key in seen:
            continue
        lib_id = library_id_from_text(p.name)
        if not lib_id:
            while _library_id_for_index(next_idx) in used_ids:
                next_idx += 1
            lib_id = _library_id_for_index(next_idx)
            next_idx += 1
        used_ids.add(lib_id)
        item: Dict[str, Any] = {
            "library_id": lib_id,
            "obj_file": safe_rel(p, sample_dir),
            "mesh_summary": parse_obj_basic(p),
        }
        raw = read_obj_text(p, raw_obj_mode, max_raw_obj_chars)
        if raw is not None:
            item["raw_obj_text"] = raw
        library.append(item)
        seen.add(key)
    return {"assembly_id": sample_dir.name, "library": library}


def find_reference_views(sample_dir: Path, style: str = "same_color") -> Dict[str, str]:
    sample_dir = sample_dir.resolve()
    roots = [sample_dir / "reference_views" / style]
    # Read-only legacy fallbacks.
    roots += [
        sample_dir / "reference_views" / ("color_by_component" if style == "color_by_component" else "same_color"),
        sample_dir / "views" / style,
        sample_dir / "views" / "assembly",
        sample_dir / "views",
    ]
    out: Dict[str, str] = {}
    for view in VIEW_NAMES:
        hits: List[Path] = []
        for root in roots:
            if not root.exists():
                continue
            for ext in IMG_EXTS:
                hits.extend(sorted(root.glob(f"assembly_{view}{ext}")))
                hits.extend(sorted(root.glob(f"*_{view}{ext}")))
                hits.extend(sorted(root.glob(f"*{view}*{ext}")))
        hit = next((p for p in hits if p.exists() and p.is_file()), None)
        if hit:
            out[view] = safe_rel(hit, sample_dir)
    return out


def find_reference_assembly_obj(sample_dir: Path, obj_kind: str = "mesh", raw_obj_mode: str = "none", max_raw_obj_chars: int = 120000) -> Optional[Dict[str, Any]]:
    sample_dir = sample_dir.resolve()
    candidates = [
        sample_dir / "assembly.mesh.obj",
        sample_dir / "assembly.obj",
        # Read-only legacy fallbacks.
        sample_dir / "reference_obj" / "assembly.mesh.obj",
        sample_dir / "obj" / "assembly.mesh.obj",
        sample_dir / "gt" / "assembly.mesh.obj",
        sample_dir / "reference_obj" / "assembly.obj",
        sample_dir / "obj" / "assembly.obj",
    ]
    if obj_kind == "brep":
        candidates = [sample_dir / "assembly.brep.obj", sample_dir / "assembly.obj"] + candidates
    elif obj_kind == "auto":
        candidates = [sample_dir / "assembly.mesh.obj", sample_dir / "assembly.brep.obj", sample_dir / "assembly.obj"] + candidates
    seen: set[str] = set()
    for p in candidates:
        key = p.as_posix()
        if key in seen:
            continue
        seen.add(key)
        if p.exists() and p.is_file():
            out: Dict[str, Any] = {"obj_file": safe_rel(p, sample_dir), "mesh_summary": parse_obj_basic(p)}
            raw = read_obj_text(p, raw_obj_mode, max_raw_obj_chars)
            if raw is not None:
                out["raw_obj_text"] = raw
            return out
    return None


def find_mate_graph_json(sample_dir: Path) -> Optional[Path]:
    sample_dir = sample_dir.resolve()
    candidates = [sample_dir / "mate_graph.json", sample_dir / "graph" / "mate_graph.json"]
    return next((p for p in candidates if p.exists() and p.is_file()), None)


def _edge_pair(edge: Dict[str, Any]) -> Tuple[Optional[str], Optional[str]]:
    comps = edge.get("components")
    if isinstance(comps, list) and len(comps) >= 2:
        return str(comps[0]), str(comps[1])
    a = edge.get("source_component") or edge.get("source_component_id") or edge.get("component_a") or edge.get("from") or edge.get("source")
    b = edge.get("target_component") or edge.get("target_component_id") or edge.get("target_components") or edge.get("component_b") or edge.get("to") or edge.get("target")
    return (str(a) if a else None, str(b) if b else None)


def _mate_type(edge: Dict[str, Any]) -> str:
    mts = edge.get("mate_types")
    if isinstance(mts, list) and mts:
        return str(mts[0])
    return str(edge.get("mate_type") or edge.get("solidworks_type") or edge.get("type") or edge.get("mate_name") or "UnknownMate")


def _normalize_mate_graph(data: Dict[str, Any], assembly_id: str, library_json: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    nodes: List[Dict[str, str]] = []
    seen_nodes: set[str] = set()
    for n in data.get("nodes") or []:
        if not isinstance(n, dict):
            continue
        cid = str(n.get("component_id") or n.get("id") or "")
        if not cid or cid in seen_nodes:
            continue
        row: Dict[str, str] = {"component_id": cid}
        lib_id = n.get("library_id")
        if lib_id:
            row["library_id"] = str(lib_id)
        nodes.append(row)
        seen_nodes.add(cid)

    edges: List[Dict[str, str]] = []
    seen_edges: set[Tuple[str, str, str]] = set()
    for e in data.get("edges") or []:
        if not isinstance(e, dict):
            continue
        a, b = _edge_pair(e)
        if not a or not b or a == b:
            continue
        mt = _mate_type(e)
        key = tuple(sorted([a, b]) + [mt])
        if key in seen_edges:
            continue
        edges.append({"source_component": a, "target_component": b, "mate_type": mt})
        seen_edges.add(key)
    out: Dict[str, Any] = {"assembly_id": data.get("assembly_id") or assembly_id, "nodes": nodes, "edges": edges}
    if library_json and library_json.get("library"):
        out["library"] = [{"library_id": str(x.get("library_id")), "obj_file": x.get("obj_file")} for x in library_json.get("library", []) if isinstance(x, dict) and x.get("library_id")]
    return out


def load_or_build_mate_graph(sample_dir: Path, library_json: Optional[Dict[str, Any]] = None) -> Optional[Dict[str, Any]]:
    """Load flat mate_graph.json only.

    This function deliberately does not synthesize mate_graph from
    assembly_graph_gt.json. In Stage-B, providing mate_graph.json means the
    experiment explicitly gives the model the component-instance list and mate
    constraints. If the file is absent, mate-graph experiments must preflight-fail.
    """
    path = find_mate_graph_json(sample_dir)
    if not path:
        return None
    data = read_json(path)
    if not isinstance(data, dict):
        return None
    return _normalize_mate_graph(data, sample_dir.name, library_json=library_json)


def _node_id(n: Dict[str, Any]) -> Optional[str]:
    return n.get("component_id") or n.get("id") or n.get("component")


def sw_transform_to_pose(transform: Dict[str, Any]) -> Tuple[Dict[str, float], Dict[str, float]]:
    arr = None
    if isinstance(transform, dict):
        arr = transform.get("array_data") or transform.get("ArrayData")
    if not isinstance(arr, list) or len(arr) < 12:
        return {}, {}
    vals = [float(v) for v in arr]
    R = [
        [vals[0], vals[3], vals[6]],
        [vals[1], vals[4], vals[7]],
        [vals[2], vals[5], vals[8]],
    ]
    position = {"x": vals[9] * 1000.0, "y": vals[10] * 1000.0, "z": vals[11] * 1000.0}
    sy = math.sqrt(R[0][0] * R[0][0] + R[1][0] * R[1][0])
    singular = sy < 1e-9
    if not singular:
        rx = math.atan2(R[2][1], R[2][2])
        ry = math.atan2(-R[2][0], sy)
        rz = math.atan2(R[1][0], R[0][0])
    else:
        rx = math.atan2(-R[1][2], R[1][1])
        ry = math.atan2(-R[2][0], sy)
        rz = 0.0
    orientation = {"rx": math.degrees(rx), "ry": math.degrees(ry), "rz": math.degrees(rz)}
    return position, orientation


def load_exported_gt(sample_dir: Path) -> Dict[str, Any]:
    sample_dir = sample_dir.resolve()
    candidates = [sample_dir / "assembly_graph_gt.json", sample_dir / "gt" / "assembly_graph_gt.json"]
    gt_path = next((p for p in candidates if p.exists() and p.is_file()), None)
    if not gt_path:
        return {"assembly_id": sample_dir.name, "nodes": [], "node_parts": [], "edges": [], "_gt_path": None}
    data = read_json(gt_path)
    assembly_id = data.get("assembly_id") or data.get("assembly_name") or sample_dir.name
    raw_nodes = data.get("node_parts") if isinstance(data.get("node_parts"), list) else None
    raw_edges = data.get("edges") if isinstance(data.get("edges"), list) else None
    if raw_nodes is None:
        dep = data.get("dependency_graph") if isinstance(data.get("dependency_graph"), dict) else {}
        raw_nodes = dep.get("nodes") or data.get("nodes") or []
        raw_edges = dep.get("edges") or data.get("edges") or []

    nodes: List[Dict[str, Any]] = []
    for n in raw_nodes or []:
        if not isinstance(n, dict):
            continue
        cid = _node_id(n)
        if not cid:
            continue
        if n.get("node_type") not in (None, "component", "Node Part"):
            continue
        name = n.get("component_name_raw") or n.get("component_name") or n.get("name") or str(cid)
        transform = n.get("transform") or {}
        sw_pos, sw_ori = sw_transform_to_pose(transform)
        position = n.get("position") or (n.get("pose") or {}).get("position") or sw_pos
        orientation = n.get("orientation") or (n.get("pose") or {}).get("orientation") or sw_ori
        nodes.append({
            "component_id": str(cid),
            "id": str(cid),
            "type": "Node Part",
            "component_name": str(name),
            "name": str(name),
            "position": position,
            "orientation": orientation,
            "pose": {"position": position, "orientation": orientation},
            "transform": transform,
        })

    edges: List[Dict[str, str]] = []
    for e in raw_edges or []:
        if not isinstance(e, dict):
            continue
        a, b = _edge_pair(e)
        if not a or not b:
            continue
        edges.append({"source_component": a, "target_component": b, "from": a, "to": b, "mate_type": _mate_type(e)})
    return {"assembly_id": assembly_id, "nodes": nodes, "node_parts": nodes, "edges": edges, "_gt_path": str(gt_path)}


def is_prepared_sample(path: Path) -> bool:
    return (path / "component_library").is_dir() and any((path / "component_library").glob("*.obj"))


def discover_dataset_samples(root: Path, recursive: bool = False) -> List[Path]:
    root = root.resolve()
    if is_prepared_sample(root):
        return [root]
    if not root.exists():
        return []
    if recursive:
        candidates = sorted(p for p in root.rglob("*") if p.is_dir() and p.name not in {"_logs", "__pycache__"})
    else:
        candidates = sorted(p for p in root.iterdir() if p.is_dir() and p.name not in {"_logs", "__pycache__"})
    return [p for p in candidates if is_prepared_sample(p)]
