﻿#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Generate a component-level mate graph HTML from prediction or mate_graph.json."""
from __future__ import annotations

import argparse
import base64
import mimetypes
import json
import math
import os
import tempfile
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
os.environ.setdefault("OMP_NUM_THREADS", "1")

from cad_assembly_dataset import discover_component_library

VIEW_EDGE_COLOR = "#17212b"
VIEW_PASTEL_PALETTE = [
    "#d9dc83", "#d98bc9", "#ffc178", "#8fd48f", "#c8c8c8", "#9bc9ee",
    "#f3a6c9", "#a8e0ae", "#ffae64", "#89bde8", "#bfa7e8", "#d7ad96",
    "#efe58a", "#f5a3a3", "#8ed8df", "#c4dd86", "#ffcf8a", "#bfc7d5",
]


def read_json(path: Path) -> Any:
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def edge_pair(edge: Dict[str, Any]) -> Tuple[str, str]:
    comps = edge.get("components")
    if isinstance(comps, list) and len(comps) >= 2:
        return str(comps[0]), str(comps[1])
    return str(edge.get("source_component") or edge.get("from") or edge.get("component_a")), str(edge.get("target_component") or edge.get("target_components") or edge.get("to") or edge.get("component_b"))


def parse_obj_points(path: Path, max_vertices: int = 1200) -> List[List[float]]:
    pts: List[List[float]] = []
    if not path.exists():
        return pts
    with path.open("r", encoding="utf-8", errors="ignore") as f:
        for line in f:
            if not line.startswith("v "):
                continue
            parts = line.split()
            if len(parts) < 4:
                continue
            try:
                pts.append([float(parts[1]), float(parts[2]), float(parts[3])])
            except Exception:
                pass
            if len(pts) >= max_vertices:
                break
    return pts


def parse_obj_mesh(path: Path, max_faces: int = 900) -> Tuple[List[List[float]], List[List[int]]]:
    vertices: List[List[float]] = []
    faces: List[List[int]] = []
    if not path.exists():
        return vertices, faces
    with path.open("r", encoding="utf-8", errors="ignore") as f:
        for line in f:
            if line.startswith("v "):
                parts = line.split()
                if len(parts) >= 4:
                    try:
                        vertices.append([float(parts[1]), float(parts[2]), float(parts[3])])
                    except Exception:
                        pass
            elif line.startswith("f "):
                idx: List[int] = []
                for part in line.split()[1:]:
                    try:
                        raw = part.split("/")[0]
                        value = int(raw)
                        idx.append(value - 1 if value > 0 else len(vertices) + value)
                    except Exception:
                        pass
                if len(idx) >= 3:
                    for i in range(1, len(idx) - 1):
                        tri = [idx[0], idx[i], idx[i + 1]]
                        if all(0 <= j < len(vertices) for j in tri):
                            faces.append(tri)
                if len(faces) >= max_faces:
                    break
    return vertices, faces


def _project_points(points: List[List[float]], size: int = 76) -> Tuple[List[Tuple[float, float, float]], float]:
    if not points:
        return [], 1.0
    ax, ay = math.radians(35), math.radians(45)
    cx, sx = math.cos(ax), math.sin(ax)
    cz, sz = math.cos(ay), math.sin(ay)
    projected: List[Tuple[float, float, float]] = []
    for x, y, z in points:
        y1 = y * cx - z * sx
        z1 = y * sx + z * cx
        x1 = x * cz - y1 * sz
        y2 = x * sz + y1 * cz
        projected.append((x1, y2 - 0.25 * z1, z1))
    xs = [p[0] for p in projected]
    ys = [p[1] for p in projected]
    mx, my = (min(xs) + max(xs)) / 2, (min(ys) + max(ys)) / 2
    span = max(max(xs) - min(xs), max(ys) - min(ys), 1e-6)
    scale = size / span
    return [((x - mx) * scale, (y - my) * scale, z) for x, y, z in projected], scale


def component_mesh_thumbnail(path: Path, size: int = 76) -> str:
    points, faces = parse_obj_mesh(path)
    if not points:
        return component_thumbnail([])
    projected, _ = _project_points(points, size=size)
    if not faces:
        return component_thumbnail(points)
    polys: List[Tuple[float, str]] = []
    step = max(1, len(faces) // 260)
    for tri in faces[::step]:
        try:
            coords = [projected[i] for i in tri]
            depth = sum(p[2] for p in coords) / 3.0
            p2 = " ".join(f"{x:.1f},{y:.1f}" for x, y, _ in coords)
            shade = 0.76 + 0.22 * (len(polys) % 5) / 4.0
            fill = f"rgb({int(217 * shade)},{int(220 * shade)},{int(131 * shade)})"
            polys.append((depth, f"<polygon points='{p2}' fill='{fill}' stroke='{VIEW_EDGE_COLOR}' stroke-width='0.28'/>"))
        except Exception:
            pass
    if not polys:
        return component_thumbnail(points)
    polys.sort(key=lambda item: item[0])
    return (
        "<g class='thumb'><rect x='-44' y='-36' width='88' height='72' rx='6' fill='#fff' stroke='#9aa4b2' stroke-width='1.2'/>"
        "<g>"
        + "".join(poly for _, poly in polys)
        + "</g></g>"
    )



def find_component_image(sample_dir: Path, component_id: str) -> Optional[Path]:
    roots = [
        sample_dir / "reference_views" / "components",
        sample_dir / "views" / "components",
        sample_dir / "component_views",
        sample_dir / "components_optional",
        sample_dir / "views",
    ]
    patterns = [
        f"{component_id}.png",
        f"{component_id}_v02.png",
        f"{component_id}_v01.png",
        f"{component_id}_iso.*",
        f"{component_id}*iso*.*",
        f"{component_id}_v*.png",
        f"{component_id}*.png",
    ]
    for root in roots:
        if not root.exists():
            continue
        for pat in patterns:
            for p in sorted(root.glob(pat)):
                if p.suffix.lower() in {".png", ".jpg", ".jpeg", ".webp"}:
                    return p
    return None


def image_data_url(path: Path) -> str:
    mime = mimetypes.guess_type(path.as_posix())[0] or "image/png"
    return f"data:{mime};base64," + base64.b64encode(path.read_bytes()).decode("ascii")


THUMBNAIL_COLORS = VIEW_PASTEL_PALETTE



def color_for_index(i: int) -> str:
    return THUMBNAIL_COLORS[i % max(len(THUMBNAIL_COLORS), 1)]


def stable_palette_index(key: Any) -> int:
    h = 0
    for ch in str(key or ""):
        h = ((h * 131) + ord(ch)) & 0xFFFFFFFF
    return h % max(len(THUMBNAIL_COLORS), 1)


def color_for_key(key: Any) -> str:
    return color_for_index(stable_palette_index(key))

def render_obj_data_url(path: Path, color: str, size: int = 320) -> Optional[str]:
    """Render the complete OBJ with PyVista and return an embedded PNG."""
    try:
        import numpy as np
        import pyvista as pv

        mesh = pv.read(str(path))
        if not isinstance(mesh, pv.PolyData):
            mesh = mesh.extract_surface()
        mesh = mesh.triangulate()
        if mesh.n_points == 0 or mesh.n_cells == 0:
            return None

        plotter = pv.Plotter(off_screen=True, window_size=(size, size))
        try:
            plotter.set_background("white")
            plotter.add_mesh(
                mesh,
                color=color,
                smooth_shading=False,
                specular=0.02,
                ambient=0.82,
                diffuse=0.28,
                show_edges=False,
            )
            try:
                feature_edges = mesh.extract_feature_edges(
                    feature_angle=25,
                    boundary_edges=True,
                    non_manifold_edges=True,
                    feature_edges=True,
                    manifold_edges=False,
                )
                if feature_edges.n_points > 0:
                    plotter.add_mesh(
                        feature_edges,
                        color=VIEW_EDGE_COLOR,
                        line_width=1.0,
                        render_lines_as_tubes=False,
                    )
            except Exception:
                pass
            center = np.asarray(mesh.center, dtype=float)
            bounds = np.asarray(mesh.bounds, dtype=float)
            diag = float(np.linalg.norm([
                bounds[1] - bounds[0],
                bounds[3] - bounds[2],
                bounds[5] - bounds[4],
            ]))
            direction = np.asarray([1.25, -1.55, 1.05], dtype=float)
            direction /= max(float(np.linalg.norm(direction)), 1e-12)
            up = np.asarray([0.0, 0.0, 1.0], dtype=float)
            plotter.camera_position = [
                tuple((center + direction * max(diag * 2.2, 1.0)).tolist()),
                tuple(center.tolist()),
                tuple(up.tolist()),
            ]
            plotter.camera.parallel_projection = True
            plotter.reset_camera()
            plotter.camera.zoom(1.22)
            plotter.reset_camera_clipping_range()
            with tempfile.NamedTemporaryFile(suffix=".png", delete=False) as tmp:
                tmp_path = Path(tmp.name)
            try:
                plotter.screenshot(str(tmp_path), transparent_background=False)
                return image_data_url(tmp_path)
            finally:
                tmp_path.unlink(missing_ok=True)
        finally:
            plotter.close()
    except Exception:
        return None


def component_image_node(path: Optional[Path] = None, href: Optional[str] = None) -> str:
    try:
        href = href or (image_data_url(path) if path is not None else None)
    except Exception:
        return ""
    if not href:
        return ""
    return (
        "<g class='thumb'>"
        "<rect x='-50' y='-42' width='100' height='84' rx='7' fill='#fff' stroke='#9aa4b2' stroke-width='1.2'/>"
        f"<image href='{href}' x='-46' y='-38' width='92' height='76' preserveAspectRatio='xMidYMid meet'/>"
        "</g>"
    )

def missing_component_image_node(label: str) -> str:
    safe = str(label).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
    return (
        "<g class='thumb missing-image'>"
        "<rect x='-50' y='-42' width='100' height='84' rx='7' fill='#fff8f0' stroke='#c56b27' stroke-width='1.6'/>"
        "<text y='-4' class='missing-label'>missing</text>"
        f"<text y='14' class='missing-label'>{safe}</text>"
        "</g>"
    )

def component_thumbnail(points: List[List[float]], size: int = 76) -> str:
    if not points:
        return "<circle cx='0' cy='0' r='24' fill='#f5f7fa' stroke='#9aa4b2' stroke-width='1.4'/>"
    projected: List[Tuple[float, float]] = []
    ax, ay = math.radians(35), math.radians(45)
    cx, sx = math.cos(ax), math.sin(ax)
    cz, sz = math.cos(ay), math.sin(ay)
    for x, y, z in points:
        y1 = y * cx - z * sx
        z1 = y * sx + z * cx
        x1 = x * cz - y1 * sz
        y2 = x * sz + y1 * cz
        projected.append((x1, y2 - 0.25 * z1))
    xs = [p[0] for p in projected]
    ys = [p[1] for p in projected]
    mx, my = (min(xs) + max(xs)) / 2, (min(ys) + max(ys)) / 2
    span = max(max(xs) - min(xs), max(ys) - min(ys), 1e-6)
    scale = size / span
    dots = []
    step = max(1, len(projected) // 260)
    for x, y in projected[::step]:
        px = (x - mx) * scale
        py = (y - my) * scale
        dots.append(f"<circle cx='{px:.1f}' cy='{py:.1f}' r='1.4'/>")
    return (
        "<g class='thumb'><rect x='-44' y='-36' width='88' height='72' rx='6' fill='#fff' stroke='#9aa4b2' stroke-width='1.2'/>"
        "<g fill='#d9dc83' fill-opacity='0.9' stroke='none'>"
        + "".join(dots)
        + "</g></g>"
    )


def graph_html(data: Dict[str, Any], sample_dir: Optional[Path] = None, obj_kind: str = "auto") -> str:
    raw_nodes = data.get("nodes") or data.get("node_parts") or []
    node_ids: List[str] = []
    node_library_map: Dict[str, str] = {}
    for n in raw_nodes:
        if isinstance(n, dict):
            cid = n.get("component_id") or n.get("id")
            if cid and str(cid) not in node_ids:
                node_ids.append(str(cid))
            if cid and n.get("library_id"):
                node_library_map[str(cid)] = str(n.get("library_id"))
    for e in data.get("edges") or []:
        if isinstance(e, dict):
            a, b = edge_pair(e)
            for cid in [a, b]:
                if cid and cid != "None" and cid not in node_ids:
                    node_ids.append(cid)
    obj_map: Dict[str, Path] = {}
    obj_colors: Dict[str, str] = {}
    image_aliases: Dict[str, str] = {}
    if sample_dir is not None:
        try:
            lib = discover_component_library(sample_dir, obj_kind=obj_kind, raw_obj_mode="none")
            for idx, item in enumerate(lib.get("library", [])):
                lib_id = str(item.get("library_id") or item.get("component_id") or "")
                p = Path(str(item.get("obj_file") or ""))
                if not p.is_absolute():
                    p = sample_dir / p
                if lib_id and p.exists():
                    obj_map[lib_id] = p
                    obj_colors[str(p.resolve())] = color_for_index(idx)
            for cid, lib_id in list(node_library_map.items()):
                if cid and lib_id and lib_id in obj_map:
                    obj_map[cid] = obj_map[lib_id]
                    image_aliases[cid] = lib_id
        except Exception:
            obj_map = {}
    N = max(len(node_ids), 1)
    R = 260
    cx, cy = 360, 320
    pos = {}
    for i, cid in enumerate(node_ids):
        ang = 2 * math.pi * i / N - math.pi / 2
        pos[cid] = (cx + R * math.cos(ang), cy + R * math.sin(ang))
    edge_svg = []
    edge_records = []
    for edge_index, e in enumerate(data.get("edges") or []):
        if not isinstance(e, dict):
            continue
        a, b = edge_pair(e)
        if a not in pos or b not in pos:
            continue
        x1, y1 = pos[a]
        x2, y2 = pos[b]
        mx, my = (x1 + x2) / 2, (y1 + y2) / 2
        mt = e.get("mate_type") or "mate"
        eid = e.get("edge_id") or f"edge_{edge_index}"
        edge_records.append({"edge_id": eid, "components": [a, b], "mate_type": mt, "raw": e})
        edge_svg.append(f"<g class='edge' data-edge-index='{len(edge_records)-1}' data-a='{a}' data-b='{b}'><line class='edge-line' x1='{x1:.1f}' y1='{y1:.1f}' x2='{x2:.1f}' y2='{y2:.1f}'/><text x='{mx:.1f}' y='{my:.1f}' class='edge-label'>{mt}</text></g>")
    node_svg = []
    rendered_obj_images: Dict[str, Optional[str]] = {}
    for path in sorted({str(path.resolve()) for path in obj_map.values()}):
        obj_colors.setdefault(path, color_for_key(path))
    for cid in node_ids:
        x, y = pos[cid]
        lib_label = node_library_map.get(cid)
        image_ids = []
        for image_id in (lib_label, image_aliases.get(cid), cid):
            if image_id and image_id not in image_ids:
                image_ids.append(image_id)
        img = None
        if sample_dir is not None:
            for image_id in image_ids:
                img = find_component_image(sample_dir, image_id)
                if img is not None:
                    break
        obj = obj_map.get(cid) or (obj_map.get(lib_label) if lib_label else None)
        if img is not None:
            thumb = component_image_node(img)
        elif obj is not None:
            cache_key = str(obj.resolve())
            if cache_key not in rendered_obj_images:
                rendered_obj_images[cache_key] = render_obj_data_url(
                    obj,
                    obj_colors.get(cache_key, THUMBNAIL_COLORS[0]),
                )
            rendered = rendered_obj_images[cache_key]
            thumb = component_image_node(href=rendered) if rendered else component_mesh_thumbnail(obj)
        else:
            thumb = missing_component_image_node(lib_label or cid)
        title = f"<title>{cid}{' -> ' + lib_label if lib_label else ''}</title>"
        node_svg.append(f"<g class='node' data-id='{cid}' transform='translate({x:.1f},{y:.1f})'>{title}{thumb}<text y='58' class='node-label'>{cid}</text></g>")
    return f"""<!doctype html><html><head><meta charset='utf-8'><title>Mate graph</title>
<style>
body{{font-family:Arial,sans-serif;margin:0;background:#fafafa;display:flex;height:100vh;color:#222}}
.wrap{{flex:1;padding:16px;min-width:0}} svg{{width:100%;height:calc(100vh - 40px);background:white;border:1px solid #ddd}}
.panel{{width:390px;border-left:1px solid #ddd;background:#fff;padding:14px;overflow:auto}}
.node{{cursor:move}} .node-label{{font-size:12px;text-anchor:middle;font-weight:bold;pointer-events:none}}
.edge{{cursor:pointer}} .edge-line{{stroke:#555;stroke-width:2.5}} .edge.selected .edge-line{{stroke:#d62728;stroke-width:4}}
.edge-label{{font-size:11px;text-anchor:middle;fill:#333;pointer-events:none}} .missing-label{{font-size:10px;text-anchor:middle;fill:#9a4d16;pointer-events:none}} pre{{white-space:pre-wrap;word-break:break-word;font-size:12px;background:#fafafa;border:1px solid #e3e3e3;border-radius:6px;padding:10px}}
</style></head>
<body><div class='wrap'><h2>Component-level Mate Graph</h2><svg id='graph' viewBox='0 0 720 640'>{''.join(edge_svg)}{''.join(node_svg)}</svg></div>
<div class='panel'><h2>Mate Detail</h2><pre id='detail'>Click a mate line.</pre></div>
<script>
const edges = {json.dumps(edge_records)};
const svg = document.getElementById('graph');
const detail = document.getElementById('detail');
function nodePos(node) {{
  const m = /translate\\(([-0-9.]+),([-0-9.]+)\\)/.exec(node.getAttribute('transform') || '');
  return m ? [Number(m[1]), Number(m[2])] : [0,0];
}}
function setNodePos(node, x, y) {{ node.setAttribute('transform', `translate(${{x}},${{y}})`); updateEdges(); }}
function svgPoint(evt) {{
  const pt = svg.createSVGPoint();
  pt.x = evt.clientX; pt.y = evt.clientY;
  const p = pt.matrixTransform(svg.getScreenCTM().inverse());
  return [p.x, p.y];
}}
function updateEdges() {{
  const positions = {{}};
  document.querySelectorAll('.node').forEach(n => positions[n.dataset.id] = nodePos(n));
  document.querySelectorAll('.edge').forEach(g => {{
    const a = positions[g.dataset.a], b = positions[g.dataset.b];
    if (!a || !b) return;
    const line = g.querySelector('line'), text = g.querySelector('text');
    line.setAttribute('x1', a[0]); line.setAttribute('y1', a[1]); line.setAttribute('x2', b[0]); line.setAttribute('y2', b[1]);
    text.setAttribute('x', (a[0]+b[0])/2); text.setAttribute('y', (a[1]+b[1])/2);
  }});
}}
document.querySelectorAll('.edge').forEach(g => {{
  g.addEventListener('click', () => {{
    document.querySelectorAll('.edge').forEach(e => e.classList.remove('selected'));
    g.classList.add('selected');
    detail.textContent = JSON.stringify(edges[Number(g.dataset.edgeIndex)], null, 2);
  }});
}});
let drag = null;
document.querySelectorAll('.node').forEach(n => {{
  n.addEventListener('pointerdown', evt => {{
    const p = nodePos(n);
    const q = svgPoint(evt);
    drag = {{node:n, dx:q[0]-p[0], dy:q[1]-p[1]}};
    n.setPointerCapture(evt.pointerId);
  }});
}});
svg.addEventListener('pointermove', evt => {{ if (drag) {{ const q = svgPoint(evt); setNodePos(drag.node, q[0]-drag.dx, q[1]-drag.dy); }} }});
svg.addEventListener('pointerup', () => drag = null);
</script></body></html>"""


def main() -> None:
    ap = argparse.ArgumentParser(description="Render mate graph JSON to HTML.")
    ap.add_argument("json_file", type=Path, help="assembly_prediction.json or graph/mate_graph.json")
    ap.add_argument("--out", type=Path, required=True, help="Output HTML path or output directory")
    ap.add_argument("--sample-dir", type=Path, default=None, help="Sample directory used to load component OBJ thumbnails")
    ap.add_argument("--obj-kind", choices=["mesh", "brep", "auto"], default="mesh")
    args = ap.parse_args()
    data = read_json(args.json_file)
    out = args.out
    if out.suffix.lower() != ".html":
        out = out / "mate_graph.html"
    out.parent.mkdir(parents=True, exist_ok=True)
    sample_dir = args.sample_dir or args.json_file.parent
    out.write_text(graph_html(data, sample_dir=sample_dir, obj_kind=args.obj_kind), encoding="utf-8")
    print(out)


if __name__ == "__main__":
    main()





