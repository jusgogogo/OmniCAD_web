#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Evaluate predicted CAD assembly graph against assembly_graph_gt.json if available.

Supports both legacy prediction schema:
  node_parts + from/to
and v3 undirected graph schema:
  nodes + edges.components
"""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
from typing import Any, Dict, List, Tuple

import numpy as np

from cad_assembly_dataset import load_exported_gt
from cad_assembly_visualize_prediction import euler_xyz_to_matrix


def read_json(path: Path) -> Any:
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def prediction_nodes(pred: Dict[str, Any]) -> Dict[str, Dict[str, Any]]:
    if isinstance(pred.get("nodes"), list):
        out: Dict[str, Dict[str, Any]] = {}
        for n in pred.get("nodes", []):
            if not isinstance(n, dict):
                continue
            cid = n.get("component_id")
            if cid is not None:
                out[str(cid)] = n
        return out
    return {str(n.get("id")): n for n in pred.get("node_parts", []) if isinstance(n, dict) and n.get("id") is not None}


def get_prediction_position(node: Dict[str, Any]) -> np.ndarray:
    if isinstance(node.get("pose"), dict):
        p = (node.get("pose") or {}).get("position") or {}
    else:
        p = node.get("position") or {}
    return np.array([float(p.get("x", 0.0)), float(p.get("y", 0.0)), float(p.get("z", 0.0))], dtype=float)


def orientation_to_matrix(o: Dict[str, Any]) -> np.ndarray:
    if isinstance(o.get("matrix4x4"), list):
        M = np.asarray(o.get("matrix4x4"), dtype=float)
        if M.shape == (4, 4):
            return M[:3, :3]
    if isinstance(o.get("rotation_matrix"), list):
        R = np.asarray(o.get("rotation_matrix"), dtype=float)
        if R.shape == (3, 3):
            return R
    if isinstance(o.get("euler_xyz_deg"), dict):
        e = o.get("euler_xyz_deg") or {}
        return euler_xyz_to_matrix(float(e.get("x", 0.0)), float(e.get("y", 0.0)), float(e.get("z", 0.0)))
    return euler_xyz_to_matrix(float(o.get("rx", 0.0)), float(o.get("ry", 0.0)), float(o.get("rz", 0.0)))


def get_prediction_orientation_matrix(node: Dict[str, Any]) -> np.ndarray:
    if isinstance(node.get("pose"), dict):
        o = (node.get("pose") or {}).get("orientation") or {}
    else:
        o = node.get("orientation") or {}
    return orientation_to_matrix(o)


def gt_node_pose(node: Dict[str, Any]) -> Tuple[np.ndarray, np.ndarray] | None:
    if "position" in node and "orientation" in node:
        p = node.get("position") or {}
        o = node.get("orientation") or {}
        if all(k in p for k in ("x", "y", "z")):
            pos = np.array([float(p["x"]), float(p["y"]), float(p["z"])], dtype=float)
            return pos, orientation_to_matrix(o)
    arr = ((node.get("transform") or {}).get("array_data") or [])
    if len(arr) >= 12:
        a = [float(x) for x in arr]
        R = np.array([[a[0], a[3], a[6]], [a[1], a[4], a[7]], [a[2], a[5], a[8]]], dtype=float)
        pos = np.array([a[9], a[10], a[11]], dtype=float) * 1000.0
        return pos, R
    return None


def rotation_angle_deg(R_pred: np.ndarray, R_gt: np.ndarray) -> float:
    R = R_pred @ R_gt.T
    val = (np.trace(R) - 1.0) / 2.0
    val = max(-1.0, min(1.0, float(val)))
    return math.degrees(math.acos(val))


def edge_components(edge: Dict[str, Any]) -> Tuple[str | None, str | None]:
    comps = edge.get("components")
    if isinstance(comps, list) and len(comps) >= 2:
        return str(comps[0]), str(comps[1])
    a = edge.get("component_a") or edge.get("from") or edge.get("source") or edge.get("source_component") or edge.get("source_component_id")
    b = edge.get("component_b") or edge.get("to") or edge.get("target") or edge.get("target_component") or edge.get("target_components") or edge.get("target_component_id")
    return (str(a) if a is not None else None, str(b) if b is not None else None)


def edge_key(edge: Dict[str, Any]) -> Tuple[str, str, str] | None:
    a, b = edge_components(edge)
    if not a or not b:
        return None
    if a > b:
        a, b = b, a
    return a, b, str(edge.get("mate_type") or "UnknownMate")


def main() -> None:
    parser = argparse.ArgumentParser(description="Evaluate predicted assembly JSON against GT JSON.")
    parser.add_argument("sample_dir", type=Path)
    parser.add_argument("prediction_json", type=Path)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()

    gt = load_exported_gt(args.sample_dir)
    pred = read_json(args.prediction_json)
    gt_nodes = {str(n.get("id")): n for n in gt.get("node_parts", [])}
    pred_nodes = prediction_nodes(pred)

    comp_rows = []
    for cid, gnode in gt_nodes.items():
        if cid not in pred_nodes:
            comp_rows.append({"component_id": cid, "status": "missing_prediction"})
            continue
        gpose = gt_node_pose(gnode)
        if gpose is None:
            comp_rows.append({"component_id": cid, "status": "missing_gt_pose"})
            continue
        gt_pos, gt_R = gpose
        pred_pos = get_prediction_position(pred_nodes[cid])
        pred_R = get_prediction_orientation_matrix(pred_nodes[cid])
        terr = float(np.linalg.norm(pred_pos - gt_pos))
        rerr = rotation_angle_deg(pred_R, gt_R)
        comp_rows.append({
            "component_id": cid,
            "status": "ok",
            "translation_error_mm": round(terr, 6),
            "rotation_error_deg": round(rerr, 6),
        })

    gt_edges = {k for e in gt.get("edges", []) if (k := edge_key(e)) is not None}
    pred_edges = {k for e in pred.get("edges", []) if (k := edge_key(e)) is not None}
    tp = len(gt_edges & pred_edges)
    precision = tp / len(pred_edges) if pred_edges else 0.0
    recall = tp / len(gt_edges) if gt_edges else 0.0
    f1 = 2 * precision * recall / (precision + recall) if precision + recall else 0.0

    ok_rows = [r for r in comp_rows if r.get("status") == "ok"]
    summary = {
        "component_count_gt": len(gt_nodes),
        "component_count_pred": len(pred_nodes),
        "component_pose_evaluated": len(ok_rows),
        "mean_translation_error_mm": round(sum(r["translation_error_mm"] for r in ok_rows) / len(ok_rows), 6) if ok_rows else None,
        "median_translation_error_mm": round(float(np.median([r["translation_error_mm"] for r in ok_rows])), 6) if ok_rows else None,
        "mean_rotation_error_deg": round(sum(r["rotation_error_deg"] for r in ok_rows) / len(ok_rows), 6) if ok_rows else None,
        "median_rotation_error_deg": round(float(np.median([r["rotation_error_deg"] for r in ok_rows])), 6) if ok_rows else None,
        "mate_edge_gt": len(gt_edges),
        "mate_edge_pred": len(pred_edges),
        "mate_edge_tp": tp,
        "mate_edge_precision": round(precision, 6),
        "mate_edge_recall": round(recall, 6),
        "mate_edge_f1": round(f1, 6),
    }
    args.out.mkdir(parents=True, exist_ok=True)
    (args.out / "evaluation_summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    (args.out / "component_pose_errors.json").write_text(json.dumps(comp_rows, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
