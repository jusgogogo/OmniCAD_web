﻿#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Shared Stage-B runtime utilities for independent experiment files.

Experiment modes:
  exp_zs_img              library OBJ + same-color reference projection images
  exp_zs_ref_obj          library OBJ + reference assembly OBJ condition
  exp_zs_ref_img_color    library OBJ + color-by-component reference images
  exp_zs_mate_graph       library mesh OBJ + pose-free mate_graph.json
  exp_zs_mate_graph_img   library mesh OBJ + pose-free mate_graph.json + color images
  exp_zs_mate_graph_ref_obj_img library mesh OBJ + pose-free mate_graph.json + assembly.mesh.obj + color images

Clean run inputs copy only component OBJ files, reference views, assembly.mesh.obj, and mate_graph.json.
Normal outputs are assembly_prediction.json plus per-experiment log.json and an aggregate top-level log.json.

This module intentionally contains no OpenRouter/OpenAI API call.
Each exp_*.py file owns its own API invocation and response_format.
"""
from __future__ import annotations

import argparse
import base64
import csv
import json
import importlib
import mimetypes
import os
import re
import shutil
import sys
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from cad_assembly_dataset import (
    VIEW_NAMES,
    discover_component_library,
    discover_dataset_samples,
    find_reference_views,
    find_reference_assembly_obj,
    load_exported_gt,
    load_or_build_mate_graph,
    safe_rel,
)


EXPERIMENT_MODES: Dict[str, str] = {
    "exp_zs_img": "component_library + same-color reference images",
    "exp_zs_ref_obj": "component_library + assembly.mesh.obj",
    "exp_zs_ref_img_color": "component_library + color-by-component reference images",
    "exp_zs_mate_graph_img": "component_library + mate_graph.json + color-by-component reference images",
    "exp_zs_mate_graph_ref_obj_img": "component_library + mate_graph.json + assembly.mesh.obj + color-by-component reference images",
}


def read_json(path: Path) -> Any:
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def write_json(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    with tmp.open("w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    tmp.replace(path)


def write_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text or "", encoding="utf-8")


def is_context_limit_error(error_text: str) -> bool:
    text = (error_text or "").lower()
    patterns = [
        "maximum context length",
        "context length",
        "context_length",
        "context limit",
        "too many tokens",
        "requested about",
        "please reduce the length",
    ]
    return any(p in text for p in patterns)


def image_to_data_url(path: Path) -> str:
    mime = mimetypes.guess_type(path.as_posix())[0] or "image/png"
    return f"data:{mime};base64," + base64.b64encode(path.read_bytes()).decode("ascii")


def extract_json_from_text(text: str) -> Dict[str, Any]:
    text = (text or "").strip()
    if text.startswith("```"):
        text = re.sub(r"^```(?:json)?\s*", "", text)
        text = re.sub(r"\s*```$", "", text)
    try:
        value = json.loads(text)
        if isinstance(value, dict):
            return value
    except Exception:
        pass
    starts = [m.start() for m in re.finditer(r"\{", text)]
    last_error: Optional[Exception] = None
    for start in starts:
        depth = 0
        in_str = False
        esc = False
        for i in range(start, len(text)):
            ch = text[i]
            if in_str:
                if esc:
                    esc = False
                elif ch == "\\":
                    esc = True
                elif ch == '"':
                    in_str = False
            else:
                if ch == '"':
                    in_str = True
                elif ch == "{":
                    depth += 1
                elif ch == "}":
                    depth -= 1
                    if depth == 0:
                        block = text[start:i+1]
                        try:
                            val = json.loads(block)
                            if isinstance(val, dict):
                                return val
                        except Exception as exc:
                            last_error = exc
                        break
    if last_error:
        raise last_error
    raise ValueError("No JSON object found in response")


def edge_pair(edge: Dict[str, Any]) -> Tuple[Optional[str], Optional[str]]:
    comps = edge.get("components")
    if isinstance(comps, list) and len(comps) >= 2:
        return str(comps[0]), str(comps[1])
    a = edge.get("source_component") or edge.get("component_a") or edge.get("from") or edge.get("source")
    b = edge.get("target_components") or edge.get("target_component") or edge.get("component_b") or edge.get("to") or edge.get("target")
    return (str(a) if a else None, str(b) if b else None)


def normalize_prediction(
    pred: Dict[str, Any],
    assembly_id: str,
    expect_edges: bool = True,
    mate_graph: Optional[Dict[str, Any]] = None,
    library_json: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """Normalize model JSON into the final prediction shape.

    Non-mate-graph experiments expect nodes + edges.
    Mate-graph experiments already receive mate_graph.json, so the model only
    predicts component poses. In that case expect_edges=False and any returned
    edge-like content is ignored.
    """
    pred = dict(pred or {})
    raw_nodes = pred.get("nodes") or pred.get("node_parts") or []
    graph_library_by_component = mate_graph_node_map(mate_graph) if not expect_edges else {}
    valid_library_order = library_ids(library_json or {})
    filtered_nodes = [n for n in raw_nodes if isinstance(n, dict) and (n.get("component_id") or n.get("id"))]
    raw_ids = [str(n.get("component_id") or n.get("id")) for n in filtered_nodes]
    expected_ids = [f"c{i:05d}" for i in range(1, len(filtered_nodes) + 1)]
    should_renumber = not graph_library_by_component and raw_ids != expected_ids
    id_map = {
        raw_cid: (expected_ids[i] if should_renumber else raw_cid)
        for i, raw_cid in enumerate(raw_ids)
    }
    nodes: List[Dict[str, Any]] = []
    for idx, n in enumerate(filtered_nodes):
        raw_cid = str(n.get("component_id") or n.get("id"))
        cid = id_map.get(raw_cid, raw_cid)
        pose = n.get("pose") if isinstance(n.get("pose"), dict) else {}
        pos = pose.get("position") if isinstance(pose.get("position"), dict) else (n.get("position") or {})
        ori = pose.get("orientation") if isinstance(pose.get("orientation"), dict) else (n.get("orientation") or {})
        lib_id = str(n.get("library_id") or graph_library_by_component.get(str(raw_cid), ""))
        if not lib_id:
            m = re.search(r"(lib\d+)", raw_cid, flags=re.IGNORECASE)
            if m:
                lib_id = m.group(1)
        if not lib_id and idx < len(valid_library_order):
            lib_id = valid_library_order[idx]
        node_out = {
            "component_id": str(cid),
            "library_id": lib_id,
            "pose": {
                "position": {
                    "x": float(pos.get("x", 0.0)),
                    "y": float(pos.get("y", 0.0)),
                    "z": float(pos.get("z", 0.0)),
                },
                "orientation": {
                    "rx": float(ori.get("rx", 0.0)),
                    "ry": float(ori.get("ry", 0.0)),
                    "rz": float(ori.get("rz", 0.0)),
                },
            },
        }
        nodes.append(node_out)

    out: Dict[str, Any] = {"assembly_id": str(assembly_id), "nodes": nodes}

    if expect_edges:
        edges: List[Dict[str, Any]] = []
        for e in pred.get("edges") or []:
            if not isinstance(e, dict):
                continue
            a, b = edge_pair(e)
            if not a or not b:
                continue
            mt = str(e.get("mate_type") or "").strip()
            if not mt:
                continue
            edges.append({
                "source_component": id_map.get(str(a), str(a)),
                "target_component": id_map.get(str(b), str(b)),
                "mate_type": mt,
            })
        out["edges"] = edges

    return out


def library_ids(library_json: Dict[str, Any]) -> List[str]:
    return [
        str(x.get("library_id") or x.get("component_id"))
        for x in library_json.get("library", [])
        if isinstance(x, dict) and (x.get("library_id") or x.get("component_id"))
    ]


def mate_graph_node_map(mate_graph: Optional[Dict[str, Any]]) -> Dict[str, str]:
    out: Dict[str, str] = {}
    for node in (mate_graph or {}).get("nodes") or []:
        if not isinstance(node, dict):
            continue
        cid = str(node.get("component_id") or "")
        lib_id = str(node.get("library_id") or "")
        if cid and lib_id:
            out[cid] = lib_id
    return out


def minimum_node_count(library_json: Dict[str, Any], mate_graph: Optional[Dict[str, Any]]) -> int:
    graph_nodes = mate_graph_node_map(mate_graph)
    if graph_nodes:
        return len(graph_nodes)
    return len(library_ids(library_json))


def response_modes(provider: str, requested: str) -> List[str]:
    """Return the response_format fallback order for one API attempt.

    json_schema is the normal path for the current Stage-B experiments.
    auto keeps the previous fallback behavior for providers that support
    structured responses. dry-run never calls the API, but returns none for
    completeness.
    """
    if requested != "auto":
        return [requested]
    if provider in {"openai", "openrouter", "azure"}:
        return ["json_schema", "json_object", "none"]
    return ["none"]


def validation_feedback(fatal: List[str], pred: Dict[str, Any], min_nodes: int, expect_edges: bool = True) -> str:
    node_count = len(pred.get("nodes") or [])
    edge_count = len(pred.get("edges") or [])
    if expect_edges:
        edge_instruction = (
            "Infer and output mate edges between adjacent/connected component instances."
        )
    else:
        edge_instruction = (
            "Do not output edges. The input mate_graph.json already defines all component-level mates; "
            "only correct the node poses."
        )
    return (
        "\n\nVALIDATION_FEEDBACK_FOR_RETRY:\n"
        f"The previous JSON was rejected. Fatal errors: {fatal}.\n"
        f"It contained {node_count} node(s) and {edge_count} edge(s). "
        f"Output at least {min_nodes} component nodes so every required component instance is represented. "
        "Do not collapse the whole assembly into one salient component. "
        "Infer repeated uses as separate component instances when the experiment requires open-set reconstruction. "
        f"{edge_instruction}\n"
    )


def validate_prediction(pred: Dict[str, Any], library_json: Dict[str, Any], mate_graph: Optional[Dict[str, Any]], exp_module) -> Tuple[List[str], List[str]]:
    fatal: List[str] = []
    warnings: List[str] = []
    valid_library_ids = set(library_ids(library_json))
    required_graph_nodes = mate_graph_node_map(mate_graph)
    expect_edges = bool(getattr(exp_module, "EXPECT_EDGES", True))
    allowed_mates = set(getattr(exp_module, "MATE_TYPE_DEFINITIONS", {}).keys())

    nodes = pred.get("nodes") if isinstance(pred.get("nodes"), list) else []
    node_ids = [str(n.get("component_id")) for n in nodes if isinstance(n, dict) and n.get("component_id")]
    node_id_set = set(node_ids)

    if len(node_ids) != len(node_id_set):
        fatal.append("duplicate_node_component_ids")

    min_nodes = minimum_node_count(library_json, mate_graph)
    if len(node_id_set) < min_nodes:
        fatal.append(f"too_few_nodes_for_assembly:min={min_nodes}:got={len(node_id_set)}")

    if required_graph_nodes:
        required_ids = list(required_graph_nodes.keys())
        missing_ids = [cid for cid in required_ids if cid not in node_id_set]
        extra_ids = [cid for cid in node_ids if cid not in required_graph_nodes]
        if missing_ids:
            fatal.append(f"missing_required_nodes={missing_ids}")
        if extra_ids:
            fatal.append(f"extra_nodes_beyond_mate_graph={extra_ids}")
    else:
        expected_ids = [f"c{i:05d}" for i in range(1, len(nodes) + 1)]
        if node_ids != expected_ids:
            fatal.append(f"component_ids_not_sequential:expected={expected_ids}:got={node_ids}")

    used_library_ids: List[str] = []
    for n in nodes:
        if not isinstance(n, dict):
            fatal.append("non_object_node")
            continue
        cid = str(n.get("component_id") or "")
        lib_id = str(n.get("library_id") or "")
        if not lib_id:
            fatal.append(f"missing_library_id:{cid}")
        elif lib_id not in valid_library_ids:
            fatal.append(f"library_id_not_allowed:{cid}:{lib_id}")
        else:
            used_library_ids.append(lib_id)
        if required_graph_nodes and cid in required_graph_nodes and lib_id != required_graph_nodes[cid]:
            fatal.append(f"library_id_mismatch:{cid}:expected={required_graph_nodes[cid]}:got={lib_id}")
        pose = n.get("pose") or {}
        pos = pose.get("position") or {}
        ori = pose.get("orientation") or {}
        for k in ("x", "y", "z"):
            if not isinstance(pos.get(k), (int, float)):
                fatal.append(f"bad_position:{cid}:{k}")
        for k in ("rx", "ry", "rz"):
            if not isinstance(ori.get(k), (int, float)):
                fatal.append(f"bad_orientation:{cid}:{k}")

    if not required_graph_nodes:
        missing_libraries = [lib_id for lib_id in library_ids(library_json) if lib_id not in set(used_library_ids)]
        if missing_libraries:
            fatal.append(f"unused_library_ids={missing_libraries}")

    if not expect_edges:
        if "edges" in pred:
            fatal.append("edges_not_allowed_for_mate_graph_experiment")
        return fatal, warnings

    seen = set()
    for e in pred.get("edges") or []:
        if not isinstance(e, dict):
            fatal.append("non_object_edge")
            continue
        a, b = edge_pair(e)
        mt = str(e.get("mate_type") or "")
        if not a or not b:
            fatal.append(f"bad_edge_components={e}")
            continue
        if a == b:
            fatal.append(f"self_edge={a}")
        if node_id_set and (a not in node_id_set or b not in node_id_set):
            fatal.append(f"edge_endpoint_not_allowed={a},{b}")
        if mt not in allowed_mates:
            fatal.append(f"mate_type_not_allowed={mt}")
        key = tuple(sorted([a, b]) + [mt])
        if key in seen:
            warnings.append(f"duplicate_edge={key}")
        seen.add(key)
    return fatal, warnings


def image_paths_from_views(sample_dir: Path, views: Dict[str, str]) -> List[Path]:
    out: List[Path] = []
    for view in VIEW_NAMES:
        p = views.get(view)
        if not p:
            continue
        pp = Path(p)
        if not pp.is_absolute():
            pp = sample_dir / pp
        if pp.exists():
            out.append(pp)
    return out


def build_openrouter_messages(system_prompt: str, prompt: str, image_paths: List[Path]) -> List[Dict[str, Any]]:
    """Build OpenRouter Chat Completions messages in typed-content format.

    This intentionally follows the same message shape as the reference
    OpenRouter script: each message content is a list of typed blocks, e.g.
    {"type": "text", "text": ...} and {"type": "image_url", ...}.
    """
    user_content: List[Dict[str, Any]] = [{"type": "text", "text": prompt}]
    for path in image_paths:
        user_content.append({"type": "text", "text": f"IMAGE: {path.name}"})
        user_content.append({"type": "image_url", "image_url": {"url": image_to_data_url(path)}})

    return [
        {
            "role": "system",
            "content": [{"type": "text", "text": system_prompt}],
        },
        {
            "role": "user",
            "content": user_content,
        },
    ]




def call_gemini_openai_compatible(
    system_prompt: str,
    prompt: str,
    image_paths: List[Path],
    model: str,
    api_key_env: str,
    temperature: float,
    response_mode: str,
    schema_name: str,
    schema: Dict[str, Any],
    max_output_tokens: int = 4096,
    api_timeout_sec: float = 600.0,
) -> str:
    """Call Gemini through Google's OpenAI-compatible Chat Completions endpoint."""
    from openai import OpenAI

    api_key = os.getenv(api_key_env) or os.getenv("GEMINI_API_KEY") or os.getenv("GEMINI_API_KEY2")
    if not api_key:
        raise RuntimeError(f"Missing API key environment variable: {api_key_env} or GEMINI_API_KEY/GEMINI_API_KEY2")

    client_kwargs: Dict[str, Any] = {
        "api_key": api_key,
        "base_url": "https://generativelanguage.googleapis.com/v1beta/openai/",
    }
    if api_timeout_sec and float(api_timeout_sec) > 0:
        client_kwargs["timeout"] = float(api_timeout_sec)
    client = OpenAI(**client_kwargs)
    messages = build_openrouter_messages(system_prompt, prompt, image_paths)
    kwargs: Dict[str, Any] = {"model": model, "messages": messages, "temperature": temperature}
    if max_output_tokens and int(max_output_tokens) > 0:
        kwargs["max_tokens"] = int(max_output_tokens)
    if response_mode == "json_schema":
        kwargs["response_format"] = {
            "type": "json_schema",
            "json_schema": {"name": schema_name, "strict": True, "schema": schema},
        }
    elif response_mode == "json_object":
        kwargs["response_format"] = {"type": "json_object"}
    response = client.chat.completions.create(**kwargs)
    return response.choices[0].message.content or ""

def mode_defaults(experiment_mode: str) -> Tuple[str, bool, bool]:
    """Return (reference_view_style, use_mate_graph, use_reference_assembly_obj)."""
    if experiment_mode in {"exp_baseline", "exp_zs_img"}:
        return "same_color", False, False
    if experiment_mode in {"exp_ref_obj", "exp_zs_ref_obj"}:
        return "same_color", False, True
    if experiment_mode in {"exp_ref_img_color", "exp_zs_ref_img_color"}:
        return "color_by_component", False, False
    if experiment_mode in {"exp_mate_graph", "exp_zs_mate_graph"}:
        return "none", True, False
    if experiment_mode in {"exp_mate_graph_img", "exp_zs_mate_graph_img"}:
        return "color_by_component", True, False
    if experiment_mode in {"exp_mate_graph_ref_obj_img", "exp_zs_mate_graph_ref_obj_img"}:
        return "color_by_component", True, True
    return "same_color", False, False


def build_inputs(args: argparse.Namespace, sample_dir: Path) -> Tuple[Dict[str, Any], Dict[str, str], Optional[Dict[str, Any]], Optional[Dict[str, Any]], str]:
    default_style, default_mg, default_refobj = mode_defaults(args.experiment_mode)
    style = args.reference_view_style or default_style
    use_mate_graph = args.use_mate_graph_json or default_mg
    use_ref_obj = args.use_reference_assembly_obj or default_refobj
    obj_kind = args.obj_kind
    library_json = discover_component_library(sample_dir, obj_kind=obj_kind, raw_obj_mode=args.raw_obj_mode, max_raw_obj_chars=args.max_raw_obj_chars)
    reference_views = {} if style == "none" or args.experiment_mode in {"exp_ref_obj", "exp_zs_ref_obj"} else find_reference_views(sample_dir, style=style)
    reference_obj = find_reference_assembly_obj(sample_dir, obj_kind=obj_kind, raw_obj_mode=args.reference_obj_raw_mode, max_raw_obj_chars=args.max_reference_obj_chars) if use_ref_obj else None
    mate_graph = load_or_build_mate_graph(sample_dir, library_json=library_json) if use_mate_graph else None
    return library_json, reference_views, reference_obj, mate_graph, style



EXPERIMENT_FOLDER_ALIASES = {
    "exp_zs_img": "exp_baseline",
    "exp_zs_ref_obj": "exp_ref_obj",
    "exp_zs_ref_img_color": "exp_ref_img_color",
    "exp_zs_mate_graph": "exp_mate_graph",
    "exp_zs_mate_graph_img": "exp_mate_graph_img",
    "exp_zs_mate_graph_ref_obj_img": "exp_mate_graph_ref_obj_img",
}


def clean_sample_label(sample: Path) -> str:
    name = sample.name
    for suffix in ["_mesh_only", "_v42", "_prepared", "_normalized"]:
        if name.endswith(suffix):
            name = name[: -len(suffix)]
    return name


def experiment_folder_name(sample: Path, experiment_mode: str) -> str:
    return f"{clean_sample_label(sample)}__{EXPERIMENT_FOLDER_ALIASES.get(experiment_mode, experiment_mode)}"


def experiment_dirs(out_dir: Path) -> Tuple[Path, Path, Path]:
    input_dir = out_dir
    output_dir = out_dir
    debug_dir = out_dir / "debug"
    out_dir.mkdir(parents=True, exist_ok=True)
    return input_dir, output_dir, debug_dir


def copy_input_obj_files(sample_dir: Path, input_dir: Path, library_json: Dict[str, Any], reference_obj: Optional[Dict[str, Any]]) -> None:
    comp_dir = input_dir / "component_library"
    comp_dir.mkdir(parents=True, exist_ok=True)
    for item in library_json.get("library", []) or []:
        if not isinstance(item, dict):
            continue
        rel = item.get("obj_file")
        if not rel:
            continue
        src = Path(str(rel))
        if not src.is_absolute():
            src = sample_dir / src
        if src.exists() and src.is_file():
            shutil.copy2(src, comp_dir / src.name)
    if reference_obj and reference_obj.get("obj_file"):
        src = Path(str(reference_obj.get("obj_file")))
        if not src.is_absolute():
            src = sample_dir / src
        if src.exists() and src.is_file():
            shutil.copy2(src, input_dir / "assembly.mesh.obj")

def copy_input_reference_views(input_dir: Path, image_paths: List[Path], style: str) -> None:
    if not image_paths:
        return
    view_dir = input_dir / "reference_views" / style
    view_dir.mkdir(parents=True, exist_ok=True)
    for src in image_paths:
        if src.exists() and src.is_file():
            shutil.copy2(src, view_dir / src.name)

def write_clean_inputs(sample_dir: Path, input_dir: Path, prompt: str, library_json: Dict[str, Any], reference_views: Dict[str, str], reference_view_style: str, reference_obj: Optional[Dict[str, Any]], mate_graph: Optional[Dict[str, Any]], image_paths: List[Path], save_debug: bool) -> None:
    copy_input_obj_files(sample_dir, input_dir, library_json, reference_obj)
    copy_input_reference_views(input_dir, image_paths, reference_view_style)
    if reference_views:
        write_json(input_dir / "reference_views.json", reference_views)
    if mate_graph is not None:
        write_json(input_dir / "mate_graph.json", mate_graph)


def maybe_visualize_outputs(
    sample_dir: Path,
    prediction_json: Path,
    output_dir: Path,
    obj_kind: str,
    enabled: bool,
    generate_mate_graph_html: bool = True,
) -> None:
    if not enabled or not prediction_json.exists():
        return
    try:
        from cad_assembly_visualize_prediction import visualize
        visualize(sample_dir, prediction_json, output_dir / "assembly_interactive", obj_kind=obj_kind)
    except Exception as exc:
        write_text(output_dir / "assembly_interactive_error.txt", repr(exc))
    if not generate_mate_graph_html:
        for stale_name in ("mate_graph.html", "mate_graph_error.txt"):
            stale_path = output_dir / stale_name
            if stale_path.exists():
                stale_path.unlink()
        return
    try:
        from cad_assembly_visualize_graph import graph_html
        pred = read_json(prediction_json)
        html = graph_html(pred, sample_dir=sample_dir, obj_kind=obj_kind)
        write_text(output_dir / "mate_graph.html", html)
    except Exception as exc:
        write_text(output_dir / "mate_graph_error.txt", repr(exc))


def finalize_sample_status(status: Dict[str, Any], start_ts: float) -> Dict[str, Any]:
    end_ts = time.time()
    status = dict(status)
    status["end_time"] = time.strftime("%Y-%m-%d %H:%M:%S")
    status["runtime_sec"] = round(end_ts - start_ts, 3)
    status["sample_runtime_sec"] = status["runtime_sec"]
    status.setdefault("elapsed_sec", status["runtime_sec"])
    return status


def build_log_payload(statuses: List[Dict[str, Any]], start_time: Optional[str] = None, start_ts: Optional[float] = None, experiment_mode: Optional[str] = None) -> Dict[str, Any]:
    end_ts = time.time()
    success = sum(1 for s in statuses if str(s.get("status", "")).startswith("ok"))
    skipped_resume = sum(1 for s in statuses if s.get("status") == "skipped_resume")
    skipped_context_limit = sum(1 for s in statuses if s.get("status") == "skipped_context_limit")
    success_or_skipped = success + skipped_resume + skipped_context_limit
    run_times = [{
        "sample": Path(str(s.get("sample_dir") or "")).name,
        "sample_dir": s.get("sample_dir"),
        "experiment_dir": s.get("experiment_dir"),
        "runtime_sec": s.get("runtime_sec"),
        "status": s.get("status"),
    } for s in statuses]
    return {
        "experiment_mode": experiment_mode or (statuses[0].get("experiment_mode") if statuses else None),
        "start_time": start_time or (statuses[0].get("start_time") if statuses else time.strftime("%Y-%m-%d %H:%M:%S")),
        "end_time": time.strftime("%Y-%m-%d %H:%M:%S"),
        "total_success": success,
        "total_skipped_resume": skipped_resume,
        "total_skipped_context_limit": skipped_context_limit,
        "total_success_or_skipped": success_or_skipped,
        "total_fail": len(statuses) - success_or_skipped,
        "total_run": len(statuses),
        "total_runtime_sec": round(end_ts - start_ts, 3) if start_ts is not None else None,
        "run_time_of_each_sample": run_times,
        "samples": statuses,
    }


def write_experiment_log(experiment_dir: Path, status: Dict[str, Any], start_time: str, start_ts: float) -> None:
    write_json(experiment_dir / "log.json", build_log_payload([status], start_time=start_time, start_ts=start_ts, experiment_mode=str(status.get("experiment_mode") or "")))


def finalize_and_write_sample_status(status: Dict[str, Any], start_ts: float, experiment_dir: Path, start_time: str) -> Dict[str, Any]:
    finalized = finalize_sample_status(status, start_ts)
    write_experiment_log(experiment_dir, finalized, start_time=start_time, start_ts=start_ts)
    return finalized



def resolve_assembly_id(
    args: argparse.Namespace,
    sample_dir: Path,
    library_json: Dict[str, Any],
    mate_graph: Optional[Dict[str, Any]],
) -> str:
    """Resolve the canonical assembly_id for one prepared sample.

    Priority:
      1. explicit --assembly-id
      2. mate_graph.json assembly_id, because mate-graph experiments use it as the
         component-instance contract
      3. assembly_graph_gt.json assembly_id
      4. library_json assembly_id
      5. sample directory name
    
    The resolved id is attached to the normalized prediction after model output.
    """
    if getattr(args, "assembly_id", None):
        return str(args.assembly_id)

    if isinstance(mate_graph, dict) and mate_graph.get("assembly_id"):
        return str(mate_graph["assembly_id"])

    try:
        gt = load_exported_gt(sample_dir)
        if isinstance(gt, dict) and gt.get("assembly_id"):
            return str(gt["assembly_id"])
    except Exception:
        pass

    if isinstance(library_json, dict) and library_json.get("assembly_id"):
        return str(library_json["assembly_id"])

    return sample_dir.name

def run_one_sample(args: argparse.Namespace, sample_dir: Path, out_dir: Path, exp_module) -> Dict[str, Any]:
    sample_start_ts = time.time()
    sample_start_time = time.strftime("%Y-%m-%d %H:%M:%S")
    sample_dir = sample_dir.resolve()
    input_dir, output_dir, debug_dir = experiment_dirs(out_dir)
    library_json, reference_views, reference_obj, mate_graph, style = build_inputs(args, sample_dir)
    assembly_id = resolve_assembly_id(args, sample_dir, library_json, mate_graph)

    # assembly_id is not requested from the model. It is attached to the
    # normalized prediction after the model returns nodes/edges.

    expect_edges = bool(getattr(exp_module, "EXPECT_EDGES", True))
    system_prompt = exp_module.build_system_prompt()
    prompt = exp_module.build_prompt(
        assembly_id=assembly_id,
        library_json=library_json,
        reference_views=reference_views,
        reference_view_style=style,
        reference_assembly_obj=reference_obj,
        mate_graph_json=mate_graph,
        allowed_mate_types=list(exp_module.MATE_TYPE_DEFINITIONS.keys()),
        node_policy=args.node_policy,
    )
    image_paths = image_paths_from_views(sample_dir, reference_views)
    write_clean_inputs(sample_dir, input_dir, prompt, library_json, reference_views, style, reference_obj, mate_graph, image_paths, args.save_debug)

    missing: List[str] = []
    if not library_json.get("library"):
        missing.append("empty_component_library")
    uses_reference_views = bool(reference_views)
    if not args.allow_missing_views and uses_reference_views:
        for view_name, view_path in sorted(reference_views.items()):
            pp = Path(view_path)
            if not pp.is_absolute():
                pp = sample_dir / pp
            if not pp.exists():
                missing.append(f"missing_reference_view_file:{view_name}")
    if (args.use_reference_assembly_obj or mode_defaults(args.experiment_mode)[2]) and reference_obj is None:
        missing.append("missing_reference_assembly_obj")
    if (args.use_mate_graph_json or mode_defaults(args.experiment_mode)[1]) and mate_graph is None:
        missing.append("missing_mate_graph_json")

    summary_base = {
        "assembly_id": assembly_id,
        "sample_dir": sample_dir.as_posix(),
        "experiment_dir": out_dir.as_posix(),
        "experiment_mode": args.experiment_mode,
        "obj_kind": args.obj_kind,
        "reference_view_style": style,
        "library_count": len(library_json.get("library", [])),
        "component_instance_count": None,
        "reference_view_count": len(reference_views),
        "has_reference_assembly_obj": reference_obj is not None,
        "has_mate_graph": mate_graph is not None,
        "raw_obj_mode": args.raw_obj_mode,
        "reference_obj_raw_mode": args.reference_obj_raw_mode,
        "max_full_prompt_chars": int(getattr(args, "max_full_prompt_chars", 0) or 0),
        "provider": args.provider,
        "model": args.model,
        "start_time": sample_start_time,
    }

    if missing and not args.ignore_preflight:
        return finalize_and_write_sample_status({**summary_base, "status": "preflight_failed", "missing": missing}, sample_start_ts, out_dir, sample_start_time)

    if args.provider == "dry-run":
        return finalize_and_write_sample_status({**summary_base, "status": "dry_run", "missing": missing}, sample_start_ts, out_dir, sample_start_time)

    prompt_chars = len(system_prompt) + len(prompt)
    max_full_prompt_chars = int(getattr(args, "max_full_prompt_chars", 0) or 0)
    uses_full_obj = args.raw_obj_mode == "full" or args.reference_obj_raw_mode == "full"
    if uses_full_obj and max_full_prompt_chars > 0 and prompt_chars > max_full_prompt_chars:
        status = {
            **summary_base,
            "status": "skipped_context_limit",
            "elapsed_sec": round(time.time() - sample_start_ts, 3),
            "fatal_errors": ["prompt_chars_exceeded_local_limit"],
            "warnings": [],
            "prompt_chars": prompt_chars,
            "max_full_prompt_chars": max_full_prompt_chars,
            "last_error": f"local_prompt_size_skip:prompt_chars={prompt_chars}:limit={max_full_prompt_chars}",
        }
        return finalize_and_write_sample_status(status, sample_start_ts, out_dir, sample_start_time)

    attempts: List[Dict[str, Any]] = []
    best_pred: Optional[Dict[str, Any]] = None
    best_fatal: List[str] = ["not_run"]
    best_warnings: List[str] = []
    last_error: Optional[str] = None
    t0_total = time.time()
    current_prompt = prompt
    for attempt in range(1, max(1, args.max_retries) + 1):
        for rm in response_modes(args.provider, args.response_mode):
            meta: Dict[str, Any] = {"attempt": attempt, "response_mode": rm, "started_at": time.strftime("%Y-%m-%d %H:%M:%S")}
            t0 = time.time()
            try:
                raw = exp_module.call_provider(args, system_prompt, current_prompt, image_paths, rm)
                pred_raw = extract_json_from_text(raw)
                pred = normalize_prediction(
                    pred_raw,
                    assembly_id,
                    expect_edges=expect_edges,
                    mate_graph=mate_graph,
                    library_json=library_json,
                )
                fatal, warnings = validate_prediction(pred, library_json, mate_graph, exp_module)
                meta.update({"status": "valid" if not fatal else "invalid", "fatal_errors": fatal, "warnings": warnings, "elapsed_sec": round(time.time() - t0, 3)})
                attempts.append(meta)
                if args.save_debug:
                    adir = debug_dir / "attempts" / f"attempt_{attempt:02d}_{rm}"
                    adir.mkdir(parents=True, exist_ok=True)
                    write_text(adir / "debug_raw_response.txt", raw)
                    write_json(adir / "assembly_prediction_raw.json", pred_raw)
                    write_json(adir / "assembly_prediction.json", pred)
                    write_json(adir / "validation.json", {"fatal_errors": fatal, "warnings": warnings})
                    write_json(adir / "attempt_status.json", meta)
                if best_pred is None or len(fatal) < len(best_fatal):
                    best_pred, best_fatal, best_warnings = pred, fatal, warnings
                if not fatal:
                    pred_path = output_dir / "assembly_prediction.json"
                    write_json(pred_path, pred)
                    status = {**summary_base, "status": "ok" if not warnings else "ok_with_warnings", "response_mode": rm, "elapsed_sec": round(time.time() - t0_total, 3), "node_count": len(pred.get("nodes", [])), "edge_count": len(pred.get("edges", [])), "warnings": warnings}
                    if args.save_debug:
                        status["attempts"] = attempts
                    maybe_visualize_outputs(
                        sample_dir,
                        pred_path,
                        output_dir,
                        args.obj_kind,
                        not args.no_auto_visualize,
                        generate_mate_graph_html=mate_graph is None,
                    )
                    return finalize_and_write_sample_status(status, sample_start_ts, out_dir, sample_start_time)
                last_error = "; ".join(fatal)
                current_prompt = prompt + validation_feedback(
                    fatal,
                    pred,
                    minimum_node_count(library_json, mate_graph),
                    expect_edges=expect_edges,
                )
            except Exception as exc:
                last_error = repr(exc)
                meta.update({"status": "error", "error": repr(exc), "elapsed_sec": round(time.time() - t0, 3)})
                attempts.append(meta)
                if args.save_debug:
                    adir = debug_dir / "attempts" / f"attempt_{attempt:02d}_{rm}"
                    adir.mkdir(parents=True, exist_ok=True)
                    write_json(adir / "attempt_status.json", meta)
                print(f"[WARN] {sample_dir.name} attempt={attempt} mode={rm}: {exc}", file=sys.stderr)
                if is_context_limit_error(last_error):
                    status = {
                        **summary_base,
                        "status": "skipped_context_limit",
                        "elapsed_sec": round(time.time() - t0_total, 3),
                        "fatal_errors": ["context_length_exceeded"],
                        "warnings": [],
                        "last_error": last_error,
                        "attempts": attempts,
                    }
                    return finalize_and_write_sample_status(status, sample_start_ts, out_dir, sample_start_time)
            if args.retry_sleep_sec > 0:
                time.sleep(args.retry_sleep_sec)

    if best_pred is not None:
        write_json(output_dir / "assembly_prediction_best_effort.json", best_pred)
        if args.save_debug:
            write_json(debug_dir / "best_effort_validation.json", {"fatal_errors": best_fatal, "warnings": best_warnings})
    status = {**summary_base, "status": "failed_validation" if best_pred else "error", "elapsed_sec": round(time.time() - t0_total, 3), "fatal_errors": best_fatal, "warnings": best_warnings, "last_error": last_error}
    if args.save_debug:
        status["attempts"] = attempts
    return finalize_and_write_sample_status(status, sample_start_ts, out_dir, sample_start_time)


def status_merge_key(status: Dict[str, Any]) -> str:
    sample_dir = status.get("sample_dir")
    if sample_dir:
        return str(sample_dir)
    experiment_dir = status.get("experiment_dir")
    if experiment_dir:
        return str(experiment_dir)
    return json.dumps(status, ensure_ascii=False, sort_keys=True)


def read_existing_sample_statuses(out_root: Path) -> List[Dict[str, Any]]:
    statuses: List[Dict[str, Any]] = []
    if not out_root.exists():
        return statuses
    for sample_log in sorted(out_root.glob("*/log.json")):
        try:
            old_log = read_json(sample_log)
            old_samples = old_log.get("samples") or []
            if old_samples and isinstance(old_samples[0], dict):
                statuses.append(old_samples[0])
        except Exception:
            continue
    return statuses


def merge_statuses(existing: List[Dict[str, Any]], updates: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    merged: Dict[str, Dict[str, Any]] = {}
    for status in existing:
        if isinstance(status, dict):
            merged[status_merge_key(status)] = status
    for status in updates:
        if isinstance(status, dict):
            merged[status_merge_key(status)] = status
    return list(merged.values())


def write_batch_summary(out_root: Path, statuses: List[Dict[str, Any]], save_debug: bool = False, start_time: Optional[str] = None, start_ts: Optional[float] = None, experiment_mode: Optional[str] = None) -> None:
    all_statuses = merge_statuses(read_existing_sample_statuses(out_root), statuses)
    write_json(out_root / "log.json", build_log_payload(all_statuses, start_time=start_time, start_ts=start_ts, experiment_mode=experiment_mode))


def apply_sample_list_filter(samples: List[Path], sample_list_path: Optional[Path]) -> List[Path]:
    if not sample_list_path:
        return samples
    wanted_raw = [
        line.strip().strip('"')
        for line in sample_list_path.read_text(encoding="utf-8").splitlines()
        if line.strip() and not line.lstrip().startswith("#")
    ]
    wanted_names = {Path(item).name for item in wanted_raw}
    wanted_paths = {Path(item).resolve().as_posix().lower() for item in wanted_raw if any(sep in item for sep in ("\\", "/"))}
    filtered: List[Path] = []
    for sample in samples:
        if sample.name in wanted_names or sample.resolve().as_posix().lower() in wanted_paths:
            filtered.append(sample)
    return filtered


def main_for_experiment(exp_module) -> None:
    p = argparse.ArgumentParser(description=f"Run CAD assembly one-shot experiment: {exp_module.EXPERIMENT_MODE}")
    p.add_argument("input", type=Path, help="Normalized sample folder or dataset root")
    p.add_argument("--out", "--output-folder", dest="out", type=Path, default=Path("cad_assembly_baseline_runs"), help="Output folder for single-experiment runs.")
    p.add_argument("--obj-kind", choices=["mesh", "brep", "auto"], default="mesh", help="Use c000xx.mesh.obj, c000xx.brep.obj, or smallest available per component")
    p.add_argument("--reference-view-style", choices=["same_color", "color_by_component", "none"], default=None)
    p.add_argument("--use-reference-assembly-obj", action="store_true")
    p.add_argument("--use-mate-graph-json", action="store_true")
    p.add_argument("--node-policy", choices=["predict_subset", "all_library"], default="predict_subset")
    p.add_argument("--raw-obj-mode", choices=["none", "truncated", "full"], default="full", help="Whether to include component OBJ source text inside the runtime prompt. Default is full; use --max-full-prompt-chars to pre-skip oversized samples.")
    p.add_argument("--max-raw-obj-chars", type=int, default=20000)
    p.add_argument("--reference-obj-raw-mode", choices=["none", "truncated", "full"], default="full")
    p.add_argument("--max-reference-obj-chars", type=int, default=40000)
    p.add_argument("--provider", choices=["openai", "openrouter", "azure", "gemini", "dry-run"], default="dry-run")
    p.add_argument("--model", default="openai/gpt-4.1")
    p.add_argument("--api-key-env", default="OPENAI_API_KEY")
    p.add_argument("--azure-endpoint", default=None)
    p.add_argument("--azure-endpoint-env", default="AZURE_OPENAI_ENDPOINT")
    p.add_argument("--azure-api-version", default=None)
    p.add_argument("--temperature", type=float, default=0.0)
    p.add_argument("--max-output-tokens", type=int, default=4096, help="Maximum completion tokens requested from OpenAI-compatible chat APIs. Use 0 to omit.")
    p.add_argument("--api-timeout-sec", type=float, default=600.0, help="Per API request timeout in seconds. Use 0 to disable the client timeout.")
    p.add_argument("--max-full-prompt-chars", type=int, default=0, help="When full OBJ inputs make the prompt exceed this character count, skip the sample as skipped_context_limit before calling the API. 0 disables.")
    p.add_argument("--max-retries", type=int, default=3)
    p.add_argument("--retry-sleep-sec", type=float, default=2.0)
    p.add_argument("--response-mode", choices=["auto", "json_schema", "json_object", "none"], default="json_schema")
    p.add_argument("--openrouter-response-healing", action="store_true")
    p.add_argument("--assembly-id", default=None)
    p.add_argument("--recursive", action="store_true")
    p.add_argument("--sample-list", type=Path, default=None, help="Optional text file containing sample folder names or paths to run.")
    p.add_argument("--resume", action="store_true")
    p.add_argument("--max-samples", type=int, default=0)
    p.add_argument("--allow-missing-views", action="store_true")
    p.add_argument("--ignore-preflight", action="store_true")
    p.add_argument("--save-debug", action="store_true", help="Save attempts, raw intermediate JSONs, and image path debug files.")
    p.add_argument("--no-auto-visualize", action="store_true", help="Do not generate assembly_interactive, or mate_graph.html for experiments that do not input mate_graph.json.")
    p.add_argument("--num-workers", "--workers", dest="num_workers", type=int, default=1, help="Number of sample-level worker threads for this experiment. Default: 1.")
    args = p.parse_args()
    args.experiment_mode = exp_module.EXPERIMENT_MODE

    if args.provider == "openrouter" and args.api_key_env == "OPENAI_API_KEY":
        args.api_key_env = "OPENROUTER_API_KEY"
    if args.provider == "azure" and args.api_key_env == "OPENAI_API_KEY":
        args.api_key_env = "AZURE_OPENAI_API_KEY"

    samples = discover_dataset_samples(args.input, recursive=args.recursive)
    samples = apply_sample_list_filter(samples, args.sample_list)
    if args.max_samples > 0:
        samples = samples[:args.max_samples]
    if not samples:
        raise SystemExit(f"No samples found under {args.input}")
    args.out.mkdir(parents=True, exist_ok=True)
    workers = max(1, int(args.num_workers or 1))
    print(f"[OUTPUT_FOLDER] {args.out}")
    print(f"[WORKERS] {workers}")
    batch_start_ts = time.time()
    batch_start_time = time.strftime("%Y-%m-%d %H:%M:%S")
    statuses: List[Dict[str, Any]] = []

    def process_sample(sample: Path) -> Dict[str, Any]:
        out_dir = args.out / experiment_folder_name(sample, args.experiment_mode)
        pred_path = out_dir / "assembly_prediction.json"
        if args.resume and pred_path.exists():
            resume_start_ts = time.time()
            resume_start_time = time.strftime("%Y-%m-%d %H:%M:%S")
            status = finalize_sample_status({
                "sample_dir": sample.as_posix(),
                "experiment_dir": out_dir.as_posix(),
                "experiment_mode": args.experiment_mode,
                "status": "skipped_resume",
                "start_time": resume_start_time,
            }, resume_start_ts)
            write_experiment_log(out_dir, status, start_time=resume_start_time, start_ts=resume_start_ts)
            return status
        sample_log = out_dir / "log.json"
        if args.resume and sample_log.exists():
            try:
                old_log = read_json(sample_log)
                old_samples = old_log.get("samples") or []
                old_status = old_samples[0] if old_samples and isinstance(old_samples[0], dict) else {}
                same_prompt_policy = (
                    old_status.get("raw_obj_mode") == args.raw_obj_mode
                    and old_status.get("reference_obj_raw_mode") == args.reference_obj_raw_mode
                    and int(old_status.get("max_full_prompt_chars") or 0) == int(args.max_full_prompt_chars or 0)
                )
                if old_status.get("status") == "skipped_context_limit" and same_prompt_policy:
                    return old_status
            except Exception:
                pass
        if out_dir.exists():
            shutil.rmtree(out_dir)
        print(f"[RUN] {sample} -> {out_dir}")
        try:
            return run_one_sample(args, sample, out_dir, exp_module)
        except Exception as exc:
            error_start_ts = time.time()
            error_start_time = time.strftime("%Y-%m-%d %H:%M:%S")
            err = finalize_sample_status({
                "sample_dir": sample.as_posix(),
                "experiment_dir": out_dir.as_posix(),
                "experiment_mode": args.experiment_mode,
                "status": "error",
                "error": repr(exc),
                "start_time": error_start_time,
            }, error_start_ts)
            (out_dir / "output").mkdir(parents=True, exist_ok=True)
            write_experiment_log(out_dir, err, start_time=error_start_time, start_ts=error_start_ts)
            print(f"[ERROR] {sample}: {exc}", file=sys.stderr)
            return err

    if workers == 1:
        for sample in samples:
            status = process_sample(sample)
            statuses.append(status)
            write_batch_summary(args.out, statuses, save_debug=args.save_debug, start_time=batch_start_time, start_ts=batch_start_ts, experiment_mode=args.experiment_mode)
    else:
        with ThreadPoolExecutor(max_workers=workers) as executor:
            future_map = {executor.submit(process_sample, sample): sample for sample in samples}
            for fut in as_completed(future_map):
                status = fut.result()
                statuses.append(status)
                write_batch_summary(args.out, statuses, save_debug=args.save_debug, start_time=batch_start_time, start_ts=batch_start_ts, experiment_mode=args.experiment_mode)

    ok = sum(1 for s in statuses if str(s.get("status", "")).startswith("ok"))
    write_batch_summary(args.out, statuses, save_debug=args.save_debug, start_time=batch_start_time, start_ts=batch_start_ts, experiment_mode=args.experiment_mode)
    print(f"Done. ok={ok}/{len(statuses)} out={args.out}")
    if any(s.get("status") == "error" for s in statuses):
        raise SystemExit(1)


