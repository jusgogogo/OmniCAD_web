#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Preflight checker for normalized CAD assembly one-shot experiment samples."""
from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any, Dict, List

from cad_assembly_dataset import (
    VIEW_NAMES,
    discover_component_library,
    discover_dataset_samples,
    find_reference_views,
    find_reference_assembly_obj,
    load_or_build_mate_graph,
)


def write_json(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


def check_sample(sample_dir: Path, experiment_mode: str, obj_kind: str = "auto", reference_view_style: str = "same_color") -> Dict[str, Any]:
    lib = discover_component_library(sample_dir, obj_kind=obj_kind, raw_obj_mode="none")
    views = find_reference_views(sample_dir, style=reference_view_style)
    ref_obj_modes = {"exp_ref_obj", "exp_zs_ref_obj", "exp_zs_mate_graph_ref_obj_img"}
    view_modes = {"exp_baseline", "exp_ref_img_color", "exp_mate_graph_img", "exp_mate_graph_ref_obj_img", "exp_zs_img", "exp_zs_ref_img_color", "exp_zs_mate_graph_img", "exp_zs_mate_graph_ref_obj_img"}
    mate_graph_modes = {"exp_mate_graph", "exp_mate_graph_img", "exp_zs_mate_graph", "exp_zs_mate_graph_img", "exp_zs_mate_graph_ref_obj_img"}
    ref_obj = find_reference_assembly_obj(sample_dir, obj_kind=obj_kind) if experiment_mode in ref_obj_modes else None
    mate_graph = load_or_build_mate_graph(sample_dir, library_json=lib) if experiment_mode in mate_graph_modes else None
    missing: List[str] = []
    if not lib.get("library"):
        missing.append("empty_component_library")
    for item in lib.get("library", []):
        p = sample_dir / item.get("obj_file", "")
        if not p.exists():
            missing.append(f"missing_obj:{item.get('library_id') or item.get('component_id')}:{item.get('obj_file')}")
    if experiment_mode in view_modes:
        for v in VIEW_NAMES:
            if v not in views:
                missing.append(f"missing_reference_view:{v}")
    if experiment_mode in ref_obj_modes and ref_obj is None:
        missing.append("missing_reference_assembly_obj")
    if experiment_mode in mate_graph_modes and mate_graph is None:
        missing.append("missing_mate_graph_json")
    return {
        "sample": sample_dir.as_posix(),
        "experiment_mode": experiment_mode,
        "obj_kind": obj_kind,
        "reference_view_style": reference_view_style,
        "library_count": len(lib.get("library", [])),
        "reference_views_found": sorted(views.keys()),
        "has_reference_assembly_obj": ref_obj is not None,
        "has_mate_graph": mate_graph is not None,
        "missing": missing,
        "ok": not missing,
    }


def main() -> None:
    ap = argparse.ArgumentParser(description="Check CAD assembly experiment sample readiness.")
    ap.add_argument("input", type=Path)
    ap.add_argument("--out", type=Path, required=True)
    ap.add_argument("--experiment-mode", default="exp_baseline", choices=["exp_baseline", "exp_ref_obj", "exp_ref_img_color", "exp_mate_graph", "exp_mate_graph_img", "exp_zs_img", "exp_zs_ref_obj", "exp_zs_ref_img_color", "exp_zs_mate_graph", "exp_zs_mate_graph_img", "exp_zs_mate_graph_ref_obj_img"])
    ap.add_argument("--obj-kind", choices=["mesh", "brep", "auto"], default="mesh")
    ap.add_argument("--reference-view-style", choices=["same_color", "color_by_component"], default="same_color")
    ap.add_argument("--recursive", action="store_true")
    args = ap.parse_args()
    samples = discover_dataset_samples(args.input, recursive=args.recursive)
    statuses = [check_sample(s, args.experiment_mode, args.obj_kind, args.reference_view_style) for s in samples]
    write_json(args.out / "preflight_status.json", statuses)
    print(json.dumps(statuses, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
