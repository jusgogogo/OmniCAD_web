﻿#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Experiment 5: component library + mate graph + reference OBJ + color-by-component reference images."""
from __future__ import annotations

import json
import os
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional

from cad_assembly_stage2_common import build_openrouter_messages, call_gemini_openai_compatible, main_for_experiment

EXPERIMENT_MODE = "exp_zs_mate_graph_ref_obj_img"
EXPECT_EDGES = False

PROMPT_SPEC = {
    "name": EXPERIMENT_MODE,
    "inputs": ['component_library', 'mate_graph.json', 'assembly.mesh.obj', 'reference_views/color_by_component'],
    "task": 'Experiment 5: component library + mate graph + reference OBJ + color-by-component reference images.',
}


# ============================================================
# Mate Types锛坘ept local in this experiment file锛?
# ============================================================

MATE_TYPE_DEFINITIONS: Dict[str, str] = {
    "MateCoincident": "Selected points, lines, planes, or faces on two components are constrained to be coincident or flush, depending on entity type and alignment.",
    "MateConcentric": "Selected cylindrical, circular, or axial entities on two components are constrained to share a common axis.",
    "MateDistanceDim": "Selected entities on two components are constrained to maintain a specified distance.",
    "MateAngleDim": "Selected entities on two components are constrained to maintain a specified angle.",
    "MateParallel": "Selected planar faces, linear edges, or axes on two components are constrained to remain parallel.",
    "MatePerpendicular": "Selected planar faces, linear edges, or axes on two components are constrained to remain perpendicular.",
    "MateTangent": "Selected curved or planar entities on two components are constrained to remain tangent.",
    "MateLock": "The relative position and orientation between two components are fixed.",
    "MateSymmetric": "Selected entities are constrained to remain symmetric about a specified plane or planar face.",
    "MateWidth": "A tab or component is constrained relative to two opposing width faces, often centered between them.",
    "MatePath": "A selected point, vertex, or feature on one component is constrained to follow a specified path.",
    "MateLinearCoupler": "The linear motions of two components are coupled according to a specified translation ratio.",
    "MateCamFollower": "A follower component is constrained to maintain contact with or follow a cam profile.",
    "MateGearDim": "The rotational motions of two components are coupled according to a specified gear ratio.",
    "MateRackPinionDim": "The rotation of one component and the linear translation of another are coupled according to a rack-and-pinion relationship.",
    "MateScrewDim": "Relative rotation and translation between two components are coupled according to a specified screw pitch.",
    "MateHinge": "Two components are constrained to rotate relative to each other about a shared hinge axis.",
    "MateSlot": "A point, axis, or cylindrical feature is constrained to move within a slot.",
    "MateLimitDistanceDim": "The distance between selected entities is constrained within specified minimum and maximum limits.",
    "MateLimitAngleDim": "The angle between selected entities is constrained within specified minimum and maximum limits.",
    "MateUniversalJoint": "Two rotational axes are coupled through a universal-joint relationship."
}


# ============================================================
# JSON Schema锛坘ept local in this experiment file锛?
# ============================================================

ASSEMBLY_PREDICTION_SCHEMA: Dict[str, Any] = {
    "type": "object",
    "properties": {
        "nodes": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "component_id": {"type": "string"},
                    "pose": {
                        "type": "object",
                        "properties": {
                            "position": {
                                "type": "object",
                                "properties": {
                                    "x": {"type": "number"},
                                    "y": {"type": "number"},
                                    "z": {"type": "number"},
                                },
                                "required": ["x", "y", "z"],
                                "additionalProperties": False,
                            },
                            "orientation": {
                                "type": "object",
                                "properties": {
                                    "rx": {"type": "number"},
                                    "ry": {"type": "number"},
                                    "rz": {"type": "number"},
                                },
                                "required": ["rx", "ry", "rz"],
                                "additionalProperties": False,
                            },
                        },
                        "required": ["position", "orientation"],
                        "additionalProperties": False,
                    },
                },
                "required": ["component_id", "pose"],
                "additionalProperties": False,
            },
        },
    },
    "required": ["nodes"],
    "additionalProperties": False,
}


# ============================================================
# Response Format锛圤penRouter JSON schema锛?
# ============================================================

response_format = {
    "type": "json_schema",
    "json_schema": {
        "name": f"{EXPERIMENT_MODE}_assembly_prediction_schema",
        "strict": True,
        "schema": ASSEMBLY_PREDICTION_SCHEMA,
    },
}



# ============================================================
# Local JSON / OBJ helpers
# ============================================================

def _json_block(obj: Any) -> str:
    return json.dumps(obj, ensure_ascii=False, indent=2)


def output_schema_example() -> Dict[str, Any]:
    return {
        "nodes": [
            {
                "component_id": "c00001",
                "pose": {
                    "position": {"x": 0.0, "y": 0.0, "z": 0.0},
                    "orientation": {"rx": 0.0, "ry": 0.0, "rz": 0.0},
                },
            },
            {
                "component_id": "c00002",
                "pose": {
                    "position": {"x": 10.0, "y": 0.0, "z": 0.0},
                    "orientation": {"rx": 0.0, "ry": 0.0, "rz": 0.0},
                },
            },
        ],
    }


def obj_file_sections(library_json: Dict[str, Any]) -> str:
    sections: List[str] = []
    for item in library_json.get("library", []) or []:
        if not isinstance(item, dict):
            continue
        lib_id = str(item.get("library_id") or item.get("component_id") or "")
        obj_file = str(item.get("obj_file") or f"{lib_id}.mesh.obj")
        obj_name = obj_file.replace("\\\\", "/").split("/")[-1]
        raw = item.get("raw_obj_text")
        header = f"OBJ_FILE: {obj_name}\nLIBRARY_ID: {lib_id}"
        if raw is None:
            sections.append(header + "\nOBJ_CONTENT: <not provided>")
        else:
            sections.append(header + "\nOBJ_CONTENT:\n```obj\n" + str(raw) + "\n```")
    return "\n\n".join(sections)


def reference_obj_section(reference_assembly_obj: Optional[Dict[str, Any]]) -> str:
    if reference_assembly_obj is None:
        return "No reference assembly OBJ is provided."
    obj_file = str(reference_assembly_obj.get("obj_file") or "assembly.mesh.obj")
    obj_name = obj_file.replace("\\\\", "/").split("/")[-1]
    raw = reference_assembly_obj.get("raw_obj_text")
    header = f"REFERENCE_ASSEMBLY_OBJ_FILE: {obj_name}"
    if raw is None:
        return header + "\nOBJ_CONTENT: <not provided>"
    return header + f"\nOBJ_CONTENT:\n```obj\n{raw}\n```"




def prompt_mate_graph(mate_graph_json: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    data = dict(mate_graph_json or {})
    data.pop("assembly_id", None)
    return data


def used_mate_type_definitions(mate_graph_json: Optional[Dict[str, Any]]) -> Dict[str, str]:
    used = []
    for edge in (mate_graph_json or {}).get("edges") or []:
        if not isinstance(edge, dict):
            continue
        mt = str(edge.get("mate_type") or "")
        if mt in MATE_TYPE_DEFINITIONS and mt not in used:
            used.append(mt)
    return {mt: MATE_TYPE_DEFINITIONS[mt] for mt in used}


# ============================================================
# System Prompt锛圕AD assembly decision agent锛?
# ============================================================

def build_assembly_decision_system_prompt() -> str:
    return f"""
You are a visual-geometric decision agent for CAD assembly pose reconstruction.

--------------------------------------------------
TASK:

Estimate the absolute pose of each component instance from these inputs:
- component_library: reusable component-template OBJ files referenced by mate_graph.nodes
- mate_graph.json: fixed component instances and known component-level mate constraints
- assembly.mesh.obj: target assembled mesh in the prepared assembly coordinate frame
- reference_views/color_by_component: 8 multi-view images of the target assembly

Return one output node for each component_id in mate_graph.nodes. Each output node contains component_id and pose.

--------------------------------------------------
OUTPUT FORMAT:

Return one JSON object strictly following this experiment's response_format schema.

--------------------------------------------------
POSE DEFINITION:

- pose is the absolute component pose in the prepared assembly coordinate frame
- position uses x, y, z in millimeters
- orientation uses rx, ry, rz in degrees

--------------------------------------------------
COMPONENT DEFINITIONS:

- A CAD assembly is a set of rigid component instances placed in one assembly coordinate frame.
- component_library provides reusable geometry templates.
- library_id identifies one reusable geometry template from component_library.
- mate_graph.nodes is the fixed component instance list for this experiment.
- component_id identifies the mate_graph component instance whose pose is being predicted.
- library_id is already defined in mate_graph.nodes and is attached by code after model output.
- component-level means whole component instances, not B-Rep faces, mesh triangles, mesh vertices, or OBJ indices.

--------------------------------------------------
OBJ DEFINITIONS:

- component_library/*.mesh.obj describes reusable component-template mesh geometry in the component local frame.
- assembly.mesh.obj describes the target assembled mesh geometry in the prepared assembly coordinate frame.
- In OBJ_CONTENT, `v x y z` lines define mesh vertices/points.
- In OBJ_CONTENT, `f ...` lines define polygon or triangle mesh faces.
- OBJ vertex and face indices are local mesh indices; they are not component_id, library_id, mate_id, or CAD B-Rep face IDs.

--------------------------------------------------
MATE GRAPH DEFINITIONS:

- mate_graph.json is a component-level assembly graph.
- mate_graph.nodes defines the component instances already present in the assembly.
- mate_graph.edges defines known component-level mate constraints between those instances.
- mate_type values in mate_graph.edges are input constraint labels used for pose estimation.

--------------------------------------------------
ASSEMBLY CONSTRAINTS:

- Predicted poses should form a physically plausible assembly.
- Avoid large unintended interpenetration or physically conflicting placements.
- Known mate_graph.edges, visible contacts, alignments, and reference geometry should be reflected in the predicted poses.

--------------------------------------------------
IMPORTANT:

Output JSON only.
""".strip()


def build_system_prompt() -> str:
    return build_assembly_decision_system_prompt()


# ============================================================
# Prompt锛坢ate graph + reference OBJ + color image condition锛?
# ============================================================

def build_prompt(
    *,
    assembly_id: str,
    library_json: Dict[str, Any],
    reference_views: Optional[Dict[str, str]] = None,
    reference_view_style: str = "color_by_component",
    reference_assembly_obj: Optional[Dict[str, Any]] = None,
    mate_graph_json: Optional[Dict[str, Any]] = None,
    allowed_mate_types: Optional[List[str]] = None,
    node_policy: str = "predict_subset",
) -> str:
    component_library_text = obj_file_sections(library_json)
    reference_obj_text = reference_obj_section(reference_assembly_obj)
    reference_views_text = _json_block(reference_views or {})
    mate_graph_text = _json_block(prompt_mate_graph(mate_graph_json))
    used_mate_type_text = _json_block(used_mate_type_definitions(mate_graph_json))

    return f"""
You are given a mate-graph-defined CAD assembly with color reference views and a reference assembly mesh.

--------------------------------------------------
TASK:

For each component_id in mate_graph.nodes, predict its absolute pose.

--------------------------------------------------
INPUTS:

- component_library
- mate_graph.json
- assembly.mesh.obj
- reference_views/color_by_component

--------------------------------------------------
COMPONENT_LIBRARY:

component_library provides geometry templates referenced by mate_graph.nodes.

{component_library_text}

--------------------------------------------------
MATE_GRAPH:

mate_graph.nodes defines the component instances.
mate_graph.edges provides connectivity and pose constraints.

MATE TYPE DEFINITIONS FOR INPUT CONSTRAINTS:
Definitions for mate_type values already present in mate_graph.edges:
{used_mate_type_text}

{mate_graph_text}

--------------------------------------------------
REFERENCE_ASSEMBLY_OBJ:

assembly.mesh.obj represents the target assembled geometry in the prepared assembly coordinate frame.
{reference_obj_text}

--------------------------------------------------
REFERENCE_VIEWS:

The reference views show the same target assembly from 8 camera directions at the cube corners.
Use all views together to infer 3D placement from silhouette, occlusion, contact, repeated geometry, and multi-view consistency.
Colors are synthetic component-segmentation aids only.
If several nodes share one library_id, use component_id together with mate_graph connectivity.

{reference_views_text}

--------------------------------------------------
OUTPUT:

Return nodes following the response schema.
""".strip()



# ============================================================
# Init conversation锛坅gent-style wrapper锛?
# ============================================================

def init_conversation(
    *,
    assembly_id: str,
    library_json: Dict[str, Any],
    reference_views: Optional[Dict[str, str]] = None,
    reference_view_style: str = "same_color",
    reference_assembly_obj: Optional[Dict[str, Any]] = None,
    mate_graph_json: Optional[Dict[str, Any]] = None,
    allowed_mate_types: Optional[List[str]] = None,
    node_policy: str = "predict_subset",
) -> List[Dict[str, Any]]:
    messages: List[Dict[str, Any]] = []

    messages.append({
        "role": "system",
        "content": [{
            "type": "text",
            "text": build_assembly_decision_system_prompt(),
        }],
    })

    messages.append({
        "role": "user",
        "content": [{
            "type": "text",
            "text": build_prompt(
                assembly_id=assembly_id,
                library_json=library_json,
                reference_views=reference_views,
                reference_view_style=reference_view_style,
                reference_assembly_obj=reference_assembly_obj,
                mate_graph_json=mate_graph_json,
                allowed_mate_types=allowed_mate_types,
                node_policy=node_policy,
            ),
        }],
    })

    return messages




# ============================================================
# OpenRouter / OpenAI API call锛坘ept inside this experiment file锛?
# ============================================================

def call_openrouter(
    system_prompt: str,
    prompt: str,
    image_paths: List[Path],
    model: str,
    api_key_env: str,
    temperature: float,
    response_mode: str,
    response_healing: bool,
    max_output_tokens: int = 4096,
    api_timeout_sec: float = 600.0,
) -> str:
    from openai import OpenAI

    api_key = os.getenv(api_key_env) or os.getenv("openrouter")
    if not api_key:
        raise RuntimeError(f"Missing API key environment variable: {api_key_env} or openrouter")

    client_kwargs: Dict[str, Any] = {
        "api_key": api_key,
        "base_url": "https://openrouter.ai/api/v1",
    }
    if api_timeout_sec and float(api_timeout_sec) > 0:
        client_kwargs["timeout"] = float(api_timeout_sec)
    client = OpenAI(**client_kwargs)
    messages = build_openrouter_messages(system_prompt, prompt, image_paths)
    extra_body = {"plugins": [{"id": "response-healing"}]} if response_healing else None

    kwargs: Dict[str, Any] = {
        "model": model,
        "messages": messages,
        "temperature": temperature,
    }
    if max_output_tokens and int(max_output_tokens) > 0:
        kwargs["max_tokens"] = int(max_output_tokens)
    if response_mode == "json_schema":
        kwargs["response_format"] = {
            "type": "json_schema",
            "json_schema": {
                "name": f"{EXPERIMENT_MODE}_assembly_prediction_schema",
                "strict": True,
                "schema": ASSEMBLY_PREDICTION_SCHEMA,
            },
        }
    elif response_mode == "json_object":
        kwargs["response_format"] = {"type": "json_object"}
    if extra_body is not None:
        kwargs["extra_body"] = extra_body

    response = client.chat.completions.create(**kwargs)
    return response.choices[0].message.content or ""


def call_openai(
    system_prompt: str,
    prompt: str,
    image_paths: List[Path],
    model: str,
    api_key_env: str,
    temperature: float,
    response_mode: str,
) -> str:
    from openai import OpenAI

    api_key = os.getenv(api_key_env)
    if not api_key:
        raise RuntimeError(f"Missing API key environment variable: {api_key_env}")

    client = OpenAI(api_key=api_key)
    messages = build_openrouter_messages(system_prompt, prompt, image_paths)

    if response_mode == "json_schema":
        response = client.chat.completions.create(
            model=model,
            messages=messages,
            temperature=temperature,
            response_format={
                "type": "json_schema",
                "json_schema": {
                    "name": f"{EXPERIMENT_MODE}_assembly_prediction_schema",
                    "strict": True,
                    "schema": ASSEMBLY_PREDICTION_SCHEMA,
                }
            },
        )
    elif response_mode == "json_object":
        response = client.chat.completions.create(
            model=model,
            messages=messages,
            temperature=temperature,
            response_format={"type": "json_object"},
        )
    else:
        response = client.chat.completions.create(
            model=model,
            messages=messages,
            temperature=temperature,
        )

    return response.choices[0].message.content or ""


def call_azure_openai(
    system_prompt: str,
    prompt: str,
    image_paths: List[Path],
    deployment: str,
    api_key_env: str,
    endpoint: Optional[str],
    endpoint_env: str,
    api_version: Optional[str],
    temperature: float,
    response_mode: str,
) -> str:
    from openai import AzureOpenAI

    api_key = os.getenv(api_key_env)
    endpoint_val = endpoint or os.getenv(endpoint_env)
    if not api_key:
        raise RuntimeError(f"Missing API key environment variable: {api_key_env}")
    if not endpoint_val:
        raise RuntimeError(f"Missing Azure endpoint. Use --azure-endpoint or {endpoint_env}")

    client = AzureOpenAI(
        api_key=api_key,
        azure_endpoint=endpoint_val,
        api_version=api_version or "2024-08-01-preview",
    )
    messages = build_openrouter_messages(system_prompt, prompt, image_paths)

    if response_mode == "json_schema":
        response = client.chat.completions.create(
            model=deployment,
            messages=messages,
            temperature=temperature,
            response_format={
                "type": "json_schema",
                "json_schema": {
                    "name": f"{EXPERIMENT_MODE}_assembly_prediction_schema",
                    "strict": True,
                    "schema": ASSEMBLY_PREDICTION_SCHEMA,
                }
            },
        )
    elif response_mode == "json_object":
        response = client.chat.completions.create(
            model=deployment,
            messages=messages,
            temperature=temperature,
            response_format={"type": "json_object"},
        )
    else:
        response = client.chat.completions.create(
            model=deployment,
            messages=messages,
            temperature=temperature,
        )

    return response.choices[0].message.content or ""


def call_provider(args, system_prompt: str, prompt: str, image_paths: List[Path], response_mode: str) -> str:
    if args.provider == "gemini":
        return call_gemini_openai_compatible(
            system_prompt,
            prompt,
            image_paths,
            args.model,
            args.api_key_env,
            args.temperature,
            response_mode,
            f"{EXPERIMENT_MODE}_assembly_prediction_schema",
            ASSEMBLY_PREDICTION_SCHEMA,
            args.max_output_tokens,
            args.api_timeout_sec,
        )
    if args.provider == "openrouter":
        return call_openrouter(
            system_prompt,
            prompt,
            image_paths,
            args.model,
            args.api_key_env,
            args.temperature,
            response_mode,
            args.openrouter_response_healing,
            args.max_output_tokens,
            args.api_timeout_sec,
        )
    if args.provider == "openai":
        return call_openai(
            system_prompt,
            prompt,
            image_paths,
            args.model,
            args.api_key_env,
            args.temperature,
            response_mode,
        )
    if args.provider == "azure":
        return call_azure_openai(
            system_prompt,
            prompt,
            image_paths,
            args.model,
            args.api_key_env,
            args.azure_endpoint,
            args.azure_endpoint_env,
            args.azure_api_version,
            args.temperature,
            response_mode,
        )
    raise ValueError(f"Unsupported provider: {args.provider}")


# ============================================================
# CLI entry
# ============================================================

def main() -> None:
    main_for_experiment(sys.modules[__name__])


if __name__ == "__main__":
    main()


