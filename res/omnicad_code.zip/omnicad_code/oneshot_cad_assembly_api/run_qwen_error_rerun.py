#!/usr/bin/env python
"""Rerun Qwen oneshot samples whose latest outcome is 402 or connection error."""

from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
import time
from pathlib import Path


CODE_ROOT = Path(__file__).resolve().parent
RUNNER = CODE_ROOT / "cad_assembly_run_prepared_dataset.py"
PREPARED_ROOT = Path("<PREPARED_DATASET_ROOT>")
BASE_OUT = Path("<OUTPUT_ROOT>")
DEFAULT_LIST_ROOT = BASE_OUT / "sample_lists"
PROCESS_LOG_ROOT = BASE_OUT / "process_logs"

MODEL_IDS = {
    "qwen3_5_9b": "qwen/qwen3.5-9b",
    "qwen3_7_plus": "qwen/qwen3.7-plus",
}

EXPERIMENTS = [
    "exp_zs_img",
    "exp_zs_ref_obj",
    "exp_zs_ref_img_color",
    "exp_zs_mate_graph_img",
    "exp_zs_mate_graph_ref_obj_img",
]


def sample_count(path: Path) -> int:
    if not path.exists():
        return 0
    return sum(1 for line in path.read_text(encoding="utf-8").splitlines() if line.strip())


def run_one(model_key: str, experiment: str, workers: int, list_root: Path) -> dict:
    sample_list = list_root / f"{model_key}__{experiment}.txt"
    count = sample_count(sample_list)
    if count <= 0:
        return {"model": model_key, "experiment": experiment, "sample_count": 0, "status": "empty_list"}

    run_root = BASE_OUT / model_key
    log_dir = PROCESS_LOG_ROOT / model_key
    log_dir.mkdir(parents=True, exist_ok=True)
    stdout_path = log_dir / f"{experiment}.stdout.log"
    stderr_path = log_dir / f"{experiment}.stderr.log"

    cmd = [
        sys.executable,
        str(RUNNER),
        str(PREPARED_ROOT),
        "--run-root",
        str(run_root),
        "--experiments",
        experiment,
        "--provider",
        "openrouter",
        "--model",
        MODEL_IDS[model_key],
        "--api-key-env",
        "OPENROUTER_API_KEY",
        "--response-mode",
        "json_schema",
        "--raw-obj-mode",
        "full",
        "--reference-obj-raw-mode",
        "full",
        "--max-full-prompt-chars",
        "0",
        "--max-output-tokens",
        "4096",
        "--api-timeout-sec",
        "600",
        "--max-retries",
        "3",
        "--retry-sleep-sec",
        "20",
        "--openrouter-response-healing",
        "--sample-list",
        str(sample_list),
        "--resume",
        "--keep-raw-api-run",
        "--no-auto-visualize",
        "--num-workers",
        str(workers),
    ]
    start = time.time()
    with stdout_path.open("w", encoding="utf-8") as out, stderr_path.open("w", encoding="utf-8") as err:
        proc = subprocess.run(cmd, cwd=str(CODE_ROOT), stdout=out, stderr=err, text=True)
    return {
        "model": model_key,
        "experiment": experiment,
        "sample_count": count,
        "status": "ok" if proc.returncode == 0 else "failed",
        "returncode": proc.returncode,
        "runtime_sec": round(time.time() - start, 3),
        "stdout": str(stdout_path),
        "stderr": str(stderr_path),
        "command": cmd,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--model-key", choices=sorted(MODEL_IDS), required=True)
    parser.add_argument("--workers", type=int, default=8)
    parser.add_argument("--list-root", type=Path, default=DEFAULT_LIST_ROOT)
    parser.add_argument("--summary-tag", default="")
    args = parser.parse_args()

    if not os.environ.get("OPENROUTER_API_KEY"):
        raise SystemExit("OPENROUTER_API_KEY is not set")

    BASE_OUT.mkdir(parents=True, exist_ok=True)
    PROCESS_LOG_ROOT.mkdir(parents=True, exist_ok=True)
    tag = f".{args.summary_tag}" if args.summary_tag else ""
    summary_path = PROCESS_LOG_ROOT / f"{args.model_key}{tag}.summary.jsonl"
    results = []
    for exp in EXPERIMENTS:
        result = run_one(args.model_key, exp, args.workers, args.list_root)
        results.append(result)
        with summary_path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(result, ensure_ascii=False) + "\n")
        print(json.dumps(result, ensure_ascii=False), flush=True)
    (PROCESS_LOG_ROOT / f"{args.model_key}{tag}.final_summary.json").write_text(
        json.dumps({"model": args.model_key, "results": results}, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )


if __name__ == "__main__":
    main()
